"""Newheart source-backed screeners.

The three Kiwoom formulas come from user-supplied screenshots.
The five technique screeners use only repeatedly stated lecture conditions.
Qualitative items (leader status, news cause, order-book depth, real-time popularity)
are never silently converted into invented numeric thresholds.
"""
from datetime import datetime
from statistics import mean


def _pct(a,b):
    return (a/b-1)*100 if a is not None and b else None

def _mean_close(d,n):
    return mean(x['close'] for x in d[-n:]) if len(d)>=n else None

def _rank_map(codes):
    return {str(c).zfill(6):i+1 for i,c in enumerate(codes or [])}

def _crosses(bar, level):
    return level is not None and bar['low'] <= level <= bar['high']

def _new_close_high(d, idx, n=120):
    if idx < 0: idx=len(d)+idx
    if idx < 0:return False
    start=max(0,idx-n+1); window=d[start:idx+1]
    return len(window)>=min(n,60) and d[idx]['close'] >= max(x['close'] for x in window)

def _recent_expansion(d):
    """Return a stable daily seed for the F-zone state machine.

    The F-zone reference must not be replaced just because a small recent rebound made a
    local high.  Use the highest daily high in the available 120-session window as the
    warm-up seed; the intraday state machine below is responsible for moving the reference
    lower only after an actual F-zone touch followed by a +4% rebound.
    """
    if not d:
        return None
    window=d[-120:]
    valid=[b for b in window if b.get('high') is not None]
    if not valid:
        return None
    peak_bar=max(valid,key=lambda b:float(b['high']))
    peak=float(peak_bar['high'])
    idx=d.index(peak_bar)
    p=_pct(peak,d[idx-1].get('close')) if idx>0 else 0.0
    return (p or 0.0,peak,peak_bar.get('date'))




def _norm_date(v):
    return ''.join(ch for ch in str(v or '') if ch.isdigit())[:8]

def _find_bar_index(d, day):
    target=_norm_date(day)
    if not target:return None
    for i,b in enumerate(d):
        if _norm_date(b.get('date'))==target:
            return i
    return None

def _base_from_saved(x, d, saved, saved_date, require_new_high=False):
    """Restore D+1/D+2 tracking from the saved original three screeners.

    A stock stored by 주도주 종배 / 주도주 상따 / 끼도주 종배 is already part of
    the Newheart D-day tracking pool.  Do not require an additional limit-up or manual
    base_confirmed flag here; that extra gate was the regression that hid Heart/Needle.
    """
    idx=_find_bar_index(d,saved_date)
    if idx is None or not saved:
        return False,None,idx

    tags={str(v) for v in ((saved or {}).get('tags') or [])}
    locked={'주도주 종배','주도주 상따','끼도주 종배'}
    manual=(x.get('review') or {}).get('base_confirmed') is True
    is_limit=bool((saved or {}).get('today_limit')) or (idx==len(d)-2 and bool(x.get('prev_limit')))

    if not (tags & locked or is_limit or manual):
        return False,None,idx

    # Kept only for callers that explicitly need it. Heart Zone no longer calls this
    # with require_new_high=True because the panel's own documented rule says
    # 상한가/신고가 여부 무관.
    if require_new_high and not _new_close_high(d,idx,120):
        return False,None,idx

    if is_limit:
        label='저장 원본식 · 상한가 기준봉'
    elif manual:
        label='저장 원본식 · 강한 기준봉 직접확인'
    else:
        label='저장 원본식 D-day 기준봉'
    return True,label,idx


def _base_from_yesterday(x, d, require_new_high=False):
    """Strict D-1 base confirmation."""
    if len(d) < 2:
        return False, None
    p=d[-2]
    manual=(x.get('review') or {}).get('base_confirmed') is True
    auto=bool(x.get('prev_limit'))
    if not (auto or manual):
        return False, None
    if require_new_high and not _new_close_high(d,-2,120):
        return False, None
    label=('전일 상한가 기준봉' if auto else '전일 강한 기준봉 직접확인')
    if require_new_high:
        label += ' · 120봉 최고종가'
    return True,label


def _f_active_levels(minute_bars, initial_peak=None, peak_date=None):
    """Newheart F-zone state machine.

    Rules used by the program:
    - With 3-minute bars, the active reference starts from the fetched intraday price
      structure and keeps extending upward until an F-zone pullback occurs.
    - A reset can start only after price has actually touched B1 (-8%) or deeper.
    - Track the lowest low *after* that touch.  A +4% rebound must occur on a later bar;
      an intrabar wick on the same bar never counts as a reset.
    - Once the later +4% rebound is confirmed, the active high is re-anchored and then
      extends with subsequent highs until the next valid pullback/rebound cycle.
    - When 3-minute data is absent, use the supplied daily seed only as a chart fallback.
    """
    bars=[b for b in (minute_bars or [])
          if b.get('complete',True) and all(b.get(k) is not None for k in ('open','high','low','close'))]
    if not bars:
        try:
            peak=float(initial_peak) if initial_peak not in (None,0) else None
        except (TypeError,ValueError):
            peak=None
        return {'peak':peak,'a1':peak*.95 if peak else None,
                'B1':peak*.92 if peak else None,'B2':peak*.90 if peak else None,'B3':peak*.88 if peak else None,
                'sell':None,'bottom':None,'reset_count':0,'resets':[],'timeframe':None,
                'formula_mode':'fallback','debug':{'bars':0}}

    bars=sorted(bars,key=lambda b:str(b.get('time') or ''))
    active_peak=float(bars[0]['high'])
    touched=False
    bottom=None
    touch_idx=None
    resets=[]

    for i,b in enumerate(bars):
        h=float(b['high']); lo=float(b['low'])

        if not touched:
            # Before an F-zone touch, a new high simply extends the current reference.
            if h > active_peak:
                active_peak=h
            b1=active_peak*.92
            if lo <= b1:
                touched=True
                bottom=lo
                touch_idx=i
            continue

        # Once touched, keep the lowest low.  A same-bar rebound cannot reset.
        if bottom is None or lo < bottom:
            bottom=lo
            touch_idx=i
            continue

        if i > touch_idx and h >= bottom*1.04:
            active_peak=h
            resets.append({'time':b.get('time'),'bottom':bottom,'new_peak':active_peak})
            touched=False
            bottom=None
            touch_idx=None
            continue

        # After a reset, subsequent highs are handled by the not-touched branch on later bars.

    # If the most recent valid reset happened, later bars may have extended its high.  Replay
    # from the final reset forward to capture that extension without accidentally resetting.
    if resets:
        last_t=str(resets[-1].get('time') or '')
        for b in bars:
            if str(b.get('time') or '') >= last_t:
                active_peak=max(active_peak,float(b['high']))

    return {
        'peak':active_peak,
        'a1':active_peak*.95,
        'B1':active_peak*.92,
        'B2':active_peak*.90,
        'B3':active_peak*.88,
        'sell':bottom*1.04 if bottom is not None else None,
        'bottom':bottom,
        'reset_count':len(resets),
        'resets':resets,
        'timeframe':'SOR 3분봉',
        'formula_mode':'뉴하트 F존 원수식 재현',
        'debug':{
            'bars':len(bars),
            'first_time':bars[0].get('time'),
            'last_time':bars[-1].get('time'),
            'max_fetched_high':max(float(b['high']) for b in bars),
            'bottom':bottom,
            'last_reset_time':resets[-1]['time'] if resets else None,
            'active_high_line':active_peak,
        }
    }

def _row(r, ranks):
    d=r.get('daily') or []; t=d[-1] if d else {}; p=d[-2] if len(d)>1 else {}
    c=str(r.get('code','')).zfill(6)
    dq=(ranks.get('quotes') or {}).get(c) or {}
    fq=(ranks.get('formula_quotes') or {}).get(c) or {}
    rq=(ranks.get('rank_quotes') or {}).get(c) or {}
    # 거래대금 순위는 ka10032의 실제 now_rank를 최우선으로 사용한다.
    vr=rq.get('provider_rank')
    if vr is None:
        vr=ranks['value'].get(c)
    cr=ranks['change'].get(c)

    # DISPLAY values and SEARCH-FORMULA values are intentionally separate.
    display_price=dq.get('price') if dq.get('price') not in (None,0) else r.get('price')
    display_change=dq.get('change') if dq.get('change') is not None else r.get('change')
    formula_price=fq.get('price') if fq.get('price') not in (None,0) else t.get('close')
    formula_open=fq.get('open') if fq.get('open') not in (None,0) else t.get('open')
    # SEARCH FORMULA 기준가 잠금:
    # 사용자가 차트에서 보는 [일] 1봉전 종가를 유일한 등락률 기준으로 사용한다.
    # SOR quote의 base_price / flu_rt는 화면 참고값일 뿐 검색식 PASS/FAIL에는 사용하지 않는다.
    # 따라서 장중/장후/재실행 여부와 무관하게 차트의 전일 종가 대비 현재 SOR 가격으로 계산된다.
    prev_close=p.get('close') if p.get('close') not in (None,0) else None
    computed_change=_pct(formula_price,prev_close) if formula_price is not None and prev_close else None
    formula_change=computed_change

    return {
        'code':c,'name':r.get('name'),'sector':r.get('sector') or '미분류',
        'price':display_price,'change':display_change,'display_source':dq.get('display_source',''),
        'value_eok':r.get('value_eok'),'value_rank':vr,'change_rank':cr,
        'today_limit':c in ranks['today_limit'],'prev_limit':c in ranks['prev_limit'],
        'daily':d,'m15':r.get('m15') or [],'m3':r.get('m3') or [],
        'open':formula_open,'high':t.get('high'),'low':t.get('low'),'close':formula_price,
        'formula_price':formula_price,'formula_close':formula_price,'prev_close':prev_close,
        'formula_change':formula_change,'computed_daily_change':computed_change,
        'provider_rank_change':rq.get('change'),'provider_sor_change':fq.get('change'),
        'formula_source':'차트 [일] 1봉전 종가 대비 현재 SOR 가격 직접계산 · base_price 미사용',
        'today_value':t.get('value'),'prev_value':p.get('value'),
        'review':r.get('review') or {},
    }

def _out(x, status, reasons, checks=None, levels=None, confidence='source'):
    y={k:v for k,v in x.items() if k not in ('daily','m15')}
    y.update(status=status,reasons=reasons,checks=checks or [],levels=levels or {},confidence=confidence)
    return y

def _sort_value(rows):return sorted(rows,key=lambda x:(x.get('value_rank') or 99999,-(x.get('change') or -9999),x['code']))
def _sort_change(rows):return sorted(rows,key=lambda x:(x.get('change_rank') or 99999,x.get('value_rank') or 99999,x['code']))



def _sector_tokens(v):
    s=str(v or '미분류').strip()
    for sep in ('/', '|', ';'):
        s=s.replace(sep, ',')
    out=[]
    for z in s.split(','):
        z=z.strip()
        if z and z not in out:
            out.append(z)
    return out or ['미분류']

def _close_position(x):
    lo=x.get('low'); hi=x.get('high'); cl=x.get('formula_close')
    try:
        lo=float(lo); hi=float(hi); cl=float(cl)
    except (TypeError,ValueError):
        return None
    if hi<=lo:return 1.0 if cl>=hi else 0.5
    return max(0.0,min(1.0,(cl-lo)/(hi-lo)))

def _strong_sector_panel(jd, dayleader, kk):
    """Summarize breadth/leadership only inside the three locked scanner results."""
    rows={}; tags={}
    for name,items in [('주도주 종배',jd),('주도주 상따',dayleader),('끼도주 종배',kk)]:
        for r in items:
            c=r['code']; rows[c]=r; tags.setdefault(c,set()).add(name)
    groups={}
    for c,r in rows.items():
        for sec in _sector_tokens(r.get('sector')):
            if sec=='미분류': continue
            groups.setdefault(sec,[]).append(r)
    out=[]
    for sec,members in groups.items():
        members=sorted(members,key=lambda r:(r.get('value_rank') or 99999,r['code']))
        leader=members[0]
        value_sum=sum(float(r.get('value_eok') or 0) for r in members)
        overlaps=sum(len(tags.get(r['code'],())) for r in members)
        out.append({
            'code':'SECTOR:'+sec,'name':sec,'sector':sec,'price':None,'change':None,
            'value_eok':value_sum,'value_rank':leader.get('value_rank'),'change_rank':None,
            'status':f'{len(members)}종목 동반','confidence':'litto-sector-helper',
            'reasons':[f'원본 3식 합집합에서 {len(members)}종목 동반',
                       f'섹터 거래대금 합계 {value_sum:,.0f}억원',
                       f"섹터 선두 {leader.get('name')} · 통합 거래대금 {leader.get('value_rank') or '-'}위",
                       f'검색식 중복 통과 합계 {overlaps}회'],
            'checks':['테마성 연관 여부와 실제 대장성은 사용자 섹터/뉴스로 최종 확인'],
            'levels':{'leader_code':leader.get('code'),'leader_name':leader.get('name'),'breadth':len(members),
                      'members':[{'code':r['code'],'name':r.get('name'),'value_rank':r.get('value_rank')} for r in members]}
        })
    return sorted(out,key=lambda r:(-(r['levels']['breadth']),-float(r.get('value_eok') or 0),r.get('value_rank') or 99999,r['name']))

def _close_priority_panel(jd, dayleader, kk):
    """Rank only stocks already selected by the three locked user formulas.

    This is deliberately a comparative helper, not a fourth entry formula. It does
    not alter membership in any locked scanner. User-confirmed ranking rule:
    same-sector breadth first -> higher rise rate inside that breadth -> trading
    value rank as the tie-breaker. Formula overlap is shown only as information.
    """
    tags={}
    rows={}
    for name,items in [('주도주 종배',jd),('주도주 상따',dayleader),('끼도주 종배',kk)]:
        for r in items:
            c=r['code']; rows[c]=r; tags.setdefault(c,[]).append(name)
    if not rows:return []
    sector_members={}
    for c,r in rows.items():
        for sec in _sector_tokens(r.get('sector')):
            if sec!='미분류':sector_members.setdefault(sec,set()).add(c)
    sector_best={}
    for sec,members in sector_members.items():
        ranked=[(rows[c].get('value_rank') or 99999,c) for c in members]
        sector_best[sec]=min(ranked)[1] if ranked else None
    ranked_rows=[]
    for c,r in rows.items():
        secs=[z for z in _sector_tokens(r.get('sector')) if z!='미분류']
        breadth=max([len(sector_members.get(z,set())) for z in secs] or [1])
        is_sector_leader=any(sector_best.get(z)==c and len(sector_members.get(z,set()))>=2 for z in secs)
        overlap=len(tags.get(c,[]))
        cp=_close_position(r)
        # User rule: first prefer the sector with more simultaneous scanner hits,
        # then rank stocks in that sector by the higher integrated rise rate.
        # Trading-value rank is only a tie-breaker.
        change=float(r.get('change') or 0)
        key=(-breadth,-change,r.get('value_rank') or 99999,r.get('change_rank') or 99999,c)
        ranked_rows.append((key,r,breadth,is_sector_leader,cp))
    ranked_rows.sort(key=lambda z:z[0])
    out=[]
    for idx,(_,r,breadth,is_sector_leader,cp) in enumerate(ranked_rows,1):
        reasons=[f"동일 섹터 후보 {breadth}종목", f"통합 상승률 {float(r.get('change') or 0):+.2f}%"]
        reasons.append(f"원본 검색식 {len(tags[r['code']])}개 동시 통과: {', '.join(tags[r['code']])}")
        if r.get('value_rank') is not None:reasons.append(f"통합 거래대금 {r['value_rank']}위 (동률 보조)")
        if cp is not None:reasons.append(f"0봉 종가 위치: 당일 저가→고가 범위의 {cp*100:.0f}%")
        out.append(_out(r,f"종배 우선 {idx}순위",reasons,[
            '정렬: 동일 섹터 검색 종목 수 많은 순 → 같은 섹터 안에서 상승률 높은 순 → 거래대금 순위',
            '이 순위는 원본 3개 검색식의 결과를 바꾸지 않는 비교용 보조정렬',
            '뉴스·호가창·실시간 조회 대장성은 최종 확인 필요'
        ],confidence='litto-ranking-helper'))
    return out

def build(report, rank_data=None):
    rank_data=rank_data or {}
    provider_value_ranks={}
    for c,v in (rank_data.get('value_rank_map') or {}).items():
        try:
            provider_value_ranks[str(c).zfill(6)]=int(float(v))
        except (TypeError,ValueError):
            pass
    ranks={
        'value':provider_value_ranks or _rank_map(rank_data.get('value_top')),
        'change':_rank_map(rank_data.get('change_top')),
        'today_limit':set(rank_data.get('today_limit') or []),
        'prev_limit':set(rank_data.get('prev_limit') or []),
        'quotes':rank_data.get('quotes') or {},
        'formula_quotes':rank_data.get('formula_quotes') or {},
        'rank_quotes':rank_data.get('rank_quotes') or {},
    }
    base=[_row(r,ranks) for r in (report or {}).get('results',[])]
    asof=datetime.fromisoformat((report or {}).get('asof','').replace('Z','+00:00')) if (report or {}).get('asof') else None
    hhmm=(asof.hour*60+asof.minute) if asof else 0

    # 1) User screenshots: exact formulas.
    # 거래대금 원순위 상한은 패널별로 사용자가 직접 조정할 수 있다.
    raw_limits=(rank_data.get('formula_rank_limits') or {}) if isinstance(rank_data,dict) else {}
    def _rank_limit(key, default=30):
        try:
            return max(1,min(50,int(raw_limits.get(key,default))))
        except (TypeError,ValueError):
            return default
    jd_limit=_rank_limit('주도주 종배')
    dayleader_limit=_rank_limit('주도주 상따')
    kki_limit=_rank_limit('끼도주 종배')
    jd=[]; dayleader=[]; kk=[]; diagnostics=[]
    for x in base:
        d=x['daily']
        if len(d)<2:continue
        A_jd=x['value_rank'] is not None and x['value_rank']<=jd_limit
        A_dayleader=x['value_rank'] is not None and x['value_rank']<=dayleader_limit
        A_kki=x['value_rank'] is not None and x['value_rank']<=kki_limit
        # LOCKED USER FORMULAS: do not substitute ka10032 flu_rt for daily-bar math.
        # 주도주 종배 screenshot = [일] 1봉전 종가 대비 0봉전 종가등락률 >= +1%.
        B1=(x['formula_change'] is not None and x['formula_change']>=1.0)
        # 주도주 상따 screenshot = [일] 0봉전 시가 <= 0봉전 종가.
        B2=x['open'] is not None and x['formula_close'] is not None and x['open']<=x['formula_close']
        C=x['change_rank'] is not None and x['change_rank']<=100
        # 끼도주 종배: [일] 0봉전 종가가 최근 120봉 최고종가.
        # 신규상장 종목은 120봉이 아직 존재하지 않으므로, 보유한 상장 이후 전체
        # 일봉(최대 120봉) 안에서 최고종가인지 판정한다. 120봉 미만이라는 이유만으로
        # 자동 FAIL 처리하지 않는다.
        available_prior=[]
        for z in d[-120:-1]:
            try:
                v=float(z.get('close'))
            except (TypeError,ValueError):
                continue
            if v>0:
                available_prior.append(v)
        current_close=x.get('formula_close')
        D=(current_close is not None and
           (not available_prior or float(current_close)>=max(available_prior)))
        high_window_label=('최근 120봉' if len(d)>=120 else f'상장 이후 {len(d)}봉')
        pass_names=[]
        if A_jd and B1: pass_names.append('주도주 종배')
        if A_dayleader and B2 and C: pass_names.append('주도주 상따')
        if A_kki and B2 and C and D: pass_names.append('끼도주 종배')
        diagnostics.append(_out(x,(' / '.join(pass_names) if pass_names else '3개식 미충족'),[
            f"통합 거래대금 원순위 {x['value_rank'] or '-'}위 · 기준(종배/상따/끼도주) {jd_limit}/{dayleader_limit}/{kki_limit}위",
            f"SOR 현재가 {x['formula_price']:,.0f}" if x.get('formula_price') is not None else 'SOR 현재가 없음',
            f"1봉전 종가 {x['prev_close']:,.0f}" if x.get('prev_close') is not None else '1봉전 종가 없음',
            f"1봉전 종가 대비 0봉전 종가등락률 {x['formula_change']:+.2f}% → {'PASS' if B1 else 'FAIL'}" if x.get('formula_change') is not None else '통합 판정등락률 없음',
            f"참고: 일봉 재계산 {x['computed_daily_change']:+.2f}% / SOR quote {x['provider_sor_change']:+.2f}%" if x.get('computed_daily_change') is not None and x.get('provider_sor_change') is not None else '참고 계산값 일부 없음',
            f"0봉 시가 {x['open']:,.0f} ≤ 현재가 {x['formula_price']:,.0f} → {'PASS' if B2 else 'FAIL'}" if x.get('open') is not None and x.get('formula_price') is not None else '0봉 시가 비교불가',
            f"통합 등락률순위 {x['change_rank'] or '-'}위 → {'PASS' if C else 'FAIL'}",
            f"{high_window_label} 최고종가 → {'PASS' if D else 'FAIL'}",
            f"화면표시 {x.get('display_source') or '-'}: {x['price']:,.0f} / {x['change']:+.2f}%" if x.get('price') is not None and x.get('change') is not None else '화면표시 시세 없음'
        ],confidence='diagnostic'))
        if A_jd and B1:
            jd.append(_out(x,'조건충족',[
                f'통합 거래대금 원순위 상위 {jd_limit}',
                f"[일] 1봉전 종가 대비 0봉전 종가등락률 {x['formula_change']:+.2f}% ≥ +1%"],confidence='user-formula-locked'))
        if A_dayleader and B2 and C:
            dayleader.append(_out(x,'조건충족',[
                f'통합 거래대금 원순위 상위 {dayleader_limit}',
                '[일] 0봉전 시가 ≤ 0봉전 종가',
                '통합 전일대비 등락률 순위 상위 100'],confidence='user-formula-locked'))
        if A_kki and B2 and C and D:
            kk.append(_out(x,'조건충족',[
                f'통합 거래대금 원순위 상위 {kki_limit}',
                '[일] 0봉전 시가 ≤ 0봉전 종가',
                '통합 전일대비 등락률 순위 상위 100',
                f'[일] 0봉전 종가 = {high_window_label} 최고종가'],confidence='user-formula-locked'))

    # D-day search results become the NEXT session's technique universe.
    # Do not use today's 3-formula hits directly for Heart/Needle/F-zone.
    current_source_tags={}
    for panel_name, rows in [('주도주 종배',jd),('주도주 상따',dayleader),('끼도주 종배',kk)]:
        for row in rows:
            current_source_tags.setdefault(row['code'],[]).append(panel_name)

    close_priority=_close_priority_panel(jd,dayleader,kk)
    strong_sectors=_strong_sector_panel(jd,dayleader,kk)

    # D+1/D+2 tracking: use the two most recent saved scanner sessions.
    # If the same stock appears in both, the newer D+1 setup supersedes the older D+2 setup.
    snapshots=rank_data.get('prior_candidate_snapshots') or []
    if not snapshots:
        one=rank_data.get('prior_candidates') or {'date':None,'stocks':{}}
        if one.get('date'): snapshots=[{'date':one.get('date'),'stage':'D+1','stocks':one.get('stocks') or {}}]
    tracking={}
    for snap in snapshots:
        stage=snap.get('stage') or 'D+1'
        for c,rec in (snap.get('stocks') or {}).items():
            if c not in tracking:
                tracking[c]={'stage':stage,'date':snap.get('date'),'rec':rec or {}}
    technique_codes=set(tracking)

    prior_rows=[]
    for x in base:
        tr=tracking.get(x['code'])
        if not tr: continue
        d=x['daily']; saved=tr['rec']; stage=tr['stage']; saved_date=tr['date']
        idx=_find_bar_index(d,saved_date)
        p=d[idx] if idx is not None else {}
        base_ok,base_label,_=_base_from_saved(x,d,saved,saved_date,require_new_high=False)
        tags=list(saved.get('tags') or [])
        prior_rows.append(_out(x,(f'{stage} 기준봉 확인' if base_ok else f'{stage} 추적'),[
            f"기준 후보 저장일 {saved_date or '-'} · {stage}",
            '원본식: '+(', '.join(tags) if tags else '-'),
            (f"기준봉 자동확인: {base_label}" if base_ok else '저장 후보 · 기준봉 질은 차트에서 확인')
        ],['상한가 여부와 관계없이 저장된 원본 3식 전일후보를 D+1/D+2로 추적'],
        {'기준봉일':p.get('date'),'기준봉고가':p.get('high'),'기준봉종가':p.get('close'),'추적단계':stage} if p else {'추적단계':stage},
        confidence='d1-d2-tracking'))

    # 3) 피뢰침: saved D-day base -> current D+1 or D+2 expansion/drop/value increase.
    needle=[]
    for x in base:
        tr=tracking.get(x['code'])
        if not tr:continue
        d=x['daily']; t=d[-1] if d else {}
        saved=tr['rec']; stage=tr['stage']; saved_date=tr['date']
        base_ok,base_label,idx=_base_from_saved(x,d,saved,saved_date,require_new_high=False)
        if not base_ok or idx is None:continue
        p=d[idx]
        expansion=_pct(t.get('high'),p.get('close'))
        retreat=(1-x['close']/t['high'])*100 if t.get('high') else None
        money=t.get('value') is not None and p.get('value') is not None and t['value']>p['value']
        if expansion is not None and expansion>=10 and retreat is not None and retreat>=10 and money:
            needle.append(_out(x,f'피뢰침 {stage} 후보',[
                (('전일 원본식: ' if stage=='D+1' else f'{stage} 원본식: ')+', '.join(saved.get('tags') or [])),
                f"기준봉 {p.get('date')} · {base_label}",
                f'오늘 고가 시세발산 +{expansion:.1f}%',
                f'오늘 고가 대비 현재가 낙폭 -{retreat:.1f}%',
                '오늘 거래대금 > 기준봉 거래대금'],
                ['주도주/대장 여부·종목 고유 악재·호가/실시간 관심은 직접 확인'],
                {'기준봉일':p.get('date'),'기준봉고가':p.get('high'),'기준봉종가':p.get('close'),'추적단계':stage},confidence='lecture-strict-d1-d2'))

    needle_codes={x['code'] for x in needle}

    # 4) 하트존: saved D-day base -> current D+1 or D+2 low-volume first support.
    heart=[]
    for x in base:
        tr=tracking.get(x['code'])
        if not tr or x['code'] in needle_codes:continue
        d=x['daily']; t=d[-1] if d else {}
        saved=tr['rec']; stage=tr['stage']; saved_date=tr['date']
        base_ok,base_label,idx=_base_from_saved(x,d,saved,saved_date,require_new_high=False)
        if not base_ok or idx is None:continue
        p=d[idx]
        exp=_pct(t.get('high'),p.get('close'))
        close_chg=_pct(x.get('close'),p.get('close'))
        money_down=t.get('value') is not None and p.get('value') is not None and t['value']<p['value']
        ma3=_mean_close(d,3);ma5=_mean_close(d,5)
        touch3=_crosses(t,ma3);touch5=_crosses(t,ma5)
        # User rule: Heart-zone close/current price must be less than +2% vs the saved D-day close.
        # This replaces the prior broad "intraday expansion <10%" admission rule.
        close_under_2=close_chg is not None and close_chg<2
        # User rule: Heart-zone current price must remain at/above the 50% level
        # of the saved D-day candle range (low + 50% of high-low).
        ph=p.get('high'); pl=p.get('low')
        half_level=(pl + (ph-pl)*0.5) if ph is not None and pl is not None else None
        above_half=(half_level is not None and x.get('close') is not None and x['close']>=half_level)
        if money_down and close_under_2 and (touch3 or touch5) and above_half:
            ratio=(t['value']/p['value']*100) if p.get('value') else None
            heart.append(_out(x,f'하트존 {stage} 후보',[
                (('전일 원본식: ' if stage=='D+1' else f'{stage} 원본식: ')+', '.join(saved.get('tags') or [])),
                f"기준봉 {p.get('date')} · {base_label}",
                f'현재가/종가 기준봉 종가 대비 {close_chg:+.1f}% (<+2%)',
                f"오늘 거래대금 감소 ({ratio:.0f}% 수준)" if ratio is not None else '오늘 거래대금 감소',
                f"기준봉 50%선 {half_level:,.0f} 이상 유지 (현재 {x['close']:,.0f})",
                ('3일선 첫 지지 후보' if touch3 else '')+(' + ' if touch3 and touch5 else '')+('5일선 첫 지지 후보' if touch5 else '')],
                ['15분봉 60/120선 지지·0.618선·주포 잔존은 직접 확인'],
                {'기준봉일':p.get('date'),'기준봉고가':p.get('high'),'기준봉저가':p.get('low'),'기준봉종가':p.get('close'),'기준봉50%':half_level,'MA3':ma3,'MA5':ma5,'추적단계':stage},confidence='lecture-strict-d1-d2'))

    # 5) 오늘의 상한가: user-adjustable observation list.
    # The trading-value floor is user selectable in 100억원 steps.
    try:
        today_limit_min_eok=int((rank_data or {}).get('today_limit_min_eok',1000))
    except (TypeError,ValueError):
        today_limit_min_eok=1000
    today_limit_min_eok=max(100,min(10000,(today_limit_min_eok//100)*100))
    today_limit_min_value=today_limit_min_eok*100_000_000
    today_upper=[]
    for x in base:
        if not x['today_limit']:
            continue
        today_value=x.get('today_value')
        if today_value is not None and today_value>=today_limit_min_value:
            today_upper.append(_out(x,'오늘의 상한가',[
                '오늘 상한가 목록 포함',
                f'오늘 거래대금 {today_value/1e8:,.0f}억원 ≥ {today_limit_min_eok:,}억원'
            ],confidence='user-adjustable-watch-rule'))

    # 6) 약상매매 후보: user-defined pre-screen only.
    # Exact candidate rule: previous session closed at limit-up AND previous-session
    # trading value >= 100 billion KRW (1,000억원). No opening-gap/news/entry rule here.
    yak=[]
    for x in base:
        d=x['daily']
        if len(d)<2 or not x['prev_limit']:
            continue
        prev_value=x.get('prev_value')
        if prev_value is not None and prev_value>=100_000_000_000:
            yak.append(_out(x,'약상매매 후보',[
                '전 거래일 상한가 마감',
                f'전 거래일 거래대금 {prev_value/1e8:,.0f}억원 ≥ 1,000억원'
            ],confidence='user-exact-candidate-rule'))

    # 7) F존: chart profile is available for every loaded stock, while the alert
    # panel itself only uses saved D+1/D+2 candidates.  This keeps the chart overlay
    # useful without turning F-zone into a fourth same-day entry formula.
    fzone=[]
    fzone_profiles={}
    heart_codes={r['code'] for r in heart}
    for x in base:
        d=x.get('daily') or []
        if not d:
            continue
        exp=_recent_expansion(d)
        if not exp:
            continue
        expansion_pct, daily_peak, peak_date=exp
        intraday=x.get('m3') or x.get('m15') or []
        lv=_f_active_levels(intraday,daily_peak,peak_date)
        if not lv.get('peak'):
            continue
        lv['reset_timeframe']=lv.get('timeframe')
        tr=tracking.get(x['code'])
        other_setup=('피뢰침' if x['code'] in needle_codes else ('하트존' if x['code'] in heart_codes else None))
        source_reason=((('전일 원본식: ' if (tr and (tr.get('stage') or 'D+1')=='D+1') else f"{(tr or {}).get('stage') or 'D+1'} 원본식: ")
                       + ', '.join(((tr or {}).get('rec') or {}).get('tags') or [])) if tr else '차트 참고용 F존')
        prof={
            'code':x['code'],'name':x.get('name'),'sector':x.get('sector'),'price':x.get('price'),
            'change':x.get('change'),'value_eok':x.get('value_eok'),'value_rank':x.get('value_rank'),
            'status':'F존 적용 가능','reasons':[
                source_reason,
                f"활성 기준고점 {lv['peak']:,.0f}",
                f"B1 {lv['B1']:,.0f} / B2 {lv['B2']:,.0f} / B3 {lv['B3']:,.0f}",
                ('3분봉 +4% 반등 재설정 적용' if x.get('m3') else ('15분봉 대체 계산' if x.get('m15') else '일봉 기준 참고선'))
            ],
            'checks':['F존은 매수 신호가 아니라 눌림 구간 알림/참고선'],
            'levels':lv,'confidence':'newheart-fzone','chart_only':not bool(tr),
            'other_setup':other_setup,
        }
        if tr:
            prof['tracking_stage']=tr.get('stage')
            prof['tracking_date']=tr.get('date')
        fzone_profiles[x['code']]=prof

        # F-zone panel/card count is an ENTRY alert only.
        # Keep profiles for chart reference lines, but do not count/show a stock
        # until the current price is actually inside B1~B3.
        if not tr:
            continue
        price=x.get('close') if x.get('close') is not None else x.get('price')
        b1=lv.get('B1'); b3=lv.get('B3')
        if price is None or b1 is None or b3 is None:
            continue
        inside=(b3 <= price <= b1)
        if not inside:
            continue
        stage=tr.get('stage') or 'D+1'
        origin=f"전일 후보 {tr.get('date') or '-'} · {stage}"
        setup_note=(f" · 현재 {other_setup} 구조도 포착" if other_setup else '')
        fzone.append(_out(x,f'F존 {stage} 진입',[
            origin,
            f"현재가 {price:,.0f} · F존 진입중 (B1 {b1:,.0f} ~ B3 {b3:,.0f})",
            f"활성 기준고점 {lv['peak']:,.0f}{setup_note}",
            f"반등 재설정 {lv.get('reset_count',0)}회 · {lv.get('formula_mode') or '-'}"
        ],['현재가가 B1~B3 안에 실제 진입한 종목만 F존 카드/목록에 표시'],lv,confidence='newheart-fzone-entry'))

    panels={
        '주도주 종배':{'rows':_sort_value(jd),'kind':'사용자 원본식 · 거래대금 순위 사용자 조정','rule':f'통합 거래대금 원순위 상위{jd_limit} 내 일반주 AND [일]1봉전 종가 대비 0봉전 종가등락률 +1% 이상'},
        '주도주 상따':{'rows':_sort_value(dayleader),'kind':'사용자 원본식 · 거래대금 순위 사용자 조정','rule':f'통합 거래대금 원순위 상위{dayleader_limit} 내 일반주 AND [일]0봉 시가≤0봉 종가 AND 통합 등락률 상위100'},
        '끼도주 종배':{'rows':_sort_value(kk),'kind':'사용자 원본식 잠금','rule':'주도주 상따식 + [일]0봉전 종가가 최근 120봉 최고종가 (상장 120봉 미만은 상장 이후 전체)'},
        '종배 우선순위':{'rows':close_priority,'kind':'LITTO 비교 보조판','rule':'원본 3식 합집합 안에서만 비교: 동일 섹터 동반 종목 수 많은 순 → 같은 섹터 안에서 통합 상승률 높은 순 → 거래대금 순위(동률 보조). 원본 검색식 판정에는 영향 없음'},
        '강한 섹터':{'rows':strong_sectors,'kind':'LITTO 섹터 보조판','rule':'원본 3식 합집합을 사용자/자동 섹터로 묶어 동반 종목수 → 섹터 거래대금 → 섹터 선두를 표시. 검색식 판정에는 영향 없음'},
        '검색 진단':{'rows':_sort_value(diagnostics),'kind':'검증 전용','rule':f'거래대금 순위 사용자 기준 종배 {jd_limit} / 상따 {dayleader_limit} / 끼도주 {kki_limit}위 · 각 식 입력값/PASS/FAIL 표시'},
        '전일 후보':{'rows':_sort_value(prior_rows),'kind':'D+1/D+2 추적 저장소','rule':'최근 2개 저장 거래일의 원본 3식 합집합을 D+1/D+2로 추적 → 피뢰침·하트존 분석'},
        '피뢰침':{'rows':_sort_value(needle),'kind':'원본 3식 전일후보 · D+1/D+2','rule':'전일 저장 [주도주 종배 ∪ 주도주 상따 ∪ 끼도주 종배] 전 종목 → 상한가 여부 무관 → 오늘 약10% 시세발산 + 고가 대비 약10% 낙폭 + 거래대금 증가'},
        '하트존':{'rows':_sort_value(heart),'kind':'원본 3식 전일후보 · D+1/D+2','rule':'전일 저장 [주도주 종배 ∪ 주도주 상따 ∪ 끼도주 종배] 전 종목 → 상한가/신고가 여부 무관 → 현재가/종가가 기준봉 종가 대비 +2% 미만 + 거래대금 감소 + 3/5일선 첫 지지 + 기준봉 고저폭 50%선 이상 유지'},
        'F존':{'rows':_sort_value(fzone),'kind':'F존 실제 진입 · D+1/D+2','rule':'전일 저장 후보 중 현재가가 활성 기준고점 대비 B1(-8%)~B3(-12%) 구간에 실제 들어온 종목만 표시. 차트 참고선은 별도 유지. 3분봉에서 F존 터치 후 저점 대비 +4% 반등이 다음 봉에서 확인되면 기준고점 재설정'},
        '오늘의 상한가':{'rows':_sort_value(today_upper),'kind':'사용자 조정 관찰식','rule':f'오늘 상한가 목록 AND 오늘 거래대금 {today_limit_min_eok:,}억원 이상'},
        '약상매매 후보':{'rows':_sort_value(yak),'kind':'사용자 확정 후보식','rule':'전 거래일 상한가 마감 AND 전 거래일 거래대금 1,000억원 이상'},
    }
    return {'panels':panels,'fzone_profiles':fzone_profiles,
            'rank_source':rank_data.get('source',''),'asof':(report or {}).get('asof'),
            'notice':f"원본 3식은 그대로 잠금. 오늘 검색 결과는 {((report or {}).get('asof') or '')[:10]} 후보로 저장되고, 최근 2개 저장 거래일 후보를 각각 D+1/D+2로 강제 재조회해 피뢰침·하트존·F존을 추적합니다. D+3부터는 자동 추적하지 않습니다."}
