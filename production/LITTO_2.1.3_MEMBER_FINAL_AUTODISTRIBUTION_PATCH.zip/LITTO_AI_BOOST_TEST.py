"""Offline safety smoke test; does not use Kiwoom or place orders."""
import ast
from pathlib import Path
root=Path(__file__).resolve().parent
src=(root/'app.py').read_text('utf-8')
tree=ast.parse(src)
fn=next(n for n in tree.body if isinstance(n,ast.FunctionDef) and n.name=='_ai_dev_requested')
mod=ast.Module(body=[fn],type_ignores=[])
ns={};exec(compile(mod,'<classifier-test>','exec'),ns)
f=ns['_ai_dev_requested']
cases={
    '라이또야 관심종목 퍼센트 오류 고쳐줘':True,
    '라이또 프로그램의 소스코드를 확인해줘. 수정하지 마':True,
    '라이또 오류 수정하지 마':False,
    '라이또야 3분봉 느린 거 고쳐줘':True,
    '라이또 오류 원인 분석해':True,
    '오늘 종목 분석해줘':False,
    '내일 날씨 알려줘':False,
    '라이또 패치하지 마':False,
}
for prompt,expected in cases.items():
    actual=f(prompt)
    assert actual is expected,(prompt,actual,expected)
import litto_ai_live_patch
result=litto_ai_live_patch.install({},(root/'app.py').read_bytes())
assert result['hot_reloaded'] is True
print('PASS: 8 intent cases; hot-install smoke check; syntax AST')
