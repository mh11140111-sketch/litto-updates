"""Read-only market diagnostics. Does not change LITTO screening decisions."""
from pathlib import Path
from datetime import datetime, timezone, timedelta
import hashlib
import json
import os
import runpy
import sys
import threading
import zipfile

ROOT = Path(__file__).resolve().parent
KST = timezone(timedelta(hours=9))
LOCK = threading.RLock()
FIELDS = {
    'ka10032': ('trde_prica_upper', ('stk_cd','stk_nm','now_rank','pred_rank','cur_prc','flu_rt','trde_prica','pred_pre')),
    'ka10001': (None, ('stk_cd','stk_nm','cur_prc','flu_rt','pred_pre','base_pric','open_pric','high_pric','low_pric')),
    'ka10081': ('stk_dt_pole_chart_qry', ('dt','cur_prc','open_pric','high_pric','low_pric','trde_qty','trde_prica','pred_pre')),
}

def stamp():
    return datetime.now(KST).isoformat()

def pick(obj, names):
    return {k: obj[k] for k in names if k in obj}

class Recorder:
    def __init__(self, root):
        self.root = Path(root)
        self.folder = self.root / 'data' / 'litto_diagnostics' / datetime.now(KST).strftime('%Y%m%d_%H%M%S_%f')
        self.folder.mkdir(parents=True, exist_ok=False)
        hashes = {n: hashlib.sha256((self.root/n).read_bytes()).hexdigest() for n in ('app.py','kiwoom.py','search_panels.py','engine.py','yaksang.py') if (self.root/n).exists()}
        self.write('session', {'source_sha256': hashes, 'note': 'Original logic unchanged. Synthetic tests are not live-market verification.'})
        self.scan = 0

    def write(self, kind, payload):
        with LOCK:
            with (self.folder/'evidence.jsonl').open('a', encoding='utf-8') as f:
                f.write(json.dumps({'recorded_at':stamp(),'kind':kind,**payload},ensure_ascii=False,allow_nan=False)+'\n')

    def capture(self, api, body, headers, data, rh, start):
        key, fields = FIELDS[api]
        response = [pick(r, fields) for r in data.get(key, [])] if key else pick(data, fields)
        self.write('market_response', {
            'api':api, 'started_at':start,'finished_at':stamp(),
            'request':pick(body, ('mrkt_tp','mang_stk_incls','stex_tp','stk_cd','base_dt','upd_stkpc_tp')),
            'request_page':pick(headers, ('cont-yn','next-key')),
            'response_page':pick(rh, ('cont-yn','next-key')),
            'return_code':data.get('return_code'), 'response':response})

    def result(self, report, ranks, result):
        self.scan += 1
        selected = ('code','name','value_rank','formula_price','formula_close','prev_close','formula_change','provider_rank_change','provider_sor_change','status','reasons','display_source','price','change')
        panels = {k:[pick(r,selected) for r in v.get('rows',[])] for k,v in result.get('panels',{}).items() if k in ('주도주 종배','주도주 상따','끼도주 종배')}
        rankrows = {}
        for c,r in (ranks.get('rank_quotes') or {}).items():
            rankrows[c] = pick(r,('provider_rank','price','change','source','name'))
        self.write('scan_result', {'scan':self.scan,'asof':report.get('asof'),'mode':report.get('mode'),
            'value_top':ranks.get('value_top',[]),'provider_ranks':rankrows,'panels':panels,
            'daily_dates':{r['code']:[b.get('date') for b in r.get('daily',[])[-2:]] for r in report.get('results',[])}})
        with LOCK:
            target=self.root/'LITTO_DIAGNOSTIC_RESULT.zip'
            temp=target.with_suffix('.tmp')
            with zipfile.ZipFile(temp,'w',zipfile.ZIP_DEFLATED) as z:
                z.write(self.folder/'evidence.jsonl','evidence.jsonl')
            os.replace(temp,target)
        print('[LITTO diagnostic] Saved LITTO_DIAGNOSTIC_RESULT.zip', flush=True)

def install(recorder):
    import kiwoom
    import search_panels
    original_post = kiwoom.Kiwoom._post
    original_build = search_panels.build
    def post(self,path,body,headers=None):
        api=(headers or {}).get('api-id')
        start=stamp()
        result=original_post(self,path,body,headers)
        if api in FIELDS:
            try:recorder.capture(api,body,headers or {},result[0],result[1],start)
            except Exception as e:print('[LITTO diagnostic] Recording failed:',type(e).__name__,flush=True)
        return result
    def build(report,rank_data=None):
        result=original_build(report,rank_data)
        if (rank_data or {}).get('rank_quotes'):
            try:recorder.result(report,rank_data,result)
            except Exception as e:print('[LITTO diagnostic] Export failed:',type(e).__name__,flush=True)
        return result
    kiwoom.Kiwoom._post=post
    search_panels.build=build

def main():
    os.chdir(ROOT)
    if not all((ROOT/n).is_file() for n in ('app.py','kiwoom.py','search_panels.py')):
        raise SystemExit('Place these add-on files in the existing LITTO folder beside app.py.')
    recorder=Recorder(ROOT)
    install(recorder)
    print('LITTO diagnostic: original screening logic unchanged.',flush=True)
    sys.argv=[str(ROOT/'app.py'),*sys.argv[1:]]
    runpy.run_path(str(ROOT/'app.py'),run_name='__main__')

if __name__=='__main__':main()
