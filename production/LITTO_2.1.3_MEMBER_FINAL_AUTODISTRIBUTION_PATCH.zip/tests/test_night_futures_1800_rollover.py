import json
import unittest
from datetime import datetime, timedelta
from unittest.mock import patch
from zoneinfo import ZoneInfo

from night_futures import NightFuturesFeed, KST, OPENING_TS_URL, CLOSING_TS_URL, CACHE_MTIME_URL, CACHE_URL


class Night1800Tests(unittest.TestCase):
    def setUp(self):
        self.feed = NightFuturesFeed()
        self.day = datetime(2026, 10, 14, 18, 0, tzinfo=KST).timestamp()
        self.feed._state.update(opening_ts=int(self.day - 86400), closing_ts=int(self.day - 43200), price=333.0)
        self.feed._points.append({'t': int(self.day - 80000), 'p': 333.0})

    def test_previous_close_preserved_before_1800(self):
        with patch('night_futures.time.time', return_value=self.day - 1):
            def fetch(_opener, url, **kw):
                if OPENING_TS_URL in url: return str(int(self.day))
                if CLOSING_TS_URL in url: return str(int(self.day + 43200))
                if CACHE_MTIME_URL in url: return str(int(self.day))
                raise AssertionError('Future cache must not replace previous chart before 18:00')
            self.feed._open_text = fetch
            self.feed._load_cache(None)
        self.assertEqual(self.feed._state['price'], 333.0)
        self.assertEqual(len(self.feed._points), 1)

    def test_refresh_at_1800_and_retry_at_15_seconds(self):
        self.feed._load_cache = lambda _: None
        with patch('night_futures.time.time', return_value=self.day + 1):
            self.assertTrue(self.feed._refresh_session_cache_if_due(None))
            self.assertFalse(self.feed._refresh_session_cache_if_due(None))
        with patch('night_futures.time.time', return_value=self.day + 17):
            self.assertTrue(self.feed._refresh_session_cache_if_due(None))

    def test_new_session_clears_old_points(self):
        def fetch(_opener, url, **kw):
            if OPENING_TS_URL in url: return str(int(self.day))
            if CLOSING_TS_URL in url: return str(int(self.day + 43200))
            if CACHE_MTIME_URL in url: return str(int(self.day + 20))
            if CACHE_URL in url: return json.dumps({'value_day': 340, 'data': [[int(self.day + 10), 341]]})
            raise AssertionError(url)
        self.feed._open_text = fetch
        with patch('night_futures.time.time', return_value=self.day + 25):
            self.feed._load_cache(None)
        self.assertEqual(self.feed._state['opening_ts'], int(self.day))
        self.assertEqual(list(self.feed._points), [{'t': int(self.day + 10), 'p': 341.0}])
        self.assertEqual(self.feed._state['price'], 341.0)


if __name__ == '__main__':
    unittest.main()
