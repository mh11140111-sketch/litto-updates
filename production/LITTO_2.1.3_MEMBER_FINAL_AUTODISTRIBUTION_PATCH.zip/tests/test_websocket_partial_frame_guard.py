import unittest, socket, sys
from pathlib import Path
sys.path.insert(0,str(Path(__file__).resolve().parents[1]))
from us_realtime import _WebSocket
class FakeSocket:
    def __init__(self,parts): self.parts=iter(parts)
    def recv(self,n):
        v=next(self.parts)
        if isinstance(v,Exception): raise v
        assert len(v)<=n
        return v
class GuardTests(unittest.TestCase):
    def test_partial_header_timeout_recovers(self):
        ws=_WebSocket('wss://example.com',0.1)
        ws.sock=FakeSocket([b'\x81',socket.timeout(),b'\x02',b'OK'])
        self.assertEqual(ws.recv_text(),'OK')
    def test_idle_timeout_propagates(self):
        ws=_WebSocket('wss://example.com',0.1)
        ws.sock=FakeSocket([socket.timeout()])
        with self.assertRaises(socket.timeout):ws.recv_text()
    def test_closed_mid_frame_not_silent(self):
        ws=_WebSocket('wss://example.com',0.1)
        ws.sock=FakeSocket([b'\x81',b''])
        with self.assertRaises(OSError):ws.recv_text()
if __name__=='__main__':unittest.main()
