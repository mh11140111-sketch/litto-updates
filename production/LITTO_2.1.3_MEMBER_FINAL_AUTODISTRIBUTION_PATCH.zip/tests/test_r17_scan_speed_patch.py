import ast
import pathlib
import unittest

ROOT=pathlib.Path(__file__).resolve().parents[1]

class R17ScanSpeedPatchTests(unittest.TestCase):
    def test_stock_prefetched_quote_fallback(self):
        tree=ast.parse((ROOT/'kiwoom.py').read_text(encoding='utf-8'))
        cls=next(n for n in tree.body if isinstance(n,ast.ClassDef) and any(isinstance(x,ast.FunctionDef) and x.name=='stock' for x in n.body))
        stock=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=='stock')
        self.assertIn('prefetched_quote',[a.arg for a in stock.args.args])
        self.assertIn("prefetched_quote if prefetched_quote is not None else self.quote(c, 'SOR')",ast.unparse(stock))
    def test_scan_supplies_existing_quote_and_bounds_sector_wait(self):
        text=(ROOT/'app.py').read_text(encoding='utf-8')
        self.assertIn("client.stock,c,resolved_name,base_sector or '미분류',fq)",text)
        self.assertIn('sector_sync.fetch_sector(c, timeout=1.5)',text)

if __name__=='__main__': unittest.main()
