import pathlib
import sys
import threading
import unittest
from http.server import BaseHTTPRequestHandler
from urllib.error import HTTPError
from urllib.request import urlopen

sys.path.insert(0, str(pathlib.Path(__file__).resolve().parents[1]))
from litto_bounded_http import LittoBoundedHTTPServer

class TestBoundedHTTP(unittest.TestCase):
    def test_busy_server_returns_503_and_recovers(self):
        started, release = threading.Event(), threading.Event()
        class Handler(BaseHTTPRequestHandler):
            def do_GET(self):
                if self.path == '/slow':
                    started.set()
                    release.wait(timeout=2)
                self.send_response(200)
                self.end_headers()
                self.wfile.write(b'ok')
            def log_message(self, *args):
                pass
        server = LittoBoundedHTTPServer(('127.0.0.1', 0), Handler, max_requests=1)
        worker = threading.Thread(target=server.serve_forever, daemon=True)
        worker.start()
        port=server.server_port
        slow=threading.Thread(target=lambda: urlopen(f'http://127.0.0.1:{port}/slow',timeout=3).read(),daemon=True)
        try:
            slow.start()
            self.assertTrue(started.wait(2))
            with self.assertRaises(HTTPError) as ctx:
                urlopen(f'http://127.0.0.1:{port}/other',timeout=2)
            self.assertEqual(ctx.exception.code,503)
            self.assertEqual(server.request_metrics()['rejected_requests'],1)
        finally:
            release.set()
            slow.join(3)
        self.assertEqual(urlopen(f'http://127.0.0.1:{port}/ok',timeout=2).read(),b'ok')
        server.shutdown()
        server.server_close()
    def test_invalid_capacity(self):
        with self.assertRaises(ValueError):
            LittoBoundedHTTPServer(('127.0.0.1',0),BaseHTTPRequestHandler,max_requests=0)
