import ast
import pathlib
import unittest

ROOT=pathlib.Path(__file__).resolve().parents[1]

class WatchRestoreTests(unittest.TestCase):
    def test_http_branch_does_not_call_broker_synchronously(self):
        tree=ast.parse((ROOT/'app.py').read_text(encoding='utf-8'))
        fn=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='watch_realtime_snapshot')
        src=ast.unparse(fn)
        self.assertIn('_watch_restore_schedule(client, c, now_ts)',src)
        # Normal session fallback stays intact; after-close uses continue before it.
        self.assertIn("if after_close and (not bool(getattr(client, 'mock', False))):",src)
        self.assertIn('WATCH_RESTORE_LOCK',src)
    def test_worker_handles_quotes_outside_http(self):
        tree=ast.parse((ROOT/'app.py').read_text(encoding='utf-8'))
        fn=next(x for x in tree.body if isinstance(x,ast.FunctionDef) and x.name=='_watch_restore_worker')
        self.assertIn('client.quote',ast.unparse(fn))
        self.assertIn('WATCH_RESTORE_PENDING.discard(c)',ast.unparse(fn))

if __name__=='__main__':unittest.main()
