LITTO 2.1.3 member cumulative update. Run through LITTO_LAUNCHER.cmd. Retains user databases, settings, authentication and launcher. Requires member testing on Windows.
