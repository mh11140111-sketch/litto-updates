"""Run: python app.py. Python 3.10+, standard library only."""
from speed_runtime import SingleFlight
from http.server import ThreadingHTTPServer,BaseHTTPRequestHandler
from pathlib import Path
from urllib.parse import urlparse,parse_qs,quote_plus,urljoin,urlencode
import argparse,csv,io,json,os,secrets,threading,webbrowser,ctypes,base64,subprocess,time,re,copy,queue,random
from datetime import datetime,timedelta
from html.parser import HTMLParser
import xml.etree.ElementTree as ET
from email.utils import parsedate_to_datetime
from urllib.request import Request,urlopen
from engine import scan_dataset,config,KST,code
import sectors
import sector_sync
from yaksang import REVIEW_FIELDS
from importer import parse_file
from kiwoom import Kiwoom,ApiError,base_code,daily_bar,minute_bar
from demo import dataset
import search_panels
from domestic_realtime import DomesticRealtimeFeed
from orderbook_realtime import DomesticOrderbookFeed
import market_calendar
import journal
import screener_history
import night_futures

ROOT=Path(__file__).resolve().parent
journal.init(ROOT)
screener_history.init(ROOT)
LOCK=threading.RLock()
CSRF=secrets.token_urlsafe(32)
STATE={'data':dataset(),'report':None,'settings':config(),'market':'unknown','client':None,
       'busy':False,'progress':'예시 데이터 준비됨','done':0,'total':0,'fetch_errors':[],
       'connected':False,'mock':False,'cancel':threading.Event(),
       'sector_busy':False,'sector_progress':'','sector_done':0,'sector_total':0,
       'realtime_rank':{'rows':[],'daily_rows':[],'updated_at':None,'source':'키움 ka00198 · 2초 확인','daily_source':'키움 ka00198 · 당일 누적','error':None},
       'realtime_rank_prev':{},
       'ranks':{'value_top':[],'change_top':[],'today_limit':[],'prev_limit':[],'source':'예시/미조회'},
       'scan_options':{'scope':'all','limit':100,'watchlist':''}}
UNIVERSE=json.loads((ROOT/'data/universe.json').read_text(encoding='utf-8'))
LOOKUP={x['code']:x for x in UNIVERSE}
CANDIDATE_HISTORY=ROOT/'data'/'candidate_history.json'
ORDERBOOK_LAST_FILE=ROOT/'data'/'orderbook_last.json'
ORDERBOOK_LAST_LOCK=threading.RLock()

# Orderbook side mini-chart cache.
# Deliberately independent from the orderbook WebSocket path: chart REST never
# participates in the live orderbook loop and is loaded only on open/timeframe change.
ORDERBOOK_CHART_CACHE={}

ORDERBOOK_CHART_CACHE_LOCK=threading.RLock()

# Closing TOP5 performance tracking --------------------------------------------
# Completely isolated from the live scanner/orderbook paths.  Nothing runs in
# the background: snapshots are saved from the TOP5 screen and result history is
# refreshed only when the user explicitly asks for it.
TOP5_PERF_FILE=ROOT/'data'/'closing_top5_performance.json'
TOP5_PERF_LOCK=threading.RLock()

def _top5_perf_load():
    try:
        if TOP5_PERF_FILE.exists():
            raw=json.loads(TOP5_PERF_FILE.read_text(encoding='utf-8'))
            if isinstance(raw,dict) and isinstance(raw.get('days'),list):
                return raw
    except Exception:
        pass
    return {'version':1,'days':[]}

def _top5_perf_save(data):
    with TOP5_PERF_LOCK:
        TOP5_PERF_FILE.parent.mkdir(parents=True,exist_ok=True)
        tmp=TOP5_PERF_FILE.with_suffix('.tmp')
        tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
        tmp.replace(TOP5_PERF_FILE)

def _top5_num(v):
    try:
        if v in (None,''): return None
        return float(str(v).replace(',','').strip())
    except Exception:
        return None

def _top5_perf_summary(data):
    days=list(data.get('days') or []) if isinstance(data,dict) else []
    resolved=[]
    for d in days:
        for r in (d.get('rows') or []):
            rs=r.get('result') if isinstance(r,dict) else None
            if isinstance(rs,dict) and rs.get('next_date'):
                resolved.append(r)

    def rate(items,key):
        vals=[bool((x.get('result') or {}).get(key)) for x in items]
        return (sum(1 for x in vals if x)/len(vals)*100.0) if vals else None

    max_vals=[_top5_num((x.get('result') or {}).get('max_return_pct')) for x in resolved]
    max_vals=[x for x in max_vals if x is not None]
    close_vals=[_top5_num((x.get('result') or {}).get('close_return_pct')) for x in resolved]
    close_vals=[x for x in close_vals if x is not None]

    by_rank=[]
    for rank in range(1,6):
        items=[x for x in resolved if int(x.get('rank') or 0)==rank]
        by_rank.append({
            'rank':rank,'count':len(items),
            'hit4_rate':rate(items,'hit4'),
            'hit2_rate':rate(items,'hit2'),
            'close_positive_rate':rate(items,'close_positive'),
            'avg_max_return_pct':(sum(_top5_num((x.get('result') or {}).get('max_return_pct')) or 0 for x in items)/len(items)) if items else None,
        })

    return {
        'saved_days':len(days),
        'resolved_days':sum(1 for d in days if any(isinstance((r or {}).get('result'),dict) and (r.get('result') or {}).get('next_date') for r in (d.get('rows') or []))),
        'resolved_picks':len(resolved),
        'hit4_rate':rate(resolved,'hit4'),
        'hit2_rate':rate(resolved,'hit2'),
        'close_positive_rate':rate(resolved,'close_positive'),
        'avg_max_return_pct':sum(max_vals)/len(max_vals) if max_vals else None,
        'avg_close_return_pct':sum(close_vals)/len(close_vals) if close_vals else None,
        'by_rank':by_rank,
    }

def top5_performance_snapshot():
    with TOP5_PERF_LOCK:
        data=copy.deepcopy(_top5_perf_load())
    data['days']=sorted((data.get('days') or []),key=lambda x:str(x.get('date') or ''),reverse=True)
    return {'ok':True,'summary':_top5_perf_summary(data),'days':data['days'][:60],
            'source':'LITTO 종배 TOP5 저장 기록 · 익일 일봉은 키움 ka10081'}

def top5_performance_save_snapshot(payload):
    rows=payload.get('rows') if isinstance(payload,dict) else None
    if not isinstance(rows,list) or not rows:
        raise ValueError('저장할 종배 TOP5가 없습니다.')
    day=str(payload.get('date') or datetime.now(KST).date().isoformat())[:10]
    try:
        datetime.strptime(day,'%Y-%m-%d')
    except Exception:
        raise ValueError('TOP5 저장 날짜 형식이 올바르지 않습니다.')

    clean=[]
    seen=set()
    for i,row in enumerate(rows[:5],1):
        if not isinstance(row,dict): continue
        c=code(row.get('code') or '')
        if not c or c in seen: continue
        seen.add(c)
        parts=row.get('parts') if isinstance(row.get('parts'),dict) else {}
        tags=row.get('tags') if isinstance(row.get('tags'),list) else []
        clean.append({
            'rank':int(row.get('rank') or i),
            'code':c,
            'name':str(row.get('name') or c)[:80],
            'sector':str(row.get('sector') or '기타')[:100],
            'score':_top5_num(row.get('score')),
            'entry_price':_top5_num(row.get('entry_price')),
            'entry_price_source':'화면 저장시점 임시값 · 결과갱신 시 해당일 공식 종가로 확정',
            'value_eok':_top5_num(row.get('value_eok')),
            'program_ratio':_top5_num(row.get('program_ratio')),
            'parts':{k:_top5_num(parts.get(k)) for k in ('sector','value','power','signal','program')},
            'tags':[str(x)[:40] for x in tags[:12]],
            'result':None,
        })
    if not clean:
        raise ValueError('유효한 TOP5 종목이 없습니다.')

    now_iso=datetime.now(KST).isoformat()
    with TOP5_PERF_LOCK:
        data=_top5_perf_load()
        days=[x for x in (data.get('days') or []) if str(x.get('date') or '')!=day]
        days.append({'date':day,'saved_at':now_iso,'rows':clean})
        data={'version':1,'days':sorted(days,key=lambda x:str(x.get('date') or ''))}
        _top5_perf_save(data)
    return top5_performance_snapshot()

def top5_performance_refresh_results(max_days=5):
    with LOCK:
        client=STATE.get('client')
    if not client:
        raise ValueError('키움 API 연결이 필요합니다.')

    today=datetime.now(KST).date().isoformat()
    with TOP5_PERF_LOCK:
        data=_top5_perf_load()
        days=copy.deepcopy(data.get('days') or [])

    pending=[d for d in sorted(days,key=lambda x:str(x.get('date') or ''),reverse=True)
             if str(d.get('date') or '')<today and any(not isinstance((r or {}).get('result'),dict) or not (r.get('result') or {}).get('next_date') for r in (d.get('rows') or []))]
    target_dates={str(d.get('date')) for d in pending[:max(1,min(int(max_days or 5),10))]}
    updated=0
    errors=[]

    for d in days:
        day=str(d.get('date') or '')
        if day not in target_dates: continue
        for r in (d.get('rows') or []):
            if isinstance(r.get('result'),dict) and (r.get('result') or {}).get('next_date'):
                continue
            c=code(r.get('code') or '')
            if not c: continue
            try:
                raw=_kiwoom_call(client.daily_history_rows,c,80,kind='chart')
                bars=[daily_bar(x) for x in raw]
                bars=sorted([b for b in bars if b.get('date')],key=lambda x:x['date'])
                same=next((b for b in bars if b.get('date')==day),None)
                nxt=next((b for b in bars if str(b.get('date') or '')>day),None)
                if not same or not nxt:
                    continue
                entry=_top5_num(same.get('close'))
                op=_top5_num(nxt.get('open')); hi=_top5_num(nxt.get('high')); lo=_top5_num(nxt.get('low')); cl=_top5_num(nxt.get('close'))
                if not entry or entry<=0 or not all(v is not None and v>0 for v in (op,hi,lo,cl)):
                    continue
                ret=lambda v:(float(v)/entry-1.0)*100.0
                r['entry_price']=entry
                r['entry_price_source']='키움 ka10081 해당일 공식 종가'
                r['result']={
                    'next_date':nxt.get('date'),
                    'open':op,'high':hi,'low':lo,'close':cl,
                    'open_gap_pct':ret(op),
                    'max_return_pct':ret(hi),
                    'min_return_pct':ret(lo),
                    'close_return_pct':ret(cl),
                    'hit2':ret(hi)>=2.0,
                    'hit4':ret(hi)>=4.0,
                    'close_positive':ret(cl)>0,
                    'updated_at':datetime.now(KST).isoformat(),
                }
                updated+=1
            except Exception as e:
                errors.append(f"{c}: {str(e)[:80]}")

    with TOP5_PERF_LOCK:
        data={'version':1,'days':sorted(days,key=lambda x:str(x.get('date') or ''))}
        _top5_perf_save(data)
    snap=top5_performance_snapshot()
    remaining=sum(1 for d in data['days'] if str(d.get('date') or '')<today for r in (d.get('rows') or [])
                  if not isinstance((r or {}).get('result'),dict) or not (r.get('result') or {}).get('next_date'))
    snap.update({'updated_picks':updated,'remaining_picks':remaining,'errors':errors[:10]})
    return snap

def _load_last_orderbooks():
    try:
        if ORDERBOOK_LAST_FILE.exists():
            raw=json.loads(ORDERBOOK_LAST_FILE.read_text(encoding='utf-8'))
            return raw if isinstance(raw,dict) else {}
    except Exception:
        pass
    return {}

def _save_last_orderbook(stock_code,payload):
    c=code(stock_code) if stock_code else ''
    if not c or not isinstance(payload,dict): return
    asks=[x for x in (payload.get('asks') or []) if isinstance(x,dict) and float(x.get('price') or 0)>0]
    bids=[x for x in (payload.get('bids') or []) if isinstance(x,dict) and float(x.get('price') or 0)>0]
    if not asks and not bids: return
    with ORDERBOOK_LAST_LOCK:
        cache=_load_last_orderbooks()
        keep={k:payload.get(k) for k in ('asks','bids','ask_total','bid_total','orderbook_time','venue','market_code','source') if k in payload}
        keep['saved_at']=datetime.now(KST).isoformat()
        cache[c]=keep
        try:
            ORDERBOOK_LAST_FILE.parent.mkdir(parents=True,exist_ok=True)
            tmp=ORDERBOOK_LAST_FILE.with_suffix('.tmp')
            tmp.write_text(json.dumps(cache,ensure_ascii=False),encoding='utf-8')
            tmp.replace(ORDERBOOK_LAST_FILE)
        except Exception:
            pass

def _get_last_orderbook(stock_code,max_days=7):
    c=code(stock_code) if stock_code else ''
    if not c:return None
    with ORDERBOOK_LAST_LOCK:
        row=_load_last_orderbooks().get(c)
    if not isinstance(row,dict):return None
    try:
        saved=datetime.fromisoformat(str(row.get('saved_at') or ''))
        if saved.tzinfo is None:saved=saved.replace(tzinfo=KST)
        if datetime.now(KST)-saved>timedelta(days=max_days):return None
    except Exception:
        return None
    return row


# Stock-name master/cache -------------------------------------------------------
# Ranking APIs may legitimately return only a stock code.  Keep a process-wide
# name cache fed by the full Kiwoom universe and, for genuinely unknown codes,
# resolve them asynchronously so the 2-second rank loop never blocks.
STOCK_NAME_CACHE_FILE=ROOT/'data'/'stock_name_cache.json'
STOCK_MASTER_DAILY_FILE=ROOT/'data'/'stock_master_daily_refresh.json'
STOCK_MASTER_DAILY_LOCK=threading.RLock()
STOCK_MASTER_DAILY_RUNNING=False
STOCK_NAME_LOCK=threading.RLock()
STOCK_NAME_PENDING=set()
STOCK_NAME_Q=queue.Queue(maxsize=256)
try:
    STOCK_NAME_CACHE={str(k).zfill(6):str(v).strip() for k,v in json.loads(STOCK_NAME_CACHE_FILE.read_text(encoding='utf-8')).items() if str(v).strip()} if STOCK_NAME_CACHE_FILE.exists() else {}
except Exception:
    STOCK_NAME_CACHE={}
for _c,_row in list(LOOKUP.items()):
    _n=str((_row or {}).get('name') or '').strip() if isinstance(_row,dict) else ''
    if _n and _n!=_c: STOCK_NAME_CACHE[_c]=_n

def _save_stock_name_cache():
    try:
        with STOCK_NAME_LOCK: payload=dict(STOCK_NAME_CACHE)
        tmp=STOCK_NAME_CACHE_FILE.with_suffix('.tmp')
        tmp.write_text(json.dumps(payload,ensure_ascii=False,sort_keys=True),encoding='utf-8')
        tmp.replace(STOCK_NAME_CACHE_FILE)
    except Exception:
        pass

def _cache_stock_name(stock_code,name):
    c=code(stock_code) if stock_code else ''
    n=str(name or '').strip()
    if not c or not n or n==c or (n.isdigit() and code(n)==c): return False
    changed=False
    with STOCK_NAME_LOCK:
        if STOCK_NAME_CACHE.get(c)!=n:
            STOCK_NAME_CACHE[c]=n;changed=True
    # Also enrich the in-memory master used throughout LITTO.
    row=LOOKUP.get(c)
    if isinstance(row,dict): row['name']=n
    elif c: LOOKUP[c]={'code':c,'name':n}
    return changed

def _queue_stock_name_lookup(stock_code):
    c=code(stock_code) if stock_code else ''
    if not c:return
    with STOCK_NAME_LOCK:
        if c in STOCK_NAME_CACHE or c in STOCK_NAME_PENDING:return
        STOCK_NAME_PENDING.add(c)
    try:STOCK_NAME_Q.put_nowait(c)
    except queue.Full:
        with STOCK_NAME_LOCK:STOCK_NAME_PENDING.discard(c)

def _stock_name_lookup_worker():
    while True:
        c=STOCK_NAME_Q.get()
        try:
            with LOCK: client=STATE.get('client')
            if not client:
                continue
            # Quote lookup is light and usually includes the provider stock name.
            q=_kiwoom_call(client.quote,c,'SOR',kind='name')
            n=(q.get('name') or q.get('stk_nm') or '').strip() if isinstance(q,dict) else ''
            if n:
                if _cache_stock_name(c,n): _save_stock_name_cache()
        except Exception:
            pass
        finally:
            with STOCK_NAME_LOCK: STOCK_NAME_PENDING.discard(c)
            STOCK_NAME_Q.task_done()

def _refresh_stock_name_master_worker(client):
    """Refresh the full listed-code -> name master and return success metadata."""
    global UNIVERSE,LOOKUP
    rows=_kiwoom_call(client.universe,kind='name_master')
    if not rows:
        return {'ok':False,'rows':0,'added':0,'changed_names':0}

    old_codes=set(LOOKUP.keys())
    changed=False
    for r in rows:
        if not isinstance(r,dict):continue
        rawc=r.get('code') or r.get('stk_cd') or r.get('stock_code')
        if not rawc:continue
        c=code(rawc)
        n=str(r.get('name') or r.get('stk_nm') or r.get('stock_name') or '').strip()
        if c and n:
            changed=_cache_stock_name(c,n) or changed

    # Merge into a separate map first. Never clear the live master during refresh.
    by={code(x.get('code')):dict(x) for x in (UNIVERSE or []) if isinstance(x,dict) and x.get('code')}
    for r in rows:
        if not isinstance(r,dict):continue
        rawc=r.get('code') or r.get('stk_cd') or r.get('stock_code')
        if not rawc:continue
        c=code(rawc);base=by.get(c,{})
        base.update({k:v for k,v in r.items() if v not in (None,'')})
        base['code']=c
        if STOCK_NAME_CACHE.get(c):base['name']=STOCK_NAME_CACHE[c]
        by[c]=base

    UNIVERSE=list(by.values())
    LOOKUP={x['code']:x for x in UNIVERSE if x.get('code')}
    if changed:_save_stock_name_cache()
    return {
        'ok':True,
        'rows':len(rows),
        'added':len(set(LOOKUP.keys())-old_codes),
        'changed_names':1 if changed else 0,
    }


def _stock_master_daily_last_date():
    try:
        raw=json.loads(STOCK_MASTER_DAILY_FILE.read_text(encoding='utf-8'))
        return str(raw.get('date') or '')
    except Exception:
        return ''


def _mark_stock_master_daily_success(day,result):
    try:
        STOCK_MASTER_DAILY_FILE.parent.mkdir(parents=True,exist_ok=True)
        tmp=STOCK_MASTER_DAILY_FILE.with_suffix('.tmp')
        tmp.write_text(json.dumps({
            'date':day,
            'updated_at':datetime.now(KST).isoformat(),
            'rows':int((result or {}).get('rows') or 0),
            'added':int((result or {}).get('added') or 0),
            'source':'Kiwoom ka10099'
        },ensure_ascii=False,indent=2),encoding='utf-8')
        tmp.replace(STOCK_MASTER_DAILY_FILE)
    except Exception:
        pass


def _start_daily_stock_master_refresh(client):
    """Run ka10099 once after the first successful login of each KST day."""
    global STOCK_MASTER_DAILY_RUNNING
    if not client:return False
    day=datetime.now(KST).date().isoformat()
    with STOCK_MASTER_DAILY_LOCK:
        if STOCK_MASTER_DAILY_RUNNING:return False
        if _stock_master_daily_last_date()==day:return False
        STOCK_MASTER_DAILY_RUNNING=True

    def worker():
        global STOCK_MASTER_DAILY_RUNNING
        try:
            result=_refresh_stock_name_master_worker(client)
            if result.get('ok'):
                _mark_stock_master_daily_success(day,result)
                STATE['progress']=f"종목DB 일일 업데이트 완료 · {result.get('rows',0):,}종목 확인 · 신규 {result.get('added',0):,}개"
        except Exception as ex:
            try:STATE['progress']='종목DB 일일 업데이트 실패 · 다음 로그인 때 재시도 · '+str(ex)[:180]
            except Exception:pass
        finally:
            with STOCK_MASTER_DAILY_LOCK:
                STOCK_MASTER_DAILY_RUNNING=False

    threading.Thread(target=worker,daemon=True,name='litto-daily-stock-master').start()
    return True

threading.Thread(target=_stock_name_lookup_worker,daemon=True,name='litto-name-resolver').start()

NEWS_CACHE={}
NEWS_CACHE_TTL=120

# On-demand investor flow popup cache.  This feature is intentionally detached
# from the Page-1 live loop: provider calls happen only when the user clicks a
# stock name, so the frozen 2-second scanner remains untouched.
INVESTOR_FLOW_CACHE={}
INVESTOR_FLOW_CACHE_TTL=60

ORDERBOOK_STATIC_WARM_LOCK=threading.RLock()
ORDERBOOK_STATIC_WARMING=set()
def _warm_orderbook_static(client,stock_code):
    c=code(stock_code)
    if not c:return
    with ORDERBOOK_STATIC_WARM_LOCK:
        if c in ORDERBOOK_STATIC_WARMING:return
        ORDERBOOK_STATIC_WARMING.add(c)
    def worker():
        try:
            static=client.domestic_orderbook(c,'SOR')
            static['_ts']=time.time()
            cache=getattr(client,'_orderbook_rest_cache',{})
            if not isinstance(cache,dict):cache={}
            cache[c]=dict(static);client._orderbook_rest_cache=cache
        except Exception:
            pass
        finally:
            with ORDERBOOK_STATIC_WARM_LOCK:ORDERBOOK_STATIC_WARMING.discard(c)
    threading.Thread(target=worker,daemon=True,name=f'litto-ob-warm-{c}').start()

def _flow_num(v):
    try:
        if v is None or v=='': return 0.0
        return float(str(v).replace(',','').replace('+',''))
    except Exception:
        return 0.0

FLOW_FLIGHT=SingleFlight()

def investor_flow_snapshot(stock_code,force=False):
    return FLOW_FLIGHT.run((STATE.get('client'),code(stock_code)),lambda:_investor_flow_snapshot(stock_code,force))

def _investor_flow_snapshot(stock_code,force=False):
    c=code(stock_code)
    if not c: raise ValueError('종목코드가 필요합니다.')
    with LOCK: client=STATE.get('client')
    if not client: raise ValueError('키움 API 연결이 필요합니다.')
    now=time.time();cache_key=(client,c);cached=INVESTOR_FLOW_CACHE.get(cache_key)
    if not force and cached and now-cached.get('ts',0)<INVESTOR_FLOW_CACHE_TTL:
        return cached['data']
    # SOR first so NXT/KRX combined trading can be requested when supported.
    # Some accounts/providers accept only the base KRX code, so fall back once.
    body_base={'dt':datetime.now(KST).strftime('%Y%m%d'),'amt_qty_tp':'1','trde_tp':'0','unit_tp':'1000'}
    rows=None;last=None;used_code=None
    for provider_code in (c+'_AL',c):
        try:
            rows=_kiwoom_call(client.rows,'ka10060',{**body_base,'stk_cd':provider_code},'stk_invsr_orgn_chart',12,3,kind='flow')
            used_code=provider_code
            if rows is not None: break
        except Exception as e:
            last=e
    if rows is None:
        raise last or ValueError('투자자별 수급 조회에 실패했습니다.')
    # Provider normally returns newest first.  Keep one row per trade date.
    seen=set();days=[]
    fields=('ind_invsr','frgnr_invsr','orgn','fnnc_invt','insrnc','invtrt','etc_fnnc','bank','penfnd_etc','samo_fund','natn','etc_corp','natfor')
    for r in rows:
        d=str(r.get('dt') or '').strip()
        if not d or d in seen: continue
        seen.add(d)
        item={'date':d,'price':abs(_flow_num(r.get('cur_prc'))),'trading_value':abs(_flow_num(r.get('acc_trde_prica')))}
        item.update({k:_flow_num(r.get(k)) for k in fields})
        days.append(item)
        if len(days)>=10: break
    totals={k:sum(float(x.get(k) or 0) for x in days) for k in fields}
    today=days[0] if days else {k:0.0 for k in fields}
    name=_best_known_stock_name(c,LOOKUP.get(c,{}))
    data={'code':c,'name':name,'provider_code':used_code,'updated_at':datetime.now(KST).isoformat(),
          'source':'키움 ka10060 종목별투자자기관별차트 · 순매수 금액',
          'unit':'provider_amount','today':today,'ten_day':totals,'five_day':totals,'days':days}
    INVESTOR_FLOW_CACHE[cache_key]={'ts':time.time(),'data':data}
    while len(INVESTOR_FLOW_CACHE)>256:
        INVESTOR_FLOW_CACHE.pop(next(iter(INVESTOR_FLOW_CACHE)),None)
    return data


# Interest-watchlist program trading cache.
# Robust dual-path strategy:
#  1) ka90004 market-wide program snapshot (SOR integrated first, KRX fallback)
#  2) ka90013 direct per-stock daily program flow for any watched stock not found
PROGRAM_FLOW_CACHE={'ts':0.0,'key':None,'data':None}
PROGRAM_FLOW_CACHE_TTL=60

def _program_num(v):
    try:
        if v is None or v=='': return 0.0
        return float(str(v).replace(',','').replace('+','').strip())
    except Exception:
        return 0.0

def _normalize_program_code(raw):
    raw=str(raw or '').strip()
    if raw.endswith('_AL') or raw.endswith('_NX'): raw=raw[:-3]
    if len(raw)==7 and raw.startswith('A') and raw[1:].isdigit(): raw=raw[1:]
    try:return code(raw)
    except Exception:return ''

def _program_rows_direct(client, provider_code, day):
    return _kiwoom_call(
        client.rows,'ka90013',
        {'amt_qty_tp':'1','stk_cd':provider_code,'date':day},
        'stk_daly_prm_trde_trnsn',30,2,kind='flow'
    )

def _program_market_rows(client, day, stex_tp):
    out=[]
    for market_name,mrkt_tp in (('KOSPI','P00101'),('KOSDAQ','P10102')):
        part=_kiwoom_call(
            client.rows,'ka90004',
            {'dt':day,'mrkt_tp':mrkt_tp,'stex_tp':stex_tp},
            'stk_prm_trde_prst',5000,30,kind='flow'
        )
        for r in part:
            c=_normalize_program_code(r.get('stk_cd'))
            if not c: continue
            out.append({
                'code':c,'name':str(r.get('stk_nm') or '').strip(),
                'program_net_eok':_program_num(r.get('netprps_prica'))/100.0,
                'program_buy_eok':_program_num(r.get('buy_cntr_amt'))/100.0,
                'program_sell_eok':_program_num(r.get('sel_cntr_amt'))/100.0,
                'program_trade_ratio':_program_num(r.get('all_trde_rt')),
                'market':market_name,'date':day,'source_api':'ka90004',
                'stex_tp':stex_tp
            })
    return out

def _latest_market_program_day(client):
    now_kst=datetime.now(KST)
    errors=[]
    for back in range(0,8):
        day=(now_kst-timedelta(days=back)).strftime('%Y%m%d')
        # SOR integrated first; some environments/accounts may only support KRX.
        for stex in ('3','1'):
            try:
                rows=_program_market_rows(client,day,stex)
                if rows:return day,rows,errors
            except Exception as e:
                errors.append(f'ka90004 {day} stex={stex}: {str(e)[:180]}')
    return None,[],errors


# Manual watchlist search/live --------------------------------------------------
MANUAL_WATCH_CACHE={}
MANUAL_WATCH_CACHE_LOCK=threading.RLock()

def stock_search_snapshot(query,limit=20):
    q=str(query or '').strip()
    if not q:return {'query':'','rows':[]}
    qlow=q.lower()
    rows=[]
    seen=set()
    # Prefer full stock-name master/cache, then the in-memory universe.
    with STOCK_NAME_LOCK:
        items=list(STOCK_NAME_CACHE.items())
    for c,n in items:
        code6=code(c)
        name=str(n or '').strip()
        if not code6 or not name: continue
        if qlow in code6.lower() or qlow in name.lower():
            if code6 in seen: continue
            seen.add(code6); rows.append({'code':code6,'name':name})
    for c,row in LOOKUP.items():
        code6=code(c); name=str((row or {}).get('name') or '').strip()
        if not code6 or not name or code6 in seen: continue
        if qlow in code6.lower() or qlow in name.lower():
            seen.add(code6); rows.append({'code':code6,'name':name})
    # If the local name master has not finished loading yet, do one synchronous
    # Kiwoom master refresh and retry. This makes manual watch search work for
    # stocks that never appeared in the scanner (e.g. NAVER, 광전자).
    if not rows:
        with LOCK: client=STATE.get('client')
        if client:
            try:
                master=_kiwoom_call(client.universe,kind='name_master_search') or []
                changed=False
                for r in master:
                    if not isinstance(r,dict):
                        continue
                    rawc=r.get('code') or r.get('stk_cd') or r.get('stock_code')
                    if not rawc:
                        continue
                    c=code(rawc)
                    n=str(r.get('name') or r.get('stk_nm') or r.get('stock_name') or '').strip()
                    if c and n:
                        changed=_cache_stock_name(c,n) or changed
                if changed:
                    _save_stock_name_cache()
                # Retry against the freshly loaded full market master.
                with STOCK_NAME_LOCK:
                    items=list(STOCK_NAME_CACHE.items())
                for c,n in items:
                    code6=code(c); name=str(n or '').strip()
                    if not code6 or not name or code6 in seen:
                        continue
                    if qlow in code6.lower() or qlow in name.lower():
                        seen.add(code6); rows.append({'code':code6,'name':name})
            except Exception:
                pass

    # Exact 6-digit code fallback: resolve directly from Kiwoom when connected.
    if q.isdigit() and len(q)==6 and q not in seen:
        with LOCK: client=STATE.get('client')
        if client:
            try:
                qt=_kiwoom_call(client.quote,q,kind='light')
                n=str(qt.get('name') or '').strip()
                if n:
                    _cache_stock_name(q,n); rows.insert(0,{'code':q,'name':n})
            except Exception:
                pass
    # Exact/prefix matches first.
    def rank(r):
        c=r['code']; n=r['name']; nl=n.lower()
        if c==q:return (0,n)
        if nl==qlow:return (1,n)
        if c.startswith(q):return (2,n)
        if nl.startswith(qlow):return (3,n)
        return (4,n)
    rows=sorted(rows,key=rank)[:max(1,min(int(limit or 20),50))]
    try:
        mapping=sectors.load()
    except Exception:
        mapping={}
    for r in rows:
        m=mapping.get(r['code'],{}) if isinstance(mapping,dict) else {}
        r['sector']=str((m or {}).get('sector') or LOOKUP.get(r['code'],{}).get('sector') or '기타')
        r['watched']=False
    return {'query':q,'rows':rows,'count':len(rows)}

def manual_watch_live_snapshot(stock_codes,force=False):
    codes=[]
    for raw in stock_codes or []:
        c=code(raw)
        if c and c not in codes:codes.append(c)
    codes=codes[:30]
    with LOCK: client=STATE.get('client')
    if not client: raise ValueError('키움 API 연결이 필요합니다.')
    try:mapping=sectors.load()
    except Exception:mapping={}
    out=[];errors={}
    now=time.time()
    for c in codes:
        cached=None
        with MANUAL_WATCH_CACHE_LOCK:
            cached=MANUAL_WATCH_CACHE.get(c)
        if cached and not force and now-cached.get('ts',0)<30:
            out.append(dict(cached['data']));continue
        try:
            name=_best_known_stock_name(c,LOOKUP.get(c,{}))
            q=_kiwoom_call(client.quote,c,kind='light')
            if q.get('name'):name=q['name'];_cache_stock_name(c,name)
            sector=str((mapping.get(c,{}) or {}).get('sector') or LOOKUP.get(c,{}).get('sector') or '기타')
            detail=_kiwoom_call(client.stock,c,name,sector,kind='heavy')
            # Stocks manually added to the watchlist may never appear in the
            # scanner universe.  Derive the trading-value total from the latest
            # provider daily bar so the watch card has the same information as
            # scanner-originated stocks without estimating money from price*volume.
            value_eok=None
            daily_rows=detail.get('daily') if isinstance(detail,dict) else None
            if isinstance(daily_rows,list):
                for bar in reversed(daily_rows):
                    try:
                        raw_value=bar.get('value') if isinstance(bar,dict) else None
                        if raw_value is not None and float(raw_value)>0:
                            value_eok=float(raw_value)/100_000_000.0
                            break
                    except (TypeError,ValueError):
                        pass
            data={**detail,'code':c,'name':name,'sector':sector,'price':q.get('price'),'change':q.get('change'),'venue':q.get('venue'),'value_eok':value_eok,'manual_watch':True}
            with MANUAL_WATCH_CACHE_LOCK: MANUAL_WATCH_CACHE[c]={'ts':now,'data':data}
            out.append(data)
        except Exception as e:
            errors[c]=str(e)
    return {'rows':out,'errors':errors,'updated_at':datetime.now(KST).isoformat()}

def program_flow_watch_snapshot(stock_codes=None,force=False):
    now=time.time()
    wanted=[]
    for raw in stock_codes or []:
        c=_normalize_program_code(raw)
        if c and c not in wanted:wanted.append(c)
    if not wanted:
        return {'rows':{},'updated_at':datetime.now(KST).isoformat(),'data_date':None,
                'source':'키움 프로그램매매 이중조회','errors':[],'failed_codes':[]}

    cache_key=tuple(sorted(wanted))
    cached=PROGRAM_FLOW_CACHE.get('data')
    if (not force and cached and PROGRAM_FLOW_CACHE.get('key')==cache_key and
        now-float(PROGRAM_FLOW_CACHE.get('ts') or 0)<PROGRAM_FLOW_CACHE_TTL):
        return cached

    with LOCK: client=STATE.get('client')
    if not client: raise ValueError('키움 API 연결이 필요합니다.')

    errors=[]; by_code={}; data_date=None

    # Path 1: market-wide snapshot.  This is efficient and gives every stock in one pass.
    day, market_rows, market_errors=_latest_market_program_day(client)
    errors.extend(market_errors)
    if day:
        data_date=day
        for r in market_rows:
            if r['code'] in wanted:
                # Prefer SOR integrated row if both SOR and KRX happen to be present.
                old=by_code.get(r['code'])
                if old is None or str(r.get('stex_tp'))=='3': by_code[r['code']]=r

    # Path 2: directly query only the stocks missing from ka90004.
    missing=[c for c in wanted if c not in by_code]
    if missing:
        # If ka90004 could not resolve a trading date at all, probe dates directly.
        probe_days=[]
        if data_date: probe_days=[data_date]
        else:
            now_kst=datetime.now(KST)
            probe_days=[(now_kst-timedelta(days=i)).strftime('%Y%m%d') for i in range(0,8)]
        for c in missing:
            got=None
            for d in probe_days:
                for provider_code in (c+'_AL',c):
                    try:
                        rows=_program_rows_direct(client,provider_code,d)
                        if not rows: continue
                        chosen=next((r for r in rows if str(r.get('dt') or '').strip()==d),rows[0])
                        row_day=str(chosen.get('dt') or d).strip()
                        got={
                            'code':c,'name':'',
                            'program_net_eok':_program_num(chosen.get('prm_netprps_amt'))/100.0,
                            'program_buy_eok':_program_num(chosen.get('prm_buy_amt'))/100.0,
                            'program_sell_eok':_program_num(chosen.get('prm_sell_amt'))/100.0,
                            'program_trade_ratio':None,
                            'market':'SOR' if provider_code.endswith('_AL') else 'KRX',
                            'date':row_day,'source_api':'ka90013','provider_code':provider_code
                        }
                        if not data_date:data_date=row_day
                        break
                    except Exception as e:
                        errors.append(f'ka90013 {c} {provider_code} {d}: {str(e)[:180]}')
                if got is not None: break
            if got is not None: by_code[c]=got

    failed=[c for c in wanted if c not in by_code]
    data={'rows':by_code,'updated_at':datetime.now(KST).isoformat(),
          'data_date':data_date,
          'source':'키움 프로그램매매 · ka90004 시장전체 + ka90013 종목직접 이중조회',
          'requested_codes':wanted,'returned_codes':list(by_code.keys()),
          'failed_codes':failed,'errors':errors[-60:]}
    PROGRAM_FLOW_CACHE['ts']=now;PROGRAM_FLOW_CACHE['key']=cache_key;PROGRAM_FLOW_CACHE['data']=data
    return data

# PAGE1 provider-call gate ------------------------------------------------------
# All Kiwoom REST calls used by the Page-1 live engine pass through this gate.
# Heavy scanning releases the gate between individual requests, so 2-second rank
# refreshes and lookup ranking can continue to make progress during a full scan.
API_GATE_LOCK=threading.RLock()
API_GATE_STATUS_LOCK=threading.RLock()
API_GATE_STATE={'calls':0,'errors':0,'rate_errors':0,'backoff_until':0.0,
                'backoff_seconds':0.0,'last_call_at':0.0,'last_error':'','last_kind':''}

def _is_rate_error(exc):
    t=str(exc or '').lower()
    return any(x in t for x in ('429','rate','too many','초과','제한','호출 횟수','과도'))

def _kiwoom_call(fn,*args,kind='light',**kwargs):
    """Keep provider serialization while allowing independent local status reads."""
    while True:
        with API_GATE_LOCK:
            with API_GATE_STATUS_LOCK:
                wait=max(0.0,API_GATE_STATE['backoff_until']-time.time())
            if wait<=0:
                try:
                    out=fn(*args,**kwargs)
                    with API_GATE_STATUS_LOCK:
                        API_GATE_STATE['calls']+=1
                        API_GATE_STATE['last_call_at']=time.time()
                        API_GATE_STATE['last_kind']=kind
                        API_GATE_STATE['backoff_seconds']/=2.0
                    return out
                except Exception as e:
                    with API_GATE_STATUS_LOCK:
                        API_GATE_STATE['errors']+=1
                        API_GATE_STATE['last_error']=str(e)[:300]
                        API_GATE_STATE['last_kind']=kind
                        if _is_rate_error(e):
                            API_GATE_STATE['rate_errors']+=1
                            prev=API_GATE_STATE['backoff_seconds']
                            delay=2.0 if prev<2 else min(prev*2,8.0)
                            API_GATE_STATE.update(backoff_seconds=delay,backoff_until=time.time()+delay)
                    raise
        time.sleep(min(wait,0.5))

def _api_gate_status():
    with API_GATE_STATUS_LOCK:
        return {**API_GATE_STATE,'backoff_remaining':max(0.0,API_GATE_STATE['backoff_until']-time.time())}

PAGE1_RUNTIME_CACHE=ROOT/'data'/'page1_runtime_cache.json'

def _save_page1_runtime_cache():
    try:
        with LOCK:
            payload={'saved_at':datetime.now(KST).isoformat(),'data':STATE.get('data'),
                     'ranks':STATE.get('ranks'),'settings':STATE.get('settings'),'market':STATE.get('market'),
                     'scan_options':STATE.get('scan_options')}
        tmp=PAGE1_RUNTIME_CACHE.with_suffix('.tmp')
        tmp.write_text(json.dumps(payload,ensure_ascii=False),encoding='utf-8')
        tmp.replace(PAGE1_RUNTIME_CACHE)
    except Exception:
        pass

def _restore_page1_runtime_cache():
    try:
        if not PAGE1_RUNTIME_CACHE.exists(): return False
        raw=json.loads(PAGE1_RUNTIME_CACHE.read_text(encoding='utf-8'))
        saved=datetime.fromisoformat(raw.get('saved_at'))
        if saved.tzinfo is None:
            saved=saved.replace(tzinfo=KST)
        now=datetime.now(KST)
        age_days=(now.date()-saved.astimezone(KST).date()).days
        if age_days < 0 or age_days > 4: return False
        data=raw.get('data'); ranks=raw.get('ranks')
        if not isinstance(data,dict) or not isinstance(data.get('stocks'),list): return False
        with LOCK:
            STATE['data']=data
            if isinstance(ranks,dict): STATE['ranks']=ranks
            if isinstance(raw.get('settings'),dict): STATE['settings']=config(raw.get('settings'))
            if raw.get('market') in ('unknown','weak','strong','mixed'): STATE['market']=raw.get('market')
            if isinstance(raw.get('scan_options'),dict): STATE['scan_options']=raw.get('scan_options')
            recompute()
            restored_report=copy.deepcopy(STATE.get('report') or {})
            STATE['progress']=('오늘 마지막 1페이지 상태 복구 완료 · 실시간 재연결 대기' if age_days==0 else f"최근 거래일 상태 복구 완료 · {saved.astimezone(KST).strftime('%Y-%m-%d %H:%M')} 저장 · 새 장 데이터 대기")
        # 검색 이력 기능을 나중에 추가한 기존 사용자도 마지막 저장 스크리너를 살린다.
        # INSERT OR IGNORE이므로 재실행해도 포착 횟수는 증가하지 않는다.
        try:
            restored_day=saved.astimezone(KST).date().isoformat()
            screener_history.import_report_once(restored_report,restored_day,saved.astimezone(KST).isoformat())
        except Exception:
            pass
        return True
    except Exception:
        return False


# --- KRX market-action auto board -------------------------------------------------
# The public collector keeps only market-action notices that link back to KIND.
# It is intentionally isolated from the Newheart search formulas and trading logic.
MARKET_ACTION_CACHE_TTL=300
MARKET_ACTION_HISTORY=ROOT/'data'/'market_actions_cache.json'
MARKET_ACTION_MEMORY={'at':0.0,'payload':None}
MARKET_ACTION_FEEDS=[
    # KRX-linked disclosure stream. Pages are walked backwards so a fresh install
    # can reconstruct enough history for 1~10 trading-day boards.
    'https://t.me/s/darthacking',
]

# Regression fixture supplied by the user for 2026-09-16. It is used only when
# the live history is incomplete or disagrees with the verified same-day board.
# Future dates are never populated from this fixture.
MARKET_ACTION_REFERENCE_DATE='2026-09-18'
MARKET_ACTION_REFERENCE={
 'risk_designated':[],
 'halt_preview':[('좋은사람들',10,'투자위험예고')],
 'short_overheat_designated':[('에스엠벡셀',3,'단기과열 지정'),('드림시큐리티',3,'단기과열 지정')],
 'warning_release_judgment':[('엑시콘',10,'투자경고 해제 판단일')],
 'warning_preview_judgment':[],
 'short_preview_judgment':[],
 'warning_designated':[
   ('아이티센피엔에스',1,'투자경고 지정'),('인피니트헬스케어',1,'투자경고 지정'),
   ('샌즈랩',2,'투자경고 지정'),('한국첨단소재',2,'투자경고 지정'),('빛과전자',2,'투자경고 지정'),
   ('카티스',2,'투자경고 지정'),('타이거일렉',2,'투자경고 지정'),
   ('피에스케이홀딩스',3,'투자경고 지정'),('페니트리움바이오',4,'투자경고 지정'),
   ('키다리스튜디오',6,'투자경고 지정'),('테스',6,'투자경고 지정'),('서산',6,'투자경고 지정'),
   ('티에스이',6,'투자경고 지정'),('아이앤씨',7,'투자경고 지정'),('피델릭스',7,'투자경고 지정'),
   ('파두',8,'투자경고 지정')],
 'warning_preview':[
   ('아티스트컴퍼니',1,'투자경고 지정예고'),('한켐',1,'투자경고 지정예고'),
   ('미투온',1,'투자경고 지정예고'),('에이치엠넥스',1,'투자경고 지정예고'),('큐라티스',1,'투자경고 지정예고'),
   ('인텍플러스',2,'투자경고 지정예고'),
   ('한국첨단소재',3,'투자경고 지정예고'),('광전자',3,'투자경고 지정예고'),('삼익제약',3,'투자경고 지정예고'),
   ('카티스',4,'투자경고 지정예고'),('에스투더블유',4,'투자경고 지정예고'),
   ('알파칩스',5,'투자경고 지정예고'),('마이크로컨텍솔',5,'투자경고 지정예고'),
   ('테라뷰',6,'투자경고 지정예고'),('씨싸이트',6,'투자경고 지정예고'),
   ('신스틸',7,'투자경고 지정예고'),('삼미금속',7,'투자경고 지정예고'),('키다리스튜디오',7,'투자경고 지정예고'),
   ('유진테크',9,'투자경고 지정예고'),('삼익제약',9,'투자경고 지정예고'),('좋은사람들',9,'투자경고 지정예고')],
 'short_overheat_preview':[
   ('인벤테라',1,'단기과열 지정예고'),('동국산업',1,'단기과열 지정예고'),
   ('한컴위드',2,'단기과열 지정예고'),('지니언스',2,'단기과열 지정예고'),
   ('아이티센피엔에스',2,'단기과열 지정예고'),('인피니트헬스케어',2,'단기과열 지정예고'),
   ('아티스트컴퍼니',3,'단기과열 지정예고'),('라온시큐어',3,'단기과열 지정예고'),
   ('에스피소프트',4,'단기과열 지정예고'),('샌즈랩',4,'단기과열 지정예고'),
   ('에스투더블유',4,'단기과열 지정예고'),('엑스게이트',4,'단기과열 지정예고'),
   ('피아이이',5,'단기과열 지정예고'),('범한퓨얼셀',5,'단기과열 지정예고'),
   ('우리로',5,'단기과열 지정예고'),('엑스비스',5,'단기과열 지정예고'),
   ('우리기술',6,'단기과열 지정예고'),('씨싸이트',7,'단기과열 지정예고'),
   ('오르비텍',7,'단기과열 지정예고'),('한전기술',7,'단기과열 지정예고'),('라온피플',9,'단기과열 지정예고')]
}

# 2026-09-18 TODAY REPORT is the verified baseline.
# From the next trading day onward these rows roll forward automatically as event anchors.
MARKET_ACTION_VERIFIED_ADDITIONS={}

def _prev_trade_day(d):
    cur=d-timedelta(days=1)
    while not _is_trade_day(cur): cur-=timedelta(days=1)
    return cur

def _notice_date_from_asof_day(asof_text,day_no):
    """Reverse the board's trading-day counter back to the source notice date.

    A notice published on D becomes day-1 on the next trading day.
    """
    try:
        asof=datetime.strptime(str(asof_text),'%Y-%m-%d').date()
        n=max(1,int(day_no))
    except Exception:return ''
    day1=asof
    # Move backwards through trading days until we reach the day-1 session.
    left=n-1
    while left>0:
        day1=_prev_trade_day(day1);left-=1
    return _prev_trade_day(day1).isoformat()

def _verified_market_action_seed_rows():
    rows=[]
    # Promote the manually verified 09/16 board into durable event history.
    event_cats={'risk_designated','short_overheat_designated',
                'warning_designated','warning_preview','short_overheat_preview'}
    for cat,items in MARKET_ACTION_REFERENCE.items():
        if cat not in event_cats: continue
        for name,day,title in items:
            rows.append({'name':name,'code':_stock_code_by_name(name),
                         'date':_notice_date_from_asof_day(MARKET_ACTION_REFERENCE_DATE,day),
                         'title':title,'category':cat,'url':'','verified_seed':True})
    # Add later user-verified new notices. Day counters will roll forward automatically.
    for asof,groups in MARKET_ACTION_VERIFIED_ADDITIONS.items():
        for cat,items in groups.items():
            for name,day,title in items:
                rows.append({'name':name,'code':_stock_code_by_name(name),
                             'date':_notice_date_from_asof_day(asof,day),
                             'title':title,'category':cat,'url':'','verified_seed':True})
    return rows

def _strip_html_text(x):
    import html as _html
    x=re.sub(r'(?i)<br\s*/?>','\n',str(x or ''))
    x=re.sub(r'<[^>]+>',' ',x)
    x=_html.unescape(x)
    x=x.replace('\xa0',' ')
    x=re.sub(r'[ \t]+',' ',x)
    x=re.sub(r'\n\s+','\n',x)
    return x.strip()

def _kind_link_from_block(block):
    import html as _html
    for m in re.finditer(r'href=["\']([^"\']+)["\']',block or '',re.I):
        u=_html.unescape(m.group(1))
        if 'kind.krx.co.kr/common/disclsviewer.do' in u:
            return u.replace('&amp;','&')
    m=re.search(r'https://kind\.krx\.co\.kr/common/disclsviewer\.do\?[^\s<"\']+',block or '',re.I)
    return _html.unescape(m.group(0)).replace('&amp;','&') if m else ''

def _market_action_category(title):
    """Normalize KIND market-action notice titles into state-transition events."""
    t=re.sub(r'\s+','',str(title or ''))
    # 투자경고
    if '투자경고종목' in t:
        if '해제' in t or '해제예고' in t or '지정해제' in t:
            return 'warning_release'
        if '지정예고' in t or '재지정예고' in t:
            return 'warning_preview'
        if '지정' in t and '예고' not in t:
            return 'warning_designated'
    # 투자위험
    if '투자위험종목' in t:
        if '해제' in t or '지정해제' in t:
            return 'risk_release'
        if '지정예고' in t or '재지정예고' in t:
            return 'risk_preview'
        if '지정' in t and '예고' not in t:
            return 'risk_designated'
    # 매매거래정지 예고/발동
    if '매매거래정지' in t:
        if '예고' in t:
            return 'halt_preview'
        return 'halt_triggered'
    # 단기과열
    if '단기과열종목' in t or '단기과열' in t:
        if '해제' in t or '종료' in t:
            return 'short_release'
        if '지정예고' in t or ('예고' in t and '지정' in t):
            return 'short_overheat_preview'
        if '지정' in t and '예고' not in t:
            return 'short_overheat_designated'
    return ''


def _market_action_categories(title):
    """Return every state transition represented by one notice title."""
    t=re.sub(r'\s+','',str(title or ''))
    if '투자경고종목' in t and ('지정해제' in t or '해제' in t) and ('재지정예고' in t or '재지정' in t):
        return ['warning_release','warning_preview']
    if '투자위험종목' in t and ('지정해제' in t or '해제' in t) and ('재지정예고' in t or '재지정' in t):
        return ['risk_release','risk_preview']
    one=_market_action_category(title)
    return [one] if one else []


# Korean exchange holidays that matter to this build. Weekends are handled separately.
# The list is deliberately data-driven so it can be extended without touching search logic.
KRX_HOLIDAYS_2026={
    '2026-01-01','2026-02-16','2026-02-17','2026-02-18','2026-03-02','2026-05-05',
    '2026-05-25','2026-08-17','2026-09-24','2026-09-25','2026-09-28','2026-10-05','2026-10-09','2026-12-25'
}
def _is_trade_day(d):
    return d.weekday()<5 and d.isoformat() not in KRX_HOLIDAYS_2026
def _next_trade_day(d):
    cur=d+timedelta(days=1)
    while not _is_trade_day(cur): cur+=timedelta(days=1)
    return cur

def _market_action_asof_date(now_dt=None):
    """Effective trading-session date for the 주의·경고 board.

    KRX market-action notices are normally published around 20:00 after the close.
    From 20:00 onward the board switches to the next trading session.
    On weekends/holidays it also points at the next trading session.
    """
    now_dt=now_dt or datetime.now(KST)
    d=now_dt.date()
    if not _is_trade_day(d):
        cur=d
        while not _is_trade_day(cur):
            cur+=timedelta(days=1)
        return cur
    if (now_dt.hour,now_dt.minute)>=(20,0):
        return _next_trade_day(d)
    return d

def _trade_day_no_from_notice(date_text,today=None):
    """KRX notice on D becomes day-1 for the next effective trading session."""
    try: notice=datetime.strptime(date_text,'%Y-%m-%d').date()
    except Exception:return None
    start=_next_trade_day(notice)
    end=today or _market_action_asof_date()
    if start>end:return 0
    cur=start;n=0
    while cur<=end:
        if _is_trade_day(cur):n+=1
        cur+=timedelta(days=1)
    return n

def _stock_code_by_name(name):
    target=re.sub(r'\s+','',str(name or '')).upper()
    if not target:return ''
    for x in UNIVERSE:
        if re.sub(r'\s+','',str(x.get('name',''))).upper()==target:
            return str(x.get('code',''))
    return ''

def _load_market_action_history():
    try:
        obj=json.loads(MARKET_ACTION_HISTORY.read_text(encoding='utf-8'))
        rows=obj.get('rows',[]) if isinstance(obj,dict) else []
        return rows if isinstance(rows,list) else []
    except Exception:return []

def _save_market_action_history(rows):
    try:
        MARKET_ACTION_HISTORY.parent.mkdir(parents=True,exist_ok=True)
        tmp=MARKET_ACTION_HISTORY.with_suffix('.tmp')
        tmp.write_text(json.dumps({'updated_at':datetime.now(KST).isoformat(),'rows':rows},ensure_ascii=False,indent=2),encoding='utf-8')
        tmp.replace(MARKET_ACTION_HISTORY)
    except Exception:pass

def _parse_market_action_feed(html_text):
    blocks=re.split(r'(?=<div[^>]+class=["\'][^"\']*tgme_widget_message_wrap)',html_text or '',flags=re.I)
    if len(blocks)<=1: blocks=re.split(r'(?=단기과열/투자경고\s*종목\s*현황)',html_text or '',flags=re.I)
    out=[]
    for block in blocks:
        text=_strip_html_text(block)
        if not any(k in text for k in ('투자경고','투자위험','단기과열','매매거래정지')): continue
        name_m=re.search(r'종목명\s*:\s*([^\n]+?)(?=\s*\d{4}-\d{2}-\d{2}\s*:)',text,re.S)
        if not name_m: continue
        name=' '.join(name_m.group(1).split()).strip(' -:')
        kind_url=_kind_link_from_block(block)
        # A row without a real KIND disclosure is not allowed to drive this board.
        if 'kind.krx.co.kr/' not in str(kind_url or ''):
            continue
        for m in re.finditer(r'(\d{4}-\d{2}-\d{2})\s*:\s*([^\n]+)',text):
            d,title=m.group(1),m.group(2).strip()
            title=re.split(r'공시링크\s*:',title,maxsplit=1)[0].strip()
            cats=_market_action_categories(title)
            for cat in cats:
                out.append({'name':name,'code':_stock_code_by_name(name),'date':d,'title':title,'category':cat,'url':kind_url})
    return out

def _telegram_before_cursor(html_text):
    vals=[int(x) for x in re.findall(r'[?&]before=(\d+)',html_text or '')]
    return min(vals) if vals else None

def _fetch_market_action_feed():
    """Fetch enough KRX-linked disclosure history even on a fresh install.

    The prior build read only the newest Telegram page, which made old active states
    disappear and produced wrong day numbers. This version walks older pages and
    stops after enough history has been collected.
    """
    rows=[];seen=set();last_error='';source='https://t.me/s/darthacking';url=source
    for _ in range(12):
        try:
            req=Request(url,headers={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36','Accept-Language':'ko-KR,ko;q=0.9'})
            with urlopen(req,timeout=12) as r:
                raw=r.read(5_000_000);text=_decode_web_bytes(raw,r.headers)
            page=_parse_market_action_feed(text)
            for x in page:
                k=(x.get('name'),x.get('date'),x.get('title'))
                if k not in seen:seen.add(k);rows.append(x)
            # Enough for 10 trading-day boards plus state transitions.
            dates=[x.get('date','') for x in rows if x.get('date')]
            if dates and min(dates) <= (datetime.now(KST).date()-timedelta(days=35)).isoformat():break
            cur=_telegram_before_cursor(text)
            if not cur:break
            nxt=f'{source}?before={cur}'
            if nxt==url:break
            url=nxt
        except Exception as e:
            last_error=str(e);break
    return rows,source,last_error if not rows else ''

def _kind_halt_preview_rows(days=21):
    """Fetch official KIND disclosures whose report title contains '매매거래정지 예고'.

    This collector is intentionally isolated from the existing market-action feed.
    Any KIND layout/network failure returns an empty list and NEVER breaks the
    rest of the market-action board.
    """
    endpoint='https://kind.krx.co.kr/disclosure/details.do'
    end=datetime.now(KST).date()
    start=end-timedelta(days=max(7,int(days or 21)))
    params={
        'method':'searchDetailsSub','forward':'details_sub',
        'currentPageSize':'100','pageIndex':'1','orderMode':'1','orderStat':'D',
        'searchCodeType':'','repIsuSrtCd':'','allRepIsuSrtCd':'','oldSearchCorpName':'',
        'disclosureType':'','disTypevalue':'','reportNm':'매매거래정지 예고','reportCd':'',
        'searchCorpName':'','business':'','marketType':'','kosdaqSegment':'',
        'settlementMonth':'','securities':'','submitOblgNm':'','enterprise':'',
        'reportNmTemp':'','reportNmPop':'','bfrDsclsType':'on',
        'fromDate':start.isoformat(),'toDate':end.isoformat(),
    }
    for cat in ('01','02','03','04','05','06','07','08','09','10','11','13','14','20'):
        params[f'disclosureType{cat}']=''
        params[f'pDisclosureType{cat}']=''
    try:
        req=Request(endpoint,data=urlencode(params).encode('utf-8'),headers={
            'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36',
            'Referer':'https://kind.krx.co.kr/disclosure/details.do?method=searchDetailsMain',
            'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8',
            'Accept-Language':'ko-KR,ko;q=0.9,en;q=0.6',
        },method='POST')
        with urlopen(req,timeout=12) as r:
            raw=r.read(5_000_000); html_text=_decode_web_bytes(raw,r.headers)
    except Exception:
        return [],endpoint,''

    rows=[];seen=set()
    # Details result rows are stable: No / time / company / title / submitter (+ chart).
    for tr in re.findall(r'<tr\b[^>]*>(.*?)</tr>',html_text or '',re.I|re.S):
        cells=re.findall(r'<td\b[^>]*>(.*?)</td>',tr,re.I|re.S)
        if len(cells)<5: continue
        time_text=_strip_html_text(cells[1])
        company=_strip_html_text(cells[2])
        title=_strip_html_text(cells[3])
        title_compact=re.sub(r'\s+','',title)
        if '매매거래정지예고' not in title_compact: continue
        # Company cell may include market icon alt text; anchor text is cleaner.
        am=re.search(r'<a\b[^>]*>(.*?)</a>',cells[2],re.I|re.S)
        if am:
            company=_strip_html_text(am.group(1))
        company=' '.join(str(company or '').split()).strip()
        if not company: continue
        # KIND may render YYYY-MM-DD HH:MM or MM-DD HH:MM depending on view.
        dm=re.search(r'(20\d{2})[-./](\d{1,2})[-./](\d{1,2})',time_text)
        if dm:
            d=f'{dm.group(1)}-{int(dm.group(2)):02d}-{int(dm.group(3)):02d}'
        else:
            dm=re.search(r'(\d{1,2})[-./](\d{1,2})',time_text)
            if not dm: continue
            y=end.year
            d=f'{y}-{int(dm.group(1)):02d}-{int(dm.group(2)):02d}'
        acpt=''
        mm=re.search(r"openDisclsViewer\('?(\d{10,})",cells[3],re.I)
        if mm: acpt=mm.group(1)
        url=(f'https://kind.krx.co.kr/common/disclsviewer.do?method=search&acptno={acpt}' if acpt else endpoint)
        key=(company,d,title)
        if key in seen: continue
        seen.add(key)
        rows.append({'name':company,'code':_stock_code_by_name(company),'date':d,
                     'title':title,'category':'halt_preview','url':url,'kind_official':True})
    return rows,endpoint,''

def _latest_family_event(events, cats):
    cand=[x for x in events if x.get('category') in cats]
    if not cand:return None
    return max(cand,key=lambda x:(x.get('date',''),x.get('title','')))

def _today_market_action_groups(rows):
    """Build the existing 9 cards from disclosure-state transitions only."""
    by_stock={}
    for x in rows:
        if not isinstance(x,dict): continue
        name=str(x.get('name','')).strip()
        if name:
            by_stock.setdefault(name,[]).append(x)

    groups={k:[] for k in (
        'risk_designated','halt_preview','short_overheat_designated',
        'warning_release_judgment','warning_preview_judgment','short_preview_judgment',
        'warning_designated','warning_preview','short_overheat_preview')}

    def latest_any(events,cat):
        cand=[x for x in events if x.get('category')==cat]
        return max(cand,key=lambda x:(x.get('date',''),x.get('title',''))) if cand else None
    def newer(a,b):
        return bool(a and (not b or str(a.get('date',''))>str(b.get('date',''))))
    def active_day(x,max_day=10):
        try:n=int((x or {}).get('day_no') or 0)
        except Exception:return False
        return 1<=n<=max_day

    for name,events in by_stock.items():
        events=sorted(events,key=lambda x:(x.get('date',''),x.get('title',''),x.get('category','')))

        # 투자경고: preview -> designation -> release.
        wp=latest_any(events,'warning_preview')
        wd=latest_any(events,'warning_designated')
        wr=latest_any(events,'warning_release')

        # Preview remains active only if no later/equal designation superseded it.
        if wp and active_day(wp,10) and (not wd or str(wp.get('date',''))>str(wd.get('date',''))):
            if int(wp.get('day_no') or 0)==10:
                groups['warning_preview_judgment'].append(wp)
            else:
                groups['warning_preview'].append(wp)

        if wd and active_day(wd,10) and newer(wd,wr):
            if int(wd.get('day_no') or 0)==10:
                groups['warning_release_judgment'].append(wd)
            else:
                groups['warning_designated'].append(wd)

        # 투자위험.
        rd=latest_any(events,'risk_designated')
        rr=latest_any(events,'risk_release')
        if rd and active_day(rd,10) and newer(rd,rr):
            groups['risk_designated'].append(rd)

        # 단기과열: preview -> designation(3 trading sessions) -> release.
        sp=latest_any(events,'short_overheat_preview')
        sd=latest_any(events,'short_overheat_designated')
        sr=latest_any(events,'short_release')

        if sp and active_day(sp,10) and (not sd or str(sp.get('date',''))>str(sd.get('date',''))):
            if int(sp.get('day_no') or 0)==10:
                groups['short_preview_judgment'].append(sp)
            else:
                groups['short_overheat_preview'].append(sp)

        if sd and active_day(sd,3) and newer(sd,sr):
            groups['short_overheat_designated'].append(sd)

        # 거래정지 예고는 누적 상태가 아니라 '다음 거래일 1일 유효' 공시다.
        # 오늘 유효상태판에서는 as-of 거래일의 직전 거래일 20:00 공시만 표시한다.
        # 예: 9/21 20:00 공시 -> 9/22 거래정지 예고 카드에 표시.
        hp=latest_any(events,'halt_preview')
        ht=latest_any(events,'halt_triggered')
        expected_notice_date=_prev_trade_day(_market_action_asof_date()).isoformat()
        if (hp and str(hp.get('date',''))==expected_notice_date
                and (not ht or str(hp.get('date',''))>str(ht.get('date','')))):
            hp=dict(hp)
            hp['day_no']=1
            groups['halt_preview'].append(hp)

    for key,items in groups.items():
        uniq={}
        for x in items:
            uniq[x.get('name','')]=x
        items[:]=sorted(uniq.values(),key=lambda x:(int(x.get('day_no') or 0),x.get('name','')))
    return groups


def _reference_groups_for_today():
    today=datetime.now(KST).date().isoformat()
    if today!=MARKET_ACTION_REFERENCE_DATE:return None
    out={}
    for key,items in MARKET_ACTION_REFERENCE.items():
        out[key]=[]
        for name,day,title in items:
            out[key].append({'name':name,'code':_stock_code_by_name(name),'date':today,'day_no':day,'title':title,'category':key,'url':''})
    return out

def _group_signature(groups):
    return {k:[(x.get('name',''),int(x.get('day_no') or 0)) for x in v] for k,v in (groups or {}).items()}

def _hydrate_market_action_links(groups, history_rows=None):
    """Fill missing stock codes/KIND source links without changing market-action membership."""
    history_rows=history_rows or []
    exact={}
    any_by_name={}
    # history is normally newest first; keep the first usable KIND link.
    for r in history_rows:
        if not isinstance(r,dict): continue
        name=str(r.get('name','')).strip(); cat=str(r.get('category','')).strip(); url=str(r.get('url','')).strip()
        if not name or 'kind.krx.co.kr/' not in url: continue
        exact.setdefault((name,cat),url)
        any_by_name.setdefault(name,url)
    for cat,items in (groups or {}).items():
        for x in items or []:
            if not isinstance(x,dict): continue
            name=str(x.get('name','')).strip()
            if not x.get('code') and name:
                x['code']=_stock_code_by_name(name)
            url=str(x.get('url','')).strip()
            if 'kind.krx.co.kr/' not in url and name:
                # Same market-action category is preferred. A same-company KIND notice is only
                # a secondary fallback; the browser still has a company-summary fallback by code.
                x['url']=exact.get((name,cat),'') or any_by_name.get(name,'')
    return groups

def market_actions_snapshot(force=False):
    now=time.time()
    with LOCK:
        cached=MARKET_ACTION_MEMORY.get('payload')
        if cached and not force and now-float(MARKET_ACTION_MEMORY.get('at',0))<MARKET_ACTION_CACHE_TTL:
            cached['groups']=_hydrate_market_action_links(cached.get('groups',{}),_load_market_action_history())
            return cached

    fresh,source_url,error=_fetch_market_action_feed()
    previous=_load_market_action_history()
    # Remove only the old synthetic halt-preview seed; real collected rows stay intact.
    previous=[x for x in previous if not (isinstance(x,dict) and x.get('category')=='halt_preview' and x.get('verified_seed'))]
    try:
        halt_rows,halt_source_url,halt_error=_kind_halt_preview_rows()
    except Exception as e:
        halt_rows=[];halt_source_url='https://kind.krx.co.kr/';halt_error=str(e)

    merged={}
    # Existing feed remains primary. Official halt-preview rows are additive only.
    for x in previous+fresh+halt_rows:
        if not isinstance(x,dict): continue
        key=(x.get('name',''),x.get('date',''),x.get('category',''),x.get('title',''))
        if not key[0] or not key[1] or not key[2]: continue
        merged[key]={**x,'code':x.get('code') or _stock_code_by_name(x.get('name',''))}

    asof=_market_action_asof_date()
    cutoff=asof-timedelta(days=60)
    rows=[]
    for x in merged.values():
        try:d=datetime.strptime(str(x.get('date','')),'%Y-%m-%d').date()
        except Exception:continue
        if d<cutoff: continue
        x=dict(x)
        x['day_no']=_trade_day_no_from_notice(x['date'],today=asof)
        rows.append(x)

    rows.sort(key=lambda x:(x.get('date',''),x.get('name',''),x.get('category','')),reverse=True)
    if fresh or halt_rows:
        _save_market_action_history(rows)

    groups=_today_market_action_groups(rows)
    groups=_hydrate_market_action_links(groups,rows)

    payload={
        'groups':groups,
        'updated_at':datetime.now(KST).isoformat(),
        'source':'KRX/KIND 연결 공시 자동 상태판',
        'source_url':source_url or 'https://kind.krx.co.kr/',
        'halt_source':'KIND 공식 상세검색' if halt_rows else 'KIND 직접조회 대기/폴백',
        'halt_source_url':halt_source_url,
        'halt_source_error':halt_error or None,
        'error':None if fresh else (error or '실시간 공시 조회 실패 · 마지막 저장 이력으로 표시'),
        'day_basis':'20:00 이전=당일 장 기준 · 20:00 이후=다음 거래일 기준 · 공시 다음 거래일=1일차',
        'mode':'market_action_live_session',
        'asof_trade_date':asof.isoformat(),
        'verification':{'static_reference_used':False,'fresh_rows':len(fresh),'kind_halt_rows':len(halt_rows)}
    }
    with LOCK:
        MARKET_ACTION_MEMORY['at']=now
        MARKET_ACTION_MEMORY['payload']=payload
    return payload


class _NaverFinanceNewsParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.rows=[]; self.row=None; self.td_class=''; self.in_a=False; self.a_href=''; self.a_title=''; self.buf=[]
    def handle_starttag(self,tag,attrs):
        a=dict(attrs)
        if tag=='tr': self.row={'title':'','publisher':'','time':'','url':''}
        elif self.row is not None and tag=='td': self.td_class=a.get('class','') or ''
        elif self.row is not None and tag=='a':
            href=a.get('href','') or ''
            if 'news_read.naver' in href:
                self.in_a=True; self.a_href=href; self.a_title=a.get('title','') or ''; self.buf=[]
    def handle_data(self,data):
        if self.row is None: return
        t=' '.join(str(data).split())
        if not t: return
        if self.in_a: self.buf.append(t)
        elif 'info' in self.td_class: self.row['publisher']=(self.row.get('publisher','')+' '+t).strip()
        elif 'date' in self.td_class: self.row['time']=(self.row.get('time','')+' '+t).strip()
    def handle_endtag(self,tag):
        if tag=='a' and self.in_a:
            title=' '.join(self.buf).strip() or self.a_title.strip()
            if title:
                self.row['title']=title; self.row['url']=urljoin('https://finance.naver.com',self.a_href)
            self.in_a=False; self.a_href=''; self.a_title=''; self.buf=[]
        elif tag=='td': self.td_class=''
        elif tag=='tr':
            if self.row and self.row.get('title') and self.row.get('url'): self.rows.append(self.row)
            self.row=None; self.td_class=''

def _decode_web_bytes(raw, headers=None):
    """Decode Korean legacy pages without failing the whole news request."""
    candidates=[]
    try:
        if headers is not None and hasattr(headers,'get_content_charset'):
            c=headers.get_content_charset()
            if c: candidates.append(c)
    except Exception:
        pass
    candidates += ['euc-kr','cp949','utf-8']
    seen=set()
    for enc in candidates:
        if not enc or enc.lower() in seen: continue
        seen.add(enc.lower())
        try: return raw.decode(enc)
        except Exception: pass
    return raw.decode('utf-8','replace')


def _canonical_naver_news_url(href):
    """Convert Naver Finance redirect URLs to the canonical Naver News article URL.
    This avoids finance.news_read redirect/cluster mismatches where a displayed headline
    can open a different related article.
    """
    u=urljoin('https://finance.naver.com', str(href or ''))
    try:
        q=parse_qs(urlparse(u).query)
        oid=(q.get('office_id') or q.get('oid') or [''])[0]
        aid=(q.get('article_id') or q.get('aid') or [''])[0]
        if oid and aid:
            return f'https://n.news.naver.com/mnews/article/{oid}/{aid}'
    except Exception:
        pass
    return u

class _NaverSearchNewsParser(HTMLParser):
    """Extract direct publisher links from Naver News search results.
    Naver's markup changes over time, so this parser intentionally accepts both the
    legacy news_tit class and newer anchors carrying a title attribute with http links.
    """
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.rows=[]
    def handle_starttag(self,tag,attrs):
        if tag!='a': return
        a=dict(attrs); href=(a.get('href') or '').strip(); title=(a.get('title') or '').strip()
        cls=(a.get('class') or '')
        if not href.startswith('http'): return
        if 'news_tit' in cls and title:
            self.rows.append({'title':title,'publisher':'','time':'','url':href})

def _fetch_naver_search_news(stock_name, limit):
    """Fallback source with direct article URLs, not an intermediate RSS redirect."""
    q=quote_plus(f'"{stock_name}" 주식')
    url=f'https://search.naver.com/search.naver?where=news&query={q}&sort=1'
    req=Request(url,headers={
        'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36',
        'Accept-Language':'ko-KR,ko;q=0.9',
    })
    with urlopen(req,timeout=8) as r:
        raw=r.read(); headers=r.headers
    text=_decode_web_bytes(raw,headers)
    parser=_NaverSearchNewsParser(); parser.feed(text)
    out=[]; seen=set()
    for row in parser.rows:
        title=' '.join(str(row.get('title','')).split()).strip()
        href=(row.get('url') or '').strip()
        if not title or not href or title in seen: continue
        seen.add(title); out.append({'title':title,'publisher':'','time':'','url':href})
        if len(out)>=limit: break
    return out,url


def _fetch_naver_finance_news(c, limit):
    """Primary source. Naver Finance markup may change, so callers must have a fallback."""
    url=f'https://finance.naver.com/item/news_news.naver?code={c}&page=1&sm=title_entity_id.basic&clusterId='
    req=Request(url,headers={
        'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36',
        'Accept-Language':'ko-KR,ko;q=0.9',
        'Referer':f'https://finance.naver.com/item/main.naver?code={c}',
    })
    with urlopen(req,timeout=8) as r:
        raw=r.read(); headers=r.headers
    text=_decode_web_bytes(raw,headers)
    parser=_NaverFinanceNewsParser(); parser.feed(text)
    seen=set(); rows=[]
    for row in parser.rows:
        title=re.sub(r'\s+',' ',row.get('title','')).strip()
        if not title or title in seen: continue
        seen.add(title)
        rows.append({
            'title':title,
            'publisher':row.get('publisher','').strip(),
            'time':row.get('time','').strip(),
            'url':_canonical_naver_news_url(row.get('url',''))
        })
        if len(rows)>=limit: break
    return rows,url


def _news_name_aliases(stock_name):
    """Return conservative aliases for headline matching.
    Exact stock name is primary. Only preferred-share suffixes are relaxed so
    삼성전자우 can still match 삼성전자 headlines; generic group-name expansion is avoided.
    """
    n=' '.join(str(stock_name or '').split()).strip()
    if not n: return []
    aliases=[n]
    # Preferred-share names commonly use the ordinary-share company name in headlines.
    for suffix in ('우B','우C','우'):
        if n.endswith(suffix) and len(n)>len(suffix)+1:
            base=n[:-len(suffix)].strip()
            if base and base not in aliases: aliases.append(base)
            break
    # Compare both literal and whitespace-free forms, but do not broaden to group names.
    out=[]
    for a in aliases:
        for v in (a, re.sub(r'\s+','',a)):
            if v and v not in out: out.append(v)
    return out


def _headline_matches_stock(title, stock_name):
    """Strict relevance gate: headline must explicitly name the stock/company."""
    t=' '.join(str(title or '').split()).strip()
    if not t: return False
    t_compact=re.sub(r'\s+','',t).lower()
    for alias in _news_name_aliases(stock_name):
        a=re.sub(r'\s+','',alias).lower()
        if a and a in t_compact:
            return True
    return False


def _filter_stock_news_rows(rows, stock_name, limit):
    seen=set(); out=[]
    for row in rows or []:
        title=' '.join(str(row.get('title','')).split()).strip()
        if not _headline_matches_stock(title, stock_name):
            continue
        key=re.sub(r'[^0-9a-z가-힣]+','',title.lower())
        if not key or key in seen: continue
        seen.add(key)
        x=dict(row); x['title']=title; x['exact_match']=True
        out.append(x)
        if len(out)>=limit: break
    return out


def _fetch_google_news_rss(stock_name, limit):
    """No-key fallback. Query and results are both restricted to the exact stock/company name."""
    q=quote_plus(f'"{stock_name}" (주식 OR 증권 OR 코스피 OR 코스닥)')
    url=f'https://news.google.com/rss/search?q={q}&hl=ko&gl=KR&ceid=KR:ko'
    req=Request(url,headers={
        'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36',
        'Accept-Language':'ko-KR,ko;q=0.9',
    })
    with urlopen(req,timeout=8) as r:
        raw=r.read()
    root=ET.fromstring(raw)
    rows=[]; seen=set()
    for item in root.findall('.//item'):
        title=' '.join((item.findtext('title') or '').split()).strip()
        link=(item.findtext('link') or '').strip()
        source_el=item.find('source')
        publisher=(' '.join((source_el.text or '').split()).strip() if source_el is not None else '')
        pub=(item.findtext('pubDate') or '').strip()
        when=pub
        try:
            dt=parsedate_to_datetime(pub)
            if dt is not None:
                if dt.tzinfo is not None: dt=dt.astimezone(KST)
                when=dt.strftime('%Y.%m.%d %H:%M')
        except Exception:
            pass
        # Google often appends " - publisher" to the title; remove only when it exactly matches source.
        if publisher and title.endswith(' - '+publisher):
            title=title[:-(len(publisher)+3)].strip()
        if not title or not link or title in seen: continue
        seen.add(title)
        rows.append({'title':title,'publisher':publisher,'time':when,'url':link})
        if len(rows)>=limit: break
    return rows,url


NEWS_FLIGHT=SingleFlight()

def fetch_stock_news(code_value,name='',limit=10):
    return NEWS_FLIGHT.run((str(code_value),str(name),int(limit)),lambda:_fetch_stock_news(code_value,name,limit))

def _fetch_stock_news(code_value,name='',limit=10):
    c=''.join(ch for ch in str(code_value) if ch.isdigit())[:6]
    if len(c)!=6: raise ValueError('종목코드가 올바르지 않습니다.')
    stock_name=(name or LOOKUP.get(c,{}).get('name',c)).strip()
    limit=max(1,min(int(limit),15))
    key=(c,stock_name,limit)
    now=time.time(); cached=NEWS_CACHE.get(key)
    if cached and now-cached.get('ts',0)<NEWS_CACHE_TTL:
        return cached['data']

    errors=[]; rows=[]; source=''; source_url=''
    # 1) Naver Finance stock-code page, then strict headline relevance filter.
    try:
        raw_rows,source_url=_fetch_naver_finance_news(c,max(limit*3,20))
        rows=_filter_stock_news_rows(raw_rows,stock_name,limit)
        if rows: source='네이버 금융 · 종목명 정확일치'
        elif raw_rows: errors.append('네이버 금융: 종목명 정확일치 기사 0건')
        else: errors.append('네이버 금융: 기사 0건')
    except Exception as e:
        errors.append('네이버 금융: '+str(e))

    # 2) Naver News search fallback. This returns direct publisher/article links.
    if not rows:
        try:
            raw_rows,source_url=_fetch_naver_search_news(stock_name,max(limit*3,20))
            rows=_filter_stock_news_rows(raw_rows,stock_name,limit)
            if rows: source='네이버 뉴스검색 · 종목명 정확일치'
            elif raw_rows: errors.append('네이버 뉴스검색: 종목명 정확일치 기사 0건')
            else: errors.append('네이버 뉴스검색: 기사 0건')
        except Exception as e:
            errors.append('네이버 뉴스검색: '+str(e))

    # 3) Google News RSS is title discovery only. Google RSS article URLs can be
    # opaque/intermediate redirects, so each item opens an exact-headline news search
    # instead of risking a mismatched article.
    if not rows:
        try:
            raw_rows,source_url=_fetch_google_news_rss(stock_name,max(limit*3,20))
            raw_rows=_filter_stock_news_rows(raw_rows,stock_name,max(limit*3,20))
            safe=[]
            for row in raw_rows:
                x=dict(row)
                exact='"'+x.get('title','')+'"'
                x['url']='https://search.naver.com/search.naver?where=news&query='+quote_plus(exact)
                x['link_mode']='headline_search'
                safe.append(x)
            rows=safe[:limit]
            if rows: source='Google 뉴스 제목확인 · 정확 제목검색 연결'
            elif raw_rows: errors.append('Google 뉴스: 종목명 정확일치 기사 0건')
            else: errors.append('Google 뉴스: 기사 0건')
        except Exception as e:
            errors.append('Google 뉴스: '+str(e))

    # Always keep a direct search link available.
    naver_search=f'https://search.naver.com/search.naver?where=news&query={quote_plus('\"'+stock_name+'\" 주식')}'
    data={
        'code':c,
        'name':stock_name,
        'rows':rows,
        'source':source or '뉴스 검색',
        'source_url':source_url or naver_search,
        'search_url':naver_search,
        'updated_at':datetime.now(KST).isoformat(),
        'error':None if rows else ('뉴스 목록 조회 실패 · '+' / '.join(errors))
    }
    NEWS_CACHE[key]={'ts':time.time(),'data':data}
    while len(NEWS_CACHE)>256:
        NEWS_CACHE.pop(next(iter(NEWS_CACHE)),None)
    return data


# Kiwoom credentials are stored only on this Windows user account.
# App Key + Secret Key are encrypted together with Windows DPAPI.
# A legacy reader is kept so older LITTO credential files migrate automatically.
def _user_data_dir():
    base=os.getenv('LOCALAPPDATA')
    if base:
        return Path(base)/'LITTO'
    return ROOT/'data'

CREDENTIAL_DIR=_user_data_dir()
CREDENTIAL_FILE=CREDENTIAL_DIR/'kiwoom_credentials.dat'
LEGACY_CREDENTIAL_FILE=CREDENTIAL_DIR/'kiwoom_credentials.json'
REGISTRY_PATH=r'Software\LITTO'
REGISTRY_VALUE='KiwoomCredentials'
CREDENTIAL_LAST_ERROR=''
CREDENTIAL_BACKEND=''
CREDENTIAL_SAVED=False
CREDENTIAL_PS_FILE=CREDENTIAL_DIR/'kiwoom_credentials_ps.dat'
AUTOLOGIN_VERSION='AUTOLOGIN v4'


class _DATA_BLOB(ctypes.Structure):
    _fields_=[('cbData',ctypes.c_ulong),('pbData',ctypes.POINTER(ctypes.c_ubyte))]

def _dpapi_api():
    if os.name!='nt':
        raise RuntimeError('자동 저장은 Windows에서만 지원합니다.')
    crypt32=ctypes.WinDLL('crypt32',use_last_error=True)
    kernel32=ctypes.WinDLL('kernel32',use_last_error=True)
    crypt32.CryptProtectData.argtypes=[ctypes.POINTER(_DATA_BLOB),ctypes.c_wchar_p,ctypes.POINTER(_DATA_BLOB),ctypes.c_void_p,ctypes.c_void_p,ctypes.c_ulong,ctypes.POINTER(_DATA_BLOB)]
    crypt32.CryptProtectData.restype=ctypes.c_bool
    crypt32.CryptUnprotectData.argtypes=[ctypes.POINTER(_DATA_BLOB),ctypes.POINTER(ctypes.c_wchar_p),ctypes.POINTER(_DATA_BLOB),ctypes.c_void_p,ctypes.c_void_p,ctypes.c_ulong,ctypes.POINTER(_DATA_BLOB)]
    crypt32.CryptUnprotectData.restype=ctypes.c_bool
    kernel32.LocalFree.argtypes=[ctypes.c_void_p]
    kernel32.LocalFree.restype=ctypes.c_void_p
    return crypt32,kernel32

def _dpapi_protect_bytes(raw):
    crypt32,kernel32=_dpapi_api()
    buf=ctypes.create_string_buffer(raw)
    inp=_DATA_BLOB(len(raw),ctypes.cast(buf,ctypes.POINTER(ctypes.c_ubyte)))
    out=_DATA_BLOB()
    if not crypt32.CryptProtectData(ctypes.byref(inp),'LITTO Kiwoom credentials',None,None,None,0x1,ctypes.byref(out)):
        raise ctypes.WinError(ctypes.get_last_error())
    try:
        return ctypes.string_at(out.pbData,out.cbData)
    finally:
        kernel32.LocalFree(out.pbData)

def _dpapi_unprotect_bytes(raw):
    crypt32,kernel32=_dpapi_api()
    buf=ctypes.create_string_buffer(raw)
    inp=_DATA_BLOB(len(raw),ctypes.cast(buf,ctypes.POINTER(ctypes.c_ubyte)))
    out=_DATA_BLOB();desc=ctypes.c_wchar_p()
    if not crypt32.CryptUnprotectData(ctypes.byref(inp),ctypes.byref(desc),None,None,None,0x1,ctypes.byref(out)):
        raise ctypes.WinError(ctypes.get_last_error())
    try:
        return ctypes.string_at(out.pbData,out.cbData)
    finally:
        kernel32.LocalFree(out.pbData)
        if desc: kernel32.LocalFree(desc)



def _ps_protect_bytes(raw):
    if os.name!='nt':
        raise RuntimeError('PowerShell fallback is Windows only')
    script=r'''$ErrorActionPreference='Stop'
$inputText=[Console]::In.ReadToEnd()
$bytes=[Convert]::FromBase64String($inputText.Trim())
$enc=[Security.Cryptography.ProtectedData]::Protect($bytes,$null,[Security.Cryptography.DataProtectionScope]::CurrentUser)
[Console]::Out.Write([Convert]::ToBase64String($enc))'''
    r=subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-Command',script],input=base64.b64encode(raw).decode('ascii'),text=True,capture_output=True,timeout=15)
    if r.returncode!=0 or not r.stdout.strip():
        raise RuntimeError((r.stderr or 'PowerShell DPAPI protect failed').strip())
    return base64.b64decode(r.stdout.strip())

def _ps_unprotect_bytes(raw):
    if os.name!='nt':
        raise RuntimeError('PowerShell fallback is Windows only')
    script=r'''$ErrorActionPreference='Stop'
$inputText=[Console]::In.ReadToEnd()
$bytes=[Convert]::FromBase64String($inputText.Trim())
$dec=[Security.Cryptography.ProtectedData]::Unprotect($bytes,$null,[Security.Cryptography.DataProtectionScope]::CurrentUser)
[Console]::Out.Write([Convert]::ToBase64String($dec))'''
    r=subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-Command',script],input=base64.b64encode(raw).decode('ascii'),text=True,capture_output=True,timeout=15)
    if r.returncode!=0 or not r.stdout.strip():
        raise RuntimeError((r.stderr or 'PowerShell DPAPI unprotect failed').strip())
    return base64.b64decode(r.stdout.strip())

def _write_autologin_log(message):
    try:
        CREDENTIAL_DIR.mkdir(parents=True,exist_ok=True)
        with (CREDENTIAL_DIR/'autologin.log').open('a',encoding='utf-8') as f:
            f.write(datetime.now(KST).isoformat()+' '+str(message).replace('\n',' ')+'\n')
    except Exception:
        pass

def _legacy_dpapi_unprotect(encoded):
    return _dpapi_unprotect_bytes(base64.b64decode(encoded)).decode('utf-8')

def _registry_write_blob(encrypted):
    if os.name!='nt':
        return False
    import winreg
    key=winreg.CreateKeyEx(winreg.HKEY_CURRENT_USER,REGISTRY_PATH,0,winreg.KEY_SET_VALUE)
    try:
        winreg.SetValueEx(key,REGISTRY_VALUE,0,winreg.REG_SZ,base64.b64encode(encrypted).decode('ascii'))
    finally:
        winreg.CloseKey(key)
    return True

def _registry_read_blob():
    if os.name!='nt':
        return None
    import winreg
    try:
        key=winreg.OpenKey(winreg.HKEY_CURRENT_USER,REGISTRY_PATH,0,winreg.KEY_QUERY_VALUE)
        try:
            value,_=winreg.QueryValueEx(key,REGISTRY_VALUE)
        finally:
            winreg.CloseKey(key)
        return base64.b64decode(value) if value else None
    except FileNotFoundError:
        return None

def _registry_delete_blob():
    if os.name!='nt':
        return
    import winreg
    try:
        key=winreg.OpenKey(winreg.HKEY_CURRENT_USER,REGISTRY_PATH,0,winreg.KEY_SET_VALUE)
        try:
            winreg.DeleteValue(key,REGISTRY_VALUE)
        finally:
            winreg.CloseKey(key)
    except FileNotFoundError:
        pass

def _save_credentials(appkey,secretkey):
    global CREDENTIAL_LAST_ERROR,CREDENTIAL_BACKEND,CREDENTIAL_SAVED
    appkey=str(appkey or '').strip();secretkey=str(secretkey or '').strip()
    if not appkey or not secretkey: raise ValueError('App Key와 Secret Key를 모두 입력하세요.')
    payload=json.dumps({'appkey':appkey,'secretkey':secretkey,'saved_at':datetime.now(KST).isoformat()},ensure_ascii=False).encode('utf-8')
    errors=[];saved=False
    try:
        encrypted=_dpapi_protect_bytes(payload)
        try:
            if _registry_write_blob(encrypted):
                saved=True;CREDENTIAL_BACKEND='Windows 레지스트리(HKCU)+DPAPI'
        except Exception as e: errors.append('registry: '+str(e))
        try:
            CREDENTIAL_DIR.mkdir(parents=True,exist_ok=True)
            tmp=CREDENTIAL_FILE.with_suffix('.tmp');tmp.write_bytes(encrypted);tmp.replace(CREDENTIAL_FILE)
            saved=True
            if not CREDENTIAL_BACKEND:CREDENTIAL_BACKEND='LocalAppData+DPAPI'
        except Exception as e: errors.append('dpapi file: '+str(e))
    except Exception as e:
        errors.append('native dpapi: '+str(e))
    try:
        encrypted_ps=_ps_protect_bytes(payload)
        CREDENTIAL_DIR.mkdir(parents=True,exist_ok=True)
        tmp=CREDENTIAL_PS_FILE.with_suffix('.tmp');tmp.write_bytes(encrypted_ps);tmp.replace(CREDENTIAL_PS_FILE)
        saved=True
        CREDENTIAL_BACKEND=(CREDENTIAL_BACKEND+' + ' if CREDENTIAL_BACKEND else '')+'PowerShell DPAPI'
    except Exception as e:
        errors.append('powershell: '+str(e))
    CREDENTIAL_LAST_ERROR='; '.join(errors)
    _write_autologin_log('SAVE '+('OK '+CREDENTIAL_BACKEND if saved else 'FAIL '+CREDENTIAL_LAST_ERROR))
    CREDENTIAL_SAVED=saved
    if not saved:
        raise RuntimeError(CREDENTIAL_LAST_ERROR or '인증정보 저장 실패')

def _decode_credential_blob(blob):
    raw=json.loads(_dpapi_unprotect_bytes(blob).decode('utf-8'))
    a=str(raw.get('appkey') or '').strip();s=str(raw.get('secretkey') or '').strip()
    return (a,s) if a and s else ('','')

def _load_credentials():
    global CREDENTIAL_LAST_ERROR,CREDENTIAL_BACKEND,CREDENTIAL_SAVED
    CREDENTIAL_LAST_ERROR='';CREDENTIAL_BACKEND=''
    errors=[]
    try:
        blob=_registry_read_blob()
        if blob:
            a,ss=_decode_credential_blob(blob)
            if a and ss:
                CREDENTIAL_BACKEND='Windows 레지스트리(HKCU)+DPAPI';_write_autologin_log('LOAD OK registry');CREDENTIAL_SAVED=True;return a,ss
    except Exception as e: errors.append('registry load: '+str(e))
    try:
        if CREDENTIAL_FILE.exists():
            a,ss=_decode_credential_blob(CREDENTIAL_FILE.read_bytes())
            if a and ss:
                CREDENTIAL_BACKEND='LocalAppData+DPAPI';_write_autologin_log('LOAD OK dpapi file');CREDENTIAL_SAVED=True;return a,ss
    except Exception as e: errors.append('file load: '+str(e))
    try:
        if CREDENTIAL_PS_FILE.exists():
            raw=json.loads(_ps_unprotect_bytes(CREDENTIAL_PS_FILE.read_bytes()).decode('utf-8'))
            a=str(raw.get('appkey') or '').strip();ss=str(raw.get('secretkey') or '').strip()
            if a and ss:
                CREDENTIAL_BACKEND='PowerShell DPAPI';_write_autologin_log('LOAD OK powershell');CREDENTIAL_SAVED=True;return a,ss
    except Exception as e: errors.append('powershell load: '+str(e))
    try:
        if LEGACY_CREDENTIAL_FILE.exists():
            raw=json.loads(LEGACY_CREDENTIAL_FILE.read_text(encoding='utf-8'))
            a=_legacy_dpapi_unprotect(raw.get('appkey',''));ss=_legacy_dpapi_unprotect(raw.get('secretkey',''))
            if a and ss:
                _save_credentials(a,ss);CREDENTIAL_SAVED=True;return a,ss
    except Exception as e: errors.append('legacy load: '+str(e))
    CREDENTIAL_LAST_ERROR='; '.join(errors)
    _write_autologin_log('LOAD NONE '+CREDENTIAL_LAST_ERROR)
    CREDENTIAL_SAVED=False
    return '',''

def _delete_credentials():
    global CREDENTIAL_LAST_ERROR,CREDENTIAL_BACKEND,CREDENTIAL_SAVED
    try:_registry_delete_blob()
    except Exception as e:CREDENTIAL_LAST_ERROR='registry delete: '+str(e)
    for f in (CREDENTIAL_FILE,CREDENTIAL_PS_FILE,LEGACY_CREDENTIAL_FILE):
        try:f.unlink()
        except FileNotFoundError:pass
    CREDENTIAL_BACKEND=''
    CREDENTIAL_SAVED=False

def _startup_auto_connect():
    """Restore the Kiwoom session before the browser opens.

    After one successful live login, the user never needs to type App Key /
    Secret Key again on the same Windows account unless saved credentials are
    explicitly deleted or Kiwoom rejects/revokes them.
    """
    appkey,secretkey=_load_credentials()
    if not appkey or not secretkey:
        return False
    with LOCK:
        if STATE.get('connected') or STATE.get('client'):
            return True
        STATE['progress']='저장된 App Key / Secret Key로 자동 로그인 중...'
    try:
        client=Kiwoom(appkey,secretkey,False)
        client.auth()
        with LOCK:
            STATE.update(client=client,connected=True,mock=False,
                         progress='자동 로그인 성공 · 로그인 유지 · '+(CREDENTIAL_BACKEND or 'DPAPI'),
                         realtime_rank={'rows':[],'daily_rows':[],'updated_at':None,'source':'키움 ka00198 · 2초 확인','daily_source':'키움 ka00198 · 당일 누적','error':None},
                         realtime_rank_prev={})
        _start_daily_stock_master_refresh(client)
        try:
            mapping=sectors.load()
            mapped=sum(1 for v in mapping.values() if v.get('sector') and v.get('sector')!='미분류')
            if mapped < 100 and not STATE.get('sector_busy'):
                threading.Thread(target=sector_sync_worker,daemon=True).start()
        except Exception:
            pass
        start_page1_live_engine()
        return True
    except Exception as e:
        with LOCK:
            STATE.update(client=None,connected=False,
                         progress='자동 로그인 실패 · 저장정보 유지 · '+str(e))
        return False

def _load_candidate_history():
    try:
        raw=json.loads(CANDIDATE_HISTORY.read_text(encoding='utf-8'))
        return raw if isinstance(raw,dict) else {}
    except (OSError,ValueError,TypeError,json.JSONDecodeError):
        return {}

def _save_candidate_history(history):
    CANDIDATE_HISTORY.parent.mkdir(parents=True,exist_ok=True)
    tmp=CANDIDATE_HISTORY.with_suffix('.tmp')
    tmp.write_text(json.dumps(history,ensure_ascii=False,indent=2),encoding='utf-8')
    tmp.replace(CANDIDATE_HISTORY)

def _prior_candidate_snapshots(today, limit=2):
    history=_load_candidate_history()
    dates=sorted((d for d in history if d < today),reverse=True)[:limit]
    out=[]
    for i,d in enumerate(dates,1):
        item=history.get(d) or {}
        out.append({'date':d,'stage':f'D+{i}','stocks':item.get('stocks') or {}})
    return out

def _latest_prior_candidates(today):
    snaps=_prior_candidate_snapshots(today,1)
    return snaps[0] if snaps else {'date':None,'stage':'D+1','stocks':{}}

def _save_today_candidates(report, day):
    panels=((report or {}).get('search_panels') or {}).get('panels') or {}
    stocks={}
    for panel_name in ('주도주 종배','주도주 상따','끼도주 종배'):
        for row in (panels.get(panel_name) or {}).get('rows',[]):
            c=code(row.get('code'))
            rec=stocks.setdefault(c,{'code':c,'name':row.get('name') or c,'sector':row.get('sector') or '미분류','tags':[]})
            if panel_name not in rec['tags']:rec['tags'].append(panel_name)
            # Save the D-day facts needed for next-day explanation/audit.
            for k in ('price','value_eok','value_rank','change_rank','formula_close','prev_close','open','high','low','today_value','today_limit'):
                if row.get(k) is not None:rec[k]=row.get(k)
    history=_load_candidate_history()
    history[day]={'date':day,'saved_at':datetime.now(KST).isoformat(),'stocks':stocks}
    # Keep a bounded local history; enough for weekends/holidays and audit.
    for old in sorted(history)[:-260]:history.pop(old,None)
    _save_candidate_history(history)

def recompute():
    sectors.apply(STATE['data'],sectors.load())
    STATE['report']=scan_dataset(STATE['data'],STATE['settings'],STATE['market'])
    STATE['report']['errors']+=STATE['fetch_errors']
    STATE['report']['search_panels']=search_panels.build(STATE['report'],STATE.get('ranks'))

recompute()
_restore_page1_runtime_cache()

# ---------------------------------------------------------------------------
# LIVE 주도주 종배 v1
# Rank membership is refreshed from Kiwoom ka10032 every 2 seconds while price,
# rate and accumulated trading fields are overlaid from domestic WebSocket 0B.
# This is intentionally separate from the normal scanner so the existing search
# result remains a stable audit snapshot.
LIVE_LEADER_LOCK=threading.RLock()
LIVE_LEADER_CACHE={'rank_at':0.0,'rank_rows':[],'payload':None}
LIVE_LEADER_ENGINE={'thread':None,'generation':0,'client_id':None,'started_at':0.0}

def _live_leader_engine_loop(client, generation):
    while True:
        with LIVE_LEADER_LOCK:
            if generation != LIVE_LEADER_ENGINE.get('generation'):
                return
        with LOCK:
            if not STATE.get('connected') or STATE.get('client') is not client:
                return
        try:
            live_leader_snapshot(False)
        except Exception:
            pass
        time.sleep(0.75)

def start_live_leader_engine():
    with LOCK:
        client=STATE.get('client')
        connected=bool(STATE.get('connected'))
    if not client or not connected:
        return False
    cid=id(client)
    with LIVE_LEADER_LOCK:
        t=LIVE_LEADER_ENGINE.get('thread')
        if t and t.is_alive() and LIVE_LEADER_ENGINE.get('client_id')==cid:
            return True
        LIVE_LEADER_ENGINE['generation']=int(LIVE_LEADER_ENGINE.get('generation') or 0)+1
        gen=LIVE_LEADER_ENGINE['generation']
        t=threading.Thread(target=_live_leader_engine_loop,args=(client,gen),daemon=True,name='LITTO-LIVE-LEADER')
        LIVE_LEADER_ENGINE.update(thread=t,client_id=cid,started_at=time.time())
        t.start()
    return True

def stop_live_leader_engine():
    with LIVE_LEADER_LOCK:
        LIVE_LEADER_ENGINE['generation']=int(LIVE_LEADER_ENGINE.get('generation') or 0)+1
        LIVE_LEADER_ENGINE['client_id']=None
        LIVE_LEADER_CACHE['payload']=None
        LIVE_LEADER_CACHE['rank_rows']=[]
        LIVE_LEADER_CACHE['rank_at']=0.0


def _live_num(v, absolute=False):
    try:
        z=float(str(v).replace(',',''))
        return abs(z) if absolute else z
    except (ValueError,TypeError):
        return None


def live_leader_snapshot(force_rank=False):
    with LOCK:
        client=STATE.get('client')
    if not client:
        return {'rows':[],'updated_at':None,'rank_updated_at':None,'source':'키움 미연결',
                'realtime':{'connected':False,'state':'미연결','error':'키움 미연결'},'error':'키움 미연결'}
    now=time.time()
    try:
        with LIVE_LEADER_LOCK:
            rank_at=float(LIVE_LEADER_CACHE.get('rank_at') or 0)
            rank_rows=list(LIVE_LEADER_CACHE.get('rank_rows') or [])
        if force_rank or not rank_rows or now-rank_at>=2.0:
            raw=client.top(30)
            parsed=[]
            from yaksang import excluded_product
            for r in raw:
                c=base_code(r.get('stk_cd',''))
                rk=_live_num(r.get('now_rank'))
                if not c or rk is None or int(rk)>30: continue
                name=(r.get('stk_nm') or r.get('name') or c).strip()
                reason=excluded_product({'name':name,'product_type':r.get('product_type'),
                                         'etf':r.get('etf'),'etn':r.get('etn'),
                                         'leveraged':r.get('leveraged'),'inverse':r.get('inverse')})
                if not reason and ('스팩' in name or 'SPAC' in name.upper()): reason='스팩'
                if reason: continue
                parsed.append({'code':c,'name':name,'rank':int(rk),
                               'price':_live_num(r.get('cur_prc'),True),
                               'change_rate':_live_num(r.get('flu_rt')),
                               'acc_value':_live_num(r.get('trde_prica'),True)})
            parsed.sort(key=lambda x:(x['rank'],x['code']))
            rank_rows=parsed; rank_at=now
            with LIVE_LEADER_LOCK:
                LIVE_LEADER_CACHE['rank_at']=rank_at; LIVE_LEADER_CACHE['rank_rows']=rank_rows
        feed=getattr(client,'_domestic_realtime_feed',None)
        if feed is None:
            feed=DomesticRealtimeFeed(client); client._domestic_realtime_feed=feed
        feed.ensure([x['code'] for x in rank_rows])
        live,rt=feed.snapshot()
        rows=[]
        for base in rank_rows:
            q=live.get(base['code']) or {}
            price=q.get('price') if q.get('price') is not None else base.get('price')
            rate=q.get('change_rate') if q.get('change_rate') is not None else base.get('change_rate')
            acc_value=q.get('acc_value') if q.get('acc_value') is not None else base.get('acc_value')
            # Locked formula B: current close/price change versus previous close >= +1%.
            if rate is None or float(rate)<1.0: continue
            rows.append({**base,'price':price,'change_rate':rate,'acc_value':acc_value,
                         'acc_volume':q.get('acc_volume'),'time':q.get('time'),
                         'live':bool(q),'received_at':q.get('received_at')})
        payload={'rows':rows,'updated_at':datetime.now(KST).isoformat(),
                 'rank_updated_at':datetime.fromtimestamp(rank_at,KST).isoformat() if rank_at else None,
                 'source':'ka10032 통합 거래대금 원순위 TOP30 (2초) + WebSocket 0B 주식체결',
                 'rank_refresh_seconds':2,'realtime':rt,'error':None}
        with LIVE_LEADER_LOCK: LIVE_LEADER_CACHE['payload']=payload
        return payload
    except Exception as e:
        with LIVE_LEADER_LOCK: old=LIVE_LEADER_CACHE.get('payload')
        if old:
            return {**old,'error':'실시간 종배 갱신 실패: '+str(e)}
        return {'rows':[],'updated_at':None,'rank_updated_at':None,'source':'실시간 종배',
                'realtime':{'connected':False,'state':'오류','error':str(e)},'error':str(e)}


# ---------------------------------------------------------------------------
# PAGE 1 realtime engine
#
# Architecture:
#   * Heavy REST scan: startup + every 5 minutes (triggered by the UI)
#   * Candidate/rank refresh: 2 seconds (ka10032 + ka10027)
#   * Price/change/value/open/high/low: Kiwoom WebSocket 0B tick stream
#   * Panel calculation: local memory only; no heavy REST re-scan per tick
#
# This keeps 섹터 수정/설정/other pages responsive while the heavy scan runs.
PAGE1_LIVE_LOCK=threading.RLock()
PAGE1_RECALC_EVENT=threading.Event()
PAGE1_HYDRATE_Q=queue.Queue(maxsize=120)
PAGE1_LIVE_ENGINE={'thread':None,'recalc_thread':None,'hydrate_thread':None,'generation':0,'client_id':None,
                   'rank_at':0.0,'last_tick_at':0.0,'error':'','state':'대기','hydrating':set(),
                   'data_version':0,'recalc_version':0,'last_recalc_at':0.0,
                   'last_heavy_at':0.0,'next_heavy_at':0.0,'heavy_count':0,
                   'market_phase':'CLOSED','candidate_count':0}

def _page1_market_phase():
    now=datetime.now(KST)
    if now.weekday()>=5:return 'CLOSED'
    hm=now.hour*60+now.minute
    if hm<510:return 'PRE'          # before 08:30
    if hm<900:return 'REGULAR'      # 08:30~15:00 broad live window
    if hm<1210:return 'AFTER'       # 15:00~20:10 incl. NXT/after hours
    return 'CLOSED'

def _request_page1_recalc():
    with PAGE1_LIVE_LOCK:
        PAGE1_LIVE_ENGINE['data_version']=int(PAGE1_LIVE_ENGINE.get('data_version') or 0)+1
    PAGE1_RECALC_EVENT.set()

def _page1_recalc_loop(client,generation):
    """Coalesced local calculation outside the global state lock."""
    while True:
        with PAGE1_LIVE_LOCK:
            if generation!=PAGE1_LIVE_ENGINE.get('generation'):return
        PAGE1_RECALC_EVENT.wait(0.8)
        if not PAGE1_RECALC_EVENT.is_set():continue
        PAGE1_RECALC_EVENT.clear(); time.sleep(0.12)
        with PAGE1_LIVE_LOCK:version=PAGE1_LIVE_ENGINE.get('data_version',0)
        with LOCK:
            data=copy.deepcopy(STATE.get('data') or {'stocks':[]})
            settings=copy.deepcopy(STATE.get('settings') or {})
            market=STATE.get('market','unknown')
            ranks=copy.deepcopy(STATE.get('ranks') or {})
            errors=copy.deepcopy(STATE.get('fetch_errors') or [])
        try:
            sectors.apply(data,sectors.load())
            report=scan_dataset(data,settings,market)
            report['errors']+=errors
            report['search_panels']=search_panels.build(report,ranks)
        except Exception as e:
            with PAGE1_LIVE_LOCK:PAGE1_LIVE_ENGINE['error']='로컬 패널 계산: '+str(e)[:220]
            continue
        with PAGE1_LIVE_LOCK:
            current=PAGE1_LIVE_ENGINE.get('data_version',0)
        if current!=version:
            PAGE1_RECALC_EVENT.set();continue
        with LOCK:STATE['report']=report
        with PAGE1_LIVE_LOCK:
            PAGE1_LIVE_ENGINE['recalc_version']=version;PAGE1_LIVE_ENGINE['last_recalc_at']=time.time()

def _page1_rank_num(v, absolute=False):
    try:
        z=float(str(v).replace(',',''))
        return abs(z) if absolute else z
    except (ValueError,TypeError):
        return None


def _page1_rank_refresh(client):
    """Refresh only the light candidate/rank lists.  No full historical scan."""
    raw=_kiwoom_call(client.top,50,kind='rank')
    change_rows=_kiwoom_call(client.change_top,100,kind='rank')
    value_rank_map={}; value_top=[]; rank_quotes={}; candidates=[]
    from yaksang import excluded_product
    for r in raw:
        c=base_code(r.get('stk_cd',''))
        rk=_page1_rank_num(r.get('now_rank'))
        if not c or rk is None: continue
        rk=int(rk)
        value_rank_map[c]=rk
        value_top.append(c)
        # ka10032 trde_prica is million KRW. 100 million KRW == 1 eok,
        # therefore provider_value / 100 gives the display value in 억원.
        provider_value_million=_page1_rank_num(r.get('trde_prica'),True)
        provider_value_eok=(provider_value_million/100.0) if provider_value_million is not None else None
        rank_quotes[c]={'price':_page1_rank_num(r.get('cur_prc'),True),
                        'change':_page1_rank_num(r.get('flu_rt')),
                        'value_eok':provider_value_eok,
                        'trading_value_million_krw':provider_value_million,
                        'provider_rank':rk,'name':(r.get('stk_nm') or r.get('name') or '').strip(),
                        'source':'ka10032 stex_tp=3 · PAGE1 LIVE'}
        if rk>30: continue
        name=(r.get('stk_nm') or r.get('name') or c).strip()
        reason=excluded_product({'name':name,'product_type':r.get('product_type'),
                                 'etf':r.get('etf'),'etn':r.get('etn'),
                                 'leveraged':r.get('leveraged'),'inverse':r.get('inverse')})
        if not reason and ('스팩' in name or 'SPAC' in name.upper()): reason='스팩'
        if not reason: candidates.append((c,name))
    change_top=[base_code(r.get('stk_cd','')) for r in change_rows if base_code(r.get('stk_cd',''))]
    with LOCK:
        ranks=STATE.get('ranks') or {}
        ranks['value_top']=value_top
        ranks['value_rank_map']=value_rank_map
        ranks['rank_quotes']=rank_quotes
        ranks['change_top']=change_top
        ranks['source']='PAGE1 LIVE · ka10032/ka10027 2초 + 0B 틱'
        STATE['ranks']=ranks
        # Keep visible 거래대금 alive from the authoritative integrated ka10032
        # response even before/while the first WebSocket tick is arriving.
        # The 0B tick overlay below will then replace it with the newest value.
        for st in (STATE.get('data') or {}).get('stocks',[]):
            cc=base_code(st.get('code',''))
            # Keep each loaded/watch stock's provider 거래대금 원순위 in sync.
            # Clearing to None when it leaves TOP50 prevents a stale <=35 rank
            # from incorrectly passing the closing-bet checklist.
            st['value_rank']=value_rank_map.get(cc)
            rv=(rank_quotes.get(cc) or {}).get('value_eok')
            if rv is not None:
                st['value_eok']=rv
                daily=st.get('daily') or []
                if daily and str(daily[-1].get('date',''))[:10]==datetime.now(KST).date().isoformat():
                    daily[-1]['value']=rv*100_000_000.0
    _request_page1_recalc()
    return candidates


def _page1_hydrate_new_candidates(client, candidates):
    """Queue newly-entered candidates; provider calls run on a dedicated worker."""
    with LOCK:existing={base_code(x.get('code','')) for x in STATE.get('data',{}).get('stocks',[])}
    queued=0
    for c,n in candidates:
        if c in existing:continue
        with PAGE1_LIVE_LOCK:
            if c in PAGE1_LIVE_ENGINE['hydrating']:continue
            PAGE1_LIVE_ENGINE['hydrating'].add(c)
        try:
            PAGE1_HYDRATE_Q.put_nowait((c,n));queued+=1
        except queue.Full:
            with PAGE1_LIVE_LOCK:PAGE1_LIVE_ENGINE['hydrating'].discard(c)
            break
    return bool(queued)

def _page1_hydrate_loop(client,generation):
    while True:
        with PAGE1_LIVE_LOCK:
            if generation!=PAGE1_LIVE_ENGINE.get('generation'):return
        try:c,name=PAGE1_HYDRATE_Q.get(timeout=.5)
        except queue.Empty:continue
        try:
            with LOCK:
                if any(base_code(x.get('code',''))==c for x in STATE.get('data',{}).get('stocks',[])):continue
                old_by_code={base_code(x.get('code','')):x for x in STATE.get('data',{}).get('stocks',[])}
            mapping=sectors.load();sec=(mapping.get(c) or {}).get('sector') or '미분류'
            fq=_kiwoom_call(client.quote,c,'SOR',kind='hydrate')
            resolved=(fq.get('name') or name or LOOKUP.get(c,{}).get('name') or c).strip()
            st=_kiwoom_call(client.stock,c,resolved,sec,kind='hydrate')
            st['review']=old_by_code.get(c,{}).get('review',{})
            if c in mapping:st['sector_source']=(mapping[c].get('source','')+' '+mapping[c].get('asof','')).strip()
            with LOCK:
                stocks=STATE.get('data',{}).setdefault('stocks',[])
                if not any(base_code(x.get('code',''))==c for x in stocks):stocks.append(st)
                ranks=STATE.get('ranks') or {};fqmap=ranks.setdefault('formula_quotes',{});qmap=ranks.setdefault('quotes',{})
                fqmap[c]=fq;dq=dict(fq);dq['display_source']='PAGE1 LIVE · 신규후보 비동기 보충 + 0B';qmap[c]=dq
            _request_page1_recalc()
        except Exception as e:
            with PAGE1_LIVE_LOCK:PAGE1_LIVE_ENGINE['error']='신규후보 보충: '+str(e)[:220]
        finally:
            with PAGE1_LIVE_LOCK:PAGE1_LIVE_ENGINE['hydrating'].discard(c)
            PAGE1_HYDRATE_Q.task_done()

def _page1_apply_ticks(client):
    """Overlay WebSocket ticks onto the current candidate pool and recalc panels locally."""
    with LOCK:
        stocks=list(STATE.get('data',{}).get('stocks',[]))
        ranks=STATE.get('ranks') or {}
    codes=[base_code(x.get('code','')) for x in stocks if base_code(x.get('code',''))]
    if not codes:return False,{'connected':False,'state':'후보 대기','subscribed':0,'live_count':0}
    feed=getattr(client,'_domestic_realtime_feed',None)
    if feed is None:
        feed=DomesticRealtimeFeed(client);client._domestic_realtime_feed=feed
    feed.ensure(codes)
    live,rt=feed.snapshot()
    changed=False; now_day=datetime.now(KST).date().isoformat()
    with LOCK:
        fqmap=(STATE.get('ranks') or {}).setdefault('formula_quotes',{})
        qmap=(STATE.get('ranks') or {}).setdefault('quotes',{})
        rqmap=(STATE.get('ranks') or {}).setdefault('rank_quotes',{})
        for st in STATE.get('data',{}).get('stocks',[]):
            c=base_code(st.get('code',''));q=live.get(c)
            if not q: continue
            stamp=float(q.get('received_at') or 0)
            prev=float(st.get('_live_received_at') or 0)
            if stamp<=prev: continue
            st['_live_received_at']=stamp;changed=True
            price=q.get('price');rate=q.get('change_rate')
            # 0B field 14 is million KRW, not KRW. Prefer the explicit normalized
            # field from DomesticRealtimeFeed; keep a compatibility fallback.
            av_krw=q.get('acc_value_krw')
            av_million=q.get('acc_value_million_krw')
            if av_million is None: av_million=q.get('acc_value')
            value_eok=(float(av_krw)/100_000_000.0) if av_krw is not None else ((float(av_million)/100.0) if av_million is not None else None)
            if price is not None: st['price']=price
            if rate is not None: st['change']=rate
            if value_eok is not None: st['value_eok']=value_eok
            daily=st.get('daily') or []
            if daily:
                t=daily[-1]
                if str(t.get('date',''))[:10]==now_day:
                    if price is not None:t['close']=price
                    if q.get('open') is not None:t['open']=q['open']
                    if q.get('high') is not None:t['high']=q['high']
                    if q.get('low') is not None:t['low']=q['low']
                    if av_krw is not None:t['value']=av_krw
                    elif av_million is not None:t['value']=float(av_million)*1_000_000.0
                    if q.get('acc_volume') is not None:t['volume']=q['acc_volume']
            fq=fqmap.setdefault(c,{})
            if price is not None:fq['price']=price
            if rate is not None:fq['change']=rate
            if q.get('open') is not None:fq['open']=q['open']
            dq=qmap.setdefault(c,{})
            if price is not None:dq['price']=price
            if rate is not None:dq['change']=rate
            dq['display_source']='Kiwoom WebSocket 0B 틱 실시간'
            rq=rqmap.setdefault(c,{})
            if price is not None:rq['price']=price
            if rate is not None:rq['change']=rate
        if changed:
            pass
    if changed:_request_page1_recalc()
    return changed,rt


def _page1_start_heavy_scan(client, force=False):
    now=time.time(); phase=_page1_market_phase()
    with PAGE1_LIVE_LOCK:
        due=float(PAGE1_LIVE_ENGINE.get('next_heavy_at') or 0)
        PAGE1_LIVE_ENGINE['market_phase']=phase
    with LOCK:
        busy=bool(STATE.get('busy'));connected=bool(STATE.get('connected'));same=STATE.get('client') is client
        opts=copy.deepcopy(STATE.get('scan_options') or {'scope':'all','limit':100,'watchlist':''})
    if not connected or not same or busy:return False
    if not force and (phase=='CLOSED' or (due and now<due)):return False
    with LOCK:
        if STATE.get('busy'):return False
        STATE.update(busy=True,done=0,total=0,progress='백엔드 5분 자동검색 · 검색 대상 조회 중');STATE['cancel'].clear()
    with PAGE1_LIVE_LOCK:
        PAGE1_LIVE_ENGINE['next_heavy_at']=now+300
    threading.Thread(target=live_worker,args=(opts,),daemon=True,name='LITTO-PAGE1-HEAVY').start()
    return True

def _page1_live_loop(client,generation):
    next_rank=0.0
    while True:
        with PAGE1_LIVE_LOCK:
            if generation!=PAGE1_LIVE_ENGINE.get('generation'):return
        with LOCK:
            if not STATE.get('connected') or STATE.get('client') is not client:return
        try:
            now=time.time(); phase=_page1_market_phase()
            with PAGE1_LIVE_LOCK:PAGE1_LIVE_ENGINE['market_phase']=phase
            # 2-second candidate refresh remains active even while the heavy scanner
            # is running. Provider calls are serialized one request at a time by API_GATE.
            if now>=next_rank and phase!='CLOSED':
                candidates=_page1_rank_refresh(client)
                _page1_hydrate_new_candidates(client,candidates)
                next_rank=now+2.0
                with PAGE1_LIVE_LOCK:
                    PAGE1_LIVE_ENGINE['rank_at']=now;PAGE1_LIVE_ENGINE['candidate_count']=len(candidates)
            _page1_start_heavy_scan(client,False)
            changed,rt=_page1_apply_ticks(client)
            with PAGE1_LIVE_LOCK:
                PAGE1_LIVE_ENGINE['state']='LIVE' if rt.get('connected') else (rt.get('state') or '연결 중')
                PAGE1_LIVE_ENGINE['error']=rt.get('error') or PAGE1_LIVE_ENGINE.get('error','')
                if changed:PAGE1_LIVE_ENGINE['last_tick_at']=time.time()
            time.sleep(.35)
        except Exception as e:
            with PAGE1_LIVE_LOCK:
                PAGE1_LIVE_ENGINE['state']='재시도';PAGE1_LIVE_ENGINE['error']=str(e)[:300]
            time.sleep(1.0)

def start_page1_live_engine():
    with LOCK:client=STATE.get('client');connected=bool(STATE.get('connected'));mode=(STATE.get('data') or {}).get('mode')
    if not client or not connected:return False
    cid=id(client)
    with PAGE1_LIVE_LOCK:
        t=PAGE1_LIVE_ENGINE.get('thread')
        if t and t.is_alive() and PAGE1_LIVE_ENGINE.get('client_id')==cid:return True
        PAGE1_LIVE_ENGINE['generation']=int(PAGE1_LIVE_ENGINE.get('generation') or 0)+1
        gen=PAGE1_LIVE_ENGINE['generation'];now=time.time()
        PAGE1_LIVE_ENGINE.update(client_id=cid,state='시작 중',error='',next_heavy_at=(now+1 if mode!='live' else now+300))
        t=threading.Thread(target=_page1_live_loop,args=(client,gen),daemon=True,name='LITTO-PAGE1-LIVE')
        r=threading.Thread(target=_page1_recalc_loop,args=(client,gen),daemon=True,name='LITTO-PAGE1-RECALC')
        h=threading.Thread(target=_page1_hydrate_loop,args=(client,gen),daemon=True,name='LITTO-PAGE1-HYDRATE')
        PAGE1_LIVE_ENGINE.update(thread=t,recalc_thread=r,hydrate_thread=h)
        t.start();r.start();h.start()
    return True

def stop_page1_live_engine():
    with PAGE1_LIVE_LOCK:
        PAGE1_LIVE_ENGINE['generation']=int(PAGE1_LIVE_ENGINE.get('generation') or 0)+1
        PAGE1_LIVE_ENGINE['client_id']=None;PAGE1_LIVE_ENGINE['state']='중지'
    PAGE1_RECALC_EVENT.set()


def page1_live_status():
    with PAGE1_LIVE_LOCK:
        now=time.time();next_heavy=float(PAGE1_LIVE_ENGINE.get('next_heavy_at') or 0)
        base={'state':PAGE1_LIVE_ENGINE.get('state','대기'),'error':PAGE1_LIVE_ENGINE.get('error',''),
              'rank_refresh_seconds':2,
              'rank_updated_at':datetime.fromtimestamp(PAGE1_LIVE_ENGINE['rank_at'],KST).isoformat() if PAGE1_LIVE_ENGINE.get('rank_at') else None,
              'last_tick_at':datetime.fromtimestamp(PAGE1_LIVE_ENGINE['last_tick_at'],KST).isoformat() if PAGE1_LIVE_ENGINE.get('last_tick_at') else None,
              'last_recalc_at':datetime.fromtimestamp(PAGE1_LIVE_ENGINE['last_recalc_at'],KST).isoformat() if PAGE1_LIVE_ENGINE.get('last_recalc_at') else None,
              'last_heavy_at':datetime.fromtimestamp(PAGE1_LIVE_ENGINE['last_heavy_at'],KST).isoformat() if PAGE1_LIVE_ENGINE.get('last_heavy_at') else None,
              'next_heavy_seconds':max(0,int(next_heavy-now)) if next_heavy else None,
              'heavy_scan_seconds':300,'heavy_count':PAGE1_LIVE_ENGINE.get('heavy_count',0),
              'candidate_count':PAGE1_LIVE_ENGINE.get('candidate_count',0),'hydrating':len(PAGE1_LIVE_ENGINE.get('hydrating') or []),
              'market_phase':PAGE1_LIVE_ENGINE.get('market_phase','CLOSED')}
    with LOCK:
        client=STATE.get('client'); busy=bool(STATE.get('busy'))
    rt={}
    if client:
        try:
            feed=getattr(client,'_domestic_realtime_feed',None)
            if feed:_,rt=feed.snapshot()
        except Exception:pass
    base['busy']=busy;base['realtime']=rt;base['api_gate']=_api_gate_status()
    return base


def snapshot():
    sector_map=sectors.load()
    with LOCK:
        universe=UNIVERSE
        out={k:STATE.get(k) for k in ('report','busy','progress','done','total','connected','mock',
             'sector_busy','sector_progress','sector_done','sector_total')}
    sector_stats=sectors.stats(universe,sector_map) if universe else {'total':0,'mapped':len(sector_map),'manual':sum(str(v.get('source','')).startswith('사용자 직접 지정') for v in sector_map.values()),'missing_count':0,'missing':[]}
    out.update(universe_count=len(universe),sector_count=sector_stats.get('mapped',len(sector_map)),
               sector_stats=sector_stats,page1_live=page1_live_status(),credential_saved=CREDENTIAL_SAVED,
               credential_backend=CREDENTIAL_BACKEND,credential_error=CREDENTIAL_LAST_ERROR,
               autologin_version=AUTOLOGIN_VERSION,
               credential_files={'native':CREDENTIAL_FILE.exists(),'powershell':CREDENTIAL_PS_FILE.exists()})
    return out


def _best_known_stock_name(stock_code,*sources):
    """Return the best non-code stock name already known locally.

    Never performs a provider request.  Ranking popups can therefore repair missing
    names without blocking the 2-second rank loop or the UI thread.
    """
    c=code(stock_code) if stock_code else ''
    if not c:return ''
    def valid(v):
        t=str(v or '').strip()
        return t if t and t!=c and not (t.isdigit() and code(t)==c) else ''
    for src in sources:
        if isinstance(src,dict):
            for k in ('name','stock_name','stk_nm','종목명'):
                v=valid(src.get(k))
                if v:return v
    base=LOOKUP.get(c) or LOOKUP.get(str(c)) or {}
    for k in ('name','stock_name','stk_nm','종목명'):
        v=valid(base.get(k) if isinstance(base,dict) else '')
        if v:
            _cache_stock_name(c,v)
            return v
    # Full-market master/cache is authoritative fallback for stocks that have
    # never appeared in LITTO's own scanner/ranking dataset.
    with STOCK_NAME_LOCK:
        v=valid(STOCK_NAME_CACHE.get(c))
    if v:return v
    # Scanner/live dataset is the next most reliable local source and is already
    # populated for names that may be newer than the bundled universe file.
    with LOCK:
        data=(STATE.get('data') or {})
        report=(STATE.get('report') or {})
    for st in (data.get('stocks') or []):
        try:sc=code(st.get('code')) if st.get('code') else ''
        except Exception:sc=''
        if sc==c:
            v=valid(st.get('name'))
            if v:return v
    for rr in (report.get('results') or []):
        try:rc=code(rr.get('code')) if rr.get('code') else ''
        except Exception:rc=''
        if rc==c:
            v=valid(rr.get('name'))
            if v:return v
    panels=((report.get('search_panels') or {}).get('panels') or {})
    for panel in panels.values():
        for rr in ((panel or {}).get('rows') or []):
            try:rc=code(rr.get('code')) if rr.get('code') else ''
            except Exception:rc=''
            if rc==c:
                v=valid(rr.get('name'))
                if v:return v
    # Do not block the ranking popup.  Queue a one-shot provider lookup and let
    # the next 2-second refresh replace the temporary code with the resolved name.
    _queue_stock_name_lookup(c)
    return c

REALTIME_RANK_FETCH_LOCK=threading.RLock()
REALTIME_DAILY_CACHE={'at':0.0,'rows':[],'updated_at':None,'error':None}
REALTIME_DAILY_TTL=300.0

def realtime_rank_snapshot(force=False):
    """Fetch/cache Kiwoom ka00198 lookup ranking without provider-call bursts.

    The 30-second provider ranking (qry_tp=5) keeps the existing fast refresh.
    The provider's day-cumulative ranking (qry_tp=4) is isolated behind a short
    cache because it changes slowly and must not make a transient failure block
    the live ranking.  No ranking/filtering formula is changed here.
    """
    with LOCK:
        client=STATE.get('client')
        cached=dict(STATE.get('realtime_rank') or {})
    if not client:
        return {'rows':[],'daily_rows':[],'updated_at':None,'source':'키움 ka00198 · 2초 확인','daily_source':'키움 ka00198 · 당일 누적','error':'키움 미연결'}

    # Manual refresh and the 2-second timer can overlap.  Only one provider
    # refresh is allowed at a time; followers re-check the freshly stored cache.
    with REALTIME_RANK_FETCH_LOCK:
        now=datetime.now(KST)
        with LOCK:
            cached=dict(STATE.get('realtime_rank') or {})
        old_at=cached.get('updated_at')
        if not force and old_at:
            try:
                if (now-datetime.fromisoformat(old_at)).total_seconds()<1.5:
                    return cached
            except (ValueError,TypeError):
                pass

        try:
            rows=_kiwoom_call(client.realtime_rank,'5',30,kind='popular')
        except Exception as e:
            if cached:
                cached['error']='조회순위 갱신 실패: '+str(e)
                cached['stale']=True
                try:
                    cached['stale_seconds']=max(0.0,(now-datetime.fromisoformat(cached.get('updated_at'))).total_seconds())
                except Exception:
                    cached['stale_seconds']=None
                return cached
            return {'rows':[],'daily_rows':[],'updated_at':None,
                    'source':'키움 ka00198 · 실시간종목조회순위 · 2초 확인',
                    'daily_source':'키움 ka00198 · 실시간종목조회순위 · 당일 누적',
                    'error':'조회순위 갱신 실패: '+str(e),'stale':True,'stale_seconds':None}

        try:
            rank_sector_map=sectors.load()
        except Exception:
            rank_sector_map={}
        def _rank_sector(c):
            m=(rank_sector_map.get(c) or {}) if isinstance(rank_sector_map,dict) else {}
            s=str((m or {}).get('sector') or '').strip()
            if s:
                return s
            base=(LOOKUP.get(c) or {}) if isinstance(LOOKUP,dict) else {}
            return str((base or {}).get('sector') or '기타').strip() or '기타'

        # qry_tp=4 is provider-calculated day cumulative.  Refreshing this every
        # 2 seconds doubles ka00198 traffic for little benefit, so keep the last
        # successful result for 15 seconds.  If it fails, live qry_tp=5 still
        # updates normally and the previous daily cumulative result is retained.
        now_ts=time.time()
        daily_error=None
        with LOCK:
            daily_rows=list(REALTIME_DAILY_CACHE.get('rows') or [])
            daily_at=float(REALTIME_DAILY_CACHE.get('at') or 0.0)
            daily_updated_at=REALTIME_DAILY_CACHE.get('updated_at')
        if force or not daily_rows or (now_ts-daily_at)>=REALTIME_DAILY_TTL:
            try:
                fresh_daily=_kiwoom_call(client.realtime_rank,'4',30,kind='popular')
                daily_rows=list(fresh_daily or [])
                daily_updated_at=now.isoformat()
                with LOCK:
                    REALTIME_DAILY_CACHE['at']=now_ts
                    REALTIME_DAILY_CACHE['rows']=daily_rows
                    REALTIME_DAILY_CACHE['updated_at']=daily_updated_at
                    REALTIME_DAILY_CACHE['error']=None
            except Exception as e:
                daily_error='당일 누적 갱신 지연: '+str(e)
                with LOCK:
                    REALTIME_DAILY_CACHE['error']=daily_error

        with LOCK:
            prev=dict(STATE.get('realtime_rank_prev') or {})
        current={}
        normalized=[]
        for r in rows:
            c=code(r.get('code')) if r.get('code') else ''
            rank=int(r['rank'])
            previous=prev.get(c) if c else None
            move=(int(previous)-rank) if previous is not None else None
            x=dict(r,code=c,previous_rank=previous,move=move,new=(previous is None))
            x['name']=_best_known_stock_name(c,r)
            x['sector']=_rank_sector(c)
            normalized.append(x)
            if c: current[c]=rank
        normalized_daily=[]
        for r in daily_rows:
            x=dict(r)
            c=code(x.get('code')) if x.get('code') else ''
            x['code']=c
            x['name']=_best_known_stock_name(c,r)
            x['sector']=_rank_sector(c)
            normalized_daily.append(x)
        payload={'rows':normalized,'daily_rows':normalized_daily,'updated_at':now.isoformat(),
                 'daily_updated_at':daily_updated_at,
                 'source':'키움 ka00198 · 실시간종목조회순위 · 2초 확인',
                 'daily_source':'키움 ka00198 · 실시간종목조회순위 · 당일 누적',
                 'daily_error':daily_error,'error':None,'stale':False,'stale_seconds':0.0}
        with LOCK:
            STATE['realtime_rank_prev']=current
            STATE['realtime_rank']=payload
        return payload


MARKET_MOVERS_LOCK=threading.RLock()
MARKET_MOVERS_CACHE={'at':0.0,'payload':None}

def _market_mover_sector(code_value, mapping):
    c=base_code(code_value)
    m=(mapping.get(c) or {}) if isinstance(mapping,dict) else {}
    sector=str(m.get('sector') or '').strip()
    if sector and sector not in {'미분류','기타'}:
        return sector
    base=(LOOKUP.get(c) or {}) if isinstance(LOOKUP,dict) else {}
    sector=str(base.get('sector') or '').strip()
    return sector or '기타'

def market_movers_snapshot(force=False):
    """HTS 0177-style 상승/하락 TOP20 + 상승 TOP20 섹터 그룹핑.

    0177 is the Kiwoom HTS screen number. The REST data source used here is
    ka10027 전일대비등락률상위 with integrated SOR (KRX+NXT), because REST
    does not expose HTS screen numbers directly.
    """
    with LOCK:
        client=STATE.get('client')
    if not client:
        return {
            'up':[],'down':[],'sector_groups':[],'updated_at':None,
            'source':'키움 미연결','error':'키움 API 연결이 필요합니다.'
        }

    now=time.time()
    with MARKET_MOVERS_LOCK:
        cached=MARKET_MOVERS_CACHE.get('payload')
        cached_at=float(MARKET_MOVERS_CACHE.get('at') or 0)
    if not force and cached and now-cached_at < 5.0:
        return cached

    try:
        up=_kiwoom_call(client.change_top_side,'up',20,kind='popular')
        down=_kiwoom_call(client.change_top_side,'down',20,kind='popular')
        mapping=sectors.load()

        def enrich(rows):
            out=[]
            for r in (rows or [])[:20]:
                x=dict(r)
                c=base_code(x.get('code') or '')
                x['code']=c
                x['name']=_best_known_stock_name(c,x)
                x['sector']=_market_mover_sector(c,mapping)
                out.append(x)
            return out

        up=enrich(up)
        down=enrich(down)

        groups={}
        for row in up:
            sector=str(row.get('sector') or '기타').strip() or '기타'
            # multi-tag sectors are grouped under each user-visible sector tag.
            tags=[x.strip() for x in re.split(r'[,;/|]+',sector) if x.strip()]
            if not tags:
                tags=['기타']
            for tag in tags:
                g=groups.setdefault(tag,{'sector':tag,'count':0,'stocks':[],'avg_change':0.0,'max_change':None})
                g['count']+=1
                g['stocks'].append({
                    'rank':row.get('rank'),'code':row.get('code'),'name':row.get('name'),
                    'price':row.get('price'),'change_rate':row.get('change_rate')
                })

        sector_groups=[]
        for g in groups.values():
            vals=[float(x.get('change_rate')) for x in g['stocks'] if x.get('change_rate') is not None]
            g['avg_change']=sum(vals)/len(vals) if vals else None
            g['max_change']=max(vals) if vals else None
            g['stocks'].sort(key=lambda x:(int(x.get('rank') or 999),str(x.get('code') or '')))
            sector_groups.append(g)
        sector_groups.sort(key=lambda g:(-int(g.get('count') or 0),
                                         -(float(g.get('avg_change')) if g.get('avg_change') is not None else -999),
                                         str(g.get('sector') or '')))

        payload={
            'up':up,'down':down,'sector_groups':sector_groups,
            'updated_at':datetime.now(KST).isoformat(),
            'source':'키움 HTS 0177 대응 · 상승/하락 + 거래대금순 · ka10032 통합시세(KRX+NXT) · 5초 캐시',
            'error':None
        }
        with MARKET_MOVERS_LOCK:
            MARKET_MOVERS_CACHE['at']=now
            MARKET_MOVERS_CACHE['payload']=payload
        return payload
    except Exception as e:
        with MARKET_MOVERS_LOCK:
            old=MARKET_MOVERS_CACHE.get('payload')
        if old:
            return {**old,'error':'0177 상승/하락 갱신 실패: '+str(e)}
        return {
            'up':[],'down':[],'sector_groups':[],'updated_at':None,
            'source':'키움 HTS 0177 대응','error':'0177 상승/하락 갱신 실패: '+str(e)
        }

def sector_sync_worker():
    global UNIVERSE,LOOKUP
    try:
        with LOCK:
            client=STATE.get('client');STATE['sector_busy']=True;STATE['sector_progress']='상장 종목 목록 조회 중';STATE['sector_done']=0;STATE['sector_total']=0
        if not client:raise ApiError('먼저 키움 API를 연결하세요.')
        universe=client.universe()
        if not universe:raise ApiError('상장 종목 목록을 가져오지 못했습니다.')
        with LOCK:
            UNIVERSE=universe;LOOKUP={x['code']:x for x in UNIVERSE};STATE['sector_total']=len(universe)
        def prog(done,total,msg):
            with LOCK:
                STATE['sector_done']=done;STATE['sector_total']=total;STATE['sector_progress']=msg
        current=sectors.load()
        # Primary source: Kiwoom's official industry catalogue + constituents.
        # This avoids relying on an external HTML layout. Manual assignments are
        # never overwritten. Naver remains a fallback only for still-missing rows.
        prog(0,len(universe),'키움 업종 자동분류 조회 중')
        official=client.industry_map()
        added=0
        for c,info in official.items():
            old=current.get(c) or {}
            if str(old.get('source','')).startswith('사용자 직접 지정'):
                continue
            if not old.get('sector') or old.get('sector')=='미분류':
                current[c]=info; added+=1
        # Fallback only for stocks Kiwoom did not classify.
        fallback,st=sector_sync.sync(universe,current,workers=6,progress=prog)
        for c,info in fallback.items():
            old=current.get(c) or {}
            if str(old.get('source','')).startswith('사용자 직접 지정'):
                continue
            if not old.get('sector') or old.get('sector')=='미분류':
                current[c]=info; added+=1
        sectors.save(current)
        stats=sectors.stats(universe,current)
        with LOCK:
            sectors.apply(STATE['data'],current);recompute();STATE['sector_progress']=f"자동 섹터 완료 · {stats['mapped']:,}/{stats['total']:,}종목 분류 · 신규 {added:,}개"
    except Exception as e:
        with LOCK:STATE['sector_progress']='섹터 동기화 실패: '+str(e)
    finally:
        with LOCK:STATE['sector_busy']=False

def live_worker(options):
    """Run the three user formulas first, then the Newheart technique analysis.

    Search-core rule: do not mix display values with formula values.
    * value rank: ka10032 stex_tp=3 raw rank preserved; ETF/ETN/leveraged/inverse removed after top-N is fixed
    * change rank: ka10027 stex_tp=3
    * formula change: [일] 1봉전 종가 대비 0봉전 종가 직접 계산; 0봉 현재/open: SOR(_AL)
    * display current/change: same integrated SOR(_AL) quote as the formula (KRX+NXT, including after-market through 20:00)
    """
    collected=[];errors=[]
    try:
        with LOCK:client=STATE['client']
        if not client:raise ApiError('먼저 키움 API를 연결하세요.')
        n=int(options.get('limit',50))
        if n not in (20,50,100,200):raise ValueError('검색 상위 개수는 20/50/100/200입니다.')
        manual=[code(x.strip()) for x in options.get('watchlist','').replace('\n',',').split(',') if x.strip()]
        if len(manual)>200:raise ValueError('관심종목은 최대 200개입니다.')
        today=datetime.now(KST).date().isoformat()
        prior_snapshots=_prior_candidate_snapshots(today,2)
        prior_snapshot=prior_snapshots[0] if prior_snapshots else {'date':None,'stage':'D+1','stocks':{}}
        prior_codes=[]
        for snap in prior_snapshots:
            for c in (snap.get('stocks') or {}):
                if c not in prior_codes: prior_codes.append(c)

        # The three original formulas all start from value-rank top 30.
        # Pull more only for browsing, but never let that alter the locked formula universe.
        value_rows=_kiwoom_call(client.top,max(30,n),kind='heavy')
        change_rows=_kiwoom_call(client.change_top,100,kind='heavy')
        # Preserve Kiwoom's provider RAW integrated trading-value rank exactly.
        # IMPORTANT: ka10032 provides `now_rank`; never re-number rows by response order.
        # The locked formula universe is provider now_rank <= 30.
        raw_value_top=[base_code(r['stk_cd']) for r in value_rows]
        value_top=raw_value_top
        change_top=[base_code(r['stk_cd']) for r in change_rows]

        def _rank_num(v, absolute=False):
            try:
                z=float(str(v).replace(',',''))
                return abs(z) if absolute else z
            except (ValueError,TypeError):
                return None

        value_rank_map={}
        raw_top30_rows=[]
        for r in value_rows:
            c=base_code(r.get('stk_cd',''))
            if not c:
                continue
            provider_rank=_rank_num(r.get('now_rank'))
            if provider_rank is None:
                continue
            provider_rank=int(provider_rank)
            value_rank_map[c]=provider_rank
            if provider_rank <= 30:
                raw_top30_rows.append(r)

        raw_top30_rows.sort(key=lambda r:(value_rank_map.get(base_code(r.get('stk_cd','')),99999),
                                          base_code(r.get('stk_cd',''))))
        # MTS target semantics:
        # 1) First fix the RAW integrated transaction-value ranks 1..30.
        # 2) Only AFTER rank positions are fixed, hide ETF/ETN/SPAC from the search result.
        #    Vacated ranks stay vacant; rank 36+ is never promoted.
        search_codes=[]
        rank_excluded=[]
        for r in raw_top30_rows:
            c=base_code(r.get('stk_cd',''))
            if not c:
                continue
            name=(r.get('stk_nm') or r.get('name') or '').strip()
            from yaksang import excluded_product
            reason=excluded_product({'name':name,'product_type':r.get('product_type'),
                                     'etf':r.get('etf'),'etn':r.get('etn'),
                                     'leveraged':r.get('leveraged'),'inverse':r.get('inverse')})
            upper_name=name.upper()
            if not reason and ('스팩' in name or 'SPAC' in upper_name):
                reason='스팩'
            if reason:
                rank_excluded.append({
                    'code':c,
                    'name':name,
                    'rank':value_rank_map.get(c),
                    'reason':reason,
                })
                continue
            search_codes.append(c)

        rank_quotes={}
        for r in value_rows:
            c=base_code(r.get('stk_cd',''))
            if not c: continue
            rank_quotes[c]={
                'price':_rank_num(r.get('cur_prc'),True),
                'change':_rank_num(r.get('flu_rt')),
                'provider_rank':_rank_num(r.get('now_rank')),
                'name':(r.get('stk_nm') or '').strip(),
                'source':'ka10032 stex_tp=3'
            }

        today_limit_codes=_kiwoom_call(client.limit_codes,False,kind='heavy')
        prev_limit_codes=_kiwoom_call(client.limit_codes,True,kind='heavy')
        rank_data={'value_top':value_top,
                   'value_rank_map':value_rank_map,
                   'rank_excluded':rank_excluded,
                   'change_top':change_top,
                   'today_limit':today_limit_codes,
                   'prev_limit':prev_limit_codes,
                   'quotes':{},'formula_quotes':{},'rank_quotes':rank_quotes,
                   'prior_candidates':prior_snapshot,'prior_candidate_snapshots':prior_snapshots,
                   'source':'MTS 통합 20:00 기준 고정: ka10032 stex_tp=3 now_rank 원순위 1~30 + ka10027 stex_tp=3 + SOR(_AL) 통합 현재가/기준가/시가 + ka10081 _AL 통합 일봉 (KRX+NXT, 애프터마켓 포함)'}

        # Only the locked top-30 universe can pass the three formulas.
        # Extra watchlist stocks are fetched only for diagnosis/chart and cannot create false positives.
        names={base_code(r['stk_cd']):r.get('stk_nm',r['stk_cd']) for r in value_rows}
        targets={c:names.get(c,LOOKUP.get(c,{}).get('name',c)) for c in search_codes}
        # D+1/D+2 techniques must follow saved candidates even if they fell out of today's top-30.
        for snap in prior_snapshots:
            for c,rec in (snap.get('stocks') or {}).items():
                targets[c]=rec.get('name') or LOOKUP.get(c,{}).get('name',names.get(c,c))
        # Today's limit-up list is needed for the '오늘의 상한가' panel, and the
        # previous-session limit-up list is needed for the 약상 candidate panel.
        # Fetching these extra stocks never changes the locked three search formulas,
        # because those formulas still require value-rank A within the original top 30.
        for c in set(today_limit_codes)|set(prev_limit_codes):
            c=base_code(c)
            if c: targets[c]=LOOKUP.get(c,{}).get('name',names.get(c,c))
        for c in manual:targets[c]=LOOKUP.get(c,{}).get('name',names.get(c,c))
        with LOCK:
            old={s['code']:s for s in STATE['data']['stocks']}
            STATE['total']=len(targets)
        # Basic industry fallback: ensure scanned rows do not stay '미분류' just
        # because the user has not run the full-market sector sync yet. Existing
        # user-assigned sectors always win; only missing rows are looked up.
        sector_map=sectors.load()
        sector_map_dirty=False

        for i,(c,name) in enumerate(targets.items(),1):
            if STATE['cancel'].is_set():break
            with LOCK:STATE['progress']=f'{i:,}/{len(targets):,} · {name} 통합 20:00 기준 일봉·현재가 조회'
            try:
                # Resolve the stock name from the provider quote first. Some ranking
                # responses can omit stk_nm; never leave a live row as code-only.
                fq=_kiwoom_call(client.quote,c,'SOR',kind='heavy')
                provider_name=(fq.get('name') or '').strip()
                resolved_name=(provider_name or (name if str(name).strip()!=c else '')
                               or LOOKUP.get(c,{}).get('name') or c)
                old_sector=old.get(c,{}).get('sector')
                mapped=sector_map.get(c) or {}
                base_sector=(old_sector if old_sector and old_sector!='미분류' else mapped.get('sector'))
                if not base_sector or base_sector=='미분류':
                    try:
                        auto_sector=sector_sync.fetch_sector(c)
                    except Exception:
                        auto_sector=None
                    if auto_sector:
                        base_sector=auto_sector
                        sector_map[c]={'sector':auto_sector,'source':'네이버 증권 업종 자동조회','asof':today}
                        sector_map_dirty=True
                stock=_kiwoom_call(client.stock,c,resolved_name,base_sector or '미분류',kind='heavy')
                if c in sector_map:
                    stock['sector_source']=sector_map[c].get('source','')+' '+sector_map[c].get('asof','')
                stock['review']=old.get(c,{}).get('review',{})

                # FORMULA + DISPLAY quote: keep one market basis everywhere.
                # _AL is Kiwoom's integrated KRX+NXT quote; with the current market
                # structure it remains the integrated basis through 20:00, including
                # KRX/NXT after-market activity.  Do not mix an NXT-only display quote
                # into an integrated scanner result.
                rank_data['formula_quotes'][c]=fq
                dq=dict(fq)
                dq['display_source']='통합 SOR(_AL) 원문값 · KRX+NXT · 20:00 애프터마켓 포함'
                rank_data['quotes'][c]=dq
                collected.append(stock)
            except (ApiError,ValueError,KeyError,TypeError) as e:
                errors.append({'code':c,'error':str(e)})
            with LOCK:STATE['done']=i

        if sector_map_dirty:
            sectors.save(sector_map)
        if not collected:
            raise ApiError('조회된 시세가 없습니다. 연결/등록 IP/이용 권한을 확인하세요.')

        # DEV F-zone restore: fetch SOR 3-minute history only for saved D+1/D+2
        # candidates. Other loaded stocks still get a daily fallback F-zone overlay.
        prior_code_set=set(prior_codes)
        if prior_code_set:
            for idx,st in enumerate(collected,1):
                c=base_code(st.get('code',''))
                if c not in prior_code_set:
                    continue
                if STATE['cancel'].is_set():
                    break
                try:
                    with LOCK:
                        STATE['progress']=f"F존 3분봉 조회 · {st.get('name') or c} ({idx}/{len(collected)})"
                    st['m3']=_kiwoom_call(client.minute,c,3,kind='heavy')
                except Exception as e:
                    errors.append({'code':c,'error':'F존 3분봉: '+str(e)})
                    st['m3']=[]

        # A user may edit sectors while this background scan is still running.
        # Re-apply the latest persisted mapping immediately before publishing the
        # new scan result so a stale sector_map loaded at scan start can never
        # overwrite a manual edit.
        try:
            latest_sector_map=sectors.load()
            for st in collected:
                c=base_code(st.get('code',''))
                mapped=latest_sector_map.get(c) or {}
                sec=(mapped.get('sector') or '').strip()
                if sec:
                    st['sector']=sec
                    st['sector_source']=(mapped.get('source','')+' '+mapped.get('asof','')).strip()
        except Exception:
            pass

        now=datetime.now(KST).isoformat()
        new_data={'mode':'import' if client.mock else 'live','asof':now,'stocks':collected,
                  'scope':('키움 모의 서버 · 실제 매매 판단용 아님 · ' if client.mock else '')+
                          '원본 3식 정밀검증 모드: 통합 거래대금 원순위 상위30에서 ETF/ETN/레버리지/인버스 제외 + 관심종목'}
        # CPU-heavy panel calculation is done outside LOCK so sector editing,
        # navigation and journal actions remain responsive during publication.
        calc_data=copy.deepcopy(new_data); sectors.apply(calc_data,sectors.load())
        calc_report=scan_dataset(calc_data,copy.deepcopy(STATE.get('settings') or {}),STATE.get('market','unknown'))
        calc_report['errors']+=errors
        calc_report['search_panels']=search_panels.build(calc_report,rank_data)
        with LOCK:
            STATE['data']=new_data
            STATE['fetch_errors']=errors
            STATE['ranks']=rank_data
            STATE['report']=calc_report

            # --- ka10032 / 주도주 종배 원본 진단 파일 자동 저장 -----------------
            # 검색식은 바꾸지 않는다. 키움이 실제로 준 거래대금 순위와
            # 프로그램의 A/B 판정값을 그대로 파일로 남겨 MTS와 1:1 대조한다.
            try:
                diag_dir=ROOT/'diagnostics'
                diag_dir.mkdir(parents=True,exist_ok=True)

                # 1) ka10032 원문 전체(최대 조회 개수) JSON
                (diag_dir/'KA10032_RAW.json').write_text(
                    json.dumps({
                        'saved_at':datetime.now(KST).isoformat(),
                        'request':{'mrkt_tp':'000','mang_stk_incls':'1','stex_tp':'3'},
                        'rows':value_rows,
                    },ensure_ascii=False,indent=2),
                    encoding='utf-8'
                )

                # 2) 거래대금 순위 1~50 핵심값 CSV
                with (diag_dir/'KA10032_TOP50.csv').open('w',newline='',encoding='utf-8-sig') as f:
                    w=csv.writer(f)
                    w.writerow(['now_rank','code','name','cur_prc','flu_rt','trde_prica','product_type',
                                'etf','etn','leveraged','inverse','top30','search_target'])
                    search_set=set(search_codes)
                    for r in sorted(value_rows,key=lambda z:(value_rank_map.get(base_code(z.get('stk_cd','')),99999),
                                                             base_code(z.get('stk_cd','')))):
                        c=base_code(r.get('stk_cd',''))
                        rk=value_rank_map.get(c)
                        if rk is None or rk>50:
                            continue
                        w.writerow([
                            rk,c,(r.get('stk_nm') or r.get('name') or ''),
                            r.get('cur_prc'),r.get('flu_rt'),r.get('trde_prica'),
                            r.get('product_type'),r.get('etf'),r.get('etn'),
                            r.get('leveraged'),r.get('inverse'),
                            'Y' if rk<=30 else 'N',
                            'Y' if c in search_set else 'N'
                        ])

                # 3) 실제 주도주 종배 A/B 판정 CSV
                diag_rows=((STATE.get('report') or {}).get('search_panels') or {}).get('panels',{}).get('검색 진단',{}).get('rows',[])
                with (diag_dir/'JUDOJOO_DIAG.csv').open('w',newline='',encoding='utf-8-sig') as f:
                    w=csv.writer(f)
                    w.writerow(['value_rank','code','name','prev_close','formula_price','formula_change',
                                'provider_rank_change','provider_sor_change','status','reasons'])
                    for x in diag_rows:
                        w.writerow([
                            x.get('value_rank'),x.get('code'),x.get('name'),
                            x.get('prev_close'),x.get('formula_price'),x.get('formula_change'),
                            x.get('provider_rank_change'),x.get('provider_sor_change'),
                            x.get('status'),' | '.join(x.get('reasons') or [])
                        ])
            except Exception as _diag_e:
                errors.append({'code':'진단파일','error':str(_diag_e)})
            # -------------------------------------------------------------------

            _save_today_candidates(STATE['report'],today)
            try:
                screener_history.save_report(STATE['report'],today,datetime.now(KST).isoformat())
            except Exception as _history_e:
                errors.append({'code':'검색이력','error':str(_history_e)})
            prior_msg=(f" · D+1/D+2 추적 {len(prior_codes)}종목" if prior_codes else ' · 이전 저장 후보 없음')
            STATE['progress']=('중지됨 · 부분 결과 ' if STATE['cancel'].is_set() else '검색 완료 · ')+f'{len(collected):,}종목 / 조회 오류 {len(errors)}개'+prior_msg
    except (ApiError,ValueError,KeyError,TypeError) as e:
        with LOCK:
            STATE['fetch_errors']=errors
            STATE['progress']=str(e)
            if STATE['report']:
                STATE['report']=dict(STATE['report'],errors=STATE['report'].get('errors',[])+errors+[{'code':'검색','error':str(e)}])
    finally:
        with LOCK:STATE['busy']=False
        now_ts=time.time()
        with PAGE1_LIVE_LOCK:
            PAGE1_LIVE_ENGINE['last_heavy_at']=now_ts;PAGE1_LIVE_ENGINE['next_heavy_at']=now_ts+300
            PAGE1_LIVE_ENGINE['heavy_count']=int(PAGE1_LIVE_ENGINE.get('heavy_count') or 0)+1
        _save_page1_runtime_cache()

def journal_import_from_kiwoom(date_text=None):
    """Import one trading day's realized sell P/L into the local journal.

    For review purposes ka10073 (realized P/L) is preferred because it follows
    the sell-side realized result shown by HTS more closely. ka10170 remains a
    fallback when realized-P/L lookup is unavailable.
    """
    client=STATE.get('client')
    if not client: raise ValueError('키움 API 연결이 필요합니다.')
    try:
        dt=datetime.strptime((date_text or datetime.now(KST).date().isoformat())[:10],'%Y-%m-%d').date()
    except ValueError:
        raise ValueError('날짜 형식은 YYYY-MM-DD 입니다.')
    iso=dt.isoformat(); ymd=dt.strftime('%Y%m%d')
    notes=[]; normalized=[]; source=''
    try:
        result=client.realized_pnl(ymd,ymd)
        rows=result.get('rows') or []
        if rows:
            normalized=[journal.normalize_ka10073(r,iso) for r in rows]
            normalized=[r for r in normalized if float(r.get('sell_qty') or 0)>0]
            source='ka10073'
        else:
            notes.append('ka10073 정상 응답 · 실현손익 0건')
    except Exception as e:
        notes.append('ka10073: '+str(e))
    if not normalized:
        try:
            result=client.daily_trading_journal(ymd)
            rows=result.get('rows') or []
            if rows:
                normalized=[journal.normalize_ka10170(r,iso) for r in rows]
                normalized=[r for r in normalized if float(r.get('sell_qty') or 0)>0]
                source='ka10170'
            else:
                notes.append('ka10170 정상 응답 · 완료 매매 0건')
        except Exception as e:
            notes.append('ka10170: '+str(e))
    inserted,updated=journal.upsert_import(ROOT,normalized)
    msg=' / '.join(notes)
    journal.log_import(ROOT,iso,source or '키움 계좌조회',len(normalized),msg)
    return {'date':iso,'source':source or 'none','rows':len(normalized),'inserted':inserted,'updated':updated,'message':msg}

def safe_cell(x):
    s='' if x is None else str(x)
    return "'"+s if s.startswith(('=','+','-','@','\t','\r')) else s

MARKET_OVERVIEW_CACHE={'ts':0,'data':None}
MARKET_INVESTOR_HISTORY_CACHE={}
MARKET_INVESTOR_HISTORY_LOCK=threading.RLock()
HEADER_INDEX_CACHE={}
HEADER_INDEX_LOCK=threading.RLock()
US_MARKET_CACHE={'ts':0,'data':None}
US_WATCHLIST_CACHE={'ts':0,'key':'','data':None}

def _enrich_market_overview(data):
    data=dict(data or {})
    mk=data.get('markets') or {}
    values=[]
    for key in ('kospi','kosdaq'):
        x=mk.get(key) or {}
        v=x.get('trading_value_krw')
        if v is None and x.get('trading_value') is not None:
            try: v=float(x.get('trading_value'))*1_000_000
            except Exception: v=None
        if v is not None: values.append(float(v))
    data['total_trading_value_krw']=sum(values) if values else None
    return data


SECTOR_CALENDAR_KRX_HOLIDAYS_2026={
    '2026-01-01': '신정',
    '2026-02-16': '설날 연휴',
    '2026-02-17': '설날',
    '2026-02-18': '설날 연휴',
    '2026-03-01': '삼일절',
    '2026-03-02': '삼일절 대체',
    '2026-05-01': '노동절',
    '2026-05-05': '어린이날',
    '2026-05-24': '부처님오신날',
    '2026-05-25': '부처님오신날 대체',
    '2026-06-03': '지방선거일',
    '2026-06-06': '현충일',
    '2026-07-17': '제헌절',
    '2026-08-15': '광복절',
    '2026-08-17': '광복절 대체',
    '2026-09-24': '추석 연휴',
    '2026-09-25': '추석',
    '2026-09-26': '추석 연휴',
    '2026-09-28': '추석 대체',
    '2026-10-03': '개천절',
    '2026-10-05': '개천절 대체',
    '2026-10-09': '한글날',
    '2026-12-25': '성탄절',
    '2026-12-31': '연말 휴장',
}

def _sector_calendar_market_closed(date_obj):
    """KRX closed-day guard for the 2026 strong-sector calendar."""
    if date_obj.weekday() >= 5:  # Sat/Sun
        return True
    return date_obj.isoformat() in SECTOR_CALENDAR_KRX_HOLIDAYS_2026

def sector_strength_calendar_snapshot(month=None):
    """Monthly strong-sector calendar derived from the user's daily LITTO candidates.

    A stock is counted once per day even when it matched multiple techniques.
    Source universe = 주도주 종배 + 주도주 상따 + 끼도주 종배, the same candidate
    snapshot already persisted for D+1 tracking.  The current day is overlaid from
    the live report so the calendar does not have to wait for the next disk save.
    """
    now=datetime.now(KST)
    try:
        if month:
            m=datetime.strptime(str(month)[:7],'%Y-%m')
        else:
            m=now.replace(day=1,tzinfo=None)
    except Exception:
        raise ValueError('month는 YYYY-MM 형식이어야 합니다.')
    month_key=f'{m.year:04d}-{m.month:02d}'
    history=_load_candidate_history()

    # Overlay today's live candidates.  This also makes manual sector edits visible
    # immediately without waiting for the next 5-minute full scan/history write.
    today=now.date().isoformat()
    with LOCK:
        report=copy.deepcopy(STATE.get('report') or {})
    panels=((report.get('search_panels') or {}).get('panels') or {})
    live_stocks={}
    for panel_name in ('주도주 종배','주도주 상따','끼도주 종배'):
        for row in ((panels.get(panel_name) or {}).get('rows') or []):
            c=code(row.get('code')) if row.get('code') else ''
            if not c: continue
            rec=live_stocks.setdefault(c,{'code':c,'name':row.get('name') or c,'sector':row.get('sector') or '미분류','tags':[]})
            # Prefer the latest sector value in case one panel carried a fresher edit.
            if row.get('sector'): rec['sector']=row.get('sector')
            if panel_name not in rec['tags']: rec['tags'].append(panel_name)
    if live_stocks and not _sector_calendar_market_closed(now.date()):
        history[today]={'date':today,'saved_at':now.isoformat(),'stocks':live_stocks}

    days=[]
    month_totals={}
    for day,item in sorted(history.items()):
        if not str(day).startswith(month_key+'-'): continue
        try:
            day_obj=datetime.strptime(str(day)[:10],'%Y-%m-%d').date()
        except Exception:
            continue
        if _sector_calendar_market_closed(day_obj):
            continue
        stocks=(item or {}).get('stocks') or {}
        sec_map={}
        valid_count=0
        for c,rec in stocks.items():
            sec=str((rec or {}).get('sector') or '미분류').strip() or '미분류'
            if sec=='미분류': continue
            valid_count+=1
            ent=sec_map.setdefault(sec,{'sector':sec,'count':0,'stocks':[]})
            ent['count']+=1
            ent['stocks'].append({'code':code((rec or {}).get('code') or c),'name':(rec or {}).get('name') or c,'tags':(rec or {}).get('tags') or []})
            month_totals[sec]=month_totals.get(sec,0)+1
        sectors_out=sorted(sec_map.values(),key=lambda x:(-x['count'],x['sector']))
        days.append({'date':day,'candidate_count':len(stocks),'classified_count':valid_count,'sectors':sectors_out})
    monthly=sorted(({'sector':k,'count':v} for k,v in month_totals.items()),key=lambda x:(-x['count'],x['sector']))
    return {
        'month':month_key,
        'days':days,
        'monthly_sectors':monthly,
        'source':'LITTO 일별 후보 · 주도주 종배 + 주도주 상따 + 끼도주 종배',
        'rule':'종목은 하루 1회만 집계 · 미분류 제외',
        'updated_at':now.isoformat(),
        'history_days':len(history),
    }

def market_overview_snapshot(force=False):
    now=time.time()
    if not force and MARKET_OVERVIEW_CACHE.get('data') and now-MARKET_OVERVIEW_CACHE.get('ts',0)<30:
        return _enrich_market_overview(MARKET_OVERVIEW_CACHE['data'])
    client=STATE.get('client')
    if not client:
        return _enrich_market_overview({'updated_at':None,'source':'키움 공식 REST','markets':{},'error':'키움 미연결'})
    try:
        data=client.market_overview(); MARKET_OVERVIEW_CACHE.update(ts=now,data=data); return _enrich_market_overview(data)
    except Exception as e:
        old=MARKET_OVERVIEW_CACHE.get('data')
        if old:
            return _enrich_market_overview({**old,'error':str(e)})
        return _enrich_market_overview({'updated_at':None,'source':'키움 공식 REST','markets':{},'error':str(e)})



def market_investor_history_snapshot(market='kospi',days=10,force=False):
    market=str(market or '').lower().strip()
    if market not in ('kospi','kosdaq'):
        raise ValueError('market은 kospi 또는 kosdaq 이어야 합니다.')
    days=max(1,min(int(days or 10),20))
    key=(market,days)
    now=time.time()
    with MARKET_INVESTOR_HISTORY_LOCK:
        old=MARKET_INVESTOR_HISTORY_CACHE.get(key)
        if old and not force and now-old.get('ts',0)<300:
            return copy.deepcopy(old['data'])
    client=STATE.get('client')
    if not client:
        return {'market':market,'rows':[],'totals':{},'error':'키움 미연결','updated_at':None}
    try:
        data=client.market_investor_history(market,days)
        with MARKET_INVESTOR_HISTORY_LOCK:
            MARKET_INVESTOR_HISTORY_CACHE[key]={'ts':now,'data':copy.deepcopy(data)}
        return data
    except Exception as e:
        with MARKET_INVESTOR_HISTORY_LOCK:
            old=MARKET_INVESTOR_HISTORY_CACHE.get(key)
        if old and old.get('data'):
            return {**copy.deepcopy(old['data']),'error':str(e)}
        return {'market':market,'rows':[],'totals':{},'error':str(e),'updated_at':None}


def _header_yahoo_quote(symbol,force=False):
    """Small cached Yahoo chart quote used only for the header index strip."""
    sym=str(symbol or '').strip()
    now=time.time()
    with HEADER_INDEX_LOCK:
        old=HEADER_INDEX_CACHE.get(sym)
        if old and not force and now-old.get('ts',0)<15 and old.get('data'):
            return dict(old['data'])
    last_err=None
    for host in ('query1.finance.yahoo.com','query2.finance.yahoo.com'):
        try:
            from urllib.parse import quote as _urlquote
            url=(f'https://{host}/v8/finance/chart/{_urlquote(sym,safe="")}'
                 '?interval=1m&range=1d&includePrePost=true&events=div%2Csplits')
            req=Request(url,headers={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124 Safari/537.36',
                                     'Accept':'application/json,text/plain,*/*','Referer':'https://finance.yahoo.com/'})
            with urlopen(req,timeout=5) as resp:
                payload=json.loads(resp.read(1_500_000))
            result=((payload.get('chart') or {}).get('result') or [None])[0]
            if not isinstance(result,dict): raise RuntimeError('지수 응답 없음')
            meta=result.get('meta') or {}
            price=None
            for k in ('regularMarketPrice','postMarketPrice','preMarketPrice'):
                try:
                    v=meta.get(k)
                    if v not in (None,''): price=float(v); break
                except Exception: pass
            if price is None:
                closes=((((result.get('indicators') or {}).get('quote') or [{}])[0] or {}).get('close') or [])
                for c in reversed(closes):
                    try:
                        if c is not None: price=float(c); break
                    except Exception: pass
            prev=None
            for k in ('chartPreviousClose','previousClose','regularMarketPreviousClose'):
                try:
                    v=meta.get(k)
                    if v not in (None,''): prev=float(v); break
                except Exception: pass
            if price is None or prev in (None,0): raise RuntimeError('지수 현재가/전일종가 없음')
            rate=(price-prev)/prev*100.0
            data={'price':price,'previous_close':prev,'change_rate':rate,'source':'Yahoo Finance chart'}
            with HEADER_INDEX_LOCK: HEADER_INDEX_CACHE[sym]={'ts':now,'data':dict(data)}
            return data
        except Exception as e:
            last_err=e
    with HEADER_INDEX_LOCK:
        old=HEADER_INDEX_CACHE.get(sym)
        if old and old.get('data'):
            return {**old['data'],'stale':True,'error':str(last_err or '')}
    return {'price':None,'previous_close':None,'change_rate':None,'error':str(last_err or '조회 실패')}


NASDAQ_FUTURES_CHART_CACHE={'ts':0.0,'data':None}
NASDAQ_FUTURES_CHART_LOCK=threading.RLock()

def nasdaq_futures_chart_snapshot(force=False):
    """On-demand NQ=F intraday chart for the header popup only.

    This endpoint is never called by the normal header refresh. It therefore
    adds no background polling/API load to the existing LITTO runtime.
    """
    now=time.time()
    with NASDAQ_FUTURES_CHART_LOCK:
        old=NASDAQ_FUTURES_CHART_CACHE.get('data')
        if old and not force and now-NASDAQ_FUTURES_CHART_CACHE.get('ts',0)<20:
            return dict(old)
    last_err=None
    for host in ('query1.finance.yahoo.com','query2.finance.yahoo.com'):
        try:
            from urllib.parse import quote as _urlquote
            sym='NQ=F'
            url=(f'https://{host}/v8/finance/chart/{_urlquote(sym,safe="")}'
                 '?interval=1m&range=1d&includePrePost=true&events=div%2Csplits')
            req=Request(url,headers={
                'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124 Safari/537.36',
                'Accept':'application/json,text/plain,*/*','Referer':'https://finance.yahoo.com/'})
            with urlopen(req,timeout=6) as resp:
                payload=json.loads(resp.read(2_000_000))
            result=((payload.get('chart') or {}).get('result') or [None])[0]
            if not isinstance(result,dict): raise RuntimeError('나스닥 선물 차트 응답 없음')
            ts=result.get('timestamp') or []
            q=(((result.get('indicators') or {}).get('quote') or [{}])[0] or {})
            opens=q.get('open') or []; highs=q.get('high') or []; lows=q.get('low') or []; closes=q.get('close') or []
            n=min(len(ts),len(opens),len(highs),len(lows),len(closes))
            bars=[]
            for i in range(n):
                try:
                    o=float(opens[i]);h=float(highs[i]);l=float(lows[i]);c=float(closes[i]);t=int(ts[i])
                    if not all(map(lambda x: x==x and abs(x)!=float('inf'),(o,h,l,c))): continue
                    bars.append({'t':t,'o':o,'h':h,'l':l,'c':c})
                except Exception:
                    continue
            if len(bars)<2: raise RuntimeError('나스닥 선물 차트 데이터 부족')
            meta=result.get('meta') or {}
            prev=None
            for k in ('chartPreviousClose','previousClose','regularMarketPreviousClose'):
                try:
                    v=meta.get(k)
                    if v not in (None,''): prev=float(v); break
                except Exception: pass
            price=bars[-1]['c']
            rate=((price-prev)/prev*100.0) if prev not in (None,0) else None
            data={'symbol':'NQ=F','name':'NASDAQ 100 선물','interval':'1m','range':'1d','price':price,
                  'previous_close':prev,'change_rate':rate,'bars':bars,'source':'Yahoo Finance NQ=F',
                  'updated_at':datetime.now(KST).isoformat()}
            with NASDAQ_FUTURES_CHART_LOCK:
                NASDAQ_FUTURES_CHART_CACHE.update(ts=now,data=dict(data))
            return data
        except Exception as e:
            last_err=e
    with NASDAQ_FUTURES_CHART_LOCK:
        old=NASDAQ_FUTURES_CHART_CACHE.get('data')
        if old:
            return {**old,'stale':True,'error':str(last_err or '')}
    return {'symbol':'NQ=F','name':'NASDAQ 100 선물','bars':[],'error':str(last_err or '조회 실패'),
            'source':'Yahoo Finance NQ=F','updated_at':datetime.now(KST).isoformat()}

ESIGNAL_NQ_URL='https://esignal.co.kr/kospi200-futures-night/'
ESIGNAL_NQ_CACHE={'ts':0.0,'data':None}
ESIGNAL_NQ_LOCK=threading.RLock()

def _parse_esignal_nasdaq_futures(raw):
    """Extract the Nasdaq futures percentage from eSignal Korea HTML/embedded data.

    The page has changed markup before, so use label proximity instead of a
    brittle CSS selector. We only accept realistic daily percentage values.
    """
    try:
        import html as _html
        s=_html.unescape(str(raw or ''))
    except Exception:
        s=str(raw or '')
    if not s:
        return None
    # Normalize escaped JSON and HTML while retaining nearby labels/values.
    s=s.replace('\\u0025','%').replace('\\/','/').replace('&nbsp;',' ')
    compact=re.sub(r'\s+',' ',re.sub(r'<[^>]+>',' ',s))
    labels=[
        r'나스닥\s*100\s*선물', r'나스닥\s*선물',
        r'NASDAQ\s*100\s*FUTURES?', r'NASDAQ\s*FUTURES?',
        r'E[-\s]*MINI\s*NASDAQ(?:[-\s]*100)?', r'\bNQ\b'
    ]
    pct=r'([+\-−]?\s*\d{1,2}(?:\.\d{1,4})?)\s*%'
    candidates=[]
    for label in labels:
        # value after label
        for m in re.finditer(label+r'.{0,280}?'+pct,compact,re.I):
            candidates.append(m.group(1))
        # value before label (table layouts sometimes place % first)
        for m in re.finditer(pct+r'.{0,160}?'+label,compact,re.I):
            candidates.append(m.group(1))
    # Embedded JS/JSON key fallbacks.
    json_patterns=[
        r'(?:nasdaq|nq)[_\- ]?(?:futures?|future|선물)[^\n\r]{0,180}?(?:change[_\- ]?(?:rate|percent|pct)|rate|percent|pct)["\'\s:=]+([+\-−]?\d{1,2}(?:\.\d{1,4})?)',
        r'(?:change[_\- ]?(?:rate|percent|pct)|rate|percent|pct)["\'\s:=]+([+\-−]?\d{1,2}(?:\.\d{1,4})?)[^\n\r]{0,180}?(?:nasdaq|nq)[_\- ]?(?:futures?|future|선물)'
    ]
    for pat in json_patterns:
        for m in re.finditer(pat,s,re.I): candidates.append(m.group(1))
    for v in candidates:
        try:
            n=float(str(v).replace('−','-').replace(' ',''))
            if -15.0 <= n <= 15.0:
                return n
        except Exception:
            pass
    return None

def _esignal_nasdaq_futures(force=False):
    """eSignal Korea Nasdaq futures percentage, cached for 15 seconds."""
    now=time.time()
    with ESIGNAL_NQ_LOCK:
        old=ESIGNAL_NQ_CACHE.get('data')
        if old and not force and now-ESIGNAL_NQ_CACHE.get('ts',0)<15:
            return dict(old)
    err=None
    try:
        req=Request(ESIGNAL_NQ_URL,headers={
            'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124 Safari/537.36',
            'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
            'Accept-Language':'ko-KR,ko;q=0.9,en-US;q=0.7,en;q=0.6',
            'Referer':'https://esignal.co.kr/',
            'Cache-Control':'no-cache',
            'Pragma':'no-cache',
        })
        with urlopen(req,timeout=6) as resp:
            raw=resp.read(2_500_000).decode(resp.headers.get_content_charset() or 'utf-8','ignore')
        rate=_parse_esignal_nasdaq_futures(raw)
        if rate is None:
            raise RuntimeError('eSignal 페이지에서 나스닥선물 등락률을 찾지 못했습니다.')
        data={'price':None,'previous_close':None,'change_rate':rate,'source':'eSignal Korea','url':ESIGNAL_NQ_URL}
        with ESIGNAL_NQ_LOCK:
            ESIGNAL_NQ_CACHE.update(ts=now,data=dict(data))
        return data
    except Exception as e:
        err=str(e)
    with ESIGNAL_NQ_LOCK:
        old=ESIGNAL_NQ_CACHE.get('data')
        # For temporary network/WAF failures, prefer a recent eSignal value for
        # up to 10 minutes before switching to the fallback feed.
        if old and now-ESIGNAL_NQ_CACHE.get('ts',0)<600:
            return {**old,'stale':True,'error':err}
    return {'price':None,'previous_close':None,'change_rate':None,'source':'eSignal Korea','error':err}


TV_FUTURES_CACHE={}
TV_FUTURES_LOCK=threading.RLock()

def _tradingview_futures_quote(symbol,force=False):
    """TradingView scanner quote for a continuous KRX futures symbol.

    Example symbols: KRX:K2I1! (KOSPI200), KRX:KQI1! (KOSDAQ150).
    Returns close and daily percentage change. If the public scanner rejects the
    request, callers receive an empty quote rather than a fabricated value.
    """
    sym=str(symbol or '').strip()
    now=time.time()
    with TV_FUTURES_LOCK:
        old=TV_FUTURES_CACHE.get(sym)
        if old and not force and now-old.get('ts',0)<15 and old.get('data'):
            return dict(old['data'])
    err=None
    try:
        payload={'symbols':{'tickers':[sym],'query':{'types':[]}},'columns':['close','change']}
        req=Request('https://scanner.tradingview.com/global/scan',
                    data=json.dumps(payload).encode('utf-8'),
                    headers={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124 Safari/537.36',
                             'Content-Type':'application/json','Accept':'application/json','Origin':'https://www.tradingview.com','Referer':'https://www.tradingview.com/'},
                    method='POST')
        with urlopen(req,timeout=6) as resp:
            d=json.loads(resp.read(1_000_000))
        rows=d.get('data') or []
        vals=(rows[0].get('d') if rows and isinstance(rows[0],dict) else None) or []
        if len(vals)<2: raise RuntimeError('TradingView 선물 응답 없음')
        price=float(vals[0]) if vals[0] not in (None,'') else None
        rate=float(vals[1]) if vals[1] not in (None,'') else None
        data={'price':price,'change_rate':rate,'source':'TradingView '+sym}
        with TV_FUTURES_LOCK: TV_FUTURES_CACHE[sym]={'ts':now,'data':dict(data)}
        return data
    except Exception as e:
        err=str(e)
    with TV_FUTURES_LOCK:
        old=TV_FUTURES_CACHE.get(sym)
        if old and old.get('data'):
            return {**old['data'],'stale':True,'error':err}
    return {'price':None,'change_rate':None,'source':'TradingView '+sym,'error':err or '조회 실패'}

def header_indices_snapshot(force=False):
    """Compact KOSPI / KOSDAQ / NASDAQ futures percentage strip."""
    kospi={'change_rate':None,'price':None,'source':'키움 시장종합'}
    kosdaq={'change_rate':None,'price':None,'source':'키움 시장종합'}
    try:
        mk=market_overview_snapshot(force=force).get('markets') or {}
        kp=mk.get('kospi') or {}
        kq=mk.get('kosdaq') or {}
        if kp.get('change_rate') is not None:
            kospi={'change_rate':float(kp.get('change_rate')),'price':kp.get('price'),'source':'키움 공식 REST'}
        if kq.get('change_rate') is not None:
            kosdaq={'change_rate':float(kq.get('change_rate')),'price':kq.get('price'),'source':'키움 공식 REST'}
    except Exception as e:
        kospi['error']=str(e)
        kosdaq['error']=str(e)
    if kospi.get('change_rate') is None:
        fb=_header_yahoo_quote('^KS11',force=force)
        kospi={**fb,'source':'Yahoo KOSPI fallback'}
    if kosdaq.get('change_rate') is None:
        fb=_header_yahoo_quote('^KQ11',force=force)
        kosdaq={**fb,'source':'Yahoo KOSDAQ fallback'}
    # Nasdaq futures: eSignal Korea is the primary display source because it
    # matches the value users monitor in the study room. Yahoo NQ=F is only a
    # fallback when eSignal cannot be read and there is no recent eSignal cache.
    nqf=_esignal_nasdaq_futures(force=force)
    if nqf.get('change_rate') is None:
        fb=_header_yahoo_quote('NQ=F',force=force)
        nqf={**fb,'source':'Yahoo NQ=F fallback','primary_error':nqf.get('error')}
    # KRX continuous futures for the compact trading header.
    # K2I1! = KOSPI200 futures, KQI1! = KOSDAQ150 futures.
    kpf=_tradingview_futures_quote('KRX:K2I1!',force=force)
    kqf=_tradingview_futures_quote('KRX:KQI1!',force=force)
    return {'updated_at':datetime.now(KST).isoformat(),
            'items':{'kospi':kospi,'kosdaq':kosdaq,'kospi_futures':kpf,'kosdaq_futures':kqf,'nasdaq_futures':nqf}}

def us_market_snapshot(force=False):
    now=time.time()
    if not force and US_MARKET_CACHE.get('data') and now-US_MARKET_CACHE.get('ts',0)<30:
        return US_MARKET_CACHE['data']
    client=STATE.get('client')
    if not client:
        return {'updated_at':None,'source':'키움 미국주식 REST','sections':{},'errors':{'all':'키움 API 연결이 필요합니다.'}}
    try:
        data=client.us_market_snapshot();US_MARKET_CACHE.update(ts=now,data=data);return data
    except Exception as e:
        old=US_MARKET_CACHE.get('data')
        if old:return {**old,'errors':{**(old.get('errors') or {}),'all':str(e)}}
        return {'updated_at':None,'source':'키움 미국주식 REST','sections':{},'errors':{'all':str(e)}}


def account_watchlist_groups_snapshot():
    with LOCK:
        client=STATE.get('client')
    if not client:
        return {'connected':False,'groups':[],'error':'키움 로그인이 필요합니다.','source':'Kiwoom ka01300'}
    try:
        rows=_kiwoom_call(client.watchlist_groups,kind='light')
        return {'connected':True,'groups':rows,'count':len(rows),'source':'Kiwoom ka01300 · HTS 저장 관심종목 그룹'}
    except Exception as e:
        return {'connected':True,'groups':[],'error':str(e)[:220],'source':'Kiwoom ka01300'}

def account_watchlist_group_snapshot(group_code):
    with LOCK:
        client=STATE.get('client')
    if not client:
        return {'connected':False,'rows':[],'error':'키움 로그인이 필요합니다.','source':'Kiwoom ka01301'}
    g=str(group_code or '').strip()
    if not g:
        raise ValueError('관심종목 그룹을 선택해 주세요.')
    rows=_kiwoom_call(client.watchlist_group,g,kind='light')
    sector_map=sectors.load()
    out=[]
    for raw in rows:
        c=str(raw.get('code') or '').strip()
        if not c:
            continue
        live=LOOKUP.get(c,{}) if isinstance(LOOKUP,dict) else {}
        name=(live.get('name') or STOCK_NAME_CACHE.get(c) or c)
        sinfo=sector_map.get(c,{}) if isinstance(sector_map,dict) else {}
        sector=(live.get('sector') or sinfo.get('sector') or '기타')
        out.append({
            'code':c,'name':str(name),'sector':str(sector),
            'bookmark':raw.get('bookmark',''),
            'bookmark_color':raw.get('bookmark_color','')
        })
        if name==c:
            _queue_stock_name_lookup(c)
    return {
        'connected':True,'group_code':g,'rows':out,'count':len(out),
        'source':'Kiwoom ka01301 · HTS 저장 관심종목 그룹 상세'
    }

def us_watchlist_snapshot(symbols,force=False):
    syms=[];seen=set()
    for x in symbols:
        v=str(x or '').strip().upper()
        if v and v not in seen:
            seen.add(v);syms.append(v)
    key=','.join(syms)
    now=time.time()
    if not force and US_WATCHLIST_CACHE.get('data') and US_WATCHLIST_CACHE.get('key')==key and now-US_WATCHLIST_CACHE.get('ts',0)<60:
        return US_WATCHLIST_CACHE['data']
    client=STATE.get('client')
    if not client:
        return {'updated_at':None,'source':'키움 미국주식 REST usa20100','quotes':[],'errors':{'all':'키움 API 연결이 필요합니다.'}}
    try:
        data=client.us_watchlist_quotes(syms)
        US_WATCHLIST_CACHE.update(ts=now,key=key,data=data)
        return data
    except Exception as e:
        old=US_WATCHLIST_CACHE.get('data') if US_WATCHLIST_CACHE.get('key')==key else None
        if old:return {**old,'errors':{**(old.get('errors') or {}),'all':str(e)}}
        return {'updated_at':None,'source':'키움 미국주식 REST usa20100','quotes':[],'errors':{'all':str(e)}}


# Independent account page -----------------------------------------------------
ACCOUNT_STATUS_CACHE={'ts':0.0,'data':None}
ACCOUNT_REALIZED_CACHE={'ts':0.0,'value':None,'rows':[],'summary':{},'error':None}
ACCOUNT_AUTO_CONNECT_GUARD={'ts':0.0}
ACCOUNT_SOR_QUOTE_CACHE={}
ACCOUNT_SOR_QUOTE_TTL=4.0

def _account_client():
    """Reuse the same Kiwoom session as the rest of LITTO, and restore saved login if needed."""
    with LOCK:
        client=STATE.get('client')
    if client:
        return client

    now=time.time()
    if now-float(ACCOUNT_AUTO_CONNECT_GUARD.get('ts') or 0)>=5.0:
        ACCOUNT_AUTO_CONNECT_GUARD['ts']=now
        try:_startup_auto_connect()
        except Exception:pass

    with LOCK:
        return STATE.get('client')


def _overlay_account_sor_quotes(client,data,now=None):
    """Replace KRX-stale kt00018 prices with Kiwoom integrated SOR quotes.

    kt00018 can report a KRX valuation even when a position was filled on NXT.
    For live accounts, quote() with the _AL/SOR symbol is the same integrated
    current-price source used by LITTO's SOR screens.
    """
    if not isinstance(data,dict) or bool(getattr(client,'mock',False)):
        return data
    now=float(now or time.time())
    rows=data.get('holdings') or []
    if not isinstance(rows,list) or not rows:
        return data

    raw_summary=dict(data.get('summary') or {})
    old_total_eval=raw_summary.get('total_evaluation')
    try: old_total_eval=float(old_total_eval) if old_total_eval not in (None,'') else None
    except (TypeError,ValueError): old_total_eval=None

    changed=False
    new_rows=[]
    for src in rows:
        if not isinstance(src,dict):
            continue
        r=dict(src)
        c=code(r.get('code') or '')
        qty=float(r.get('quantity') or 0)
        if not c or qty<=0:
            new_rows.append(r); continue

        q=None
        cached=ACCOUNT_SOR_QUOTE_CACHE.get(c)
        if isinstance(cached,dict) and now-float(cached.get('ts') or 0)<ACCOUNT_SOR_QUOTE_TTL:
            q=cached.get('quote')
        else:
            try:
                q=_kiwoom_call(lambda:client.quote(c,'SOR'),kind='quote')
                if isinstance(q,dict) and float(q.get('price') or 0)>0:
                    ACCOUNT_SOR_QUOTE_CACHE[c]={'ts':now,'quote':dict(q)}
            except Exception:
                q=(cached or {}).get('quote') if isinstance(cached,dict) else None

        px=float((q or {}).get('price') or 0) if isinstance(q,dict) else 0.0
        if px<=0:
            new_rows.append(r); continue

        # A-mode: keep Kiwoom kt00018 valuation fields exactly as returned.
        # Only overlay the displayed current price with the integrated SOR/NXT quote.
        # Do NOT recalculate evaluation_amount / evaluation_pnl / profit_rate here,
        # because Kiwoom's MTS valuation includes its own fee/tax/accounting basis.
        if abs(float(r.get('current_price') or 0)-px) >= 0.5:
            changed=True
        r.update({
            'current_price':px,
            'price_source':'SOR',
            'market_code':(q or {}).get('market_code'),
        })
        new_rows.append(r)

    if not new_rows:
        return data

    # Preserve the complete kt00018 account summary without recomputation.
    summary=dict(raw_summary)

    out=dict(data)
    out['holdings']=new_rows
    out['summary']=summary
    out['price_basis']='SOR display + Kiwoom kt00018 valuation'
    if changed:
        out['source']=str(out.get('source') or '키움 공식 REST')+' + ka10001 통합(SOR) 현재가(표시용)'
    return out

ACCOUNT_FLIGHT=SingleFlight()

def account_status_snapshot(force=False):
    return ACCOUNT_FLIGHT.run('account',lambda:_account_status_snapshot(force))

def _account_status_snapshot(force=False):
    now=time.time()
    client=_account_client()
    if not client:
        return {
            'connected':False,'account_no':'','mock':False,'updated_at':None,
            'summary':{},'holdings':[],'realized_pnl':None,
            'source':'키움 공식 REST','error':'키움 로그인 연결이 필요합니다.'
        }

    if ACCOUNT_STATUS_CACHE.get('client') is not client:
        ACCOUNT_STATUS_CACHE.clear()
        ACCOUNT_STATUS_CACHE.update(ts=0.0,data=None,client=client)
        ACCOUNT_REALIZED_CACHE.update(ts=0.0,value=None,rows=[],summary={},error=None)
        ACCOUNT_SOR_QUOTE_CACHE.clear()

    cached=ACCOUNT_STATUS_CACHE.get('data')
    if cached and not force and now-float(ACCOUNT_STATUS_CACHE.get('ts') or 0)<0.8:
        return cached

    try:
        data=_kiwoom_call(client.account_snapshot,kind='account')
        # kt00018 can remain KRX-valued during NXT/SOR trading. Overlay each
        # holding with the integrated _AL/SOR quote before serving the account UI.
        data=_overlay_account_sor_quotes(client,data,now)

        # Realized P/L is lighter at 10-second cadence; evaluation/holdings refresh every second.
        # IMPORTANT: prefer Kiwoom ka10073 realized-P/L rows.  ka10170 can expose
        # today's trading journal values whose buy average may differ from the
        # exact cost basis used by Kiwoom's MTS "종목실현손익", especially after
        # partial exits / KRX+NXT(SOR) executions.
        if force or now-float(ACCOUNT_REALIZED_CACHE.get('ts') or 0)>=10.0:
            try:
                def _rn(v):
                    if v in (None,''): return None
                    try:return float(str(v).replace(',','').strip())
                    except (TypeError,ValueError):return None

                today_ymd=datetime.now(KST).strftime('%Y%m%d')
                realized_rows=[]
                summary={}
                source='ka10073'

                # 1) Exact realized P/L source used for the account screen.
                rp=_kiwoom_call(client.realized_pnl,today_ymd,today_ymd,kind='account')
                for r in (rp.get('rows') or []):
                    if not isinstance(r,dict): continue
                    name=str(r.get('stk_nm') or '').strip()
                    code=str(r.get('stk_cd') or '').strip()
                    if code and len(code)>6 and code[0] in 'AJQ': code=code[1:]
                    sell_qty=_rn(r.get('cntr_qty'))
                    if not name and not code: continue
                    if sell_qty is not None and sell_qty<=0: continue

                    buy_avg=_rn(r.get('buy_uv'))
                    sell_avg=_rn(r.get('cntr_pric'))
                    pnl=_rn(r.get('tdy_sel_pl'))
                    profit_rate=_rn(r.get('pl_rt'))
                    fee=_rn(r.get('tdy_trde_cmsn')) or 0.0
                    tax=_rn(r.get('tdy_trde_tax')) or 0.0
                    fees_tax=fee+tax

                    # ka10073 does not always provide amount fields; derive display
                    # amounts only from Kiwoom's own avg-price / filled-qty fields.
                    buy_amount=_rn(r.get('buy_amt'))
                    sell_amount=_rn(r.get('sell_amt'))
                    if buy_amount is None and buy_avg is not None and sell_qty is not None:
                        buy_amount=buy_avg*sell_qty
                    if sell_amount is None and sell_avg is not None and sell_qty is not None:
                        sell_amount=sell_avg*sell_qty

                    realized_rows.append({
                        'name':name,
                        'code':code,
                        'buy_avg_price':buy_avg,
                        'buy_qty':sell_qty,
                        'sell_avg_price':sell_avg,
                        'sell_qty':sell_qty,
                        'fees_tax':fees_tax,
                        'pnl':pnl,
                        'sell_amount':sell_amount,
                        'buy_amount':buy_amount,
                        'profit_rate':profit_rate,
                        'source':'ka10073',
                    })

                # 2) Fallback only when ka10073 has no usable rows.
                if not realized_rows:
                    source='ka10170'
                    j=_kiwoom_call(client.daily_trading_journal,kind='account')
                    summary=j.get('summary') or {}
                    for r in (j.get('rows') or []):
                        if not isinstance(r,dict): continue
                        name=str(r.get('stk_nm') or '').strip()
                        code=str(r.get('stk_cd') or '').strip()
                        if code and len(code)>6 and code[0] in 'AJQ': code=code[1:]
                        sell_qty=_rn(r.get('sell_qty'))
                        if not name and not code: continue
                        if sell_qty is not None and sell_qty<=0: continue
                        realized_rows.append({
                            'name':name,
                            'code':code,
                            'buy_avg_price':_rn(r.get('buy_avg_pric')),
                            'buy_qty':_rn(r.get('buy_qty')),
                            'sell_avg_price':_rn(r.get('sel_avg_pric')),
                            'sell_qty':sell_qty,
                            'fees_tax':_rn(r.get('cmsn_alm_tax')),
                            'pnl':_rn(r.get('pl_amt')),
                            'sell_amount':_rn(r.get('sell_amt')),
                            'buy_amount':_rn(r.get('buy_amt')),
                            'profit_rate':_rn(r.get('prft_rt')),
                            'source':'ka10170',
                        })

                realized_rows.sort(key=lambda x:abs(float(x.get('pnl') or 0)),reverse=True)

                # For ka10073, the account total is the sum of Kiwoom's realized
                # P/L fields, not a LITTO recomputation from the current holding AVG.
                if source=='ka10073':
                    pnl_values=[x.get('pnl') for x in realized_rows if x.get('pnl') is not None]
                    value=sum(float(v) for v in pnl_values) if pnl_values else None
                    summary={'tot_pl_amt':value,'source':'ka10073'}
                else:
                    raw=summary.get('tot_pl_amt')
                    try:value=float(str(raw).replace(',','')) if raw not in (None,'') else None
                    except (TypeError,ValueError):value=None

                ACCOUNT_REALIZED_CACHE.update(
                    ts=now,value=value,rows=realized_rows,summary=summary,error=None
                )
            except Exception as e:
                ACCOUNT_REALIZED_CACHE.update(ts=now,error=str(e)[:180])

        payload={
            **data,'connected':True,
            'realized_pnl':ACCOUNT_REALIZED_CACHE.get('value'),
            'realized_rows':ACCOUNT_REALIZED_CACHE.get('rows') or [],
            'realized_summary':ACCOUNT_REALIZED_CACHE.get('summary') or {},
            'realized_error':ACCOUNT_REALIZED_CACHE.get('error'),
            'poll_seconds':1,'error':None
        }
        ACCOUNT_STATUS_CACHE.update(ts=time.time(),data=payload)
        return payload
    except Exception as e:
        if cached:
            return {**cached,'stale':True,'error':str(e)[:220]}
        return {
            'connected':True,'account_no':'','mock':bool(getattr(client,'mock',False)),
            'updated_at':None,'summary':{},'holdings':[],
            'realized_pnl':ACCOUNT_REALIZED_CACHE.get('value'),
            'realized_rows':ACCOUNT_REALIZED_CACHE.get('rows') or [],
            'realized_summary':ACCOUNT_REALIZED_CACHE.get('summary') or {},
            'source':'키움 공식 REST','error':str(e)[:220]
        }



# Manual order bridge ----------------------------------------------------------
# Orders are never generated automatically.  Every placement/cancel request must
# come from the explicit orderbook UI and carry confirm=True.
MANUAL_ORDER_LOCK=threading.RLock()
MANUAL_ORDER_RECENT={}
# Live-order arming is enforced on the server as well as in the browser.
# It expires automatically so a stale browser checkbox cannot leave live trading armed.
MANUAL_ORDER_ARM={'armed':False,'ts':0.0}
MANUAL_ORDER_ARM_TTL=600.0

def manual_order_arm(payload):
    client=_manual_order_client()
    armed=bool(payload.get('armed'))
    now=time.time()
    with MANUAL_ORDER_LOCK:
        if getattr(client,'mock',False):
            MANUAL_ORDER_ARM.update(armed=False,ts=0.0)
            return {'ok':True,'armed':True,'mock':True,'expires_in':0}
        MANUAL_ORDER_ARM.update(armed=armed,ts=now if armed else 0.0)
    return {'ok':True,'armed':armed,'mock':False,'expires_in':int(MANUAL_ORDER_ARM_TTL if armed else 0)}

def _manual_require_live_arm(client):
    if getattr(client,'mock',False):
        return
    now=time.time()
    with MANUAL_ORDER_LOCK:
        armed=bool(MANUAL_ORDER_ARM.get('armed'))
        ts=float(MANUAL_ORDER_ARM.get('ts') or 0.0)
        if armed and now-ts<=MANUAL_ORDER_ARM_TTL:
            return
        MANUAL_ORDER_ARM.update(armed=False,ts=0.0)
    raise ValueError('실전 주문 잠금 상태입니다. 실전계좌 주문 활성화를 다시 체크하세요.')

def _manual_order_client():
    with LOCK:
        client=STATE.get('client')
    if not client:
        try:_startup_auto_connect()
        except Exception:pass
        with LOCK:
            client=STATE.get('client')
    if not client:
        raise ValueError('키움 API 연결이 필요합니다.')
    return client

def _manual_order_once(request_id):
    rid=str(request_id or '').strip()
    if not rid:
        raise ValueError('주문 요청 식별자가 없습니다.')
    now=time.time()
    with MANUAL_ORDER_LOCK:
        for k,t in list(MANUAL_ORDER_RECENT.items()):
            if now-float(t)>45: MANUAL_ORDER_RECENT.pop(k,None)
        if rid in MANUAL_ORDER_RECENT:
            raise ValueError('같은 주문 요청이 이미 처리되었습니다. 중복 주문을 차단했습니다.')
        MANUAL_ORDER_RECENT[rid]=now
    return rid

def manual_place_order(payload):
    if payload.get('confirm') is not True:
        raise ValueError('주문 확인 절차가 필요합니다.')
    rid=_manual_order_once(payload.get('request_id'))
    client=_manual_order_client()
    _manual_require_live_arm(client)
    try:
        result=_kiwoom_call(
            client.manual_cash_order,
            payload.get('side'),
            payload.get('code'),
            payload.get('qty'),
            payload.get('price'),
            payload.get('order_type') or 'limit',
            payload.get('venue') or 'SOR',
            kind='order'
        )
        # Make the account panel pick up fills/changes immediately on its next refresh.
        try:
            ACCOUNT_STATUS_CACHE['ts']=0.0
            ACCOUNT_REALIZED_CACHE['ts']=0.0
        except Exception:pass
        return {**result,'request_id':rid,'submitted_at':datetime.now(KST).isoformat()}
    except Exception:
        # A provider error means no accepted order number was returned.  Allow user retry.
        with MANUAL_ORDER_LOCK:MANUAL_ORDER_RECENT.pop(rid,None)
        raise

def manual_unfilled_orders(stock_code=''):
    client=_manual_order_client()
    rows=_kiwoom_call(client.unfilled_orders,stock_code or '',kind='order')
    return {
        'rows':rows,
        'count':len(rows),
        'updated_at':datetime.now(KST).isoformat(),
        'mock':bool(getattr(client,'mock',False))
    }

def manual_cancel_order(payload):
    if payload.get('confirm') is not True:
        raise ValueError('취소 확인 절차가 필요합니다.')
    rid=_manual_order_once(payload.get('request_id'))
    client=_manual_order_client()
    try:
        result=_kiwoom_call(
            client.cancel_cash_order,
            payload.get('order_no'),
            payload.get('code'),
            payload.get('qty') or 0,
            payload.get('venue') or 'SOR',
            kind='order'
        )
        return {**result,'request_id':rid,'submitted_at':datetime.now(KST).isoformat()}
    except Exception:
        with MANUAL_ORDER_LOCK:MANUAL_ORDER_RECENT.pop(rid,None)
        raise

def manual_cancel_all(payload):
    if payload.get('confirm') is not True:
        raise ValueError('전체 취소 확인 절차가 필요합니다.')
    rid=_manual_order_once(payload.get('request_id'))
    client=_manual_order_client()
    stock_code=str(payload.get('code') or '').strip()
    rows=_kiwoom_call(client.unfilled_orders,stock_code,kind='order')
    results=[];errors=[]
    for row in rows:
        try:
            r=_kiwoom_call(
                client.cancel_cash_order,
                row.get('order_no'),
                row.get('code'),
                0,
                row.get('venue') or 'SOR',
                kind='order'
            )
            results.append(r)
            time.sleep(0.08)
        except Exception as e:
            errors.append({
                'order_no':row.get('order_no'),
                'code':row.get('code'),
                'error':str(e)[:180]
            })
    return {
        'ok':not errors,
        'request_id':rid,
        'canceled':len(results),
        'errors':errors,
        'submitted_at':datetime.now(KST).isoformat()
    }


class Handler(BaseHTTPRequestHandler):
    def log_message(self,*args):pass
    def respond(self,status,data,ctype='application/json; charset=utf-8',attachment=None):
        if isinstance(data,(dict,list)):data=json.dumps(data,ensure_ascii=False,allow_nan=False)
        if isinstance(data,str):data=data.encode('utf-8')
        self.send_response(status);self.send_header('Content-Type',ctype)
        self.send_header('Content-Length',str(len(data)))
        self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('X-Frame-Options','DENY');self.send_header('Referrer-Policy','no-referrer')
        self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'")
        if attachment:self.send_header('Content-Disposition','attachment; filename="'+attachment+'"')
        try:
            self.end_headers();self.wfile.write(data)
        except (BrokenPipeError,ConnectionAbortedError,ConnectionResetError):
            # The desktop/webview may close or navigate while a response is being
            # written.  This is a normal client-side disconnect, not a backend
            # failure; suppress the noisy traceback and release the worker thread.
            return

    def trusted(self):
        expected=f'127.0.0.1:{self.server.server_port}'
        return self.headers.get('Host')==expected and self.headers.get('Origin') in (None,'http://'+expected)

    def do_GET(self):
        if not self.trusted():return self.respond(403,{'error':'로컬 주소로 접속하세요.'})
        path=urlparse(self.path).path
        if path=='/api/state':return self.respond(200,snapshot())
        if path=='/api/top5-performance':
            return self.respond(200,top5_performance_snapshot())
        if path=='/api/top5-performance-refresh':
            qs=parse_qs(urlparse(self.path).query)
            try:max_days=int((qs.get('max_days') or ['5'])[0] or 5)
            except Exception:max_days=5
            try:return self.respond(200,top5_performance_refresh_results(max_days=max_days))
            except (ValueError,ApiError) as e:return self.respond(400,{'error':str(e)})
        if path=='/api/account-status':
            force=parse_qs(urlparse(self.path).query).get('force',['0'])[0]=='1'
            return self.respond(200,account_status_snapshot(force=force))
        if path=='/api/night-futures':
            return self.respond(200,night_futures.snapshot())
        if path=='/api/page1-diagnostic':
            with LOCK:
                ranks=copy.deepcopy(STATE.get('ranks') or {})
                report=copy.deepcopy(STATE.get('report') or {})
            diag_rows=(((report.get('search_panels') or {}).get('panels') or {}).get('검색 진단') or {}).get('rows',[])
            return self.respond(200,{'at':datetime.now(KST).isoformat(),'live':page1_live_status(),
                                     'rank_source':ranks.get('source'),'value_top':(ranks.get('value_top') or [])[:50],
                                     'change_top':(ranks.get('change_top') or [])[:100],
                                     'search_diagnostic':diag_rows[:80]})
        if path=='/api/orderbook-mini-chart':
            qs=parse_qs(urlparse(self.path).query)
            c=base_code((qs.get('code') or [''])[0])
            tf=str((qs.get('tf') or ['3'])[0]).strip().lower()
            if not c:
                return self.respond(400,{'error':'종목코드가 필요합니다.'})
            if tf not in ('1','3','15','daily'):
                return self.respond(400,{'error':'지원 봉은 1분·3분·15분·일봉입니다.'})
            with LOCK:
                client=STATE.get('client')
            if not client:
                return self.respond(409,{'error':'키움 API 연결이 필요합니다.'})

            now=time.time()
            cache_key=(c,tf)
            ttl=120.0 if tf=='daily' else 25.0
            with ORDERBOOK_CHART_CACHE_LOCK:
                cached=ORDERBOOK_CHART_CACHE.get(cache_key)
                if cached and now-float(cached.get('ts') or 0)<ttl:
                    payload=copy.deepcopy(cached.get('data') or {})
                    payload['cached']=True
                    return self.respond(200,payload)

            try:
                if tf=='daily':
                    raw=_kiwoom_call(client.daily_history_rows,c,150,kind='chart')
                    bars=[daily_bar(r) for r in raw]
                    bars.sort(key=lambda x:x.get('date',''))
                    bars=bars[-120:]
                else:
                    minutes=int(tf)
                    # Performance-first: one SOR(_AL) history request only.
                    # F-zone levels themselves come from the already-computed scanner state;
                    # do not run the heavy F-zone engine or a second NXT history request here.
                    provider=c if bool(getattr(client,'mock',False)) else c+'_AL'
                    raw=_kiwoom_call(
                        client.rows,'ka10080',
                        {'stk_cd':provider,'tic_scope':str(minutes),'upd_stkpc_tp':'1'},
                        'stk_min_pole_chart_qry',360,4,kind='chart'
                    )
                    stamp=datetime.now(KST)
                    merged={}
                    for r in raw:
                        key=str(r.get('cntr_tm') or '')
                        if key:
                            merged[key]=minute_bar(r,stamp,minutes)
                    bars=sorted(merged.values(),key=lambda x:x.get('time',''))[-300:]

                payload={
                    'code':c,'tf':tf,'bars':bars,'count':len(bars),
                    'updated_at':datetime.now(KST).isoformat(),
                    'source':'키움 ka10081 SOR' if tf=='daily' else '키움 ka10080 SOR(_AL)',
                    'cached':False,
                }
                with ORDERBOOK_CHART_CACHE_LOCK:
                    ORDERBOOK_CHART_CACHE[cache_key]={'ts':now,'data':copy.deepcopy(payload)}
                return self.respond(200,payload)
            except Exception as e:
                with ORDERBOOK_CHART_CACHE_LOCK:
                    stale=ORDERBOOK_CHART_CACHE.get(cache_key)
                if stale and stale.get('data'):
                    payload=copy.deepcopy(stale['data'])
                    payload['cached']=True
                    payload['stale']=True
                    payload['warning']='최신 차트 조회 실패 · 캐시 표시'
                    return self.respond(200,payload)
                return self.respond(500,{'error':'호가창 차트 조회 실패: '+str(e)})
        if path=='/api/chart-daily-history':
            qs=parse_qs(urlparse(self.path).query)
            raw=(qs.get('code') or [''])[0]
            c=base_code(raw)
            if not c:
                return self.respond(400,{'error':'종목코드가 필요합니다.'})
            with LOCK:
                client=STATE.get('client')
            if not client:
                return self.respond(409,{'error':'키움 API 연결이 필요합니다.'})
            try:
                rows=_kiwoom_call(client.daily_history_rows,c,180,kind='chart')
                bars=[daily_bar(r) for r in rows]
                bars.sort(key=lambda x:x.get('date',''))
                return self.respond(200,{'code':c,'daily':bars,'count':len(bars)})
            except Exception as e:
                return self.respond(500,{'error':'일봉 과거데이터 조회 실패: '+str(e)})
        if path=='/api/realtime-rank':
            force=parse_qs(urlparse(self.path).query).get('force',['0'])[0]=='1'
            return self.respond(200,realtime_rank_snapshot(force=force))
        if path=='/api/market-movers':
            force=parse_qs(urlparse(self.path).query).get('force',['0'])[0]=='1'
            return self.respond(200,market_movers_snapshot(force=force))
        if path=='/api/live-leader':
            force=parse_qs(urlparse(self.path).query).get('force',['0'])[0]=='1'
            start_live_leader_engine()
            if not force:
                with LIVE_LEADER_LOCK:
                    cached=LIVE_LEADER_CACHE.get('payload')
                if cached:
                    return self.respond(200,cached)
            return self.respond(200,live_leader_snapshot(force_rank=force))
        if path=='/api/sector-popularity':
            qs=parse_qs(urlparse(self.path).query)
            target=str((qs.get('sector') or [''])[0]).strip()
            if not target:
                return self.respond(400,{'error':'섹터명이 필요합니다.'})
            mapping=sectors.load()
            def _sector_tags(v):
                import re
                return [x.strip() for x in re.split(r'[,;/|]+',str(v or '')) if x.strip()]
            def _norm_sector(v):
                import re
                return re.sub(r'[^0-9A-Za-z가-힣]+','',str(v or '')).lower()
            def _sector_match(target_name, sector_value):
                nt=_norm_sector(target_name)
                if not nt:return False
                for tag in _sector_tags(sector_value):
                    ns=_norm_sector(tag)
                    if not ns:continue
                    if nt==ns or nt in ns or ns in nt:
                        return True
                return False
            # Prefer the full listed universe. If it has not been loaded yet, fall back
            # to codes already known by the scanner / sector database.
            universe=list(UNIVERSE or [])
            by_code={code(x.get('code')):x for x in universe if x.get('code')}
            with LOCK:
                report=(STATE.get('report') or {})
                data=(STATE.get('data') or {})
            for st in data.get('stocks',[]) or []:
                c=code(st.get('code')) if st.get('code') else ''
                if c and c not in by_code: by_code[c]=st
            for c in mapping:
                cc=code(c)
                if cc and cc not in by_code: by_code[cc]={'code':cc,'name':LOOKUP.get(cc,{}).get('name') or cc}
            members=[]
            for c,base in by_code.items():
                info=mapping.get(c) or mapping.get(str(c)) or {}
                sec=info.get('sector') or base.get('sector') or ''
                if not _sector_match(target,sec):
                    continue
                members.append({'code':c,'name':_best_known_stock_name(c,base),'sector':sec})
            if not members:
                panels=((report.get('search_panels') or {}).get('panels') or {})
                seen=set()
                for pname in ('주도주 종배','주도주 상따','끼도주 종배'):
                    for row in ((panels.get(pname) or {}).get('rows') or []):
                        c=code(row.get('code')) if row.get('code') else ''
                        sec=row.get('sector') or ''
                        if c and c not in seen and _sector_match(target,sec):
                            seen.add(c)
                            members.append({'code':c,'name':_best_known_stock_name(c,row),'sector':sec})
            ranks=realtime_rank_snapshot(force=False)
            live_rows=ranks.get('rows') or []
            daily_rows=ranks.get('daily_rows') or []
            live={code(x.get('code')):x for x in live_rows if x.get('code')}
            daily={code(x.get('code')):x for x in daily_rows if x.get('code')}
            result_map={code(x.get('code')):x for x in (report.get('results') or []) if x.get('code')}
            out=[]
            for m in members:
                c=m['code']; lr=live.get(c); dr=daily.get(c); rr=result_map.get(c) or {}
                # popularity order is provider ranking only: current lookup first,
                # then Kiwoom's own daily cumulative lookup rank. Unranked members follow.
                live_rank=int(lr.get('rank')) if lr and str(lr.get('rank','')).isdigit() else None
                daily_rank=int(dr.get('rank')) if dr and str(dr.get('rank','')).isdigit() else None
                src=lr or dr or rr
                resolved_name=_best_known_stock_name(c,lr,dr,rr,m)
                out.append({
                    **m,
                    'name':resolved_name,
                    'live_rank':live_rank,
                    'daily_rank':daily_rank,
                    'price':src.get('price') if isinstance(src,dict) else None,
                    'change':src.get('change') if isinstance(src,dict) else None,
                    'move':lr.get('move') if lr else None,
                    'new':bool(lr.get('new')) if lr else False,
                    'value_eok':rr.get('value_eok') if isinstance(rr,dict) else None,
                })
            out.sort(key=lambda x:(0 if x['live_rank'] is not None else 1,
                                   x['live_rank'] if x['live_rank'] is not None else 999999,
                                   0 if x['daily_rank'] is not None else 1,
                                   x['daily_rank'] if x['daily_rank'] is not None else 999999,
                                   x['name']))
            return self.respond(200,{'sector':target,'rows':out,'count':len(out),'ranked_count':sum(1 for x in out if x['live_rank'] is not None or x['daily_rank'] is not None),'updated_at':ranks.get('updated_at'),'source':'키움 ka00198 실시간 조회순위 → 당일 누적 조회순위','error':ranks.get('error')})
        if path=='/api/stock-search':
            qs=parse_qs(urlparse(self.path).query)
            q=(qs.get('q') or [''])[0]
            try:return self.respond(200,stock_search_snapshot(q,20))
            except ValueError as e:return self.respond(400,{'error':str(e)})
        if path=='/api/watch-manual-live':
            qs=parse_qs(urlparse(self.path).query)
            raw=(qs.get('codes') or [''])[0]
            codes=[x.strip() for x in raw.split(',') if x.strip()]
            force=(qs.get('force',['0'])[0]=='1')
            try:return self.respond(200,manual_watch_live_snapshot(codes,force=force))
            except (ValueError,ApiError) as e:return self.respond(400,{'error':str(e)})
        if path=='/api/orderbook-live':
            qs=parse_qs(urlparse(self.path).query)
            c=code((qs.get('code') or [''])[0])
            if not c:return self.respond(400,{'error':'종목코드가 필요합니다.'})
            try:last_seq=int((qs.get('seq') or ['0'])[0] or 0)
            except Exception:last_seq=0
            with LOCK: client=STATE.get('client')
            if not client:return self.respond(400,{'error':'키움 API 연결이 필요합니다.'})
            feed=getattr(client,'_domestic_orderbook_feed',None)
            if feed is None:
                feed=DomesticOrderbookFeed(client);client._domestic_orderbook_feed=feed
            feed.ensure(c)
            # Event-waiting endpoint: the request returns as soon as Kiwoom 0D/0B
            # changes instead of polling the REST snapshot every second.
            data=feed.wait_snapshot(c,last_seq,0.75)
            cache=getattr(client,'_orderbook_rest_cache',{})
            static=cache.get(c) if isinstance(cache,dict) else None
            if isinstance(static,dict):
                # Keep slow-changing reference fields warm, but NEVER overwrite a
                # live 0D ladder/current price. This preserves HTS-like latency.
                for k in ('base_price','open','high','low','market_code'):
                    if data.get(k) in (None,'') and static.get(k) not in (None,''):
                        data[k]=static.get(k)
                live_book=any(float(x.get('price') or 0)>0 for x in (data.get('asks') or []) if isinstance(x,dict)) or any(float(x.get('price') or 0)>0 for x in (data.get('bids') or []) if isinstance(x,dict))
                if not live_book:
                    if any(float(x.get('price') or 0)>0 for x in (static.get('asks') or []) if isinstance(x,dict)):
                        data['asks']=static.get('asks',[])
                    if any(float(x.get('price') or 0)>0 for x in (static.get('bids') or []) if isinstance(x,dict)):
                        data['bids']=static.get('bids',[])
                    for k in ('ask_total','bid_total','orderbook_time'):
                        if static.get(k) not in (None,''):data[k]=static.get(k)
                    data['fallback_snapshot']=True
            has_book=any(float(x.get('price') or 0)>0 for x in (data.get('asks') or []) if isinstance(x,dict)) or any(float(x.get('price') or 0)>0 for x in (data.get('bids') or []) if isinstance(x,dict))
            if not has_book:
                last_book=_get_last_orderbook(c,7)
                if isinstance(last_book,dict):
                    for k in ('asks','bids','ask_total','bid_total','orderbook_time','market_code'):
                        if last_book.get(k) not in (None,''):data[k]=last_book.get(k)
                    data['cached_orderbook']=True; data['cached_at']=last_book.get('saved_at')
            now_kst=datetime.now(KST)
            data['market_closed']=(now_kst.weekday()>=5 or not (9 <= now_kst.hour < 20))
            data['name']=_best_known_stock_name(c,LOOKUP.get(c,{}))
            data['server_ts']=time.time()
            return self.respond(200,data)
        if path=='/api/orderbook':
            qs=parse_qs(urlparse(self.path).query)
            c=code((qs.get('code') or [''])[0])
            if not c:return self.respond(400,{'error':'종목코드가 필요합니다.'})
            with LOCK: client=STATE.get('client')
            if not client:return self.respond(400,{'error':'키움 API 연결이 필요합니다.'})
            feed=getattr(client,'_domestic_orderbook_feed',None)
            if feed is None:
                feed=DomesticOrderbookFeed(client);client._domestic_orderbook_feed=feed
            feed.ensure(c)
            live=feed.snapshot(c)
            # ka10004 is a REST snapshot and remains useful after the realtime
            # websocket stops sending at/after market close.  Cache briefly so
            # the 1-second UI refresh does not spam the REST endpoint.
            cache=getattr(client,'_orderbook_rest_cache',{})
            now=time.time(); cached=cache.get(c) if isinstance(cache,dict) else None
            live_has_book=any(float(x.get('price') or 0)>0 for x in (live.get('asks') or []) if isinstance(x,dict)) or any(float(x.get('price') or 0)>0 for x in (live.get('bids') or []) if isinstance(x,dict))
            # HTS-like first paint: when realtime 0D is already alive, do not block
            # the popup on ka10004/ka10001 REST. Use even a slightly stale static
            # reference snapshot immediately and refresh it in the background.
            static=dict(cached) if isinstance(cached,dict) else None
            fresh=isinstance(cached,dict) and now-float(cached.get('_ts') or 0)<1.2
            if not fresh:
                if live_has_book:
                    _warm_orderbook_static(client,c)
                    if static is None: static={}
                else:
                    try:
                        static=client.domestic_orderbook(c,'SOR')
                        static['_ts']=now
                        if not isinstance(cache,dict): cache={}
                        cache[c]=dict(static); client._orderbook_rest_cache=cache
                    except Exception as e:
                        static={'static_error':str(e)}
            # Prefer the SOR REST snapshot for price/base/orderbook so the screen
            # matches the MTS 통합 호가. Realtime 0D/0B is kept as a fallback.
            data=dict(live or {})
            if isinstance(static,dict):
                for k in ('current_price','change_rate','base_price','open','high','low','ask_total','bid_total','orderbook_time','venue','market_code','source'):
                    if static.get(k) not in (None,''): data[k]=static.get(k)
                if any(float(x.get('price') or 0)>0 for x in static.get('asks',[]) if isinstance(x,dict)):
                    data['asks']=static.get('asks',[])
                if any(float(x.get('price') or 0)>0 for x in static.get('bids',[]) if isinstance(x,dict)):
                    data['bids']=static.get('bids',[])
                if static.get('static_error'): data['static_error']=static['static_error']
            # Persist the last real 10-level snapshot. Kiwoom REST/realtime can
            # legitimately return an empty ladder after close/weekends; MTS can
            # still display its locally retained close snapshot, so LITTO keeps
            # its own last non-empty snapshot for the same purpose.
            has_book=any(float(x.get('price') or 0)>0 for x in (data.get('asks') or []) if isinstance(x,dict)) or any(float(x.get('price') or 0)>0 for x in (data.get('bids') or []) if isinstance(x,dict))
            if has_book:
                _save_last_orderbook(c,data)
            else:
                last_book=_get_last_orderbook(c,7)
                if isinstance(last_book,dict):
                    for k in ('asks','bids','ask_total','bid_total','orderbook_time','venue','market_code','source'):
                        if last_book.get(k) not in (None,''): data[k]=last_book.get(k)
                    data['cached_orderbook']=True
                    data['cached_at']=last_book.get('saved_at')
            now_kst=datetime.now(KST)
            data['market_closed']=(now_kst.weekday()>=5 or not (9 <= now_kst.hour < 20))
            data['name']=_best_known_stock_name(c,LOOKUP.get(c,{}))
            return self.respond(200,data)
        if path=='/api/investor-flow':
            qs=parse_qs(urlparse(self.path).query)
            c=(qs.get('code') or [''])[0]
            force=(qs.get('force',['0'])[0]=='1')
            try:return self.respond(200,investor_flow_snapshot(c,force=force))
            except (ValueError,ApiError) as e:return self.respond(400,{'error':str(e)})
        if path=='/api/program-flow-watch':
            qs=parse_qs(urlparse(self.path).query)
            raw=(qs.get('codes') or [''])[0]
            codes=[x.strip() for x in raw.split(',') if x.strip()][:80]
            force=(qs.get('force',['0'])[0]=='1')
            try:return self.respond(200,program_flow_watch_snapshot(codes,force=force))
            except (ValueError,ApiError) as e:return self.respond(400,{'error':str(e)})
        if path=='/api/news':
            qs=parse_qs(urlparse(self.path).query)
            c=(qs.get('code') or [''])[0]; name=(qs.get('name') or [''])[0]
            return self.respond(200,fetch_stock_news(c,name,10))
        if path=='/api/sector-strength-calendar':
            qs=parse_qs(urlparse(self.path).query)
            month=(qs.get('month') or [None])[0]
            try:return self.respond(200,sector_strength_calendar_snapshot(month))
            except ValueError as e:return self.respond(400,{'error':str(e)})
        if path=='/api/market-overview':
            qs=parse_qs(urlparse(self.path).query)
            force=(qs.get('force',['0'])[0]=='1')
            return self.respond(200,market_overview_snapshot(force=force))
        if path=='/api/market-investor-history':
            qs=parse_qs(urlparse(self.path).query)
            market=(qs.get('market') or ['kospi'])[0]
            try: days=int((qs.get('days') or ['10'])[0])
            except: days=10
            force=(qs.get('force',['0'])[0]=='1')
            try:return self.respond(200,market_investor_history_snapshot(market,days,force=force))
            except ValueError as e:return self.respond(400,{'error':str(e)})
        if path=='/api/header-indices':
            force=parse_qs(urlparse(self.path).query).get('force',['0'])[0]=='1'
            return self.respond(200,header_indices_snapshot(force=force))
        if path=='/api/nasdaq-futures-chart':
            force=parse_qs(urlparse(self.path).query).get('force',['0'])[0]=='1'
            return self.respond(200,nasdaq_futures_chart_snapshot(force=force))
        if path=='/api/us-market':
            force=parse_qs(urlparse(self.path).query).get('force',['0'])[0]=='1'
            return self.respond(200,us_market_snapshot(force=force))
        if path=='/api/account-watchlist-groups':
            return self.respond(200,account_watchlist_groups_snapshot())
        if path=='/api/account-watchlist':
            qs=parse_qs(urlparse(self.path).query)
            group=(qs.get('group') or [''])[0]
            try:return self.respond(200,account_watchlist_group_snapshot(group))
            except ValueError as e:return self.respond(400,{'error':str(e)})
        if path=='/api/us-watchlist':
            qs=parse_qs(urlparse(self.path).query)
            force=qs.get('force',['0'])[0]=='1'
            raw=(qs.get('symbols') or [''])[0]
            symbols=[x for x in raw.split(',') if x.strip()]
            if len(symbols)>80:return self.respond(400,{'error':'미국 관심종목은 한 번에 80개 이하만 조회합니다.'})
            return self.respond(200,us_watchlist_snapshot(symbols,force=force))
        if path=='/api/market-calendar':
            force=parse_qs(urlparse(self.path).query).get('force',['0'])[0]=='1'
            return self.respond(200,market_calendar.snapshot(force=force))
        if path=='/api/market-actions':
            force=parse_qs(urlparse(self.path).query).get('force',['0'])[0]=='1'
            return self.respond(200,market_actions_snapshot(force=force))
        if path=='/api/screener-history':
            qs=parse_qs(urlparse(self.path).query)
            day=(qs.get('date') or [None])[0]
            panel=(qs.get('panel') or [None])[0]
            try:limit=int((qs.get('limit') or ['1000'])[0])
            except Exception:limit=1000
            try:return self.respond(200,screener_history.snapshot(day,panel,limit))
            except Exception as e:return self.respond(500,{'error':'검색 이력 조회 실패: '+str(e)})
        if path=='/api/journal':
            qs=parse_qs(urlparse(self.path).query)
            start=(qs.get('start') or [None])[0];end=(qs.get('end') or [None])[0]
            try:limit=int((qs.get('limit') or ['500'])[0])
            except Exception:limit=500
            snap=journal.snapshot(ROOT,start=start,end=end,limit=limit)
            # 매매일지의 종목에도 LITTO에 저장된 사용자 섹터 DB를 그대로 표시한다.
            sector_map=sectors.load()
            for row in snap.get('rows',[]):
                c=code(row.get('stock_code'))
                info=sector_map.get(c,{})
                row['saved_sector']=info.get('sector') or ''
                row['saved_sector_source']=info.get('source') or ''
            return self.respond(200,snap)
        if path=='/api/journal/export':
            qs=parse_qs(urlparse(self.path).query);start=(qs.get('start') or [None])[0];end=(qs.get('end') or [None])[0]
            rows=journal.list_trades(ROOT,start,end,2000);buf=io.StringIO();w=csv.writer(buf)
            w.writerow(['날짜','종목코드','종목명','매수수량','평균매수가','매도수량','평균매도가','손익','수익률','수수료','세금','전략','원칙준수','추격','물타기','진입이유','매도이유','잘한점','잘못한점','다음행동','출처'])
            for r in rows:
                w.writerow([safe_cell(x) for x in [r.get('trade_date'),r.get('stock_code'),r.get('stock_name'),r.get('buy_qty'),r.get('buy_avg'),r.get('sell_qty'),r.get('sell_avg'),r.get('pnl'),r.get('return_rate'),r.get('fees'),r.get('tax'),r.get('strategy'),r.get('rule_followed'),r.get('chasing'),r.get('averaging_down'),r.get('entry_reason'),r.get('exit_reason'),r.get('good'),r.get('bad'),r.get('next_action'),r.get('source')]])
            return self.respond(200,'\ufeff'+buf.getvalue(),'text/csv; charset=utf-8','trading_journal.csv')
        if path=='/api/sectors':
            buf=io.StringIO();w=csv.writer(buf);w.writerow(['code','name','sector','source','asof']);mapping=sectors.load()
            for item in UNIVERSE:
                v=mapping.get(item['code'],{});w.writerow([safe_cell(x) for x in [item['code'],item['name'],v.get('sector','미분류'),v.get('source',''),v.get('asof','')]])
            return self.respond(200,'\ufeff'+buf.getvalue(),'text/csv; charset=utf-8','sectors.csv')
        if path=='/api/template':return self.respond(200,dataset(),attachment='example_prices.json')
        if path=='/api/export':
            with LOCK:report=STATE['report']
            buf=io.StringIO();writer=csv.writer(buf)
            writer.writerow(['종목코드','종목명','섹터','분류출처','기법','기술조건','상태','현재가','등락률(%)','거래대금(억원)','기준봉','조회시각','자료모드','미충족·확인사항'])
            for r in report['results']:
                for p in r['patterns']:
                    missing=' / '.join(c['label']+': '+c['detail'] for c in p['checks']+p['quality'] if c['state']!='pass')
                    writer.writerow([safe_cell(x) for x in [r['code'],r['name'],r['sector'],r.get('sector_source',''),p['name'],p['technical'],p['status'],r['price'],round(r['change'],2),r['value_eok'],(r['base'] or {}).get('date'),r['asof'],report['mode'],missing]])
            return self.respond(200,'\ufeff'+buf.getvalue(),'text/csv; charset=utf-8','scan_results.csv')
        if path=='/mts':
            html=(ROOT/'web/mts.html').read_text(encoding='utf-8').replace('__CSRF__',CSRF)
            return self.respond(200,html,'text/html; charset=utf-8')
        if path in ('/mts.js','/mts.css'):
            ctype='application/javascript' if path.endswith('.js') else 'text/css'
            return self.respond(200,(ROOT/'web'/path[1:]).read_bytes(),ctype+'; charset=utf-8')
        if path=='/':
            html=(ROOT/'web/index.html').read_text(encoding='utf-8').replace('__CSRF__',CSRF)
            # Dev build self-heal: always expose page 4 even if an older index.html
            # was accidentally left in the working folder.
            if 'data-page="us"' not in html:
                anchor='<button class="litto-pagebtn" data-page="market">3. 시장종합</button>'
                usbtn=anchor+'\n      <button class="litto-pagebtn" data-page="us">4. 미국시장</button>'
                html=html.replace(anchor,usbtn,1)
            if 'data-page="journal"' not in html:
                anchor='<button class="litto-pagebtn" data-page="us">4. 미국시장</button>'
                html=html.replace(anchor,anchor+'\n      <button class="litto-pagebtn" data-page="journal">5. 매매일지</button>',1)
            # Force a fresh frontend on every dev patch revision.
            html=html.replace('href="/style.css"','href="/style.css?v=20260917journal1"')
            html=html.replace('src="/app.js"','src="/app.js?v=20260918fzone-dev1"')
            return self.respond(200,html,'text/html; charset=utf-8')
        if path in ('/app.js','/style.css'):
            ctype='application/javascript' if path.endswith('.js') else 'text/css'
            return self.respond(200,(ROOT/'web'/path[1:]).read_bytes(),ctype+'; charset=utf-8')
        return self.respond(404,{'error':'찾을 수 없습니다.'})

    def do_POST(self):
        if not self.trusted() or self.headers.get('X-Session-Token')!=CSRF:
            return self.respond(403,{'error':'세션 확인 실패. 페이지를 새로고침하세요.'})
        try:
            size=int(self.headers.get('Content-Length',0))
            if not 0<size<=30_000_000:raise ValueError('요청 파일은 30MB 이하입니다.')
            body=json.loads(self.rfile.read(size))
            path=urlparse(self.path).path
            with LOCK:
                # The heavy scanner runs in a background thread.  Keep local/UI
                # operations responsive while it is running.  Only operations
                # that would start another heavy scan or replace/disconnect the
                # Kiwoom client are blocked.
                scan_conflicts={'/api/scan','/api/connect','/api/disconnect','/api/demo','/api/import'}
                if STATE['busy'] and path in scan_conflicts and path!='/api/cancel':
                    return self.respond(409,{'error':'백그라운드 검색 중입니다. 이 작업은 검색 완료 후 다시 시도하세요.'})
                if path=='/api/top5-performance/save':
                    return self.respond(200,top5_performance_save_snapshot(body))
                if path=='/api/order/arm':
                    return self.respond(200,manual_order_arm(body))
                elif path=='/api/order/place':
                    return self.respond(200,manual_place_order(body))
                elif path=='/api/order/unfilled':
                    return self.respond(200,manual_unfilled_orders(body.get('code') or ''))
                elif path=='/api/order/cancel':
                    return self.respond(200,manual_cancel_order(body))
                elif path=='/api/order/cancel-all':
                    return self.respond(200,manual_cancel_all(body))
                elif path=='/api/journal/import':
                    result=journal_import_from_kiwoom(body.get('date'))
                    STATE['progress']=f"매매일지 자동수집 완료 · {result['date']} · {result['rows']}건"
                    return self.respond(200,{**result,'journal':journal.snapshot(ROOT,start=result['date'],end=result['date'],limit=500)})
                elif path=='/api/journal/review':
                    row=journal.update_review(ROOT,int(body.get('id')),body.get('review') or {})
                    return self.respond(200,{'row':row,'journal':journal.snapshot(ROOT,limit=500)})
                elif path=='/api/journal/manual':
                    row=journal.add_manual(ROOT,body.get('trade') or {})
                    return self.respond(200,{'row':row,'journal':journal.snapshot(ROOT,limit=500)})
                elif path=='/api/journal/delete':
                    journal.delete_trade(ROOT,int(body.get('id')))
                    return self.respond(200,{'ok':True,'journal':journal.snapshot(ROOT,limit=500)})
                elif path=='/api/journal/storage':
                    info=journal.set_storage_dir(ROOT,body.get('directory') or '',migrate=bool(body.get('migrate',True)))
                    return self.respond(200,{'ok':True,'storage':info,'journal':journal.snapshot(ROOT,limit=500)})
                elif path=='/api/journal/storage-reset':
                    info=journal.reset_storage_dir(ROOT,migrate=bool(body.get('migrate',True)))
                    return self.respond(200,{'ok':True,'storage':info,'journal':journal.snapshot(ROOT,limit=500)})
                elif path=='/api/journal/storage-confirm-default':
                    info=journal.confirm_default_storage(ROOT)
                    return self.respond(200,{'ok':True,'storage':info,'journal':journal.snapshot(ROOT,limit=500)})
                elif path=='/api/sectors':
                    incoming=sectors.parse(body['text']);mapping=sectors.load();mapping.update(incoming);sectors.save(mapping);sectors.apply(STATE['data'],mapping);_request_page1_recalc();STATE['progress']=f'섹터 {len(incoming)}개 적용 및 저장'
                elif path=='/api/sector-sync':
                    if not STATE['client']:raise ValueError('키움 API 연결이 필요합니다.')
                    if STATE.get('sector_busy'):raise ValueError('이미 섹터 동기화 중입니다.')
                    threading.Thread(target=sector_sync_worker,daemon=True).start()
                    STATE['sector_progress']='전 종목 섹터 동기화 시작'
                elif path=='/api/sector':
                    c=code(body['code']); sector=str(body.get('sector','')).strip()[:100]
                    if not sector: raise ValueError('섹터명을 입력하세요.')
                    mapping=sectors.load()
                    mapping[c]={'sector':sector,'source':'사용자 직접 지정','asof':datetime.now(KST).date().isoformat()}
                    sectors.save(mapping)
                    # Apply immediately to all current stock rows and recompute panels.
                    for st in STATE['data'].get('stocks',[]):
                        if code(st.get('code'))==c:
                            st['sector']=sector;st['sector_source']='사용자 직접 지정 '+datetime.now(KST).date().isoformat()
                    _request_page1_recalc();STATE['progress']=f'{c} 사용자 섹터 저장: {sector}'
                elif path=='/api/demo':
                    STATE['data']=dataset();STATE['fetch_errors']=[];STATE['ranks']={'value_top':[],'change_top':[],'today_limit':[],'prev_limit':[],'source':'가상 예시'};recompute();STATE['progress']='가상 예시 불러옴'
                elif path=='/api/import':
                    data=parse_file(body['text'],body.get('kind','json'),body.get('asof') or None)
                    sectors.apply(data,sectors.load())
                    report=scan_dataset(data,STATE['settings'],STATE['market'])
                    if not report['results'] and not report['excluded_products']:raise ValueError('유효한 종목 없음: '+str(report['errors'][:3]))
                    STATE.update(data=data,report=report,fetch_errors=[],progress='시세 파일 분석 완료')
                elif path=='/api/settings':
                    new=config(body.get('settings'))
                    market=body.get('market','unknown')
                    if market not in ('unknown','weak','strong','mixed'):raise ValueError('장세 설정값 오류')
                    STATE['settings']=new;STATE['market']=market;recompute()
                elif path=='/api/review':
                    c=code(body['code']);found=False
                    for s in STATE['data']['stocks']:
                        if code(s['code'])==c:
                            rev=body.get('review',{})
                            if any(rev.get(k) is not None and type(rev.get(k)) is not bool for k in REVIEW_FIELDS):raise ValueError('확인값 오류')
                            rev={k:rev.get(k) for k in REVIEW_FIELDS}
                            rev['date']=max(b['date'] for b in s['daily'])
                            s['review']=rev
                            sector=str(body.get('sector','미분류'))[:80]
                            if sector and sector!='미분류' and sector!=s.get('sector'):
                                mapping=sectors.load();mapping[c]={'sector':sector,'source':'사용자 직접 지정','asof':rev['date']};sectors.save(mapping)
                            s['sector']=sector;found=True;break
                    if not found:raise ValueError('종목을 찾을 수 없습니다.')
                    recompute()
                elif path=='/api/connect':
                    appkey=body.get('appkey') or ''
                    secretkey=body.get('secretkey') or ''
                    if not appkey or not secretkey:
                        saved_app,saved_secret=_load_credentials()
                        appkey=appkey or saved_app or os.getenv('KIWOOM_APPKEY','')
                        secretkey=secretkey or saved_secret or os.getenv('KIWOOM_SECRETKEY','')
                    if not appkey or not secretkey:raise ValueError('App Key와 Secret Key를 입력하세요.')
                    client=Kiwoom(appkey,secretkey,body.get('mock',False))
                    client.auth()
                    if not client.mock:
                        try:_save_credentials(appkey,secretkey)
                        except Exception as e:raise ValueError('인증은 성공했지만 자동 로그인 저장에 실패했습니다: '+str(e))
                    STATE.update(client=client,connected=True,mock=client.mock,progress='키움 인증 성공 · 로그인 유지 설정 완료 · 아직 시세 검색 전',realtime_rank={'rows':[],'daily_rows':[],'updated_at':None,'source':'키움 ka00198 · 2초 확인','daily_source':'키움 ka00198 · 당일 누적','error':None},realtime_rank_prev={})
                    # Same daily guard as auto-login: first successful login only.
                    _start_daily_stock_master_refresh(client)
                    # First-use convenience: populate basic sectors automatically.
                    # Existing manual sectors remain authoritative.
                    try:
                        mapping=sectors.load()
                        mapped=sum(1 for v in mapping.values() if v.get('sector') and v.get('sector')!='미분류')
                        if mapped < 100 and not STATE.get('sector_busy'):
                            threading.Thread(target=sector_sync_worker,daemon=True).start()
                    except Exception:
                        pass
                    start_page1_live_engine()
                elif path=='/api/forget-credentials':
                    _delete_credentials();STATE['progress']='저장된 키움 인증정보 삭제 완료'
                elif path=='/api/disconnect':
                    old_client=STATE.get('client')
                    if old_client:
                        try:
                            f=getattr(old_client,'_domestic_realtime_feed',None)
                            if f:f.stop()
                        except Exception:
                            pass
                    stop_live_leader_engine()
                    stop_page1_live_engine()
                    STATE.update(client=None,connected=False,progress='키움 연결 해제 · 저장된 인증정보는 유지됨',realtime_rank={'rows':[],'daily_rows':[],'updated_at':None,'source':'키움 ka00198 · 2초 확인','daily_source':'키움 ka00198 · 당일 누적','error':'키움 미연결'},realtime_rank_prev={})
                elif path=='/api/scan':
                    if not STATE['client']:raise ValueError('키움 API 연결이 필요합니다.')
                    STATE['scan_options']={'scope':body.get('scope','all'),'limit':body.get('limit',100),'watchlist':body.get('watchlist','')}
                    STATE.update(busy=True,done=0,total=0,progress='검색 대상 조회 중');STATE['cancel'].clear()
                    threading.Thread(target=live_worker,args=(body,),daemon=True).start()
                elif path=='/api/cancel':STATE['cancel'].set();STATE['progress']='현재 종목 조회 후 중지합니다.'
                else:return self.respond(404,{'error':'없는 요청입니다.'})
            return self.respond(200,snapshot())
        except (ValueError,KeyError,TypeError,ApiError) as e:
            return self.respond(400,{'error':str(e)})

def main():
    parser=argparse.ArgumentParser();parser.add_argument('--port',type=int,default=8765);parser.add_argument('--no-browser',action='store_true');a=parser.parse_args()
    try:server=ThreadingHTTPServer(('127.0.0.1',a.port),Handler)
    except OSError:
        print('포트 사용 중입니다. 기존 실행 창을 닫거나 python app.py --port 8766 으로 실행하세요.');return
    url=f'http://127.0.0.1:{server.server_port}'
    print('LITTO Trading System | '+url+' | 종료: Ctrl+C')
    # Restore the saved Kiwoom session BEFORE opening the browser.
    # This makes restart/login behavior deterministic instead of racing the UI.
    _startup_auto_connect()
    if not a.no_browser:threading.Timer(.35,lambda:webbrowser.open(url)).start()
    try:server.serve_forever()
    except KeyboardInterrupt:STATE['cancel'].set();server.server_close()

if __name__=='__main__':main()
