// Timer refreshes must not accumulate while a previous read is still running.
const LITTO_REFRESH_BUSY=new Set();
async function littoRefreshOnce(key,loader){
  if(LITTO_REFRESH_BUSY.has(key))return;
  LITTO_REFRESH_BUSY.add(key);
  try{return await loader()}finally{LITTO_REFRESH_BUSY.delete(key)}
}
const $=s=>document.querySelector(s), $$=s=>[...document.querySelectorAll(s)];
const token=document.body.dataset.token; let STATE=null, activePanel='끼도주 종배';
let chartStock=null, chartTf='daily';
let CHART_SPLIT_MODE=false, CHART_SPLIT_LOADING=false;
let CHART_LINE_MODE=null, CHART_GEOM=null, CHART_HOVER_PRICE=null;
const CHART_LEVELS_KEY='litto_chart_support_levels_v1';
const CHART_MARKERS_KEY='litto_chart_market_close_markers_v1';
let CHART_MARKERS_ENABLED=localStorage.getItem(CHART_MARKERS_KEY)!=='0';
const CHART_FZONE_KEY='litto_chart_fzone_visible_v1';
let CHART_FZONE_ENABLED=localStorage.getItem(CHART_FZONE_KEY)!=='0';
const CHART_ZOOM_BARS={daily:90,m15:120,m3:120,m1:120};
const CHART_PAN_OFFSET={daily:0,m15:0,m3:0,m1:0};
let CHART_DRAG_ACTIVE=false,CHART_DRAG_MOVED=false,CHART_DRAG_SUPPRESS_CLICK=false,CHART_DRAG_RAF=0;
const GENERAL_CHART_CACHE=new Map();
const GENERAL_CHART_CACHE_TTL=20000;
function syncChartMarkerButtons(){const on=CHART_MARKERS_ENABLED;const main=document.getElementById('chartMarketMarkersToggle');if(main){main.textContent=on?'장마감선 ON':'장마감선 OFF';main.classList.toggle('active',on)}const mini=document.getElementById('obMiniMarkerToggle');if(mini){mini.textContent=on?'마감선 ON':'마감선 OFF';mini.classList.toggle('active',on)}}
function setChartMarkersEnabled(v){CHART_MARKERS_ENABLED=!!v;try{localStorage.setItem(CHART_MARKERS_KEY,CHART_MARKERS_ENABLED?'1':'0')}catch(_e){}syncChartMarkerButtons();if(chartStock)drawChart();window.dispatchEvent(new Event('litto-chart-marker-toggle'))}
function syncChartFzoneButtons(){const on=CHART_FZONE_ENABLED;const main=document.getElementById('chartFzoneToggle');if(main){main.textContent=on?'F존 ON':'F존 OFF';main.classList.toggle('active',on)}const mini=document.getElementById('obMiniFzoneToggle');if(mini){mini.textContent=on?'F존 ON':'F존 OFF';mini.classList.toggle('active',on)}}
function setChartFzoneEnabled(v){CHART_FZONE_ENABLED=!!v;try{localStorage.setItem(CHART_FZONE_KEY,CHART_FZONE_ENABLED?'1':'0')}catch(_e){}syncChartFzoneButtons();if(chartStock)drawChart();window.dispatchEvent(new Event('litto-chart-fzone-toggle'))}
let LIVE_RANK={rows:[],updated_at:null,source:'키움 ka00198 · 2초 확인',error:null};
const DAILY_RANK_PREFIX='litto_daily_live_rank_v1_';
let DAILY_RANK_ROWS=[];
function rankDayKey(){const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`}
function dailyRankStorageKey(){return DAILY_RANK_PREFIX+rankDayKey()}
function loadDailyRanks(){try{const raw=localStorage.getItem(dailyRankStorageKey());DAILY_RANK_ROWS=raw?JSON.parse(raw):[];if(!Array.isArray(DAILY_RANK_ROWS))DAILY_RANK_ROWS=[]}catch(e){DAILY_RANK_ROWS=[]}}
function saveDailyRanks(){try{localStorage.setItem(dailyRankStorageKey(),JSON.stringify(DAILY_RANK_ROWS.slice(0,120)))}catch(e){}}
function mergeDailyRanks(rows){const now=Date.now(),m=new Map((DAILY_RANK_ROWS||[]).map(x=>[String(x.code||''),x]));for(const r of (rows||[])){const code=String(r.code||'');if(!code)continue;const prev=m.get(code)||{};const rank=Number(r.rank||999);m.set(code,{...prev,...r,code,first_seen:prev.first_seen||now,last_seen:now,best_rank:Math.min(Number(prev.best_rank||999),rank),last_rank:rank})}DAILY_RANK_ROWS=[...m.values()].sort((a,b)=>(Number(a.best_rank||999)-Number(b.best_rank||999))||(Number(b.last_seen||0)-Number(a.last_seen||0)));saveDailyRanks()}
function ensureDailyRankPanel(){const root=$('#realtimeRankRows'),risers=$('#realtimeRankRisers');if(!root||!risers)return null;const dash=root.closest('.rank-dashboard');if(!dash)return null;let panel=$('#realtimeRankDailyPanel');if(!panel){panel=document.createElement('div');panel.id='realtimeRankDailyPanel';panel.className='rank-daily-panel';panel.innerHTML='<div class="rank-subhead"><b>당일 누적순위 TOP 20</b><span>키움 ka00198 · 당일 누적</span></div><div id="realtimeRankDaily" class="live-rank-list compact-rank"><div class="empty">키움 연결 후 당일 누적순위가 표시됩니다.</div></div>';risers.parentElement.insertAdjacentElement('beforebegin',panel)}const firstHead=root.parentElement?.querySelector('.rank-subhead');if(firstHead){const b=firstHead.querySelector('b'),sp=firstHead.querySelector('span');if(b)b.textContent='실시간 TOP 20';if(sp)sp.textContent='키움 현재 순위'}return $('#realtimeRankDaily')}
loadDailyRanks();
const PANEL_ORDER=['주도주 종배','주도주 상따','끼도주 종배','종배 우선순위','강한 섹터','종배 TOP5','검색 진단','전일 후보','피뢰침','하트존','F존','오늘의 상한가','약상매매 후보'];

const PAGE1_AUTO_INTERVAL_MS=5*60*1000;
function autoScanButton(){return $('#autoScanToggle')}
function installAutoScanButton(){
  const scan=$('#scan'); if(!scan||autoScanButton())return;
  const b=document.createElement('button');b.id='autoScanToggle';b.type='button';b.className=scan.className||'';
  b.disabled=true;b.textContent='1페이지 AUTO · 백엔드';
  b.title='전체검색 스케줄은 브라우저가 아니라 백엔드에서 관리합니다.';
  scan.insertAdjacentElement('afterend',b);
}
function updateAutoScanButton(){
  const b=autoScanButton();if(!b)return;
  const p=STATE?.page1_live||{};
  const sec=p.next_heavy_seconds;
  b.textContent=`1페이지 AUTO · ${sec==null?'대기':Math.ceil(sec/60)+'분'}`;
}
async function runScan(auto=false){
  if(auto)return; // V7: automatic heavy scans are backend-owned.
  try{
    const next=await api('/api/scan',{scope:$('#scope').value,limit:100,watchlist:$('#watch').value});
    render(next);
  }catch(e){alert(e.message)}
}
function autoScanTick(){installAutoScanButton();updateAutoScanButton()}
function ensurePage1Monitor(){
  const badge=$('#page1LiveStatus');if(!badge||$('#page1LiveMonitor'))return;
  const wrap=document.createElement('div');wrap.id='page1LiveMonitor';wrap.style.cssText='display:flex;gap:6px;align-items:center;flex-wrap:wrap;margin-top:6px;font-size:11px;color:#8fa4b8';
  wrap.innerHTML='<span id="p1MonText">실시간 엔진 준비</span><button id="p1DiagBtn" type="button" class="ghost" style="padding:3px 7px;font-size:11px">진단</button>';
  badge.parentElement?.appendChild(wrap);
  $('#p1DiagBtn').onclick=async()=>{try{const r=await fetch('/api/page1-diagnostic');const d=await r.json();if(!r.ok)throw Error(d.error||'진단 실패');console.log('LITTO PAGE1 DIAGNOSTIC',d);alert(`PAGE1 진단\n상태: ${d.live?.state||'-'}\n후보: ${d.live?.candidate_count||0}종목\n구독: ${d.live?.realtime?.subscribed||0}종목\n신선: ${d.live?.realtime?.fresh_count||0}종목\nSTALE: ${d.live?.realtime?.stale_count||0}종목\nAPI 오류: ${d.live?.api_gate?.errors||0}\n세부값은 개발자도구 콘솔에 출력했어.`)}catch(e){alert(e.message)}};
}

async function api(path,body){const r=await fetch(path,{method:'POST',headers:{'Content-Type':'application/json','X-Session-Token':token},body:JSON.stringify(body||{})});const d=await r.json();if(!r.ok)throw Error(d.error||'요청 실패');return d}
const money=n=>n==null?'-':Number(n).toLocaleString(undefined,{maximumFractionDigits:0}); const pct=n=>n==null?'-':`${n>=0?'+':''}${Number(n).toFixed(2)}%`; function cls(n){return n>0?'up':n<0?'down':''}

function applyLittoV12Branding(){
  try{
    document.title=String(document.title||'LITTO Trading System').replace(/v1\.(?:0|2|21)/gi,'v1.22').replace(/VERSION\s*1\.(?:0|2|21)/gi,'VERSION 1.22');
    const walker=document.createTreeWalker(document.body,NodeFilter.SHOW_TEXT);
    const nodes=[];
    let n;
    while((n=walker.nextNode())){
      const t=n.nodeValue||'';
      if(/(?:LITTO\s*)?VERSION\s*1\.0|LITTO\s*v1\.0|\bv1\.0\b/i.test(t))nodes.push(n);
    }
    for(const node of nodes){
      node.nodeValue=String(node.nodeValue||'')
        .replace(/LITTO\s+VERSION\s+1\.(?:0|2|21)/gi,'LITTO VERSION 1.22')
        .replace(/VERSION\s+1\.(?:0|2|21)/gi,'VERSION 1.22')
        .replace(/LITTO\s+v1\.(?:0|2|21)/gi,'LITTO v1.22')
        .replace(/\bv1\.(?:0|2|21)\b/gi,'v1.22');
    }
    document.querySelectorAll('[title],[aria-label]').forEach(el=>{
      for(const a of ['title','aria-label']){
        const v=el.getAttribute(a);
        if(v&&/v1\.0|version\s*1\.0/i.test(v)){
          el.setAttribute(a,v.replace(/v1\.(?:0|2|21)/gi,'v1.22').replace(/VERSION\s*1\.(?:0|2|21)/gi,'VERSION 1.22'));
        }
      }
    });
  }catch(_e){}
}


function ensureInlineScannerHidden(){
  if(!document.getElementById('littoInlineScannerHiddenStyle')){
    const st=document.createElement('style');
    st.id='littoInlineScannerHiddenStyle';
    st.textContent=`
      /* v1.2: inline scanner remains in DOM only as the floating scanner render source. */
      #scanner{
        position:absolute !important;
        left:-100000px !important;
        top:0 !important;
        width:1px !important;
        height:1px !important;
        min-height:0 !important;
        margin:0 !important;
        padding:0 !important;
        overflow:hidden !important;
        opacity:0 !important;
        pointer-events:none !important;
      }
      .principle-card{
        display:none !important;
      }
    `;
    document.head.appendChild(st);
  }
  const scanner=document.getElementById('scanner');
  if(scanner){
    scanner.setAttribute('aria-hidden','true');
    scanner.dataset.inlineHidden='1';
  }
  document.querySelectorAll('.principle-card').forEach(el=>el.setAttribute('aria-hidden','true'));
}


function updateLittoHeaderClock(){
  const clock=document.getElementById('littoHeaderClock');
  if(!clock)return;
  const now=new Date();
  clock.textContent=now.toLocaleTimeString('ko-KR',{
    hour:'2-digit',minute:'2-digit',second:'2-digit',hour12:false
  });
}

function ensureV12HeaderPolish(){
  if(!document.getElementById('littoV12HeaderPolishStyle')){
    const st=document.createElement('style');
    st.id='littoV12HeaderPolishStyle';
    st.textContent=`
      /* v1.2 header/sticky polish */
      .topbar,
      header.topbar,
      .pagebar,
      #pageBar,
      #tradeSubtabs,
      .trade-subtabs,
      .litto-sticky-marketbar{
        background:#07111d !important;
        backdrop-filter:none !important;
      }

      /* Eliminate transparent seam where scrolling text was visible through. */
      .pagebar,
      #pageBar{
        margin-bottom:0 !important;
        padding-bottom:0 !important;
        border-bottom:1px solid #1b3042 !important;
      }
      #tradeSubtabs,
      .trade-subtabs{
        margin-top:0 !important;
        border-top:0 !important;
        transform:translateY(-1px);
        box-shadow:0 8px 18px rgba(0,0,0,.28);
      }

      /* Main top navigation slightly more compact. */
      .pagebar button,
      #pageBar button,
      .page-tab{
        font-size:15px !important;
        min-height:48px !important;
        padding:10px 18px !important;
        border-radius:16px !important;
      }

      #littoHeaderClock{
        display:inline-flex;
        align-items:center;
        margin-left:10px;
        padding:5px 10px;
        border:1px solid #29435a;
        border-radius:999px;
        background:#0b1825;
        color:#a9bfd3;
        font-size:12px;
        font-weight:700;
        font-variant-numeric:tabular-nums;
        letter-spacing:.02em;
        white-space:nowrap;
        vertical-align:middle;
      }
    `;
    document.head.appendChild(st);
  }

  // Put live clock immediately after the version badge.
  let versionEl=[...document.querySelectorAll('body *')].find(el=>{
    const t=(el.textContent||'').trim();
    // v1.21 포함 모든 1.x 버전 배지를 인식한다.
    return /^LITTO VERSION 1\.\d+(?:\.\d+)?$/i.test(t) && el.children.length===0;
  });
  if(versionEl && !document.getElementById('littoHeaderClock')){
    const clock=document.createElement('span');
    clock.id='littoHeaderClock';
    versionEl.insertAdjacentElement('afterend',clock);
  }

  const clock=document.getElementById('littoHeaderClock');
  if(clock){
    updateLittoHeaderClock();
    if(!document.getElementById('kiwoomLoginBtn')){
      const btn=document.createElement('button');
      btn.id='kiwoomLoginBtn';
      btn.type='button';
      btn.textContent='키움 로그인';
      clock.insertAdjacentElement('afterend',btn);
      btn.onclick=openKiwoomLoginModal;
    }
  }

  // 장전 확인 사이트 버튼은 시계 생성 여부와 무관하게 항상 복구 시도.
  ensurePremarketSitesUI();
}

function esc(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}
function sectorTags(v){return String(v||'').split(/[,;]+/).map(x=>x.trim()).filter(Boolean)}
function patchSectorEverywhere(root,code,sector){
  const c=String(code||'');
  if(!root||!c)return;
  const seen=new WeakSet();
  const walk=v=>{
    if(!v||typeof v!=='object'||seen.has(v))return;
    seen.add(v);
    if(String(v.code||'')===c){
      v.sector=sector;
      if('sector_source' in v)v.sector_source='사용자 직접 지정';
    }
    if(Array.isArray(v)){v.forEach(walk);return}
    Object.values(v).forEach(walk);
  };
  walk(root);
}
function rerenderSectorViews(){
  try{renderPanel()}catch(_e){}
  try{renderMain()}catch(_e){}
  try{renderMetrics()}catch(_e){}
  try{renderRealtimeRank()}catch(_e){}
  try{renderWatchlistPage()}catch(_e){}
  // 관심종목형 검색결과 화면을 보고 있는 중이면 섹터 변경을 즉시 반영한다.
  // 이전에는 이 화면만 재렌더링하지 않아 다른 메뉴에 갔다 와야 섹터명이 바뀌었다.
  try{
    if(typeof SCANNER_RESULTS_ACTIVE!=='undefined' && SCANNER_RESULTS_ACTIVE && typeof renderScannerResultsPage==='function'){
      renderScannerResultsPage(activePanel);
    }
  }catch(_e){}
  try{
    const fw=document.getElementById('scannerFloatWindow');
    if(fw && !fw.hidden && !fw.classList.contains('scanner-float-closed')){
      refreshScannerFloatWindow(activePanel);
    }
  }catch(_e){}
}
async function editSector(code,current){
  const v=prompt('사용자 섹터를 입력하세요. 여러 개면 쉼표(,)로 구분하세요.',current&&current!=='미분류'?current:'');
  if(v===null)return;
  const sector=v.trim();
  if(!sector){alert('섹터명을 입력하세요.');return}
  try{
    const data=await api('/api/sector',{code,sector});
    const c=String(code||'');

    // 관심종목 저장값도 즉시 갱신
    const rows=loadWatchlist();
    let changed=false;
    for(const x of rows){
      if(String(x.code||'')===c){
        x.sector=sector;
        changed=true;
      }
    }
    if(changed)saveWatchlist(rows);

    // 백엔드 report 재계산을 기다리지 않고 현재 응답/화면 상태를 즉시 패치
    patchSectorEverywhere(data,c,sector);
    patchSectorEverywhere(STATE,c,sector);
    patchSectorEverywhere(LIVE_RANK,c,sector);
    patchSectorEverywhere(WATCH_MANUAL_LIVE,c,sector);

    render(data);

    // render()가 STATE를 교체한 뒤 새 STATE에도 한 번 더 반영
    patchSectorEverywhere(STATE,c,sector);
    rerenderSectorViews();
  }catch(e){alert(e.message)}
}
function findStock(code){return (STATE?.report?.results||[]).find(x=>String(x.code)===String(code))||null}
function findFZone(code){const root=STATE?.report?.search_panels||{};const rows=root?.panels?.['F존']?.rows||[];const hit=rows.find(x=>String(x.code)===String(code));if(hit)return hit;const p=root?.fzone_profiles?.[String(code)]||null;return p?{...p,levels:p.levels||{}}:null}
function findBaseSetup(code){const root=STATE?.report?.search_panels?.panels||{};for(const name of ['피뢰침','하트존']){const hit=(root[name]?.rows||[]).find(x=>String(x.code)===String(code));if(hit?.levels?.['기준봉일'])return {name,date:String(hit.levels['기준봉일']),levels:hit.levels}}return null}

const AUTOLOGIN_KEY='litto_kiwoom_credentials_v1';
let AUTOLOGIN_TRIED=false;
function saveBrowserCredentials(appkey,secretkey){
  if(!appkey||!secretkey)return;
  try{localStorage.setItem(AUTOLOGIN_KEY,JSON.stringify({appkey,secretkey,savedAt:Date.now()}));}catch(e){}
}
function loadBrowserCredentials(){
  try{const raw=localStorage.getItem(AUTOLOGIN_KEY);if(!raw)return null;const v=JSON.parse(raw);return v&&v.appkey&&v.secretkey?v:null}catch(e){return null}
}
function clearBrowserCredentials(){try{localStorage.removeItem(AUTOLOGIN_KEY)}catch(e){}}
async function browserAutoLogin(state){
  if(AUTOLOGIN_TRIED||state?.connected)return;
  AUTOLOGIN_TRIED=true;
  const c=loadBrowserCredentials();
  if(!c)return;
  const el=$('#credentialStatus');if(el)el.textContent='저장된 App Key / Secret Key로 자동 로그인 중...';
  try{
    const next=await api('/api/connect',{appkey:c.appkey,secretkey:c.secretkey,mock:false,remember:true});
    render(next);if(el)el.textContent='자동 로그인 유지 중 · App Key / Secret Key 저장됨';
    setTimeout(()=>refreshRealtimeRank(true),300);
  }catch(e){
    if(el)el.textContent='자동 로그인 실패 · 저장정보는 유지됨 · '+e.message;
  }
}
function render(state){
  ensureV12HeaderPolish();
  ensureInlineScannerHidden();
  STATE=state;const r=state.report||{};
  $('#conn').textContent=state.connected?(state.mock?'키움 모의 연결':'키움 실전 연결'):'키움 미연결'; const kb=$('#kiwoomLoginBtn'); if(kb){kb.textContent='로그인';kb.classList.toggle('connected',!!state.connected);kb.title=state.connected?'키움 연결됨 · 클릭해서 설정 열기':'키움 로그인 및 검색 설정';}
  $('#progress').textContent=state.progress||'';
  const p1=state.page1_live||{},rt=p1.realtime||{},gate=p1.api_gate||{};
  const p1s=$('#page1LiveStatus');
  if(p1s){
    p1s.textContent=state.connected?`${p1.state||'LIVE'} · 후보 2초 · 전체검색 5분`:'LIVE 대기';
    p1s.title=p1.error||'0B 틱 실시간 + 후보순위 2초 + 전체검색 5분 백엔드';
    p1s.classList.toggle('live-ok',state.connected&&p1.state==='LIVE');
  }
  ensurePage1Monitor();
  const mon=$('#p1MonText');if(mon){
    const age=rt.last_message_age==null?'-':`${Math.round(rt.last_message_age)}초`;
    const next=p1.next_heavy_seconds==null?'-':`${Math.floor(p1.next_heavy_seconds/60)}:${String(p1.next_heavy_seconds%60).padStart(2,'0')}`;
    mon.textContent=`체결 ${rt.connected?'LIVE':'대기'} · 구독 ${rt.subscribed||0} · 신선 ${rt.fresh_count||0} · STALE ${rt.stale_count||0} · 마지막 ${age} · 후보 ${p1.candidate_count||0} · 전체검색 ${state.busy?'진행중':next} · API오류 ${gate.errors||0}`;
  }
  updateAutoScanButton();
  if(typeof TRADE_SUBTAB!=='undefined'&&TRADE_SUBTAB==='watch')setTimeout(()=>renderWatchlistPage(),0);
  const ss=state.sector_stats||{};const sp=$('#sectorProgress');if(sp)sp.textContent=state.sector_busy?(state.sector_progress||'섹터 동기화 중'):`섹터 DB ${ss.mapped||0}/${ss.total||state.universe_count||0} · 미분류 ${ss.missing_count||0}${ss.manual?` · 직접지정 ${ss.manual}`:''}`;
  $('#asof').textContent=r.asof?new Date(r.asof).toLocaleString():'-';renderTabs();renderPanel();renderMain();renderMetrics();if(chartStock){const fresh=findStock(chartStock.code);if(fresh){const prev=chartStock;chartStock={...prev,...fresh};for(const k of ['daily','m1','m3','m15']){const a=Array.isArray(prev?.[k])?prev[k]:[],b=Array.isArray(fresh?.[k])?fresh[k]:[];chartStock[k]=b.length>a.length?b:a}drawChart()}}renderRealtimeRank()
}

function installMetricCardJumps(){
  const jumps={
    metricClose:'주도주 종배',
    metricLimit:'주도주 상따',
    metricKki:'끼도주 종배',
    metricPriority:'종배 우선순위',
    metricPrev:'전일 후보',
    metricLightning:'피뢰침',
    metricHeart:'하트존',
    metricFzone:'F존',
    metricSector:'강한 섹터',
    metricClosingTop5:'종배 TOP5'
  };
  for(const [id,panel] of Object.entries(jumps)){
    const value=document.getElementById(id), card=value?.closest('.metric-card');
    if(!card||card.dataset.metricJumpBound==='1')continue;
    card.dataset.metricJumpBound='1';
    card.dataset.metricPanel=panel;
    card.classList.add('metric-clickable');
    card.setAttribute('role','button');
    card.setAttribute('tabindex','0');
    card.title=`클릭하면 ${panel}로 이동`;
    const go=()=>activatePanel(panel);
    card.addEventListener('click',go);
    card.addEventListener('keydown',e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();go()}});
  }
}
function metricCountFromTab(name){
  const tabs=[...document.querySelectorAll('#tabs .tab')];
  const t=tabs.find(x=>String(x.dataset.panel||x.querySelector('span')?.textContent||'').trim()===name);
  if(!t)return null;
  const raw=(t.querySelector('b')?.textContent||'').replace(/[^0-9]/g,'');
  return raw===''?null:Number(raw);
}
function syncMetricCardsFromRenderedTabs(){
  const map={metricClose:'주도주 종배',metricLimit:'주도주 상따',metricKki:'끼도주 종배',metricPriority:'종배 우선순위',metricPrev:'전일 후보',metricLightning:'피뢰침',metricHeart:'하트존',metricFzone:'F존'};
  for(const [id,name] of Object.entries(map)){
    const v=metricCountFromTab(name);
    const el=document.getElementById(id);
    if(el && v!==null)el.textContent=String(v);
  }
}
function installMetricJumpDelegation(){if(document.body.dataset.metricDelegated==='1')return;document.body.dataset.metricDelegated='1';document.addEventListener('click',e=>{const card=e.target.closest?.('.metric-card');if(!card)return;const value=card.querySelector('strong[id]');const map={metricClose:'주도주 종배',metricLimit:'주도주 상따',metricKki:'끼도주 종배',metricPriority:'종배 우선순위',metricPrev:'전일 후보',metricLightning:'피뢰침',metricHeart:'하트존',metricFzone:'F존',metricSector:'강한 섹터',metricClosingTop5:'종배 TOP5'};const panel=map[value?.id];if(panel){e.preventDefault();activatePanel(panel)}})}
// === v1.22 NEWHEART 종배 TOP5 ===============================================
// 뉴하트 강의 흐름을 그대로 점수화한다.
// ① 주도섹터·대장성 30 ② 거래대금 25 ③ 종가위치·당일힘 20
// ④ 검색식/패턴 중복 15 ⑤ 프로그램 수급 10 = 100점.
let CLOSING_TOP5_ROWS=[];
let CLOSING_TOP5_FETCH_AT=0;
let CLOSING_TOP5_BUSY=false;
let CLOSING_TOP5_PROGRAM={};
const CLOSING_TOP5_TTL=30000;
const CLOSING_TOP5_SOURCE_PANELS=['주도주 종배','종배 우선순위','끼도주 종배','하트존','F존'];
const CLOSING_TOP5_SIGNAL_PANELS=['주도주 종배','주도주 상따','끼도주 종배','종배 우선순위','하트존','F존'];
function closingNormCode(v){return String(v||'').replace(/^(A|_AL|_NX)/,'').replace(/\D/g,'').padStart(6,'0')}
function closingStockRow(code,row={}){const c=closingNormCode(code);return findStock(c)||findStock(code)||row||{}}
function closingTags(code){const c=closingNormCode(code),ps=STATE?.report?.search_panels?.panels||{},out=[];for(const name of CLOSING_TOP5_SIGNAL_PANELS){if((ps[name]?.rows||[]).some(x=>closingNormCode(x.code)===c))out.push(name)}return out}
function closingCandidatePool(){
  const ps=STATE?.report?.search_panels?.panels||{},map=new Map();
  for(const pn of CLOSING_TOP5_SOURCE_PANELS){for(const row of (ps[pn]?.rows||[])){const c=closingNormCode(row.code);if(!c)continue;const base=closingStockRow(c,row);const old=map.get(c)||{};map.set(c,{...base,...old,...row,code:c,name:row.name||old.name||base.name||c,sector:row.sector||old.sector||base.sector||'기타'})}}
  return [...map.values()].filter(x=>Number(x.value_eok||0)>0);
}
function closingDayBar(stock){const d=Array.isArray(stock?.daily)?stock.daily:[];return d.length?d[d.length-1]:{}}
function closingProgramRatio(code,value){const r=CLOSING_TOP5_PROGRAM[closingNormCode(code)]||{},net=Number(r.program_net_eok),v=Number(value);return Number.isFinite(net)&&Number.isFinite(v)&&v>0?(net/v)*100:null}
function closingProgramPoints(ratio){
  const p=Number(ratio);if(!Number.isFinite(p)||p<=0)return 0;
  if(p<=10)return Math.max(0,Math.min(10,p));
  if(p<=20)return Math.max(5,10-(p-10)*0.5);
  return Math.max(2,5-(p-20)*0.15);
}
function closingSignalPoints(tags){let p=0;if(tags.includes('주도주 종배'))p+=7;if(tags.includes('종배 우선순위'))p+=5;if(tags.includes('주도주 상따'))p+=2;if(tags.includes('끼도주 종배'))p+=2;if(tags.includes('하트존'))p+=1;if(tags.includes('F존'))p+=1;return Math.min(15,p)}
function closingValuePoints(row,candidateRank){
  const r=Number(row?.value_rank);if(Number.isFinite(r)&&r>0){if(r<=5)return 25;if(r<=10)return 23;if(r<=20)return 20;if(r<=35)return 17;if(r<=50)return 12;return 7}
  return Math.max(6,25-(Math.max(1,candidateRank)-1)*2.2);
}
function closingPowerPoints(row){
  const stock=closingStockRow(row.code,row),bar=closingDayBar(stock),q=liveCardQuote(stock)||{};
  const price=Number(q.price)>0?Number(q.price):Number(bar.close||stock.price||0),hi=Number(bar.high||0),lo=Number(bar.low||0),op=Number(bar.open||0),chg=Number.isFinite(Number(q.change))?Number(q.change):Number(stock.change);
  let range=0;if(hi>lo&&price>0)range=Math.max(0,Math.min(1,(price-lo)/(hi-lo)));else if(price>0&&hi>0)range=Math.max(0,Math.min(1,price/hi));
  const pos=12*range;
  let openPts=0;if(price>0&&op>0){const r=(price/op-1)*100;openPts=r>=3?4:r>=1?3:r>=0?2:0}
  let chgPts=0;if(Number.isFinite(chg)){chgPts=chg>=5?4:chg>=3?3:chg>=1?2:chg>0?1:0}
  return Math.max(0,Math.min(20,pos+openPts+chgPts));
}
function closingSectorModel(rows){
  const groups=new Map();for(const r of rows){const sec=String(r.sector||closingStockRow(r.code,r).sector||'기타').trim()||'기타';const g=groups.get(sec)||{sector:sec,rows:[],value:0};g.rows.push(r);g.value+=Number(r.value_eok||0);groups.set(sec,g)}
  const ranked=[...groups.values()].sort((a,b)=>(b.rows.length-a.rows.length)||(b.value-a.value));
  const model={};ranked.forEach((g,i)=>{const byValue=[...g.rows].sort((a,b)=>Number(b.value_eok||0)-Number(a.value_eok||0));const byChange=[...g.rows].sort((a,b)=>Number(liveCardQuote(b)?.change??b.change??-999)-Number(liveCardQuote(a)?.change??a.change??-999));model[g.sector]={rank:i+1,count:g.rows.length,value:g.value,valueRanks:Object.fromEntries(byValue.map((x,j)=>[closingNormCode(x.code),j+1])),changeRanks:Object.fromEntries(byChange.map((x,j)=>[closingNormCode(x.code),j+1]))}});return model;
}
function closingSectorPoints(row,model){const sec=String(row.sector||closingStockRow(row.code,row).sector||'기타').trim()||'기타',m=model[sec]||{rank:99,valueRanks:{},changeRanks:{}};const base=m.rank===1?18:m.rank===2?14:m.rank===3?10:m.rank===4?7:4;const vr=m.valueRanks?.[closingNormCode(row.code)]||99,cr=m.changeRanks?.[closingNormCode(row.code)]||99;const lead=vr===1?8:vr===2?6:vr===3?4:2;const move=cr===1?4:cr===2?3:cr===3?2:1;return Math.min(30,base+lead+move)}
function computeClosingTop5(){
  const pool=closingCandidatePool();if(!pool.length){CLOSING_TOP5_ROWS=[];ensureClosingTop5Panel();return []}
  const sortedValue=[...pool].sort((a,b)=>Number(b.value_eok||0)-Number(a.value_eok||0)),candidateRank=Object.fromEntries(sortedValue.map((x,i)=>[closingNormCode(x.code),i+1])),sectorModel=closingSectorModel(pool);
  const rows=pool.map(row=>{const c=closingNormCode(row.code),base=closingStockRow(c,row),tags=closingTags(c),sector=String(row.sector||base.sector||'기타').trim()||'기타',value=Number(row.value_eok??base.value_eok??0),programRatio=closingProgramRatio(c,value);const parts={sector:closingSectorPoints({...row,sector},sectorModel),value:closingValuePoints(row,candidateRank[c]||99),power:closingPowerPoints(row),signal:closingSignalPoints(tags),program:closingProgramPoints(programRatio)};const score=Math.round(Math.min(100,Object.values(parts).reduce((a,b)=>a+Number(b||0),0)));return {...base,...row,code:c,name:row.name||base.name||c,sector,value_eok:value,tags,program_ratio:programRatio,score,parts,closing_rank:0,reasons:[`주도섹터 ${Math.round(parts.sector)}/30`,`거래대금 ${Math.round(parts.value)}/25`,`종가힘 ${Math.round(parts.power)}/20`,`신호 ${Math.round(parts.signal)}/15`,`수급 ${Math.round(parts.program)}/10`]}}).sort((a,b)=>(b.score-a.score)||(Number(b.value_eok||0)-Number(a.value_eok||0))).slice(0,5);
  rows.forEach((x,i)=>x.closing_rank=i+1);CLOSING_TOP5_ROWS=rows;ensureClosingTop5Panel();return rows;
}
function ensureClosingTop5Panel(){const ps=STATE?.report?.search_panels?.panels;if(!ps)return;ps['종배 TOP5']={kind:'뉴하트 종배 랭킹',rule:'뉴하트 강의 기준 · 주도섹터/대장성 30 + 거래대금 25 + 종가위치/당일힘 20 + 검색신호 15 + 프로그램수급 10',rows:CLOSING_TOP5_ROWS}}
async function refreshClosingTop5(force=false){
  if(!STATE?.report?.search_panels?.panels)return;
  computeClosingTop5();
  const pool=closingCandidatePool();
  const codes=[...pool].sort((a,b)=>Number(b.value_eok||0)-Number(a.value_eok||0)).map(x=>closingNormCode(x.code)).filter(Boolean).slice(0,35);
  if(!codes.length)return;
  const now=Date.now();if(CLOSING_TOP5_BUSY||(!force&&now-CLOSING_TOP5_FETCH_AT<CLOSING_TOP5_TTL))return;CLOSING_TOP5_BUSY=true;CLOSING_TOP5_FETCH_AT=now;
  try{const r=await fetch(`/api/program-flow-watch?codes=${encodeURIComponent(codes.join(','))}`,{cache:'no-store'});const d=await r.json();if(r.ok&&d&&d.rows)CLOSING_TOP5_PROGRAM=d.rows||{};computeClosingTop5();const e=$('#metricClosingTop5');if(e)e.textContent=String(CLOSING_TOP5_ROWS.length);const sub=$('#metricClosingTop5Sub');if(sub)sub.textContent=CLOSING_TOP5_ROWS[0]?`1위 ${CLOSING_TOP5_ROWS[0].name} · ${CLOSING_TOP5_ROWS[0].score}점`:'뉴하트 100점';if(activePanel==='종배 TOP5'&&SCANNER_RESULTS_ACTIVE)renderScannerResultsPage('종배 TOP5')}catch(_e){computeClosingTop5()}finally{CLOSING_TOP5_BUSY=false}
}
function closingTop5Item(x,rank){const p=x.parts||{},pr=Number(x.program_ratio);const program=Number.isFinite(pr)?`${pr>=0?'+':''}${pr.toFixed(Math.abs(pr)>=10?1:2)}%`:'-';return `<div class="closing-top5-row${rank===1?' top':''}" data-stock-action-code="${esc(x.code)}" data-stock-action-name="${esc(x.name)}"><span class="closing-top5-rank">${rank}</span><div class="closing-top5-name"><b>${esc(x.name)}</b><small>${esc(x.sector||'기타')} · ${esc(x.code)}</small></div><strong class="closing-top5-score">${x.score}<small>점</small></strong><div class="closing-top5-parts"><span>섹터 <b>${Math.round(p.sector||0)}</b>/30</span><span>대금 <b>${Math.round(p.value||0)}</b>/25</span><span>종가힘 <b>${Math.round(p.power||0)}</b>/20</span><span>신호 <b>${Math.round(p.signal||0)}</b>/15</span><span>수급 <b>${Math.round(p.program||0)}</b>/10 <em>${program}</em></span></div></div>`}
// ============================================================================
function renderMetrics(){
  ensureClosingTop5Panel();
  installMetricCardJumps();installMetricJumpDelegation();
  const ps=STATE?.report?.search_panels?.panels||{};
  const n=k=>(ps[k]?.rows||[]).length;
  const set=(id,v)=>{const e=$(id);if(e)e.textContent=v};
  set('#metricClose',n('주도주 종배'));
  set('#metricLimit',n('주도주 상따'));
  set('#metricKki',n('끼도주 종배'));
  set('#metricPriority',n('종배 우선순위'));
  set('#metricPrev',n('전일 후보'));
  set('#metricLightning',n('피뢰침'));
  set('#metricHeart',n('하트존'));
  set('#metricFzone',n('F존'));
  const sr=ps['강한 섹터']?.rows||[];
  let strong=sr[0]||null;
  if(!strong){
    // Fallback: 현재 종배 후보군에서 섹터별 종목 수/거래대금을 직접 집계한다.
    // 강한 섹터 패널 생성이 한 틱 늦어져도 상단 카드는 바로 표시되게 한다.
    const srcNames=['주도주 종배','주도주 상따','끼도주 종배','종배 우선순위'];
    const seen=new Set(), agg=new Map();
    for(const pn of srcNames){
      for(const row of (ps[pn]?.rows||[])){
        const code=String(row.code||'').replace(/^(A|_AL|_NX)/,'');
        if(!code||seen.has(code))continue;
        seen.add(code);
        // Live panel rows can temporarily omit sector. Recover it from the full stock result by code.
        const baseStock=(STATE?.report?.results||[]).find(z=>String(z.code||'').replace(/^(A|_AL|_NX)/,'')===code);
        const sectorValue=(row.sector&&row.sector!=='미분류')?row.sector:(baseStock?.sector||'');
        const secs=String(sectorValue||'').split(/[·,/|>]+/).map(x=>x.trim()).filter(x=>x&&x!=='미분류');
        for(const sec of secs){
          const a=agg.get(sec)||{name:sec,count:0,value_eok:0};
          a.count+=1;
          a.value_eok+=Number(row.value_eok ?? baseStock?.value_eok ?? 0);
          agg.set(sec,a);
        }
      }
    }
    const ranked=[...agg.values()].sort((a,b)=>(b.count-a.count)||(b.value_eok-a.value_eok));
    if(ranked.length){
      const a=ranked[0];
      strong={name:a.name,value_eok:a.value_eok,levels:{breadth:a.count}};
    }
  }
  set('#metricSector',strong?.name||'-');
  computeClosingTop5();
  set('#metricClosingTop5',CLOSING_TOP5_ROWS.length);
  set('#metricClosingTop5Sub',CLOSING_TOP5_ROWS[0]?`1위 ${CLOSING_TOP5_ROWS[0].name} · ${CLOSING_TOP5_ROWS[0].score}점`:'뉴하트 100점');
  set('#metricSectorSub',strong?`${strong?.levels?.breadth||0}종목 동반 · ${money(strong?.value_eok||0)}억`:'동반주 기준');
  const tc=$('#tableCount');if(tc)tc.textContent=`${(STATE?.report?.results||[]).length} stocks`;
  bindSectorPopularity();
  syncMetricCardsFromRenderedTabs();
  setTimeout(syncMetricCardsFromRenderedTabs,0);
  setTimeout(syncMetricCardsFromRenderedTabs,100);
}

function jumpToScannerResults(){
  openScannerFloating(activePanel);
}

function scannerFloatDefaultGeom(){
  const vw=Math.max(760,window.innerWidth||1280);
  const vh=Math.max(520,window.innerHeight||800);

  const sidebar=document.querySelector('.sidebar,aside.sidebar,.workspace>aside');
  const sidebarRight=sidebar?Math.round(sidebar.getBoundingClientRect().right):0;

  let left=sidebarRight>80?sidebarRight+8:Math.round(vw*0.145);
  left=Math.max(210,Math.min(left,Math.round(vw*0.24)));

  const top=22;
  const rightGap=8;
  const bottomGap=10;

  return {
    left,
    top,
    width:Math.max(680,vw-left-rightGap),
    height:Math.max(430,vh-top-bottomGap)
  };
}
function applyScannerFloatDefaultGeom(w){
  if(!w)return;
  const g=scannerFloatDefaultGeom();
  w.style.setProperty('left',g.left+'px','important');
  w.style.setProperty('top',g.top+'px','important');
  w.style.setProperty('width',g.width+'px','important');
  w.style.setProperty('height',g.height+'px','important');
  w.style.setProperty('right','auto','important');
  w.style.setProperty('bottom','auto','important');
  w.style.setProperty('transform','none','important');
}
function applyScannerFloatMaxGeom(w){
  if(!w)return;
  const vw=Math.max(760,window.innerWidth||1280);
  const vh=Math.max(520,window.innerHeight||800);
  w.style.setProperty('left','6px','important');
  w.style.setProperty('top','6px','important');
  w.style.setProperty('width',Math.max(680,vw-12)+'px','important');
  w.style.setProperty('height',Math.max(430,vh-12)+'px','important');
  w.style.setProperty('right','auto','important');
  w.style.setProperty('bottom','auto','important');
  w.style.setProperty('transform','none','important');
}
function setScannerFloatMaximized(w,on){
  if(!w)return;
  const max=!!on;
  w.classList.toggle('maximized',max);
  const b=document.getElementById('scannerFloatMax');
  if(b){
    b.textContent=max?'❐':'□';
    b.title=max?'기본 크기로 복원':'창 크게 보기';
  }
  if(max)applyScannerFloatMaxGeom(w);
  else applyScannerFloatDefaultGeom(w);
}

function ensureScannerFloatWindow(){
  let w=$('#scannerFloatWindow');
  if(w)return w;
  w=document.createElement('div');
  w.id='scannerFloatWindow';
  w.className='scanner-float-window';
  w.hidden=true;
  w.innerHTML=`<div class="scanner-float-head" id="scannerFloatDrag">
    <div class="scanner-float-title-wrap"><div class="eyebrow">LITTO SCANNER</div><h2 id="scannerFloatTitle">검색 결과</h2></div>
    <div class="scanner-float-actions">
      <button type="button" class="ghost" id="scannerFloatInline" title="기존 실전매매 위치로 이동">원래 위치</button>
      <button type="button" class="ghost" id="scannerFloatMax" title="창 크게/복원 · 창 모서리를 드래그해 크기 조절 가능">□</button>
      <button type="button" class="ghost scanner-float-close" id="scannerFloatClose" title="닫기">✕</button>
    </div>
  </div>
  <div class="scanner-float-tabs" id="scannerFloatTabs"></div>
  <div class="scanner-float-meta"><div id="scannerFloatMeta"></div><div class="scanner-float-source"><span id="scannerFloatNotice"></span><span id="scannerFloatRankSource"></span></div></div>
  <div class="scanner-float-body" id="scannerFloatBody"></div>`;
  document.body.appendChild(w);
  if(!$('#littoModalLayerStyle')){
    const layer=document.createElement('style');
    layer.id='littoModalLayerStyle';
    layer.textContent=`
      #stockActionModal,
      #orderbookModal,
      #investorFlowModal,
      #chartModal,
      #watchChecklistModal,
      #watchMemoModal,
      #sectorPopularityModal{
        z-index:220000 !important;
      }
      #watchManualModal{
        z-index:210000 !important;
      }
      /* v1.2: inline Signal Board is kept as a hidden render source only. */
      #scanner{
        position:absolute !important;
        left:-100000px !important;
        top:0 !important;
        width:1px !important;
        height:1px !important;
        overflow:hidden !important;
        opacity:0 !important;
        pointer-events:none !important;
      }
      #scannerFloatInline{display:none !important;}
      #scannerFloatWindow{
        z-index:120000;
      }
    `;
    document.head.appendChild(layer);
  }
  if(!$('#scannerFloatGridStyle')){
    const st=document.createElement('style');
    st.id='scannerFloatGridStyle';
    st.textContent=`
      /* v1.2 scanner float clipping fix */
      #scannerFloatWindow.scanner-float-closed{
        display:none !important;
        visibility:hidden !important;
        pointer-events:none !important;
      }

      #scannerFloatWindow .scanner-float-actions{
        position:relative !important;
        z-index:5000 !important;
        pointer-events:auto !important;
      }
      #scannerFloatWindow #scannerFloatClose{
        position:relative !important;
        z-index:6000 !important;
        pointer-events:auto !important;
        cursor:pointer !important;
      }
      #scannerFloatWindow .scanner-float-head{
        position:relative !important;
        z-index:4500 !important;
      }
      #scannerFloatWindow .scanner-float-tabs,
      #scannerFloatWindow .scanner-float-meta,
      #scannerFloatWindow #scannerFloatBody{
        position:relative !important;
        z-index:1 !important;
      }

      #scannerFloatWindow{
        display:flex !important;
        flex-direction:column !important;
        overflow:hidden !important;
      }
      #scannerFloatWindow .scanner-float-head{
        flex:0 0 auto !important;
        min-height:78px;
      }
      #scannerFloatWindow .scanner-float-tabs{
        flex:0 0 auto !important;
        min-height:48px;
        padding-bottom:4px;
        overflow-x:auto !important;
        overflow-y:hidden !important;
        white-space:nowrap !important;
        scrollbar-gutter:stable;
      }
      #scannerFloatWindow .scanner-float-tabs::-webkit-scrollbar{
        height:8px;
      }
      #scannerFloatWindow .scanner-float-meta{
        flex:0 0 auto !important;
        min-height:88px;
        height:auto !important;
        max-height:170px;
        overflow:auto !important;
        box-sizing:border-box;
        padding-bottom:10px;
      }
      #scannerFloatWindow #scannerFloatMeta,
      #scannerFloatWindow .scanner-float-source{
        white-space:normal !important;
        overflow:visible !important;
        word-break:keep-all;
        line-height:1.45;
      }
      #scannerFloatWindow #scannerFloatBody{
        flex:1 1 auto !important;
        min-height:0 !important;
        overflow-y:auto !important;
        overflow-x:hidden !important;
        padding-top:14px !important;
        box-sizing:border-box;
      }

      #scannerFloatWindow{
        display:flex;
        flex-direction:column;
        resize:both;
        min-width:720px;
        min-height:420px;
        overflow:hidden;
        max-width:calc(100vw - 12px);
        max-height:calc(100vh - 12px) !important;
        height:min(88vh,900px);
        overflow:hidden;
      }
      #scannerFloatWindow.maximized{
        resize:none !important;
      }
      #scannerFloatWindow:not(.maximized){
        resize:both !important;
      }
      #scannerFloatWindow #scannerFloatBody{
        display:grid;
        grid-template-columns:repeat(2,minmax(0,1fr));
        gap:12px;
        align-content:start;
        padding:14px 14px 28px;
        overflow-y:auto;
        overflow-x:hidden;
        min-height:0;
        flex:1 1 auto;
        max-height:none;
        scrollbar-gutter:stable;
      }
      #scannerFloatWindow.maximized #scannerFloatBody{max-height:none;}
      #scannerFloatWindow #scannerFloatBody>.prow{
        min-width:0;
        margin:0;
        border:1px solid #1d3b51;
        border-radius:14px;
        background:#0a1825;
        overflow:hidden;
      }
      #scannerFloatWindow #scannerFloatBody>.empty,
      #scannerFloatWindow #scannerFloatBody>.muted{
        grid-column:1/-1;
      }
      #scannerFloatWindow #scannerFloatBody .prowhead{
        align-items:flex-start;
        gap:8px;
      }
      #scannerFloatWindow #scannerFloatBody .stats{
        display:flex;
        flex-wrap:wrap;
        gap:6px 12px;
      }
      #scannerFloatWindow #scannerFloatBody .reasons{
        display:flex;
        flex-wrap:wrap;
        gap:6px;
      }
      #scannerFloatWindow #scannerFloatBody .levels{
        line-height:1.55;
      }
      .trade-memo-icon{
        width:24px !important;
        height:24px !important;
        min-width:24px !important;
        padding:0 !important;
        margin:0 2px !important;
        border:0 !important;
        background:transparent !important;
        font-size:14px !important;
        line-height:24px !important;
        cursor:pointer;
        opacity:.9;
      }
      .trade-memo-icon:hover{opacity:1;transform:scale(1.08)}
      #scannerFloatWindow #scannerFloatBody>.prow{
        height:auto !important;
        min-height:112px;
        overflow:visible !important;
      }
      #scannerFloatWindow #scannerFloatBody .prowhead{
        flex-wrap:wrap;
      }
      #scannerFloatWindow #scannerFloatBody .stock-title-line{
        flex-wrap:wrap;
        min-width:0;
      }
      #scannerFloatWindow #scannerFloatBody .reasons,
      #scannerFloatWindow #scannerFloatBody .checks,
      #scannerFloatWindow #scannerFloatBody .levels{
        display:flex !important;
        flex-wrap:wrap;
        white-space:normal !important;
        overflow:visible !important;
        max-height:none !important;
      }
      #scannerFloatWindow #scannerFloatBody .reasons span{
        display:inline-flex;
        align-items:center;
        padding:4px 8px;
        border-radius:7px;
        background:#0e2a1f;
        color:#57d994;
        font-size:12px;
        line-height:1.25;
      }
      #scannerFloatWindow .float-change-next{
        margin-left:6px;
        font-size:15px;
        font-weight:800;
        font-variant-numeric:tabular-nums;
      }
      @media (max-width:1180px){
        #scannerFloatWindow{
          min-width:620px;
        }
        #scannerFloatWindow #scannerFloatBody{
          grid-template-columns:1fr;
        }
      }

      @media (max-width:1050px){
        #scannerFloatWindow #scannerFloatBody{grid-template-columns:1fr}
      }
    `;
    document.head.appendChild(st);
  }
  const closeBtn=$('#scannerFloatClose');
  const closeFloatWindow=e=>{
    if(e){e.preventDefault();e.stopPropagation();e.stopImmediatePropagation?.();}
    setScannerFloatMaximized(w,false);
    w.classList.add('scanner-float-closed');
    w.hidden=true;
    w.style.setProperty('display','none','important');
  };
  closeBtn.onclick=closeFloatWindow;
  closeBtn.addEventListener('pointerdown',e=>{e.preventDefault();e.stopPropagation();e.stopImmediatePropagation?.();},true);
  closeBtn.addEventListener('click',closeFloatWindow,true);
  $('#scannerFloatMax').onclick=e=>{e.preventDefault();e.stopPropagation();setScannerFloatMaximized(w,!w.classList.contains('maximized'))};
  $('#scannerFloatInline').onclick=()=>{
    const panel=w.dataset.panel||activePanel;
    w.classList.add('scanner-float-closed');
    w.hidden=true;
    w.style.setProperty('display','none','important');
    try{if(typeof switchLittoPage==='function'&&typeof LITTO_PAGE!=='undefined'&&LITTO_PAGE!=='trade')switchLittoPage('trade')}catch(_e){}
    try{if(typeof switchTradeSubtab==='function')switchTradeSubtab('scanner')}catch(_e){}
    activePanel=panel;renderTabs();renderPanel();requestAnimationFrame(()=>jumpToScannerResults());
  };
  // HTS처럼 제목 바를 잡고 이동. 최대화 상태에서는 드래그하지 않는다.
  const head=$('#scannerFloatDrag');
  let drag=null;
  head.addEventListener('pointerdown',e=>{
    if(e.target.closest('button')||w.classList.contains('maximized'))return;
    const r=w.getBoundingClientRect();
    drag={id:e.pointerId,dx:e.clientX-r.left,dy:e.clientY-r.top};
    head.setPointerCapture?.(e.pointerId);
    w.classList.add('dragging');
    e.preventDefault();
  });
  head.addEventListener('pointermove',e=>{
    if(!drag||drag.id!==e.pointerId)return;
    const maxX=Math.max(0,window.innerWidth-w.offsetWidth),maxY=Math.max(0,window.innerHeight-56);
    const left=Math.max(0,Math.min(maxX,e.clientX-drag.dx));
    const top=Math.max(0,Math.min(maxY,e.clientY-drag.dy));
    w.style.left=left+'px';w.style.top=top+'px';w.style.transform='none';w.style.right='auto';w.style.bottom='auto';
  });
  const end=e=>{if(!drag)return;drag=null;w.classList.remove('dragging');try{head.releasePointerCapture?.(e.pointerId)}catch(_e){}};
  head.addEventListener('pointerup',end);head.addEventListener('pointercancel',end);
  applyScannerFloatDefaultGeom(w);
  return w;
}
function refreshScannerFloatWindow(name){
  const w=ensureScannerFloatWindow();
  if(!PANEL_ORDER.includes(name))return;
  activePanel=name;
  // 기존 렌더러를 그대로 사용해 결과/클릭기능의 기준을 하나로 유지한다.
  renderTabs();renderPanel();
  const ps=STATE?.report?.search_panels?.panels||{};
  w.dataset.panel=name;
  $('#scannerFloatTitle').textContent=name;
  $('#scannerFloatTabs').innerHTML=PANEL_ORDER.map(n=>`<button class="scanner-float-tab ${n===name?'active':''}" data-float-panel="${esc(n)}"><span>${esc(n)}</span><b>${(ps[n]?.rows||[]).length}</b></button>`).join('');
  $('#scannerFloatMeta').innerHTML=$('#panelMeta')?.innerHTML||`<b>${esc(name)}</b>`;
  $('#scannerFloatNotice').textContent=$('#panelNotice')?.textContent||'';
  $('#scannerFloatRankSource').textContent=$('#rankSource')?.textContent||'';
  $('#scannerFloatBody').innerHTML=$('#panelRows')?.innerHTML||'<div class="empty">검색 결과가 없습니다.</div>';
  $('#scannerFloatTabs').querySelectorAll('[data-float-panel]').forEach(b=>b.onclick=()=>refreshScannerFloatWindow(b.dataset.floatPanel));
  // 복제된 결과에도 기존 종목 기능을 다시 연결한다.
  try{bindChartClicks()}catch(_e){}try{bindStockActionClicks()}catch(_e){}try{bindSectorEdits()}catch(_e){}try{bindNewsButtons()}catch(_e){}try{bindSectorPopularity()}catch(_e){}try{bindInvestorFlowClicks()}catch(_e){}try{bindWatchStars()}catch(_e){}try{bindWatchMemoButtons($('#scannerFloatBody'))}catch(_e){}
  $$('.nav-item').forEach(x=>x.classList.toggle('active',x.dataset.panelJump===name));
}
function ensureScannerResultsLayoutStyle(){
  if(document.getElementById('scannerResultsLayoutStyle'))return;
  const st=document.createElement('style');st.id='scannerResultsLayoutStyle';st.textContent=`
    #scanner-results-page #scannerResultsSectors{
      display:grid !important;
      grid-template-columns:repeat(2,minmax(0,1fr)) !important;
      gap:16px !important;
      align-items:start !important;
    }
    #scanner-results-page .watch-overview-card{min-width:0 !important;width:auto !important;max-width:none !important;}
    #scanner-results-page .watch-mini-row{
      grid-template-columns:34px minmax(280px,1fr) minmax(84px,100px) minmax(88px,104px) minmax(72px,88px) !important;
      column-gap:8px !important;
    }
    #scanner-results-page .watch-mini-spark{display:none !important;}
    #scanner-results-page .watch-mini-name{min-width:0 !important;overflow:visible !important;}
    #scanner-results-page .watch-mini-name-line{display:flex !important;align-items:center !important;gap:5px !important;min-width:0 !important;flex-wrap:nowrap !important;overflow:visible !important;}
    #scanner-results-page .watch-mini-name-line b{flex:0 1 auto !important;min-width:max-content !important;overflow:visible !important;text-overflow:clip !important;white-space:nowrap !important;max-width:none !important;}
    #scanner-results-page .watch-mini-name-line .watch-star,
    #scanner-results-page .watch-mini-name-line .news-btn,
    #scanner-results-page .watch-mini-name-line .disclosure-btn,
    #scanner-results-page .watch-mini-name-line .watch-memo-icon,
    #scanner-results-page .watch-mini-name-line .watch-sector-edit{position:static !important;margin:0 !important;flex:0 0 auto !important;}
    #scanner-results-page .scanner-hit-line{display:flex !important;flex-wrap:wrap !important;gap:4px !important;margin-top:4px !important;}
    #scanner-results-page .scanner-hit-tag{display:inline-flex;align-items:center;padding:2px 6px;border:1px solid rgba(88,166,255,.28);border-radius:999px;background:rgba(13,110,253,.08);font-size:11px;line-height:1.25;color:#8fc7ff;white-space:nowrap;}
    #scanner-results-page .strong-sector-summary .strong-sector-toggle{cursor:pointer;user-select:none;}
    #scanner-results-page .strong-sector-summary .strong-sector-chevron{display:inline-block;margin-left:6px;transition:transform .18s ease;}
    #scanner-results-page .strong-sector-summary .strong-sector-toggle.open .strong-sector-chevron{transform:rotate(180deg);}
    .sector-sort-toolbar{display:flex;align-items:center;gap:6px;margin-top:9px;flex-wrap:wrap}.sector-sort-toolbar>span{font-size:10px;color:#7990a5;font-weight:800;margin-right:2px}.sector-sort-toolbar button{height:26px;padding:0 10px;border:1px solid #29465d;border-radius:7px;background:#0b1824;color:#91a9bd;font-size:11px;font-weight:850;cursor:pointer}.sector-sort-toolbar button:hover{background:#102538}.sector-sort-toolbar button.active{background:#173b57;border-color:#2f79aa;color:#d9f1ff;box-shadow:inset 0 0 0 1px rgba(74,168,226,.14)}.rank-subhead .sector-sort-toolbar-inline{display:inline-flex;margin-top:0;margin-left:6px;vertical-align:middle;flex-wrap:nowrap}.rank-subhead .sector-sort-toolbar-inline button{height:24px;padding:0 9px}
    @media(max-width:1050px){#scanner-results-page #scannerResultsSectors{grid-template-columns:1fr !important;}}
  `;document.head.appendChild(st);
}
const SECTOR_SORT_KEY='litto_sector_sort_mode_v1';
let SECTOR_SORT_MODE=localStorage.getItem(SECTOR_SORT_KEY)==='change'?'change':'value';
function sectorSortValue(x){const live=x?._live||findStock?.(x?.code)||{};const v=Number(live?.value_eok??x?.value_eok??0);return Number.isFinite(v)?v:0}
function sectorSortChange(x){const q=typeof liveCardQuote==='function'?liveCardQuote(x):null;const v=Number(q?.change??x?.change??x?.change_rate);return Number.isFinite(v)?v:-999999}
function sectorSortItems(items){const arr=[...(items||[])];return arr.sort((a,b)=>SECTOR_SORT_MODE==='change'?(sectorSortChange(b)-sectorSortChange(a))||(sectorSortValue(b)-sectorSortValue(a)):(sectorSortValue(b)-sectorSortValue(a))||(sectorSortChange(b)-sectorSortChange(a)))}
function sectorSortGroups(groups){const arr=[...(groups||[])];return arr.sort((a,b)=>SECTOR_SORT_MODE==='change'?((Number(b.avg)??-999)-(Number(a.avg)??-999))||((Number(b.totalValue)||0)-(Number(a.totalValue)||0)):((Number(b.totalValue)||0)-(Number(a.totalValue)||0))||((Number(b.avg)??-999)-(Number(a.avg)??-999)))}
function sectorSortToolbarHtml(){return `<div class="sector-sort-toolbar" data-sector-sort-toolbar><span>정렬</span><button type="button" data-sector-sort="value" class="${SECTOR_SORT_MODE==='value'?'active':''}">거래순</button><button type="button" data-sector-sort="change" class="${SECTOR_SORT_MODE==='change'?'active':''}">상승률순</button></div>`}
function syncSectorSortButtons(root=document){root.querySelectorAll?.('[data-sector-sort]').forEach(b=>b.classList.toggle('active',b.dataset.sectorSort===SECTOR_SORT_MODE))}
function applySectorSortMode(mode){SECTOR_SORT_MODE=mode==='change'?'change':'value';try{localStorage.setItem(SECTOR_SORT_KEY,SECTOR_SORT_MODE)}catch(_e){}syncSectorSortButtons();if(typeof SCANNER_RESULTS_ACTIVE!=='undefined'&&SCANNER_RESULTS_ACTIVE&&typeof activePanel!=='undefined')renderScannerResultsPage(activePanel);const rr=document.getElementById('realtimeRankRisers');if(rr)renderPrioritySectorSummary(rr);if(document.getElementById('marketMoversSectors'))renderRealtimeRankSectorStrip()}
function bindSectorSortButtons(root=document){root.querySelectorAll?.('[data-sector-sort]').forEach(b=>{if(b.dataset.sectorSortBound==='1')return;b.dataset.sectorSortBound='1';b.onclick=e=>{e.preventDefault();e.stopPropagation();applySectorSortMode(b.dataset.sectorSort)}});syncSectorSortButtons(root)}
function ensureScannerResultsPage(){
  ensureScannerResultsLayoutStyle();
  const main=document.querySelector('.workspace main')||document.querySelector('main');if(!main)return null;
  let sec=$('#scanner-results-page');if(sec)return sec;
  sec=document.createElement('section');sec.id='scanner-results-page';sec.className='card watchlist-page litto-page-hidden';
  sec.innerHTML=`<div class="watch-head"><div><div class="eyebrow">LITTO SCANNER</div><div class="watch-title-row"><h2 id="scannerResultsTitle">검색 결과</h2></div><div id="scannerResultsDesc" class="muted">관심종목과 같은 형식으로 검색 결과를 봅니다.</div>${sectorSortToolbarHtml()}</div><div class="watch-head-meta"><b id="scannerResultsTotal">0종목</b><span id="scannerResultsKind">실시간 검색</span></div></div><div id="scannerResultsSectors" class="watch-sectors watch-overview-grid"></div>`;
  const watch=$('#watchlist-page');if(watch&&watch.parentElement===main)main.insertBefore(sec,watch.nextSibling);else main.insertBefore(sec,main.firstElementChild?.nextSibling||null);
  bindSectorSortButtons(sec);return sec;
}
function scannerResultCompactItem(x,rank,panel){
  const q=liveCardQuote(x)||{},code=String(x.code||''),name=x.name||code,sector=x.sector||'기타';
  const change=Number.isFinite(Number(q.change))?Number(q.change):null,price=Number.isFinite(Number(q.price))?Number(q.price):null;
  const value=Number(x.value_eok||0),memo=typeof watchMemo==='function'?watchMemo(code):'';
  const memoIcon=memo?`<button class="watch-memo-icon" type="button" data-watch-memo="${esc(code)}" data-watch-memo-name="${esc(name)}" title="${esc(memo)}" aria-label="메모 있음">📝</button>`:'';
  const sectorEdit=`<button class="watch-sector-edit sector-edit" type="button" data-sector-code="${esc(code)}" data-sector-current="${esc(sector)}" title="섹터 수정: ${esc(sector)}" aria-label="섹터 수정">✎</button>`;
  const watched=typeof isWatched==='function'&&isWatched(code);
  const star=`<button class="watch-star ${watched?'active':''} compact" type="button" data-watch-code="${esc(code)}" data-watch-name="${esc(name)}" data-watch-sector="${esc(sector)}" title="${watched?'관심종목에서 제거':'관심종목에 추가'}">${watched?'★':'☆'}</button>`;
  const news=newsButtonHtml(code,name);
  const disclosure=disclosureButtonHtml(code,name);
  const tags=lookupTags(code);if(panel&&!tags.includes(panel))tags.unshift(panel);
  const tagHtml=tags.map(t=>`<span class="scanner-hit-tag">${esc(t)}</span>`).join('');
  return `<div class="watch-mini-row${rank===1?' top':''}" data-stock-action-code="${esc(code)}" data-stock-action-name="${esc(name)}" ><span class="watch-mini-rank">${rank}</span><div class="watch-mini-name"><div class="watch-mini-name-line"><b>${esc(name)}</b>${star}${news}${disclosure}${memoIcon}${sectorEdit}</div><small class="scanner-hit-line">${tagHtml||'<span class="scanner-hit-tag">검색조건 충족</span>'}</small></div><div class="watch-mini-spark"></div><div class="watch-mini-price" title="현재가">${price!=null&&price>0?money(price):'-'}</div><div class="watch-mini-value" title="거래대금"><span>${value>0?watchCompactValueText(value):'-'}</span><small>${x.value_rank?`대금 ${esc(x.value_rank)}위`:'검색조건 충족'}</small></div><div class="watch-mini-change ${change==null?'':cls(change)}" title="등락률">${change==null?'-':pct(change)}</div></div>`;
}
function renderScannerResultsPage(name){
  ensureClosingTop5Panel();
  const sec=ensureScannerResultsPage();if(!sec||!PANEL_ORDER.includes(name))return;
  const ps=STATE?.report?.search_panels?.panels||{},panel=ps[name]||{},allRows=panel.rows||[];
  const root=$('#scannerResultsSectors');if(!root)return;
  $('#scannerResultsTitle').textContent=name;$('#scannerResultsKind').textContent=panel.kind||'실시간 검색';
  $('#scannerResultsDesc').textContent=panel.rule||'관심종목과 같은 형식으로 검색 결과를 봅니다.';

  // 강한 섹터는 일반 종목행이 아니라 SECTOR:* 요약행으로 생성된다.
  // 기존 검색/판정 로직은 그대로 두고, 여기서만 요약행의 members를 종목 카드로 풀어 보여준다.
  if(name==='종배 TOP5'){
    computeClosingTop5();
    const rows=CLOSING_TOP5_ROWS||[];
    $('#scannerResultsTitle').textContent='종배 TOP5';$('#scannerResultsKind').textContent='뉴하트 100점';$('#scannerResultsTotal').textContent=`${rows.length}종목`;
    $('#scannerResultsDesc').textContent='주도섹터·대장성 30 + 거래대금 25 + 종가위치·당일힘 20 + 검색신호 15 + 프로그램수급 10';
    root.innerHTML=rows.length?`<div class="top5-perf-toolbar"><button type="button" class="top5-perf-open" id="closingTop5PerformanceBtn">성과보기</button></div><section class="closing-top5-board">${rows.map((x,i)=>closingTop5Item(x,i+1)).join('')}</section><div class="closing-top5-note">※ 프로그램 +10% 부근을 최고점으로 반영합니다. 장중에는 현재가의 당일 고가·저가 위치를 이용해 종가힘을 실시간 추정합니다.</div>`:'<div class="top5-perf-toolbar"><button type="button" class="top5-perf-open" id="closingTop5PerformanceBtn">성과보기</button></div><div class="watch-empty"><strong>종배 TOP5 후보가 아직 없습니다.</strong><span>주도주 종배·종배 우선순위·끼도주 종배·하트존·F존 후보가 생기면 자동 계산됩니다.</span></div>';
    const perfBtn=document.getElementById('closingTop5PerformanceBtn');if(perfBtn)perfBtn.onclick=e=>{e.preventDefault();e.stopPropagation();openClosingTop5Performance()};
    try{bindStockActionClicks()}catch(_e){};refreshClosingTop5(false);return;
  }

  if(name==='강한 섹터'){
    const sectorRows=allRows.filter(x=>String(x.code||'').startsWith('SECTOR:'));
    const originalPanels=['주도주 종배','주도주 상따','끼도주 종배'];
    const sourceByCode=new Map();
    originalPanels.forEach(pn=>(ps[pn]?.rows||[]).forEach(r=>{const c=String(r.code||'');if(c&&!sourceByCode.has(c))sourceByCode.set(c,r)}));
    const groups=sectorRows.map(sr=>{
      const members=Array.isArray(sr?.levels?.members)?sr.levels.members:[];
      const rawItems=members.map(m=>{
        const code=String(m.code||'');
        const base=sourceByCode.get(code)||findStock(code)||{};
        return {...base,...m,code,name:m.name||base.name||code,sector:sr.sector||sr.name||base.sector||'기타',value_rank:m.value_rank||base.value_rank};
      }).filter(x=>x.code);
      const items=sectorSortItems(rawItems);
      const changes=items.map(x=>Number(liveCardQuote(x)?.change)).filter(Number.isFinite);
      const avg=changes.length?changes.reduce((a,b)=>a+b,0)/changes.length:null;
      return {sector:sr.sector||sr.name||'기타',items,avg,totalValue:Number(sr.value_eok||0),breadth:Number(sr?.levels?.breadth||items.length)};
    }).filter(g=>g.items.length);
    const sortedGroups=sectorSortGroups(groups);
    const unique=new Set(sortedGroups.flatMap(g=>g.items.map(x=>String(x.code||''))));
    $('#scannerResultsTotal').textContent=`${groups.length}개 섹터 · ${unique.size}종목`;
    $('#scannerResultsDesc').textContent='강한 섹터를 먼저 보여줍니다. 섹터 카드를 클릭하면 해당 종목을 확인할 수 있습니다.';
    if(!groups.length){root.innerHTML='<div class="watch-empty"><strong>조건을 통과한 강한 섹터가 없습니다.</strong><span>원본 3개 검색식의 동반 종목이 생기면 자동으로 반영됩니다.</span></div>';return;}
    root.innerHTML=sortedGroups.map((g,si)=>`<section class="watch-overview-card strong-sector-summary${si===0?' strongest':''}" data-strong-sector-card="${si}"><div class="watch-overview-head strong-sector-toggle" data-strong-sector-toggle="${si}" role="button" tabindex="0" title="클릭하면 ${esc(g.sector)} 종목을 봅니다"><div class="watch-overview-title">${si===0?'<span class="watch-overview-star">★</span>':''}<b>${esc(g.sector)}</b><small>${g.items.length}종목</small></div><div class="watch-overview-metrics"><strong class="watch-overview-avg ${g.avg==null?'':cls(g.avg)}">${g.avg==null?'-':pct(g.avg)}</strong><span class="watch-overview-money">${g.totalValue>0?`${money(g.totalValue)}억`:'-'}</span><span class="strong-sector-chevron">▾</span></div></div><div class="watch-overview-body litto-page-hidden" data-strong-sector-body="${si}">${g.items.map((x,i)=>scannerResultCompactItem(x,i+1,'강한 섹터')).join('')}</div></section>`).join('');
    const toggleSector=(idx)=>{const body=root.querySelector(`[data-strong-sector-body="${idx}"]`),head=root.querySelector(`[data-strong-sector-toggle="${idx}"]`);if(!body)return;const opening=body.classList.contains('litto-page-hidden');root.querySelectorAll('[data-strong-sector-body]').forEach(x=>x.classList.add('litto-page-hidden'));root.querySelectorAll('.strong-sector-toggle').forEach(x=>x.classList.remove('open'));if(opening){body.classList.remove('litto-page-hidden');head?.classList.add('open')} };
    root.querySelectorAll('[data-strong-sector-toggle]').forEach(el=>{el.onclick=e=>{e.preventDefault();e.stopPropagation();toggleSector(el.dataset.strongSectorToggle)};el.onkeydown=e=>{if(e.key==='Enter'||e.key===' '){e.preventDefault();toggleSector(el.dataset.strongSectorToggle)}}});
    try{bindWatchStars(root)}catch(_e){}try{bindWatchMemoButtons(root)}catch(_e){}try{bindSectorEdits()}catch(_e){}try{bindStockActionClicks()}catch(_e){}try{bindNewsButtons()}catch(_e){}
    return;
  }

  const rows=allRows.filter(x=>!String(x.code||'').startsWith('SECTOR:'));
  $('#scannerResultsTotal').textContent=`${rows.length}종목`;
  if(!rows.length){root.innerHTML='<div class="watch-empty"><strong>조건을 통과한 종목이 없습니다.</strong><span>검색 데이터가 갱신되면 자동으로 결과가 반영됩니다.</span></div>';return;}
  const groups=new Map();rows.forEach(x=>{const sector=String(x.sector||'기타').trim()||'기타';if(!groups.has(sector))groups.set(sector,[]);groups.get(sector).push(x)});
  const sectors=sectorSortGroups([...groups.entries()].map(([sector,items])=>{const sorted=sectorSortItems(items);const changes=sorted.map(x=>Number(liveCardQuote(x)?.change)).filter(Number.isFinite);const avg=changes.length?changes.reduce((a,b)=>a+b,0)/changes.length:null;const totalValue=sorted.reduce((a,x)=>a+Number(x.value_eok||0),0);return {sector,items:sorted,avg,totalValue}}));
  root.innerHTML=sectors.map((g,si)=>`<section class="watch-overview-card${si===0?' strongest':''}"><div class="watch-overview-head"><div class="watch-overview-title">${si===0?'<span class="watch-overview-star">★</span>':''}<b>${esc(g.sector)}</b><small>${g.items.length}</small></div><div class="watch-overview-metrics"><strong class="watch-overview-avg ${g.avg==null?'':cls(g.avg)}">${g.avg==null?'-':pct(g.avg)}</strong><span class="watch-overview-money">${g.totalValue>0?`${money(g.totalValue)}억`:'-'}</span></div></div><div class="watch-overview-body">${g.items.map((x,i)=>scannerResultCompactItem(x,i+1,name)).join('')}</div></section>`).join('');
  try{bindWatchStars(root)}catch(_e){}try{bindWatchMemoButtons(root)}catch(_e){}try{bindSectorEdits()}catch(_e){}try{bindStockActionClicks()}catch(_e){}try{bindNewsButtons()}catch(_e){}bindSectorSortButtons(sec);
}
function openScannerFloating(name){
  if(window.__littoWatchNavGuardUntil && Date.now()<window.__littoWatchNavGuardUntil)return;
  if(!PANEL_ORDER.includes(name))return;
  if(typeof LITTO_PAGE!=='undefined'&&LITTO_PAGE!=='trade'&&typeof switchLittoPage==='function')switchLittoPage('trade');
  TRADE_SUBTAB='scanner';localStorage.setItem('litto_trade_subtab_v1','scanner');SCANNER_RESULTS_ACTIVE=true;activePanel=name;
  ensureTradeSubtabs();renderScannerResultsPage(name);applyTradeSubtab();syncTradeSidebarNav();
  $$('.nav-item').forEach(x=>x.classList.toggle('active',x.dataset.panelJump===name));
  window.scrollTo({top:0,behavior:'smooth'});
}
function activatePanel(name){if(!PANEL_ORDER.includes(name))return;leaveScreenerHistory();restoreMainScannerView();openScannerFloating(name)}
function renderTabs(){ensureClosingTop5Panel();const ps=STATE?.report?.search_panels?.panels||{};$('#tabs').innerHTML=PANEL_ORDER.map(n=>`<button class="tab ${n===activePanel?'active':''}" data-panel="${esc(n)}"><span>${esc(n)}</span><b>${(ps[n]?.rows||[]).length}</b></button>`).join('');$$('.tab').forEach(b=>b.onclick=()=>{activePanel=b.dataset.panel;renderTabs();renderPanel()});}
function rankBaseCode(v){let s=String(v||'').trim().toUpperCase();if(/^[A-Z][0-9A-Z]{6}$/.test(s)&&s.startsWith('A'))s=s.slice(1);if(s.endsWith('_AL')||s.endsWith('_NX'))s=s.slice(0,-3);return s}
function lookupRank(code){const c=rankBaseCode(code);return (LIVE_RANK?.rows||[]).find(x=>rankBaseCode(x.code)===c)||null}
function liveCardQuote(row){const live=lookupRank(row?.code);return {change:live?.change!=null?Number(live.change):Number(row?.change),price:live?.price!=null?Number(live.price):Number(row?.price),rank:live?.rank??null}}
function inlineLookupRankHtml(code){const r=lookupRank(code);if(!r)return '<span class="lookup-inline lookup-none">조회 -</span>';const mv=r.new?'<b class="rank-new">NEW</b>':Number(r.move||0)>0?`<b class="rank-up">↑${Number(r.move)}</b>`:Number(r.move||0)<0?`<b class="rank-down">↓${Math.abs(Number(r.move))}</b>`:'<b class="rank-flat">―</b>';const hot=!r.new&&Number(r.move||0)>=3?' <em>급상승</em>':'';return `<span class="lookup-inline">조회 <strong>${r.rank}위</strong> ${mv}${hot}</span>`}
function watchValueRankForCode(item){const code=rankBaseCode(item?.code||item||'');if(!code)return null;const direct=[item,watchLive(item),findStock(code)].filter(Boolean);for(const x of direct){const v=Number(x?.value_rank);if(Number.isFinite(v)&&v>0)return Math.round(v)}const ps=STATE?.report?.search_panels?.panels||{};for(const p of Object.values(ps)){for(const r of (p?.rows||[])){if(rankBaseCode(r?.code)===code){const v=Number(r?.value_rank);if(Number.isFinite(v)&&v>0)return Math.round(v)}}}return null}
function watchRankCompactHtml(item){const c=rankBaseCode(item?.code||item||''),lookup=lookupRank(c),valueRank=watchValueRankForCode(item);return `<span class="watch-ranks-inline">${lookup&&Number(lookup.rank)>0?`조회${Number(lookup.rank)}`:'조회-'}<i>·</i>${valueRank?`대금${valueRank}`:'대금-'}</span>`}
function ensureNewsModal(){let m=$('#newsModal');if(m)return m;const wrap=document.createElement('div');wrap.innerHTML=`<div class="modal news-modal" id="newsModal"><div class="modalback" data-close-news></div><div class="newsbox"><div class="newshead"><div><div class="eyebrow">STOCK NEWS</div><h2 id="newsTitle">관련 종목뉴스</h2><div id="newsSub" class="newssub"></div></div><div class="newsactions"><a id="newsSource" class="button ghost" href="#" target="_blank" rel="noopener noreferrer">뉴스 전체보기</a><button id="newsClose" class="ghost">닫기</button></div></div><div id="newsRows" class="newsrows"><div class="empty">종목의 최신 뉴스를 불러옵니다.</div></div></div></div>`;document.body.appendChild(wrap.firstElementChild);m=$('#newsModal');$('#newsClose').onclick=closeNews;$$('[data-close-news]').forEach(x=>x.onclick=closeNews);return m}
function closeNews(){const m=$('#newsModal');if(m)m.classList.remove('open')}
function newsAgeBadge(t){if(!t)return'';const m=String(t).match(/(\d{4})[.\-/](\d{1,2})[.\-/](\d{1,2})\s+(\d{1,2}):(\d{2})/);if(!m)return'';const d=new Date(Number(m[1]),Number(m[2])-1,Number(m[3]),Number(m[4]),Number(m[5]));const min=(Date.now()-d.getTime())/60000;return min>=0&&min<=60?'<span class="news-new">NEW</span>':''}
// Read-only popup cache: bounded, memory-only; no account/order caching.
const LITTO_POPUP_CACHE=new Map(), LITTO_POPUP_PENDING=new Map();
let LITTO_NEWS_REQUEST=0, LITTO_FLOW_REQUEST=0;
async function* littoPopupRead(url,ttl){
  const old=LITTO_POPUP_CACHE.get(url);
  if(old){
    yield {...old.data,_refreshing:Date.now()-old.at>=ttl};
    if(Date.now()-old.at<ttl)return;
  }
  let request=LITTO_POPUP_PENDING.get(url);
  if(!request){
    request=(async()=>{
      const response=await fetch(url,{cache:'no-store'});
      const data=await response.json();
      if(!response.ok)throw Error(data.error||'조회 실패');
      if(data.error)throw Error(data.error);
      LITTO_POPUP_CACHE.delete(url);
      const sourceTime=Date.parse(data.updated_at||'');
      LITTO_POPUP_CACHE.set(url,{at:Number.isFinite(sourceTime)?Math.min(Date.now(),sourceTime):Date.now(),data});
      while(LITTO_POPUP_CACHE.size>80)LITTO_POPUP_CACHE.delete(LITTO_POPUP_CACHE.keys().next().value);
      return data;
    })();
    LITTO_POPUP_PENDING.set(url,request);
    request.finally(()=>LITTO_POPUP_PENDING.delete(url)).catch(()=>{});
  }
  try{yield await request}catch(error){
    if(!old)throw error;
    yield {...old.data,_refreshError:error.message};
  }
}
function littoPopupStatus(data){return data._refreshing?' · 저장된 자료 표시 / 갱신 중':data._refreshError?' · 갱신 실패 (이전 자료)':''}
async function openNews(code,name){const requestId=++LITTO_NEWS_REQUEST;const m=ensureNewsModal();m.classList.add('open');$('#newsTitle').textContent=`${name||code} 관련 종목뉴스`;$('#newsSub').textContent=`${code} · 최신 기사 조회 중`;$('#newsRows').innerHTML='<div class="empty">뉴스를 불러오는 중입니다...</div>';$('#newsSource').href=`https://search.naver.com/search.naver?where=news&query=${encodeURIComponent((name||code)+' 주식')}`;try{for await(const d of littoPopupRead(`/api/news?code=${encodeURIComponent(code)}&name=${encodeURIComponent(name||'')}`,120000)){if(requestId!==LITTO_NEWS_REQUEST)return;$('#newsSub').textContent=`${d.source||'종목뉴스'} · ${d.updated_at?new Date(d.updated_at).toLocaleTimeString():''}`;if(d.source_url)$('#newsSource').href=d.source_url;const rows=d.rows||[];$('#newsRows').innerHTML=rows.map(x=>`<a class="newsrow" href="${esc(x.url)}" target="_blank" rel="noopener noreferrer"><div class="newsrow-title">${newsAgeBadge(x.time)}<b>${esc(x.title)}</b></div><div class="newsmeta"><span>${esc(x.publisher||'')}</span><span>${esc(x.time||'')}</span></div></a>`).join('')||`<div class="empty">${esc(d.error||'관련 뉴스를 찾지 못했습니다.')}<br><span class="muted">오른쪽 위 ‘뉴스 전체보기’로 검색할 수 있습니다.</span></div>`;$('#newsSub').textContent+=littoPopupStatus(d);}}catch(e){if(requestId!==LITTO_NEWS_REQUEST)return;$('#newsSub').textContent='뉴스 조회 실패';$('#newsRows').innerHTML=`<div class="empty">${esc(e.message)}<br><span class="muted">오른쪽 위 ‘뉴스 전체보기’를 이용해 주세요.</span></div>`}}
function newsButtonHtml(code,name){return `<button class="news-btn" data-news-code="${esc(code)}" data-news-name="${esc(name||'')}">뉴스</button>`}
function stockMemoIconHtml(code,name){
  const c=String(code||'').trim();
  if(!c||typeof watchMemo!=='function')return '';
  const memo=watchMemo(c);
  if(!memo)return '';
  return `<button class="watch-memo-icon trade-memo-icon" type="button" data-watch-memo="${esc(c)}" data-watch-memo-name="${esc(name||c)}" title="${esc(memo)}" aria-label="메모 있음">📝</button>`;
}
function disclosureButtonHtml(code,name){const q=encodeURIComponent(String(code||name||''));const label=esc(name||code||'');const url=`https://dart.fss.or.kr/dsab001/main.do?autoSearch=Y&textCrpNm=${q}`;return `<a class="disclosure-btn" href="${url}" target="_blank" rel="noopener noreferrer" title="${label} DART 공시 보기" onclick="event.stopPropagation()">공시</a>`}
function bindNewsButtons(){$$('[data-news-code]').forEach(b=>{b.onclick=e=>{e.stopPropagation();openNews(b.dataset.newsCode,b.dataset.newsName)}})}
// v1.2 HTS floating scanner compatibility: legacy investor-flow binder was referenced but not defined.
// Investor flow is opened through the common stock action modal, so this binder is intentionally a safe no-op.
function bindInvestorFlowClicks(){}

function ensureInvestorFlowModal(){let m=$('#investorFlowModal');if(m)return m;m=document.createElement('div');m.id='investorFlowModal';m.className='investor-flow-modal';m.innerHTML=`<div class="investor-flow-backdrop" data-flow-close></div><div class="investor-flow-dialog"><div class="investor-flow-head"><div><div class="eyebrow">INVESTOR FLOW</div><h2 id="investorFlowTitle">수급 상세</h2><div id="investorFlowMeta" class="muted">종목 클릭 시 조회</div></div><button class="investor-flow-close" data-flow-close type="button">✕</button></div><div id="investorFlowBody" class="investor-flow-body"><div class="empty">불러오는 중...</div></div></div>`;document.body.appendChild(m);m.querySelectorAll('[data-flow-close]').forEach(x=>x.onclick=()=>m.hidden=true);m.hidden=true;return m}
function flowEok(v){const n=Number(v);if(!Number.isFinite(n))return '-';const e=n/100;if(e===0)return '0';const sign=e>0?'+':'-';const a=Math.abs(e);if(a>=10000){const jo=Math.floor(a/10000),rem=a-jo*10000;const remTxt=rem>=100?Math.round(rem).toLocaleString('ko-KR')+'억':rem>=1?rem.toLocaleString('ko-KR',{minimumFractionDigits:0,maximumFractionDigits:1})+'억':'';return `${sign}${jo.toLocaleString('ko-KR')}조${remTxt?' '+remTxt:''}`}if(a>=100)return `${sign}${Math.round(a).toLocaleString('ko-KR')}억`;if(a>=1)return `${sign}${a.toLocaleString('ko-KR',{minimumFractionDigits:0,maximumFractionDigits:1})}억`;const man=a*10000;return `${sign}${Math.round(man).toLocaleString('ko-KR')}만`}
function flowCls(v){const n=Number(v);return n>0?'up':n<0?'down':''}
function flowBox(label,v){return `<div class="flow-box"><span>${esc(label)}</span><b class="${flowCls(v)}">${flowEok(v)}</b></div>`}
async function openInvestorFlow(code,name){const requestId=++LITTO_FLOW_REQUEST;const m=ensureInvestorFlowModal();m.style.zIndex='220000';m.hidden=false;$('#investorFlowTitle').textContent=`${name||code} 수급`;$('#investorFlowMeta').textContent=`${code} · 키움 투자자별 순매수`;$('#investorFlowBody').innerHTML='<div class="empty">수급을 불러오는 중...</div>';try{for await(const d of littoPopupRead(`/api/investor-flow?code=${encodeURIComponent(code)}`,60000)){if(requestId!==LITTO_FLOW_REQUEST)return;const t=d.today||{},f=d.ten_day||d.five_day||{};const inst=[['금융투자','fnnc_invt'],['보험','insrnc'],['투신','invtrt'],['기타금융','etc_fnnc'],['은행','bank'],['연기금등','penfnd_etc'],['사모펀드','samo_fund'],['국가','natn']];$('#investorFlowTitle').textContent=`${d.name||name||code} 수급`;$('#investorFlowMeta').textContent=`${d.code} · ${d.source||''} · 최근 ${d.days?.length||0}거래일`;const instBoxes=inst.map(([n,k])=>`<button type="button" class="flow-box flow-inst-click" data-flow-inst="${k}" data-flow-inst-name="${n}"><span>${n}</span><b class="${flowCls(f[k])}">${flowEok(f[k])}</b></button>`).join('');$('#investorFlowBody').innerHTML=`<div class="flow-section"><h3>오늘 순매수</h3><div class="flow-main-grid">${flowBox('외국인',t.frgnr_invsr)}${flowBox('기관계',t.orgn)}${flowBox('개인',t.ind_invsr)}</div></div><div class="flow-section"><h3>기관 상세 · 오늘</h3><div class="flow-inst-grid">${inst.map(([n,k])=>flowBox(n,t[k])).join('')}</div></div><div class="flow-section"><h3>최근 10거래일 누적 <small class="muted">기관 항목을 누르면 일별 수급 표시</small></h3><div class="flow-main-grid">${flowBox('외국인',f.frgnr_invsr)}${flowBox('기관계',f.orgn)}${flowBox('개인',f.ind_invsr)}</div><div class="flow-inst-grid compact">${instBoxes}</div><div id="flowInstDaily" class="flow-inst-daily"><div class="empty">기관 상세 항목을 선택하세요.</div></div></div><div class="flow-section"><h3>일별 수급 · 외국인 / 기관계 / 개인</h3><div class="flow-days">${(d.days||[]).map(x=>`<div class="flow-day"><b>${esc(String(x.date||'').replace(/(\d{4})(\d{2})(\d{2})/,'$1-$2-$3'))}</b><span class="${flowCls(x.frgnr_invsr)}">외 ${flowEok(x.frgnr_invsr)}</span><span class="${flowCls(x.orgn)}">기 ${flowEok(x.orgn)}</span><span class="${flowCls(x.ind_invsr)}">개 ${flowEok(x.ind_invsr)}</span></div>`).join('')||'<div class="empty">수급 데이터가 없습니다.</div>'}</div></div><div class="flow-note">금액은 키움 ka10060 금액 모드 응답을 억원 단위로 환산해 표시합니다.</div>`;const renderInstDaily=(key,label,btn)=>{document.querySelectorAll('.flow-inst-click').forEach(x=>x.classList.toggle('active',x===btn));const root=$('#flowInstDaily');if(!root)return;root.innerHTML=`<div class="flow-inst-daily-head"><b>${esc(label)} · 최근 10거래일</b><span>합계 ${flowEok(f[key])}</span></div><div class="flow-days">${(d.days||[]).map(x=>`<div class="flow-day flow-day-single"><b>${esc(String(x.date||'').replace(/(\d{4})(\d{2})(\d{2})/,'$1-$2-$3'))}</b><span class="${flowCls(x[key])}">${flowEok(x[key])}</span></div>`).join('')||'<div class="empty">수급 데이터가 없습니다.</div>'}</div>`};document.querySelectorAll('.flow-inst-click').forEach(btn=>btn.onclick=()=>renderInstDaily(btn.dataset.flowInst,btn.dataset.flowInstName,btn));$('#investorFlowMeta').textContent+=littoPopupStatus(d);}}catch(e){if(requestId!==LITTO_FLOW_REQUEST)return;$('#investorFlowBody').innerHTML=`<div class="empty">${esc(e.message)}</div>`}}
function ensureOrderbookAccountUiStyle(){
  if(document.getElementById('orderbookAccountUiStyle'))return;
  const st=document.createElement('style');st.id='orderbookAccountUiStyle';st.textContent=`
    #orderbookModal .ob-pos-card:first-child b{font-size:22px!important;font-weight:950!important}
    #orderbookModal #obTradeAmount{height:40px!important;font-size:15px!important;font-weight:900!important}
    #orderbookModal .ob-ladder{grid-template-rows:repeat(6,minmax(0,1fr))!important;grid-auto-rows:minmax(0,1fr)!important}
    #orderbookModal .orderbook-row{padding-top:0!important;padding-bottom:0!important;position:relative!important;height:100%!important;min-height:0!important;align-items:stretch!important}
    #orderbookModal .ob-mid,#orderbookModal .ob-book-qty,#orderbookModal .ob-book-qty.empty{height:100%!important;min-height:0!important}
    #orderbookModal .ob-mid{display:flex!important;flex-direction:column!important;justify-content:center!important;align-items:center!important;gap:1px!important;transform:translateY(-1px)!important}
    #orderbookModal .ob-mid .ob-price,#orderbookModal .ob-mid .ob-rate{text-align:center!important;width:100%!important}
    #orderbookModal .ob-book-qty{display:flex!important;align-items:center!important;position:relative!important;overflow:hidden!important}
    #orderbookModal .ob-book-qty.ask{justify-content:flex-end!important;padding:0 12px 0 4px!important}
    #orderbookModal .ob-book-qty.bid{justify-content:flex-start!important;padding:0 4px 0 12px!important}
    #orderbookModal .ob-book-qty i{top:5px!important;bottom:5px!important;border-radius:4px!important}
    #orderbookModal .ob-qty-text{position:absolute!important;top:50%!important;transform:translateY(-50%)!important;z-index:3!important;height:auto!important;min-height:0!important;display:flex!important;flex-direction:column!important;justify-content:center!important;line-height:1.05!important;margin:0!important;padding:0!important;pointer-events:none!important}
    #orderbookModal .ob-book-qty.ask .ob-qty-text{right:10px!important;left:auto!important;align-items:flex-end!important;text-align:right!important}
    #orderbookModal .ob-book-qty.bid .ob-qty-text{left:10px!important;right:auto!important;align-items:flex-start!important;text-align:left!important}
    #orderbookModal .ob-qty-text span,#orderbookModal .ob-qty-text small{display:block!important}
    #orderbookModal .ob-qty-text span{line-height:1.05!important}
    #orderbookModal .ob-qty-text small{margin-top:2px!important;line-height:1!important}
    #orderbookModal .ob-current-line{align-items:center!important}
    #orderbookModal .ob-mid{transform:none!important}
    #orderbookModal .ob-book-qty i{top:50%!important;bottom:auto!important;height:62%!important;transform:translateY(-50%)!important;max-height:none!important}
    #orderbookModal .ob-badge.avg{color:#ffd43b!important;border-color:#8a6c10!important;background:rgba(255,212,59,.10)!important;font-weight:950!important}
    #orderbookModal #obAskTotal{color:#ff6b7d!important;font-weight:950!important}
    #orderbookModal #obBidTotal{color:#63adff!important;font-weight:950!important}
    #orderbookModal .ob-own-order{
      position:absolute;top:50%;transform:translateY(-50%);z-index:4;
      min-width:24px;padding:2px 5px;border-radius:6px;font-size:15px;font-weight:950;
      line-height:1.05;text-align:center;pointer-events:none;background:rgba(4,13,22,.82);
      box-shadow:0 0 0 1px rgba(255,255,255,.06);
    }
    #orderbookModal .ob-own-order.sell{left:8px;color:#ff6b7d}
    #orderbookModal .ob-own-order.buy{right:8px;color:#63adff}
  `;document.head.appendChild(st)
}
function ensureOrderbookModal(){ensureOrderbookAccountUiStyle();let m=$('#orderbookModal');if(m)return m;m=document.createElement('div');m.id='orderbookModal';m.className='orderbook-modal';m.innerHTML=`<div class="orderbook-backdrop" data-orderbook-close></div><div class="orderbook-dialog hts-orderbook"><div class="ob-topnav"><button id="obQuickInfo" type="button">수급</button><button id="obQuickChart" type="button">차트</button><button class="active" type="button">호가</button></div><div class="orderbook-head hts-head"><div><div class="eyebrow">HTS LIVE · KIWOOM SOR</div><div class="ob-titleline"><h2 id="orderbookTitle">실시간 호가</h2><span id="orderbookCode" class="ob-code"></span></div><div id="orderbookMeta" class="muted">키움 호가잔량 연결 중</div></div><div id="orderbookPositionSummary" class="ob-position-summary"><div class="ob-pos-empty">보유 없음</div></div><div id="orderbookHeadline" class="ob-headline"></div><button class="orderbook-close" data-orderbook-close type="button">✕</button></div><div class="ob-layout"><section class="ob-ladder-panel"><div class="ob-column-head"><span>매도잔량</span><span>호가</span><span>매수잔량</span></div><div id="orderbookAsks" class="ob-ladder asks"></div><div id="orderbookCurrent" class="ob-current-line"></div><div id="orderbookBids" class="ob-ladder bids"></div><div class="ob-ladder-foot"><div><span>매도총잔량</span><b id="obAskTotal">-</b></div><small id="obViewPosition">1~6 / 10호가</small><div><b id="obBidTotal">-</b><span>매수총잔량</span></div></div></section><aside class="ob-side"><div id="orderbookSideStats" class="ob-side-stats"></div><div id="orderbookSummary" class="orderbook-summary"></div><div class="ob-tape-panel"><div class="ob-tape-head"><b>실시간 체결</b><span id="obFeedBadge" class="ob-feed-badge">CONNECT</span></div><div id="obRecentTrades" class="ob-recent-trades"><div class="empty">체결 수신 대기</div></div></div></aside><aside class="ob-trade-panel"><div class="ob-trade-head"><div><span>MANUAL ORDER</span><b id="obTradeAccount">계좌 확인 중</b></div><span id="obTradeMode" class="ob-trade-mode">조회</span></div><div class="ob-trade-tabs"><button id="obTradeBuy" class="active buy" type="button">매수</button><button id="obTradeSell" class="sell" type="button">매도</button></div><div class="ob-trade-types"><button id="obTradeLimit" class="active" type="button">지정가</button><button id="obTradeMarket" type="button">시장가</button></div><label class="ob-trade-field"><span>주문가격</span><input id="obTradePrice" inputmode="numeric" autocomplete="off" placeholder="호가 클릭"/></label><label class="ob-trade-field"><span>수량</span><div class="ob-qty-input"><button id="obQtyMinus" type="button">−</button><input id="obTradeQty" inputmode="numeric" value="1"/><button id="obQtyPlus" type="button">+</button></div></label><label class="ob-trade-field"><span>주문금액</span><input id="obTradeAmount" inputmode="numeric" autocomplete="off" placeholder="예: 1000000"/></label><div class="ob-sell-ratios"><button data-ob-sell-ratio="25" type="button">25%</button><button data-ob-sell-ratio="50" type="button">50%</button><button data-ob-sell-ratio="75" type="button">75%</button><button data-ob-sell-ratio="100" type="button">전량</button></div><div class="ob-trade-info" id="obTradeInfo"><span>보유 -</span><span>예상 -</span></div><label class="ob-live-arm"><input id="obLiveArm" type="checkbox"/><span>실전계좌 주문 활성화</span></label><button id="obSubmitOrder" class="ob-submit-order buy" type="button">매수 주문</button><div id="obOrderResult" class="ob-order-result">주문 전송 전 최종 확인창이 표시됩니다.</div><div class="ob-unfilled-head"><b>미체결</b><button id="obCancelAll" type="button">전체취소</button></div><div id="obUnfilledOrders" class="ob-unfilled-list"><div class="empty">미체결 조회 대기</div></div></aside></div><div class="orderbook-note">실시간 호가·체결은 키움 WebSocket 이벤트를 즉시 반영합니다. 주문은 최종 확인 후 전송됩니다.</div></div>`;document.body.appendChild(m);m.querySelectorAll('[data-orderbook-close]').forEach(x=>x.onclick=()=>closeOrderbook());m.hidden=true;return m}
let ORDERBOOK_TIMER=null,ORDERBOOK_CODE='',ORDERBOOK_NAME='',ORDERBOOK_LAST_BEST_KEY='',ORDERBOOK_LAST_CURRENT=0;
let ORDERBOOK_LIVE_TOKEN=0,ORDERBOOK_LIVE_SEQ=0,ORDERBOOK_LAST_BOOK_HASH='',ORDERBOOK_LAST_TAPE_HASH='',ORDERBOOK_PENDING_DATA=null,ORDERBOOK_RENDER_TIMER=null,ORDERBOOK_LAST_RENDER=0;
let ORDERBOOK_PREV_QTY={};
let ORDERBOOK_VIEW_OFFSET=0,ORDERBOOK_LAST_ASKS=[],ORDERBOOK_LAST_BIDS=[],ORDERBOOK_LAST_BASE=0,ORDERBOOK_DRAG_START_Y=null,ORDERBOOK_DRAG_MOVED=false;
let ORDER_TRADE_TIMER=null,ORDER_TRADE_FAST_TIMER=null,ORDER_TRADE_REFRESHING=false,ORDER_TRADE_SIDE='buy',ORDER_TRADE_TYPE='limit',ORDER_TRADE_ACCOUNT=null,ORDER_TRADE_ACCOUNT_AT=0,ORDER_TRADE_UNFILLED=[],ORDER_TRADE_UNFILLED_HASH='';
const ORDERBOOK_VISIBLE_LEVELS=6;
const STOCK_ACTION_PREFETCH=new Map();
const ORDERBOOK_PREFETCH_CACHE=new Map();
const ORDERBOOK_PREFETCH_INFLIGHT=new Map();
const ORDERBOOK_PREFETCH_TTL=5000;
let ORDER_TRADE_LAST_FILL=null,ORDER_TRADE_LAST_SUBMIT=null;
function closeOrderbook(){const m=$('#orderbookModal');if(m)m.hidden=true;ORDERBOOK_LIVE_TOKEN++;ORDERBOOK_PENDING_DATA=null;if(ORDERBOOK_RENDER_TIMER){clearTimeout(ORDERBOOK_RENDER_TIMER);ORDERBOOK_RENDER_TIMER=null}if(ORDERBOOK_TIMER){clearInterval(ORDERBOOK_TIMER);ORDERBOOK_TIMER=null}if(ORDER_TRADE_TIMER){clearInterval(ORDER_TRADE_TIMER);ORDER_TRADE_TIMER=null}if(ORDER_TRADE_FAST_TIMER){clearInterval(ORDER_TRADE_FAST_TIMER);ORDER_TRADE_FAST_TIMER=null}ORDERBOOK_LAST_BEST_KEY='';ORDERBOOK_LAST_CURRENT=0;ORDERBOOK_LIVE_SEQ=0;ORDERBOOK_LAST_BOOK_HASH='';ORDERBOOK_LAST_TAPE_HASH='';ORDERBOOK_PREV_QTY={};ORDERBOOK_VIEW_OFFSET=0;ORDERBOOK_LAST_ASKS=[];ORDERBOOK_LAST_BIDS=[];ORDERBOOK_DRAG_START_Y=null;ORDERBOOK_DRAG_MOVED=false;ORDER_TRADE_LAST_FILL=null;ORDER_TRADE_LAST_SUBMIT=null;ORDER_TRADE_ACCOUNT_AT=0;ORDER_TRADE_UNFILLED_HASH=''}
function orderbookMoney(price,qty){const v=Math.abs(Number(price)||0)*Math.abs(Number(qty)||0);if(!v)return '-';if(v>=100000000)return `${(v/100000000).toLocaleString('ko-KR',{maximumFractionDigits:1})}억`;if(v>=10000)return `${Math.round(v/10000).toLocaleString('ko-KR')}만`;return `${Math.round(v).toLocaleString('ko-KR')}원`}
function obFmt(v){const n=Number(v);return Number.isFinite(n)&&n!==0?Math.round(Math.abs(n)).toLocaleString('ko-KR'):'-'}
function obPctFrom(price,base){const p=Number(price),b=Number(base);if(!p||!b)return '';const r=(p/b-1)*100;return `${r>=0?'+':''}${r.toFixed(2)}%`}
function obLimitPrice(base,rate){const b=Number(base);return b?Math.round(b*(1+rate)):null}
function mergeOrderbookSide(next,prev,side){
  const clean=arr=>(Array.isArray(arr)?arr:[]).filter(x=>Number(x?.price)>0).map(x=>({price:Math.abs(Number(x.price)||0),qty:Math.abs(Number(x.qty)||0)}));
  const cur=clean(next),old=clean(prev);
  if(!cur.length)return old;
  const seen=new Set(cur.map(x=>String(x.price)));
  const out=cur.slice();
  for(const row of old){
    const key=String(row.price);
    if(seen.has(key))continue;
    out.push(row);
    seen.add(key);
    if(out.length>=10)break;
  }
  return out.slice(0,10);
}
function padOrderbookWindow(rows,target=ORDERBOOK_VISIBLE_LEVELS){
  const out=(Array.isArray(rows)?rows:[]).slice(0,target);
  while(out.length<target)out.push({price:0,qty:0});
  return out;
}
function obOwnUnfilledQty(price,side){
  const p=obPriceNorm(price);if(!p)return 0;
  const wanted=side==='ask'?'sell':'buy';
  return (ORDER_TRADE_UNFILLED||[]).reduce((sum,r)=>{
    if(r?.side!==wanted||obPriceNorm(r?.order_price)!==p)return sum;
    return sum+Math.max(0,Number(r?.remain_qty||0));
  },0)
}
function orderbookRow(x,side,maxQty,base){
  const p=Math.abs(Number(x?.price)||0),q=Math.abs(Number(x?.qty)||0),w=maxQty?Math.max(2,Math.min(100,q/maxQty*100)):0,pct=obPctFrom(p,base),badges=obPriceBadges(p),key=`${side}:${p}`,prev=Number(ORDERBOOK_PREV_QTY[key]),ownQty=obOwnUnfilledQty(p,side);
  const delta=Number.isFinite(prev)?(q>prev?' qty-rise':q<prev?' qty-fall':''):'';
  const qty=`<div class="ob-book-qty ${side}"><i style="width:${w}%"></i><div class="ob-qty-text"><span>${q?q.toLocaleString('ko-KR'):'-'}</span><small>${q&&p?orderbookMoney(p,q):'-'}</small></div></div>`;
  const empty='<div class="ob-book-qty empty"></div>';
  const price=`<div class="ob-mid"><b class="ob-price">${p?p.toLocaleString('ko-KR'):'-'}</b><span class="ob-rate">${pct||'-'}</span>${badges?`<span class="ob-badges">${badges}</span>`:''}</div>`;
  const own=ownQty>0?`<span class="ob-own-order ${side==='ask'?'sell':'buy'}" title="${side==='ask'?'매도':'매수'} 미체결 ${ownQty.toLocaleString('ko-KR')}주">${ownQty.toLocaleString('ko-KR')}</span>`:'';
  return side==='ask'
    ? `<div class="orderbook-row ask${delta}" data-ob-price="${p||''}" title="가격 클릭 → 지정가 입력">${own}${qty}${price}${empty}</div>`
    : `<div class="orderbook-row bid${delta}" data-ob-price="${p||''}" title="가격 클릭 → 지정가 입력">${own}${empty}${price}${qty}</div>`
}
function renderOrderbookWindow(){
  const asks=ORDERBOOK_LAST_ASKS||[],bids=ORDERBOOK_LAST_BIDS||[],base=ORDERBOOK_LAST_BASE||0;
  const maxStart=Math.max(0,10-ORDERBOOK_VISIBLE_LEVELS),start=Math.max(0,Math.min(maxStart,Number(ORDERBOOK_VIEW_OFFSET)||0));
  const askWin=padOrderbookWindow(asks.slice(start,start+ORDERBOOK_VISIBLE_LEVELS),ORDERBOOK_VISIBLE_LEVELS),bidWin=padOrderbookWindow(bids.slice(start,start+ORDERBOOK_VISIBLE_LEVELS),ORDERBOOK_VISIBLE_LEVELS);
  const maxQty=Math.max(1,...asks.map(x=>Number(x.qty)||0),...bids.map(x=>Number(x.qty)||0));
  const askBox=$('#orderbookAsks'),bidBox=$('#orderbookBids');
  if(askBox)askBox.innerHTML=askWin.slice().reverse().map(x=>orderbookRow(x,'ask',maxQty,base)).join('')||'<div class="empty">매도호가 수신 대기</div>';
  if(bidBox)bidBox.innerHTML=bidWin.map(x=>orderbookRow(x,'bid',maxQty,base)).join('')||'<div class="empty">매수호가 수신 대기</div>';
  const nav=$('#obViewPosition');if(nav)nav.textContent=`${start+1}~${Math.min(start+ORDERBOOK_VISIBLE_LEVELS,10)} / 10호가`;
}
function setOrderbookViewOffset(next){const v=Math.max(0,Math.min(Math.max(0,10-ORDERBOOK_VISIBLE_LEVELS),Math.round(Number(next)||0)));if(v===ORDERBOOK_VIEW_OFFSET)return;ORDERBOOK_VIEW_OFFSET=v;renderOrderbookWindow()}
function bindOrderbookDrag(){const panel=document.querySelector('#orderbookModal .ob-ladder-panel');if(!panel||panel.dataset.dragBound==='1')return;panel.dataset.dragBound='1';let active=false,startY=0,startOffset=0,startRow=null;panel.addEventListener('pointerdown',e=>{if(e.button!==0||e.target.closest('button,input'))return;active=true;ORDERBOOK_DRAG_MOVED=false;startY=e.clientY;startOffset=ORDERBOOK_VIEW_OFFSET;startRow=e.target.closest?.('[data-ob-price]')||null;panel.setPointerCapture?.(e.pointerId);panel.classList.add('ob-dragging')});panel.addEventListener('pointermove',e=>{if(!active)return;const dy=e.clientY-startY;if(Math.abs(dy)>6)ORDERBOOK_DRAG_MOVED=true;const step=Math.trunc(-dy/28);setOrderbookViewOffset(startOffset+step)});panel.addEventListener('pointerup',e=>{if(!active)return;const wasDrag=ORDERBOOK_DRAG_MOVED;active=false;panel.classList.remove('ob-dragging');if(!wasDrag&&startRow?.dataset?.obPrice){const picked=startRow.dataset.obPrice;obTradeSelectPrice(picked,startRow.classList.contains('ask')?'sell':'buy');try{window.littoSemiAutoPickPrice?.(picked)}catch(_e){}}startRow=null;setTimeout(()=>{ORDERBOOK_DRAG_MOVED=false},0)});panel.addEventListener('pointercancel',()=>{active=false;startRow=null;ORDERBOOK_DRAG_MOVED=false;panel.classList.remove('ob-dragging')});panel.addEventListener('wheel',e=>{if(Math.abs(e.deltaY)<2)return;e.preventDefault();setOrderbookViewOffset(ORDERBOOK_VIEW_OFFSET+(e.deltaY>0?1:-1))},{passive:false});}
function ensureOrderbookMotionStyle(){if($('#orderbookMotionStyle'))return;const st=document.createElement('style');st.id='orderbookMotionStyle';st.textContent=`
.ob-ladder-recenter{animation:obLadderShift .30s ease-out}
.ob-current-tick{animation:obCurrentTick .22s ease-out}
@keyframes obLadderShift{0%{transform:translateY(var(--ob-shift,0));opacity:.68}100%{transform:translateY(0);opacity:1}}
@keyframes obCurrentTick{0%{filter:brightness(1.7);transform:scale(1.012)}100%{filter:none;transform:scale(1)}}
`;document.head.appendChild(st)}
function pulseOrderbookLadder(direction){ensureOrderbookMotionStyle();const asks=$('#orderbookAsks'),bids=$('#orderbookBids'),cur=$('#orderbookCurrent');const shift=direction>0?'10px':direction<0?'-10px':'0px';[asks,bids].forEach(el=>{if(!el)return;el.style.setProperty('--ob-shift',shift);el.classList.remove('ob-ladder-recenter');void el.offsetWidth;el.classList.add('ob-ladder-recenter')});if(cur){cur.classList.remove('ob-current-tick');void cur.offsetWidth;cur.classList.add('ob-current-tick')}}

function obStockSnapshot(code,live={}){const s=findStock(code)||{};const daily=Array.isArray(s.daily)?s.daily:[];const last=daily[daily.length-1]||{};const prev=daily[daily.length-2]||{};const statePrice=Math.abs(Number(s.price||0));const stateRate=Number(s.change);const hasIntegrated=statePrice>0&&Number.isFinite(stateRate);const livePrice=Math.abs(Number(live.current_price||0));const liveRate=Number(live.change_rate);const liveBase=Math.abs(Number(live.base_price||0));const price=livePrice||(hasIntegrated?statePrice:Math.abs(Number(last.close||0)));const change=Number.isFinite(liveRate)?liveRate:(hasIntegrated?stateRate:Number(s.change||0));let base=liveBase;if(!base&&price&&Number.isFinite(change)&&change>-99.9)base=price/(1+change/100);if(!base)base=Math.abs(Number(prev.close||0));return {s,last,prev,price,change,base,integrated:!!(livePrice&&Number.isFinite(liveRate)),open:Math.abs(Number(live.open||last.open||0)),high:Math.abs(Number(live.high||last.high||0)),low:Math.abs(Number(live.low||last.low||0)),value:Number(s.value_eok??live.acc_value_eok??0),volume:Number(live.acc_volume||0)}}
function renderObRecentTrades(d){
  const box=$('#obRecentTrades'),badge=$('#obFeedBadge');if(!box)return;
  const age=Number(d?.last_message_age),connected=!!d?.connected;
  if(badge){badge.textContent=connected?(age<=.35?'LIVE':'LIVE '+(Number.isFinite(age)?age.toFixed(1)+'s':'')):'WAIT';badge.classList.toggle('hot',connected&&age<=.35);badge.classList.toggle('stale',!connected||age>1.5)}
  const rows=Array.isArray(d?.recent_trades)?d.recent_trades.slice(-12).reverse():[];
  const hash=rows.map(x=>`${x.time}|${x.price}|${x.qty}|${x.direction}`).join(';');
  if(hash===ORDERBOOK_LAST_TAPE_HASH)return;ORDERBOOK_LAST_TAPE_HASH=hash;
  if(!rows.length){box.innerHTML='<div class="empty">체결 수신 대기</div>';return}
  box.innerHTML=rows.map(x=>{const dir=x.direction==='up'?'up':x.direction==='down'?'down':'flat';const arrow=dir==='up'?'▲':dir==='down'?'▼':'·';const tm=String(x.time||'').replace(/[^0-9]/g,'').slice(-6);const ts=tm.length===6?`${tm.slice(0,2)}:${tm.slice(2,4)}:${tm.slice(4,6)}`:(x.time||'-');return `<div class="ob-tape-row ${dir}"><span>${esc(ts)}</span><b>${arrow} ${Number(x.price||0).toLocaleString('ko-KR')}</b><em>${x.qty!=null?Number(x.qty).toLocaleString('ko-KR')+'주':'-'}</em></div>`}).join('');
}
function queueOrderbookRender(d){
  if(d&&ORDERBOOK_CODE)ORDERBOOK_PREFETCH_CACHE.set(String(ORDERBOOK_CODE||'').replace(/\D/g,''),{ts:Date.now(),data:d});
  ORDERBOOK_PENDING_DATA=d;const now=performance.now(),wait=Math.max(0,70-(now-ORDERBOOK_LAST_RENDER));
  if(ORDERBOOK_RENDER_TIMER)return;
  ORDERBOOK_RENDER_TIMER=setTimeout(()=>{ORDERBOOK_RENDER_TIMER=null;const data=ORDERBOOK_PENDING_DATA;ORDERBOOK_PENDING_DATA=null;if(!data)return;ORDERBOOK_LAST_RENDER=performance.now();requestAnimationFrame(()=>applyOrderbookData(data))},wait);
}
function applyOrderbookData(d){
  if(!ORDERBOOK_CODE||$('#orderbookModal')?.hidden)return;
  const snap=obStockSnapshot(ORDERBOOK_CODE,d),name=d.name||ORDERBOOK_NAME||snap.s?.name||ORDERBOOK_CODE;
  $('#orderbookTitle').textContent=name;$('#orderbookCode').textContent=ORDERBOOK_CODE;
  const age=d.last_message_age==null?'-':`${Math.max(0,Number(d.last_message_age)).toFixed(Number(d.last_message_age)<1?2:1)}초`;
  const current=snap.price||Number(d.current_price||0)||Number(d.expected_price||0);
  const asksRaw=(d.asks||[]).filter(x=>Number(x.price)>0),bidsRaw=(d.bids||[]).filter(x=>Number(x.price)>0);
  const asks=mergeOrderbookSide(asksRaw,ORDERBOOK_LAST_ASKS,'ask'),bids=mergeOrderbookSide(bidsRaw,ORDERBOOK_LAST_BIDS,'bid');
  const maxQty=Math.max(1,...asks.map(x=>Number(x.qty)||0),...bids.map(x=>Number(x.qty)||0));
  const bestAsk=Number((asksRaw[0]||asks[0]||{}).price||0),bestBid=Number((bidsRaw[0]||bids[0]||{}).price||0),bestKey=`${bestAsk}|${bestBid}`;
  let shiftDir=0;if(ORDERBOOK_LAST_BEST_KEY&&bestKey!==ORDERBOOK_LAST_BEST_KEY){const [oa,ob]=ORDERBOOK_LAST_BEST_KEY.split('|').map(Number),om=(oa&&ob)?(oa+ob)/2:(oa||ob||0),nm=(bestAsk&&bestBid)?(bestAsk+bestBid)/2:(bestAsk||bestBid||0);shiftDir=nm>om?1:nm<om?-1:0}
  const bestChanged=!!ORDERBOOK_LAST_BEST_KEY&&bestKey!==ORDERBOOK_LAST_BEST_KEY;ORDERBOOK_LAST_BEST_KEY=bestKey;
  const currentChanged=!!ORDERBOOK_LAST_CURRENT&&current&&Number(current)!==Number(ORDERBOOK_LAST_CURRENT);ORDERBOOK_LAST_CURRENT=Number(current)||ORDERBOOK_LAST_CURRENT;
  const noBook=!asks.length&&!bids.length,venue=d.venue||'SOR',src=d.source||'';
  $('#orderbookMeta').textContent=noBook?`${d.market_closed?'장마감/휴장일 · ':''}${d.cached_orderbook?'마지막 저장 호가':'호가 연결 대기'}${d.error?' · '+d.error:''}`:`${venue} · ${src||'키움 실시간'}${d.connected?' · '+age:''}${d.provider_code?` · ${d.provider_code}`:''}`;
  $('#orderbookHeadline').innerHTML=`<b class="${snap.change>=0?'up':'down'}">${current?Number(current).toLocaleString('ko-KR'):'-'}</b><span class="${snap.change>=0?'up':'down'}">${snap.change>=0?'+':''}${Number(snap.change||0).toFixed(2)}%</span><small>거래대금 ${Number(snap.value||0).toLocaleString('ko-KR',{maximumFractionDigits:0})}억${snap.volume?` · ${Number(snap.volume).toLocaleString('ko-KR')}주`:''}</small>`;
  renderObPositionSummary(current);
  const bookHash=[...asks.map(x=>`a${x.price}:${x.qty}`),...bids.map(x=>`b${x.price}:${x.qty}`)].join('|');
  if(bookHash!==ORDERBOOK_LAST_BOOK_HASH){
    ORDERBOOK_LAST_ASKS=asks;ORDERBOOK_LAST_BIDS=bids;ORDERBOOK_LAST_BASE=snap.base;renderOrderbookWindow();bindOrderbookDrag();
    const next={};asks.forEach(x=>next[`ask:${Math.abs(Number(x.price)||0)}`]=Math.abs(Number(x.qty)||0));bids.forEach(x=>next[`bid:${Math.abs(Number(x.price)||0)}`]=Math.abs(Number(x.qty)||0));ORDERBOOK_PREV_QTY=next;ORDERBOOK_LAST_BOOK_HASH=bookHash;
    if(bestChanged)pulseOrderbookLadder(shiftDir);
  }
  $('#orderbookCurrent').innerHTML=`<span>현재가</span><strong class="${snap.change>=0?'up':'down'}">${current?Number(current).toLocaleString('ko-KR'):'-'}</strong><em>${snap.change>=0?'+':''}${Number(snap.change||0).toFixed(2)}%</em><small>${bestAsk&&bestBid?`스프레드 ${(bestAsk-bestBid).toLocaleString('ko-KR')}원`:''}</small>`;
  if(currentChanged&&!bestChanged){ensureOrderbookMotionStyle();const cur=$('#orderbookCurrent');if(cur){cur.classList.remove('ob-current-tick');void cur.offsetWidth;cur.classList.add('ob-current-tick')}}
  const upper=obLimitPrice(snap.base,.30),lower=obLimitPrice(snap.base,-.30);
  $('#orderbookSideStats').innerHTML=`<div><span>기준가</span><b>${obFmt(snap.base)}</b></div><div><span>시가</span><b class="${snap.open>=snap.base?'up':'down'}">${obFmt(snap.open)}</b></div><div><span>고가</span><b class="up">${obFmt(snap.high)}</b></div><div><span>저가</span><b class="down">${obFmt(snap.low)}</b></div><div><span>상한가</span><b class="up">${obFmt(upper)}</b></div><div><span>하한가</span><b class="down">${obFmt(lower)}</b></div>${d.expected_price?`<div><span>예상체결가</span><b>${obFmt(d.expected_price)}</b></div>`:''}${d.expected_qty?`<div><span>예상체결량</span><b>${obFmt(d.expected_qty)}주</b></div>`:''}`;
  const askTot=Number(d.ask_total||0),bidTot=Number(d.bid_total||0),ratio=askTot>0?bidTot/askTot:0;
  const askT=$('#obAskTotal'),bidT=$('#obBidTotal');if(askT)askT.textContent=askTot.toLocaleString('ko-KR');if(bidT)bidT.textContent=bidTot.toLocaleString('ko-KR');
  $('#orderbookSummary').innerHTML=`<div><span>매도 총잔량</span><b class="up">${askTot.toLocaleString('ko-KR')}주</b></div><div><span>매수 총잔량</span><b class="down">${bidTot.toLocaleString('ko-KR')}주</b></div><div><span>잔량비</span><b>${ratio?ratio.toFixed(2):'-'}</b></div>${d.buy_ratio!=null?`<div><span>매수비율</span><b>${Number(d.buy_ratio).toFixed(1)}%</b></div>`:''}${d.sell_ratio!=null?`<div><span>매도비율</span><b>${Number(d.sell_ratio).toFixed(1)}%</b></div>`:''}`;
  renderObRecentTrades(d);
  $('#obQuickChart').onclick=()=>{closeOrderbook();openChart(ORDERBOOK_CODE)};$('#obQuickInfo').onclick=()=>{closeOrderbook();openInvestorFlow(ORDERBOOK_CODE,name)};
}
async function refreshOrderbook(){
  if(!ORDERBOOK_CODE)return null;
  try{const r=await fetch(`/api/orderbook?code=${encodeURIComponent(ORDERBOOK_CODE)}`,{cache:'no-store'});const d=await r.json();if(!r.ok)throw Error(d.error||'호가 조회 실패');ORDERBOOK_LIVE_SEQ=Number(d.seq||0);ORDERBOOK_PREFETCH_CACHE.set(String(ORDERBOOK_CODE||'').replace(/\D/g,''),{ts:Date.now(),data:d});applyOrderbookData(d);return d}catch(e){$('#orderbookMeta').textContent=e.message;return null}
}
async function orderbookLiveLoop(token){
  while(token===ORDERBOOK_LIVE_TOKEN&&ORDERBOOK_CODE&&!$('#orderbookModal')?.hidden){
    try{const r=await fetch(`/api/orderbook-live?code=${encodeURIComponent(ORDERBOOK_CODE)}&seq=${encodeURIComponent(ORDERBOOK_LIVE_SEQ||0)}`,{cache:'no-store'});const d=await r.json();if(!r.ok)throw Error(d.error||'실시간 호가 연결 실패');if(token!==ORDERBOOK_LIVE_TOKEN)return;ORDERBOOK_LIVE_SEQ=Number(d.seq||ORDERBOOK_LIVE_SEQ||0);queueOrderbookRender(d)}catch(e){if(token!==ORDERBOOK_LIVE_TOKEN)return;const b=$('#obFeedBadge');if(b){b.textContent='RETRY';b.classList.remove('hot');b.classList.add('stale')}await new Promise(res=>setTimeout(res,350))}
  }
}

function obInt(v){const n=parseInt(String(v??'').replace(/[^\d-]/g,''),10);return Number.isFinite(n)?n:0}
function obRequestId(){return `${Date.now()}-${Math.random().toString(36).slice(2,10)}`}
function obHolding(){const rows=Array.isArray(ORDER_TRADE_ACCOUNT?.holdings)?ORDER_TRADE_ACCOUNT.holdings:[];return rows.find(x=>String(x.code||'').replace(/\D/g,'')===String(ORDERBOOK_CODE||'').replace(/\D/g,''))||null}
function obTradeCurrentPrice(){return Math.abs(Number(ORDERBOOK_LAST_CURRENT)||0)}
function obPriceNorm(v){const n=Math.round(Math.abs(Number(v)||0));return Number.isFinite(n)&&n>0?n:0}
function obSignedMoney(v){const n=Number(v)||0;const s=n>0?'+':n<0?'−':'';return `${s}${Math.round(Math.abs(n)).toLocaleString('ko-KR')}원`}
function obSignedRate(v){const n=Number(v)||0;return `${n>0?'+':''}${n.toFixed(2)}%`}
function obToneClass(v){const n=Number(v)||0;return n>0?'up':n<0?'down':'flat'}
function renderObPositionSummary(current=0){
  const box=$('#orderbookPositionSummary');if(!box)return;
  const h=obHolding(),qty=Number(h?.quantity||0);
  if(!(qty>0)){box.innerHTML='<div class="ob-pos-empty">보유 없음</div>';return}
  const avg=Number(h?.avg_price||0);
  // Display SOR/NXT live current price, but keep P&L/valuation exactly as
  // Kiwoom kt00018 returned it so its fee/tax/accounting basis is preserved.
  const liveCur=Number(current||obTradeCurrentPrice()||0);
  const acctCur=Number(h?.current_price||0);
  const cur=liveCur>0?liveCur:acctCur;
  const evalAmt=Number(h?.evaluation_amount||0);
  const pnl=Number(h?.evaluation_pnl||0);
  const rate=Number(h?.profit_rate||0);
  box.innerHTML=`<div class="ob-pos-card"><span>보유수량</span><b>${qty.toLocaleString('ko-KR')}주</b><small>가능 ${Number(h?.available_quantity??qty).toLocaleString('ko-KR')}주</small></div><div class="ob-pos-card"><span>평균단가</span><b>${avg?Math.round(avg).toLocaleString('ko-KR')+'원':'-'}</b><small>현재 ${cur?Math.round(cur).toLocaleString('ko-KR')+'원':'-'}</small></div><div class="ob-pos-card ${obToneClass(pnl)}"><span>평가손익</span><b>${obSignedMoney(pnl)}</b><small>${obSignedRate(rate)}</small></div><div class="ob-pos-card"><span>평가금액</span><b>${evalAmt?Math.round(evalAmt).toLocaleString('ko-KR')+'원':'-'}</b><small>키움 계좌평가</small></div>`
}
function obPriceBadges(price){const p=obPriceNorm(price);if(!p)return'';const h=obHolding();const avg=obPriceNorm(h?.avg_price);const tags=[];if(ORDER_TRADE_LAST_FILL&&obPriceNorm(ORDER_TRADE_LAST_FILL.price)===p){tags.push(`<span class="ob-badge fill ${ORDER_TRADE_LAST_FILL.side==='sell'?'sell':'buy'}">${esc(ORDER_TRADE_LAST_FILL.label||'체결')}</span>`)}else if(avg&&avg===p){tags.push('<span class="ob-badge avg">평단</span>')}return tags.join('')}
function obSetOrderResult(text,tone='info'){const box=$('#obOrderResult');if(!box)return;box.textContent=text;box.classList.remove('ok','warn','error');if(tone==='ok'||tone==='warn'||tone==='error')box.classList.add(tone)}
function obDetectExecution(){
  const t=ORDER_TRADE_LAST_SUBMIT;if(!t||t.resolved||String(t.code)!==String(ORDERBOOK_CODE))return;
  const hold=obHolding(),nowQty=Number(hold?.quantity||0),row=(ORDER_TRADE_UNFILLED||[]).find(x=>String(x.order_no||'')===String(t.order_no||''));
  if(row){
    t.qtyConfirmCount=0;t.qtyCandidate=null;
    const remain=Math.max(0,Number(row.remain_qty||0)),filled=Math.max(0,Number(t.qty||0)-remain);
    if(filled>0){const px=Number(row.filled_price||hold?.avg_price||t.price||obTradeCurrentPrice()||0);if(px)ORDER_TRADE_LAST_FILL={price:px,side:t.side,label:'체결',at:Date.now()};obSetOrderResult(`일부체결 ${filled.toLocaleString('ko-KR')}/${Number(t.qty||0).toLocaleString('ko-KR')}주 · 미체결 ${remain.toLocaleString('ko-KR')}주`,'warn');renderObPositionSummary(obTradeCurrentPrice())}
    return;
  }
  const changed=t.side==='buy'?nowQty>Number(t.prevQty||0):nowQty<Number(t.prevQty||0);
  if(changed){
    if(t.qtyCandidate===nowQty)t.qtyConfirmCount=Number(t.qtyConfirmCount||0)+1;else{t.qtyCandidate=nowQty;t.qtyConfirmCount=1}
    if(t.qtyConfirmCount>=2){
      const filled=t.side==='buy'?Math.max(0,nowQty-Number(t.prevQty||0)):Math.max(0,Number(t.prevQty||0)-nowQty);
      const px=Number(t.side==='buy'?(hold?.avg_price||t.price||obTradeCurrentPrice()):(t.price||obTradeCurrentPrice())||0);
      if(px)ORDER_TRADE_LAST_FILL={price:px,side:t.side,label:'체결',at:Date.now()};
      obSetOrderResult(`${t.side==='buy'?'매수':'매도'} 체결 완료 · ${Math.max(filled,1).toLocaleString('ko-KR')}주${px?` · ${Math.round(px).toLocaleString('ko-KR')}원`:''}`,'ok');
      t.resolved=true;refreshOrderbook();renderObPositionSummary(obTradeCurrentPrice());
      if(ORDER_TRADE_FAST_TIMER){clearInterval(ORDER_TRADE_FAST_TIMER);ORDER_TRADE_FAST_TIMER=null}
    }
    return;
  }
  t.qtyConfirmCount=0;t.qtyCandidate=null;
  if(Date.now()-Number(t.at||0)>30000){obSetOrderResult(`주문 접수됨 · 체결/잔고 반영 확인 중 · 주문번호 ${t.order_no}`,'warn')}
}
function obTradeUpdate(){
  const buy=ORDER_TRADE_SIDE==='buy', market=ORDER_TRADE_TYPE==='market';
  $('#obTradeBuy')?.classList.toggle('active',buy);$('#obTradeSell')?.classList.toggle('active',!buy);
  $('#obTradeLimit')?.classList.toggle('active',!market);$('#obTradeMarket')?.classList.toggle('active',market);
  const price=$('#obTradePrice');if(price){price.disabled=market;if(market){price.value='';price.placeholder='시장가 주문'}else{price.placeholder='호가 클릭'}}
  const submit=$('#obSubmitOrder');if(submit){submit.textContent=`${buy?'매수':'매도'} 주문`;submit.classList.toggle('buy',buy);submit.classList.toggle('sell',!buy)}
  const ratios=document.querySelector('.ob-sell-ratios');if(ratios)ratios.style.display=buy?'none':'grid';
  const h=obHolding(),qty=obInt($('#obTradeQty')?.value),p=market?obTradeCurrentPrice():obInt($('#obTradePrice')?.value);
  const amount=qty>0&&p>0?qty*p:0,avail=Number(h?.available_quantity??h?.quantity??0),avg=Number(h?.avg_price||0);
  const info=$('#obTradeInfo');if(info)info.innerHTML=`<span>보유 ${h?Number(h.quantity||0).toLocaleString('ko-KR')+'주':'0주'}${h?` · 가능 ${avail.toLocaleString('ko-KR')}주`:''}${avg?` <em class="ob-trade-avg">· 평단 ${Math.round(avg).toLocaleString('ko-KR')}원</em>`:''}</span><span>${market?'시장가 참고':'예상'} ${amount?amount.toLocaleString('ko-KR')+'원':'-'}</span>`;
}
function obTradeSelectPrice(price,side=null){
  const p=obInt(price);if(!p)return;
  if(side==='buy'||side==='sell')ORDER_TRADE_SIDE=side;
  ORDER_TRADE_TYPE='limit';
  const input=$('#obTradePrice');if(input)input.value=String(p);
  obTradeUpdate();
}
function obTradeQtyFromAmount(){
  const amount=obInt($('#obTradeAmount')?.value);
  const price=ORDER_TRADE_TYPE==='market'?obTradeCurrentPrice():obInt($('#obTradePrice')?.value);
  if(amount>0&&price>0){
    const q=Math.floor(amount/price);
    if(q>0)$('#obTradeQty').value=String(q);
  }
  obTradeUpdate();
}
function startOrderTradeFastWatch(ms=10000){
  if(ORDER_TRADE_FAST_TIMER)clearInterval(ORDER_TRADE_FAST_TIMER);
  const until=Date.now()+ms;
  ORDER_TRADE_FAST_TIMER=setInterval(()=>{
    if(Date.now()>=until||!ORDERBOOK_CODE||$('#orderbookModal')?.hidden){clearInterval(ORDER_TRADE_FAST_TIMER);ORDER_TRADE_FAST_TIMER=null;return}
    refreshOrderTradeContext(false);
  },550);
}
async function refreshOrderTradeContext(force=false){
  if(!ORDERBOOK_CODE||$('#orderbookModal')?.hidden)return;
  if(ORDER_TRADE_REFRESHING&&!force)return;
  ORDER_TRADE_REFRESHING=true;
  try{
    const accountCadence=ORDER_TRADE_FAST_TIMER?1800:5000;
    const needAccount=force||!ORDER_TRADE_ACCOUNT||(Date.now()-ORDER_TRADE_ACCOUNT_AT>=accountCadence);
    const [acct,unfilled]=await Promise.all([
      needAccount?fetch('/api/account-status'+(force?'?force=1':''),{cache:'no-store'}).then(r=>r.json()):Promise.resolve(ORDER_TRADE_ACCOUNT),
      api('/api/order/unfilled',{code:ORDERBOOK_CODE})
    ]);
    if(needAccount){ORDER_TRADE_ACCOUNT=acct;ORDER_TRADE_ACCOUNT_AT=Date.now()}
    const nextUnfilled=Array.isArray(unfilled?.rows)?unfilled.rows:[];
    const nextUnfilledHash=nextUnfilled.map(r=>`${r.order_no||''}|${r.side||''}|${r.order_price||0}|${r.remain_qty||0}`).sort().join(';');
    const unfilledChanged=nextUnfilledHash!==ORDER_TRADE_UNFILLED_HASH;
    ORDER_TRADE_UNFILLED=nextUnfilled;ORDER_TRADE_UNFILLED_HASH=nextUnfilledHash;
    if(unfilledChanged)renderOrderbookWindow();
    const a=$('#obTradeAccount'),mode=$('#obTradeMode');
    if(a)a.textContent=acct?.connected?`${acct.mock?'모의':'실전'} · ${acct.account_no||'연결계좌'}`:'키움 미연결';
    if(mode){mode.textContent=acct?.mock?'모의':'실전';mode.classList.toggle('mock',!!acct?.mock);mode.classList.toggle('live',!!acct?.connected&&!acct?.mock)}
    const arm=document.querySelector('.ob-live-arm');if(arm)arm.style.display=acct?.mock?'none':'flex';
    renderObUnfilled();
    obTradeUpdate();
    renderObPositionSummary(obTradeCurrentPrice());
    obDetectExecution();
  }catch(e){
    const a=$('#obTradeAccount');if(a)a.textContent='계좌조회 오류';
    const r=$('#obOrderResult');if(r&&!ORDER_TRADE_LAST_SUBMIT)r.textContent=e.message;
  }finally{ORDER_TRADE_REFRESHING=false}
}
function renderObUnfilled(){
  const box=$('#obUnfilledOrders');if(!box)return;
  const rows=ORDER_TRADE_UNFILLED||[];
  if(!rows.length){box.innerHTML='<div class="empty">현재 종목 미체결 없음</div>';return}
  box.innerHTML=rows.map(r=>`<div class="ob-unfilled-row">
    <div><b class="${r.side==='buy'?'buy':'sell'}">${r.side==='buy'?'매수':'매도'}</b><span>${esc(r.order_no||'')}</span></div>
    <div><strong>${Number(r.order_price||0).toLocaleString('ko-KR')}원</strong><span>미체결 ${Number(r.remain_qty||0).toLocaleString('ko-KR')}주</span></div>
    <button type="button" data-ob-cancel="${esc(r.order_no||'')}">취소</button>
  </div>`).join('');
  box.querySelectorAll('[data-ob-cancel]').forEach(btn=>btn.onclick=async()=>{
    const row=rows.find(x=>String(x.order_no)===String(btn.dataset.obCancel));if(!row)return;
    if(!confirm(`${ORDERBOOK_NAME||ORDERBOOK_CODE}\n${row.side==='buy'?'매수':'매도'} 미체결 ${row.remain_qty}주\n주문번호 ${row.order_no}\n\n이 주문을 전량 취소할까요?`))return;
    btn.disabled=true;
    try{
      const res=await api('/api/order/cancel',{confirm:true,request_id:obRequestId(),order_no:row.order_no,code:row.code,qty:0,venue:row.venue||'SOR'});
      $('#obOrderResult').textContent=`취소 접수 · ${res.order_no||res.canceled_order_no}`;
      await refreshOrderTradeContext(true);
    }catch(e){$('#obOrderResult').textContent=`취소 실패 · ${e.message}`}
    finally{btn.disabled=false}
  });
}
async function syncObLiveArm(armed){
  const box=$('#obLiveArm');
  try{
    const res=await api('/api/order/arm',{armed:!!armed});
    if(box)box.checked=!!res.armed;
    if(!res.mock){
      obSetOrderResult(res.armed?'실전 주문 활성화 완료 · 서버 잠금 해제':'실전 주문 잠금 완료',res.armed?'ok':'info');
    }
    return !!res.armed;
  }catch(e){
    if(box)box.checked=false;
    obSetOrderResult(`실전 주문 활성화 실패 · ${e.message}`,'error');
    return false;
  }
}
async function submitManualOrder(){
  const acct=ORDER_TRADE_ACCOUNT;
  if(!acct?.connected){alert('키움 계좌 연결이 필요합니다.');return}
  if(!acct.mock&&!$('#obLiveArm')?.checked){alert('실전 주문 활성화를 먼저 체크하세요.');return}
  const side=ORDER_TRADE_SIDE,type=ORDER_TRADE_TYPE,qty=obInt($('#obTradeQty')?.value);
  const price=type==='limit'?obInt($('#obTradePrice')?.value):0;
  if(qty<=0){alert('주문수량을 확인하세요.');return}
  if(type==='limit'&&price<=0){alert('지정가를 선택하거나 입력하세요.');return}
  const holding=obHolding();
  if(side==='sell'&&qty>Number(holding?.available_quantity??holding?.quantity??0)){alert('매매가능 수량보다 많은 수량입니다.');return}
  const orderText=`${acct.mock?'[모의]':'[실전]'} ${ORDERBOOK_NAME||ORDERBOOK_CODE}\n${side==='buy'?'매수':'매도'} · ${type==='market'?'시장가':price.toLocaleString('ko-KR')+'원'} · ${qty.toLocaleString('ko-KR')}주`;
  const estimate=type==='limit'?`\n예상금액 ${(price*qty).toLocaleString('ko-KR')}원`:'';
  if(!confirm(`${orderText}${estimate}\n\n주문을 전송할까요?`))return;
  const btn=$('#obSubmitOrder');if(btn)btn.disabled=true;
  obSetOrderResult(`${type==='market'?'시장가':'지정가'} ${side==='buy'?'매수':'매도'} 전송 중…`,'warn');
  try{
    if(!acct.mock){
      const armed=await syncObLiveArm(true);
      if(!armed)throw new Error('실전 주문 활성화가 서버에 적용되지 않았습니다.');
    }
    const res=await api('/api/order/place',{confirm:true,request_id:obRequestId(),side,code:ORDERBOOK_CODE,qty,price:type==='limit'?price:null,order_type:type,venue:acct.mock?'KRX':'SOR'});
    ORDER_TRADE_LAST_SUBMIT={order_no:res.order_no||'',side,code:ORDERBOOK_CODE,qty,price:type==='limit'?price:obTradeCurrentPrice(),prevQty:Number(holding?.quantity||0),prevAvail:Number(holding?.available_quantity??holding?.quantity??0),at:Date.now(),resolved:false,qtyConfirmCount:0,qtyCandidate:null};
    obSetOrderResult(`주문 접수 · ${type==='market'?'시장가 ':''}${side==='buy'?'매수':'매도'} ${qty.toLocaleString('ko-KR')}주 · 체결 확인 중`,'warn');
    startOrderTradeFastWatch(12000);
    await refreshOrderTradeContext(true);
  }catch(e){obSetOrderResult(`주문 실패 · ${e.message}`,'error')}
  finally{if(btn)btn.disabled=false}
}
function bindOrderTradePanel(){
  const liveArm=$('#obLiveArm');
  if(liveArm)liveArm.onchange=async()=>{liveArm.disabled=true;try{await syncObLiveArm(liveArm.checked)}finally{liveArm.disabled=false}};
  $('#obTradeBuy').onclick=()=>{ORDER_TRADE_SIDE='buy';obTradeUpdate()};
  $('#obTradeSell').onclick=()=>{ORDER_TRADE_SIDE='sell';obTradeUpdate()};
  $('#obTradeLimit').onclick=()=>{ORDER_TRADE_TYPE='limit';obTradeUpdate()};
  $('#obTradeMarket').onclick=()=>{ORDER_TRADE_TYPE='market';obTradeUpdate()};
  $('#obQtyMinus').onclick=()=>{const e=$('#obTradeQty');e.value=String(Math.max(1,obInt(e.value)-1));obTradeUpdate()};
  $('#obQtyPlus').onclick=()=>{const e=$('#obTradeQty');e.value=String(Math.max(1,obInt(e.value)+1));obTradeUpdate()};
  $('#obTradeQty').oninput=()=>obTradeUpdate();
  $('#obTradePrice').oninput=()=>obTradeUpdate();
  $('#obTradeAmount').oninput=()=>obTradeQtyFromAmount();
  document.querySelectorAll('[data-ob-sell-ratio]').forEach(b=>b.onclick=()=>{
    const h=obHolding(),available=Number(h?.available_quantity??h?.quantity??0),ratio=Number(b.dataset.obSellRatio||0);
    if(available<=0)return;
    const q=ratio>=100?Math.floor(available):Math.max(1,Math.floor(available*ratio/100));
    $('#obTradeQty').value=String(q);obTradeUpdate();
  });
  $('#obSubmitOrder').onclick=submitManualOrder;
  $('#obCancelAll').onclick=async()=>{
    const rows=ORDER_TRADE_UNFILLED||[];if(!rows.length)return;
    if(!confirm(`${ORDERBOOK_NAME||ORDERBOOK_CODE}\n미체결 ${rows.length}건을 모두 취소할까요?`))return;
    try{
      const res=await api('/api/order/cancel-all',{confirm:true,request_id:obRequestId(),code:ORDERBOOK_CODE});
      $('#obOrderResult').textContent=`전체취소 · ${res.canceled}건${res.errors?.length?' · 실패 '+res.errors.length+'건':''}`;
      await refreshOrderTradeContext(true);
    }catch(e){$('#obOrderResult').textContent=`전체취소 실패 · ${e.message}`}
  };
  const modal=$('#orderbookModal');
  if(modal&&!modal.dataset.obPriceClickBound){modal.dataset.obPriceClickBound='1';modal.addEventListener('click',e=>{const row=e.target.closest?.('[data-ob-price]');if(!row||e.target.closest?.('button,input'))return;if(ORDERBOOK_DRAG_MOVED){ORDERBOOK_DRAG_MOVED=false;return}obTradeSelectPrice(row.dataset.obPrice,row.classList.contains('ask')?'sell':'buy')})}
}

function openOrderbook(code,name){const m=ensureOrderbookModal();m.style.zIndex='220000';ORDERBOOK_CODE=String(code||'');ORDERBOOK_NAME=String(name||'');ORDERBOOK_LAST_BEST_KEY='';ORDERBOOK_LAST_CURRENT=0;ORDERBOOK_LIVE_SEQ=0;ORDERBOOK_LAST_BOOK_HASH='';ORDERBOOK_LAST_TAPE_HASH='';ORDERBOOK_PREV_QTY={};ORDER_TRADE_SIDE='buy';ORDER_TRADE_TYPE='limit';ORDER_TRADE_ACCOUNT=null;ORDER_TRADE_ACCOUNT_AT=0;ORDER_TRADE_UNFILLED=[];ORDER_TRADE_UNFILLED_HASH='';ORDERBOOK_VIEW_OFFSET=0;ORDERBOOK_LAST_ASKS=[];ORDERBOOK_LAST_BIDS=[];ORDER_TRADE_LAST_FILL=null;ORDER_TRADE_LAST_SUBMIT=null;ensureOrderbookMotionStyle();m.hidden=false;$('#orderbookTitle').textContent=ORDERBOOK_NAME||ORDERBOOK_CODE;$('#orderbookCode').textContent=ORDERBOOK_CODE;$('#orderbookMeta').textContent='키움 통합(SOR) 실시간 연결 중...';$('#orderbookHeadline').innerHTML='';$('#orderbookPositionSummary').innerHTML='<div class="ob-pos-empty">보유 없음</div>';$('#orderbookSideStats').innerHTML='';$('#orderbookSummary').innerHTML='';$('#obRecentTrades').innerHTML='<div class="empty">체결 수신 대기</div>';$('#obFeedBadge').textContent='CONNECT';$('#orderbookCurrent').innerHTML='<span>현재가</span><strong>-</strong>';$('#orderbookAsks').innerHTML='<div class="empty">호가 수신 대기</div>';$('#orderbookBids').innerHTML='<div class="empty">호가 수신 대기</div>';$('#obTradeQty').value='1';$('#obTradePrice').value='';$('#obTradeAmount').value='';$('#obLiveArm').checked=false;$('#obOrderResult').textContent='주문 전송 전 최종 확인창이 표시됩니다.';bindOrderTradePanel();obTradeUpdate();
const cachedOb=ORDERBOOK_PREFETCH_CACHE.get(String(ORDERBOOK_CODE||'').replace(/\D/g,''));
if(cachedOb&&Date.now()-cachedOb.ts<ORDERBOOK_PREFETCH_TTL&&cachedOb.data){
  try{
    applyOrderbookData(cachedOb.data);
    $('#orderbookMeta').textContent='미리 불러온 호가 표시 · 최신 실시간 연결 중...';
  }catch(_){}
}
const token=++ORDERBOOK_LIVE_TOKEN;
orderbookLiveLoop(token);
refreshOrderbook();
setTimeout(()=>{if(token===ORDERBOOK_LIVE_TOKEN&&!$('#orderbookModal')?.hidden)refreshOrderTradeContext(true)},300);
if(ORDER_TRADE_TIMER)clearInterval(ORDER_TRADE_TIMER);
ORDER_TRADE_TIMER=setInterval(()=>refreshOrderTradeContext(false),2000)}
function prefetchStockActionData(code){
  const c=String(code||'').replace(/\D/g,'');if(!c)return;
  const old=STOCK_ACTION_PREFETCH.get(c);
  if(!old||Date.now()-old.ts>=20000){
    STOCK_ACTION_PREFETCH.set(c,{ts:Date.now()});
    fetch(`/api/investor-flow?code=${encodeURIComponent(c)}`,{cache:'no-store'}).catch(()=>{});
  }

  const cached=ORDERBOOK_PREFETCH_CACHE.get(c);
  if(cached&&Date.now()-cached.ts<ORDERBOOK_PREFETCH_TTL)return;
  if(ORDERBOOK_PREFETCH_INFLIGHT.has(c))return;

  const req=fetch(`/api/orderbook?code=${encodeURIComponent(c)}`,{cache:'no-store'})
    .then(async r=>{
      const d=await r.json();
      if(!r.ok)throw Error(d.error||'호가 조회 실패');
      ORDERBOOK_PREFETCH_CACHE.set(c,{ts:Date.now(),data:d});
      return d;
    })
    .catch(()=>null)
    .finally(()=>ORDERBOOK_PREFETCH_INFLIGHT.delete(c));
  ORDERBOOK_PREFETCH_INFLIGHT.set(c,req);
}
function ensureStockActionModal(){let m=$('#stockActionModal');if(m)return m;m=document.createElement('div');m.id='stockActionModal';m.className='stock-action-modal';m.innerHTML=`<div class="stock-action-backdrop" data-stock-action-close></div><div class="stock-action-dialog"><button class="stock-action-x" data-stock-action-close type="button">✕</button><div class="eyebrow">STOCK ACTION</div><h2 id="stockActionTitle">종목 보기</h2><div id="stockActionMeta" class="muted"></div><div id="stockActionTags" class="stock-action-tags"></div><div class="stock-action-buttons"><button id="stockActionChart" type="button"><b>📈 차트 보기</b><span>기존 일봉·15분봉 차트</span></button><button id="stockActionFlow" type="button"><b>⇄ 수급 보기</b><span>개인·외국인·기관 및 기관 상세</span></button><button id="stockActionOrderbook" type="button"><b>▦ 호가 보기</b><span>실시간 10호가 · 잔량 · 체결</span></button><button id="stockActionChecklist" type="button"><b>✓ 종배 체크리스트</b><span>LITTO 종배 원칙 자동·수동 확인</span></button><button id="stockActionMemo" type="button"><b>📝 메모</b><span>종목별 메모 작성 · 삭제 전까지 영구 저장</span></button></div></div>`;document.body.appendChild(m);m.querySelectorAll('[data-stock-action-close]').forEach(x=>x.onclick=()=>m.hidden=true);m.hidden=true;return m}
function openStockAction(code,name){const m=ensureStockActionModal();m.style.zIndex='220000';m.hidden=false;$('#stockActionTitle').textContent=name||code;$('#stockActionMeta').textContent=code;const tags=lookupTags(code);const te=$('#stockActionTags');if(te)te.innerHTML=tags.length?tags.map(x=>`<span class="stock-action-tag">${esc(x)}</span>`).join(''):'<span class="stock-action-tag muted-tag">현재 검색기 분류 없음</span>';$('#stockActionChart').onclick=()=>{m.hidden=true;openChart(code)};$('#stockActionFlow').onclick=()=>{m.hidden=true;openInvestorFlow(code,name)};$('#stockActionOrderbook').onclick=()=>{m.hidden=true;openOrderbook(code,name)};$('#stockActionChecklist').onclick=()=>{m.hidden=true;openWatchChecklist(code,name)};$('#stockActionMemo').onclick=()=>{m.hidden=true;openWatchMemo(code,name)};}
function bindStockActionClicks(){document.querySelectorAll('[data-stock-action-code]').forEach(el=>{el.onmouseenter=null;el.onclick=e=>{if(e.target.closest('button,a,input,select,textarea'))return;e.preventDefault();openStockAction(el.dataset.stockActionCode,el.dataset.stockActionName)}})}
function ensureSectorPopularityModal(){let m=$('#sectorPopularityModal');if(m)return m;m=document.createElement('div');m.id='sectorPopularityModal';m.className='sector-pop-modal';m.innerHTML=`<div class="sector-pop-backdrop" data-sector-pop-close></div><div class="sector-pop-dialog"><div class="sector-pop-head"><div><div class="eyebrow">SECTOR POPULARITY</div><h2 id="sectorPopTitle">섹터 인기순위</h2><div id="sectorPopMeta" class="muted">키움 실시간 조회순위 기준</div></div><button class="sector-pop-close" data-sector-pop-close type="button">✕</button></div><div id="sectorPopRows" class="sector-pop-rows"><div class="empty">불러오는 중...</div></div></div>`;document.body.appendChild(m);if(!$('#sectorPopStyle')){const st=document.createElement('style');st.id='sectorPopStyle';st.textContent=`.sector-pop-modal{position:fixed;inset:0;z-index:3000;display:flex;align-items:center;justify-content:center;padding:28px}.sector-pop-modal[hidden]{display:none}.sector-pop-backdrop{position:absolute;inset:0;background:rgba(1,4,9,.72);backdrop-filter:blur(3px)}.sector-pop-dialog{position:relative;width:min(1120px,96vw);max-height:82vh;display:flex;flex-direction:column;background:#07111d;border:1px solid #274158;border-radius:18px;box-shadow:0 24px 70px rgba(0,0,0,.55);overflow:hidden}.sector-pop-head{display:flex;justify-content:space-between;gap:18px;align-items:center;padding:20px 22px;border-bottom:1px solid #1b3042}.sector-pop-head h2{margin:4px 0 3px}.sector-pop-close{border:1px solid #2c465e;background:#0d1b29;color:#dce8f4;border-radius:10px;width:38px;height:38px;font-size:18px}.sector-pop-rows{overflow:auto;padding:10px 14px 16px}.sector-pop-row{display:grid;grid-template-columns:42px minmax(190px,1.25fr) minmax(110px,.65fr) minmax(110px,.65fr) minmax(90px,.5fr) minmax(330px,1.8fr);column-gap:16px;align-items:center;min-height:58px;padding:8px 10px;border-bottom:1px solid #15283a}.sector-pop-row:hover{background:#0c1a28}.sector-pop-rank{font-weight:800;font-variant-numeric:tabular-nums;color:#e6edf3}.sector-pop-stock{min-width:0}.sector-pop-stock b{display:block;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.sector-pop-stock small{color:#6f859a}.sector-pop-pill{display:inline-flex;align-items:center;justify-content:center;min-height:25px;padding:2px 8px;border:1px solid #285071;border-radius:999px;background:#0b2233;color:#8fd7ff;font-size:12px;font-weight:700;font-variant-numeric:tabular-nums}.sector-pop-pill.daily{border-color:#52441f;background:#211b08;color:#e6c653}.sector-pop-pill.none{border-color:#26384a;background:#101923;color:#6f859a}.sector-pop-change{text-align:center;font-variant-numeric:tabular-nums}.sector-pop-row>div:nth-child(3),.sector-pop-row>div:nth-child(4){display:flex;justify-content:center}.sector-pop-tags{display:flex;gap:6px;justify-content:flex-start;align-items:center;flex-wrap:wrap;min-width:0}.sector-pop-row.is-clickable{cursor:pointer}@media(max-width:980px){.sector-pop-dialog{width:min(940px,97vw)}.sector-pop-row{grid-template-columns:38px minmax(170px,1.1fr) 104px 104px 82px minmax(220px,1.5fr);column-gap:10px}.sector-pop-tags{gap:4px}}@media(max-width:720px){.sector-pop-row{grid-template-columns:38px minmax(140px,1fr) 88px 86px}.sector-pop-row .daily-col,.sector-pop-row .sector-pop-tags{display:none}.sector-pop-dialog{max-height:88vh}.sector-pop-modal{padding:10px}}`;document.head.appendChild(st)}m.querySelectorAll('[data-sector-pop-close]').forEach(x=>x.onclick=()=>m.hidden=true);m.hidden=true;return m}
function sectorPopularityRowHtml(x,i){const live=x.live_rank!=null?`<span class="sector-pop-pill">실시간 ${x.live_rank}위</span>`:'<span class="sector-pop-pill none">실시간 -</span>';const daily=x.daily_rank!=null?`<span class="sector-pop-pill daily">누적 ${x.daily_rank}위</span>`:'<span class="sector-pop-pill none">누적 -</span>';const tags=lookupTags(x.code).map(t=>`<span class="rank-tag hit">${esc(t)}</span>`).join('');return `<div class="sector-pop-row is-clickable" data-stock-action-code="${esc(x.code)}" data-stock-action-name="${esc(x.name||x.code)}" title="클릭하면 차트 · 수급 · 호가 · 메모를 선택합니다"><div class="sector-pop-rank">${i+1}</div><div class="sector-pop-stock"><div class="stock-title-line"><b>${esc(x.name||x.code)}</b>${newsButtonHtml(x.code,x.name||x.code)}${disclosureButtonHtml(x.code,x.name||x.code)}</div><small>${esc(x.code)}</small></div><div>${live}</div><div class="daily-col">${daily}</div><div class="sector-pop-change ${cls(x.change)}">${x.change==null?'—':pct(x.change)}</div><div class="sector-pop-tags">${tags||'<span class="rank-tag">-</span>'}</div></div>`}
async function openSectorPopularity(sector){if(!sector)return;const m=ensureSectorPopularityModal();m.hidden=false;$('#sectorPopTitle').textContent=`${sector} · 인기순위`;$('#sectorPopMeta').textContent='키움 실시간 조회순위 → 당일 누적 조회순위';$('#sectorPopRows').innerHTML='<div class="empty">섹터 종목을 불러오는 중...</div>';try{const r=await fetch('/api/sector-popularity?sector='+encodeURIComponent(sector));const d=await r.json();if(!r.ok)throw Error(d.error||'섹터 인기순위 조회 실패');$('#sectorPopMeta').textContent=`${d.source||''} · ${d.ranked_count||0}/${d.count||0}종목 순위 포착${d.updated_at?' · '+new Date(d.updated_at).toLocaleTimeString():''}${d.error?' · '+d.error:''}`;$('#sectorPopRows').innerHTML=(d.rows||[]).map(sectorPopularityRowHtml).join('')||'<div class="empty">이 섹터에 분류된 종목이 없습니다.</div>';bindStockActionClicks()}catch(e){$('#sectorPopRows').innerHTML=`<div class="empty">${esc(e.message)}</div>`}}
function bindSectorPopularity(){document.querySelectorAll('[data-sector-pop]').forEach(x=>{x.onclick=e=>{e.stopPropagation();openSectorPopularity(x.dataset.sectorPop)}});const card=$('#metricSector')?.closest('.metric-card');if(card){card.style.cursor='pointer';card.title='클릭하면 아래 강한 섹터 결과로 이동합니다';card.onclick=null}}
function renderPanel(){const root=STATE?.report?.search_panels;if(!root){$('#panelRows').innerHTML='<div class="muted">검색 결과 없음</div>';return}const p=root.panels?.[activePanel]||{rows:[]};$('#panelNotice').textContent=root.notice||'';$('#rankSource').textContent=root.rank_source||'';$('#panelMeta').innerHTML=`<b>${esc(activePanel)}</b> · ${esc(p.kind||'')}<br>${esc(p.rule||'')}`;const rows=p.rows||[];$('#panelRows').innerHTML=rows.map((x,i)=>{const isSector=String(x.code||'').startsWith('SECTOR:');const levels=x.levels||{},liveq=isSector?null:liveCardQuote(x);const lv=Object.keys(levels).length?`<div class="levels">${Object.entries(levels).filter(([k])=>!['peak_date','members'].includes(k)).map(([k,v])=>`${esc(k)} ${typeof v==='number'?money(v):esc(v)}`).join(' · ')}${Array.isArray(levels.members)?`<br>구성: ${levels.members.map(m=>`${esc(m.name)}(${m.value_rank||'-'}위)`).join(' · ')}`:''}</div>`:'';const attrs=isSector?` data-sector-pop="${esc(x.name)}" title="클릭하면 ${esc(x.name)} 섹터 인기순위를 봅니다"`:` data-stock-action-code="${esc(x.code)}" data-stock-action-name="${esc(x.name)}" title="클릭하면 차트 · 수급 · 호가 · 메모를 선택합니다"`;const edit=isSector?'':` <button class="sector-edit" data-sector-code="${esc(x.code)}" data-sector-current="${esc(x.sector)}">섹터 수정</button>`;const watch=isSector?'':watchStarHtml(x);const lookup=isSector?'':inlineLookupRankHtml(x.code);const news=isSector?'':newsButtonHtml(x.code,x.name);const disclosure=isSector?'':disclosureButtonHtml(x.code,x.name);const memoIcon=isSector?'':stockMemoIconHtml(x.code,x.name);return `<div class="prow"${attrs}><div class="prowhead"><div class="stock-title-line"><span class="rank">${i+1}</span><b class="${isSector?'sector-pop-link':'chartlink'} stock-name">${esc(x.name)}</b>${isSector?'':`<span class="float-change-next ${cls(liveq?.change)}">${pct(liveq?.change)}</span>${memoIcon}${watch}${news}${disclosure}${lookup}`}</div><span class="status">${esc(x.status==='조건충족'&&Array.isArray(x.reasons)&&x.reasons.length?`조건 ${x.reasons.length}개 충족`:x.status)}</span></div><div class="stats"><span>거래대금 ${money(x.value_eok)}억</span><span>대금순위 ${x.value_rank||'-'}</span>${isSector?'':`<span>등락순위 ${x.change_rank||'-'}</span>`}<span class="sectorcell">${esc(x.sector)}${edit}</span></div><div class="reasons">${(x.reasons||[]).map(v=>`<span>✓ ${esc(v)}</span>`).join('')}</div>${(x.checks||[]).length?`<div class="checks">직접 확인: ${(x.checks||[]).map(esc).join(' · ')}</div>`:''}${lv}</div>`}).join('')||'<div class="empty">조건을 통과한 종목이 없습니다.</div>';bindChartClicks();bindStockActionClicks();bindSectorEdits();bindNewsButtons();bindSectorPopularity();bindInvestorFlowClicks();bindWatchStars();bindWatchMemoButtons();}
function hideFullAnalysisResult(){
  for(const h of document.querySelectorAll('h1,h2,h3')){
    if((h.textContent||'').trim()==='전체 분석 결과'){
      const sec=h.closest('section,.card');
      if(sec){sec.classList.add('litto-hidden-full-analysis');sec.setAttribute('aria-hidden','true')}
    }
  }
}
function renderMain(){const report=STATE?.report||{},q=$('#q').value.trim().toLowerCase(),sec=$('#sector').value;let results=report.results||[];const sectors=[...new Set(results.flatMap(x=>sectorTags(x.sector)))].sort();const old=$('#sector').value;$('#sector').innerHTML='<option value="">전체 섹터</option>'+sectors.map(v=>`<option>${esc(v)}</option>`).join('');$('#sector').value=sectors.includes(old)?old:'';results=results.filter(x=>(!sec||sectorTags(x.sector).includes(sec))&&(!q||[x.code,x.name,x.sector].some(v=>String(v||'').toLowerCase().includes(q))));$('#rows').innerHTML=results.flatMap(x=>(x.patterns||[]).map(p=>`<tr class="stockrow" data-stock-action-code="${esc(x.code)}" data-stock-action-name="${esc(x.name)}" title="클릭하면 차트 · 수급 · 호가 · 메모를 선택합니다"><td><div class="stock-title-line"><b class="chartlink stock-name">${esc(x.name)}</b>${stockMemoIconHtml(x.code,x.name)}${newsButtonHtml(x.code,x.name)}${disclosureButtonHtml(x.code,x.name)}</div></td><td><span>${esc(x.sector)}</span> <button class="sector-edit" data-sector-code="${esc(x.code)}" data-sector-current="${esc(x.sector)}">수정</button></td><td>${money(liveCardQuote(x).price)}</td><td class="${cls(liveCardQuote(x).change)}">${pct(liveCardQuote(x).change)}</td><td>${money(x.value_eok)}</td><td>${esc(p.name)}</td><td>${esc(p.status)}</td></tr>`)).join('')||'<tr><td colspan="7">결과 없음</td></tr>';bindChartClicks();bindStockActionClicks();bindSectorEdits();bindWatchMemoButtons();hideFullAnalysisResult();}
function bindChartClicks(){$$('[data-chart-code]').forEach(el=>{el.onclick=e=>{if(e.target.closest('button,a,input,select,textarea'))return;const code=el.dataset.chartCode;const name=el.dataset.chartName||el.querySelector('.stock-name,.ma-name,b')?.textContent?.trim()||findStock(code)?.name||code;openStockAction(code,name)}})}
function bindSectorEdits(){$$('[data-sector-code]').forEach(b=>{b.onclick=e=>{e.stopPropagation();editSector(b.dataset.sectorCode,b.dataset.sectorCurrent)}})}

function loadChartLevels(){try{const x=JSON.parse(localStorage.getItem(CHART_LEVELS_KEY)||'{}');return x&&typeof x==='object'?x:{}}catch(e){return {}}}
function saveChartLevels(all){try{localStorage.setItem(CHART_LEVELS_KEY,JSON.stringify(all||{}))}catch(e){}}
function chartLevelGroup(tf=chartTf){return tf==='daily'?'daily':'minute'}
function chartLevels(code,tf=chartTf){
  const all=loadChartLevels(),key=String(code||''),entry=all[key],group=chartLevelGroup(tf);
  // Legacy v1 storage was a single array shared by every timeframe.
  // Keep those existing lines on the daily chart only so minute charts
  // immediately recover their normal price scale instead of inheriting them.
  const raw=Array.isArray(entry)?(group==='daily'?entry:[]):(entry&&typeof entry==='object'?(entry[group]||[]):[]);
  return Array.isArray(raw)?raw.map(Number).filter(Number.isFinite).sort((a,b)=>a-b):[]
}
function setChartLevels(code,levels,tf=chartTf){
  const all=loadChartLevels(),key=String(code||''),group=chartLevelGroup(tf),prev=all[key];
  const entry=Array.isArray(prev)?{daily:prev,minute:[]}:(prev&&typeof prev==='object'?{daily:[...(prev.daily||[])],minute:[...(prev.minute||[])]}:{daily:[],minute:[]});
  const arr=[...new Set((levels||[]).map(Number).filter(Number.isFinite))].sort((a,b)=>a-b);
  entry[group]=arr;
  if(entry.daily.length||entry.minute.length)all[key]=entry;else delete all[key];
  saveChartLevels(all);
  try{window.dispatchEvent(new CustomEvent('litto-chart-levels-changed',{detail:{code:key,group}}))}catch(_e){}
}
function snapChartPrice(v){v=Number(v);if(!Number.isFinite(v))return v;let tick=1;if(v>=500000)tick=1000;else if(v>=200000)tick=500;else if(v>=50000)tick=100;else if(v>=20000)tick=50;else if(v>=5000)tick=10;else if(v>=2000)tick=5;return Math.round(v/tick)*tick}
function setChartLineMode(mode){CHART_LINE_MODE=CHART_LINE_MODE===mode?null:mode;CHART_HOVER_PRICE=null;const c=$('#stockChart');if(c)c.classList.toggle('support-line-mode',!!CHART_LINE_MODE);const add=$('#chartAddLevel'),del=$('#chartDeleteLevel');if(add)add.classList.toggle('active',CHART_LINE_MODE==='add');if(del)del.classList.toggle('active',CHART_LINE_MODE==='delete');if(c)c.title=CHART_LINE_MODE==='add'?'마우스를 위아래로 움직여 흰색 가이드선을 맞춘 뒤 클릭하면 저장됩니다.':CHART_LINE_MODE==='delete'?'삭제할 수평선 가까이를 클릭하세요.':'';if(chartStock)drawChart()}
function ensureChartLineControls(){const box=$('#chartModal .chartactions');if(!box)return;if(!$('#chartAddLevel')){const b=document.createElement('button');b.id='chartAddLevel';b.type='button';b.className='ghost';b.textContent='＋ 수평선';b.title='지지/저항용 흰색 수평선을 추가합니다.';b.onclick=()=>setChartLineMode('add');box.insertBefore(b,$('#chartClose'))}if(!$('#chartDeleteLevel')){const b=document.createElement('button');b.id='chartDeleteLevel';b.type='button';b.className='ghost';b.textContent='선 삭제';b.title='삭제할 흰색 수평선 가까이를 클릭합니다.';b.onclick=()=>setChartLineMode('delete');box.insertBefore(b,$('#chartClose'))}if(!$('#chartMarketMarkersToggle')){const b=document.createElement('button');b.id='chartMarketMarkersToggle';b.type='button';b.className='ghost';b.title='15:00·15:30 세로선, 오늘 20:00 장마감 빨간선과 15:30 공식 종가 노란선을 표시/숨깁니다.';b.onclick=()=>setChartMarkersEnabled(!CHART_MARKERS_ENABLED);box.insertBefore(b,$('#chartClose'))}syncChartMarkerButtons()}
function ensureChartHoverTooltip(){let tip=$('#chartHoverTooltip');if(tip)return tip;const wrap=$('#stockChart')?.parentElement;if(!wrap)return null;tip=document.createElement('div');tip.id='chartHoverTooltip';tip.className='chart-hover-tooltip';tip.hidden=true;wrap.appendChild(tip);return tip}
function hideChartHoverTooltip(){const tip=$('#chartHoverTooltip');if(tip)tip.hidden=true}
function installChartLineCanvas(){const c=$('#stockChart');if(!c||c.dataset.supportLineBound==='1')return;c.dataset.supportLineBound='1';ensureChartHoverTooltip();c.style.cursor='grab';c.addEventListener('wheel',e=>{if(!chartStock)return;e.preventDefault();const all=(chartTf==='daily'?chartStock.daily:chartTf==='m1'?chartStock.m1:chartTf==='m3'?chartStock.m3:chartStock.m15)||[];if(!all.length)return;const minBars=chartTf==='daily'?20:24;const def=chartTf==='daily'?90:120;const current=Math.max(minBars,Math.min(all.length,Number(CHART_ZOOM_BARS[chartTf]||def)));const next=e.deltaY<0?Math.max(minBars,Math.floor(current*.84)):Math.min(all.length,Math.ceil(current*1.18));if(next!==current){CHART_ZOOM_BARS[chartTf]=next;CHART_PAN_OFFSET[chartTf]=Math.min(Number(CHART_PAN_OFFSET[chartTf]||0),Math.max(0,all.length-next));drawChart()}},{passive:false});
  let dragLastX=0,dragCarryX=0,dragTf=null;
  const finishDrag=()=>{if(!CHART_DRAG_ACTIVE)return;const moved=CHART_DRAG_MOVED;CHART_DRAG_ACTIVE=false;dragCarryX=0;c.style.cursor=CHART_LINE_MODE?'crosshair':'grab';if(moved){CHART_DRAG_SUPPRESS_CLICK=true;setTimeout(()=>{CHART_DRAG_SUPPRESS_CLICK=false},0)}setTimeout(()=>{CHART_DRAG_MOVED=false},0)};
  c.addEventListener('mousedown',e=>{if(e.button!==0||!chartStock||CHART_LINE_MODE)return;const g=CHART_GEOM;if(!g)return;const r=c.getBoundingClientRect(),cx=e.clientX-r.left,cy=e.clientY-r.top;if(cx<g.padLeft||cx>g.w-g.padRight||cy<g.padTop||cy>g.h-18)return;CHART_DRAG_ACTIVE=true;CHART_DRAG_MOVED=false;dragLastX=e.clientX;dragCarryX=0;dragTf=chartTf;c.style.cursor='grabbing';hideChartHoverTooltip();e.preventDefault()});
  window.addEventListener('mousemove',e=>{if(!CHART_DRAG_ACTIVE||dragTf!==chartTf||!chartStock)return;const g=CHART_GEOM;if(!g)return;const dx=e.clientX-dragLastX;dragLastX=e.clientX;dragCarryX+=dx;if(!CHART_DRAG_MOVED&&Math.abs(dragCarryX)<5)return;CHART_DRAG_MOVED=true;const all=(chartTf==='daily'?chartStock.daily:chartTf==='m1'?chartStock.m1:chartTf==='m3'?chartStock.m3:chartStock.m15)||[];const def=chartTf==='daily'?90:120;const limit=Math.max(1,Math.min(all.length||def,Number(CHART_ZOOM_BARS[chartTf]||def)));const maxOffset=Math.max(0,all.length-limit);if(maxOffset<=0)return;const pxPerBar=Math.max(3,Number(g.xStep||6));const steps=dragCarryX>0?Math.floor(dragCarryX/pxPerBar):Math.ceil(dragCarryX/pxPerBar);if(!steps)return;dragCarryX-=steps*pxPerBar;const cur=Number(CHART_PAN_OFFSET[chartTf]||0);const next=Math.max(0,Math.min(maxOffset,cur+steps));if(next===cur)return;CHART_PAN_OFFSET[chartTf]=next;if(!CHART_DRAG_RAF)CHART_DRAG_RAF=requestAnimationFrame(()=>{CHART_DRAG_RAF=0;if(chartStock)drawChart()})});
  window.addEventListener('mouseup',finishDrag);
  window.addEventListener('blur',finishDrag);
  const hoverPrice=e=>{const g=CHART_GEOM;if(!chartStock||!g)return;if(CHART_DRAG_ACTIVE){hideChartHoverTooltip();return}const r=c.getBoundingClientRect(),scaleX=g.w/Math.max(1,r.width),scaleY=g.h/Math.max(1,r.height),cx=(e.clientX-r.left)*scaleX,cy=(e.clientY-r.top)*scaleY;
  if(CHART_LINE_MODE==='add'){hideChartHoverTooltip();if(cy<g.padTop||cy>g.padTop+g.priceH){if(CHART_HOVER_PRICE!==null){CHART_HOVER_PRICE=null;drawChart()}return}const price=snapChartPrice(g.maxP-((cy-g.padTop)/g.priceH)*g.range);if(price!==CHART_HOVER_PRICE){CHART_HOVER_PRICE=price;drawChart()}return}
  if(CHART_LINE_MODE||chartTf!=='daily'||!Array.isArray(g.bars)||!g.bars.length){hideChartHoverTooltip();return}
  if(cx<g.padLeft||cx>g.w-g.padRight||cy<g.padTop||cy>g.padTop+g.priceH){hideChartHoverTooltip();return}
  const idx=Math.max(0,Math.min(g.bars.length-1,Math.round((cx-g.padLeft)/g.xStep-.5)));const b=g.bars[idx],allIdx=g.startIndex+idx,prev=allIdx>0?g.all[allIdx-1]:null;const close=Number(b.close),prevClose=Number(prev?.close),chg=Number.isFinite(prevClose)&&prevClose!==0?(close/prevClose-1)*100:null;const clsName=chg==null?'':chg>0?'up':chg<0?'down':'flat';const tip=ensureChartHoverTooltip();if(!tip)return;tip.innerHTML=`<div class="chart-hover-date">${esc(String(b.date||fmtTime(b,'daily')))}</div><div class="chart-hover-grid"><span>시가</span><b>${money(b.open)}</b><span>고가</span><b>${money(b.high)}</b><span>저가</span><b>${money(b.low)}</b><span>종가</span><b>${money(b.close)}</b><span>등락률</span><b class="${clsName}">${chg==null?'-':pct(chg)}</b><span>거래량</span><b>${money(b.volume)}</b></div>`;tip.hidden=false;const tw=tip.offsetWidth||190,th=tip.offsetHeight||150;const vx=cx/scaleX,vy=cy/scaleY;let left=vx+16,top=vy+14;if(left+tw>r.width-8)left=vx-tw-16;if(top+th>r.height-8)top=Math.max(8,vy-th-14);tip.style.left=Math.max(8,left)+'px';tip.style.top=Math.max(8,top)+'px'};c.addEventListener('mousemove',hoverPrice);c.addEventListener('mouseleave',()=>{hideChartHoverTooltip();if(CHART_LINE_MODE==='add'&&CHART_HOVER_PRICE!==null){CHART_HOVER_PRICE=null;drawChart()}});c.addEventListener('click',e=>{if(CHART_DRAG_SUPPRESS_CLICK)return;if(!chartStock||!CHART_GEOM)return;const r=c.getBoundingClientRect(),g=CHART_GEOM,scaleY=g.h/Math.max(1,r.height),cy=(e.clientY-r.top)*scaleY;if(cy<g.padTop||cy>g.padTop+g.priceH)return;let price=snapChartPrice(g.maxP-((cy-g.padTop)/g.priceH)*g.range);let levels=chartLevels(chartStock.code);if(CHART_LINE_MODE==='add'){if(!levels.some(v=>Math.abs(v-price)<1e-9)){levels.push(price);setChartLevels(chartStock.code,levels)}CHART_HOVER_PRICE=null;setChartLineMode(null);drawChart();return}if(CHART_LINE_MODE==='delete'){if(!levels.length){setChartLineMode(null);return}let nearest=levels.reduce((a,b)=>Math.abs(b-price)<Math.abs(a-price)?b:a,levels[0]);const px=Math.abs(nearest-price)/g.range*g.priceH;if(px<=24){levels=levels.filter(v=>v!==nearest);setChartLevels(chartStock.code,levels);drawChart()}setChartLineMode(null);return}if(!levels.length)return;const nearest=levels.reduce((a,b)=>Math.abs(b-price)<Math.abs(a-price)?b:a,levels[0]);const px=Math.abs(nearest-price)/g.range*g.priceH;if(px>16)return;const raw=prompt('수평선 가격을 지정하세요.',Math.round(nearest).toLocaleString('ko-KR'));if(raw==null)return;const next=Number(String(raw).replace(/[^0-9.\-]/g,''));if(!Number.isFinite(next)||next<=0){alert('올바른 가격을 입력하세요.');return}levels=levels.filter(v=>v!==nearest);levels.push(snapChartPrice(next));setChartLevels(chartStock.code,levels);drawChart()})}

async function ensureDirectStockSnapshot(code,force=false){
  const c=String(code||'').trim();if(!c)return null;
  const existing=findStock(c)||WATCH_MANUAL_LIVE[c];
  if(existing&&!force)return existing;
  try{
    const r=await fetch('/api/watch-manual-live?codes='+encodeURIComponent(c)+(force?'&force=1':''));
    let d={};try{d=await r.json()}catch(_){d={}}
    if(!r.ok)throw Error(d.error||'종목 데이터 조회 실패');
    const row=(d.rows||[]).find(x=>String(x?.code||'')===c)||(d.rows||[])[0]||null;
    if(row?.code){WATCH_MANUAL_LIVE[String(row.code)]=row;WATCH_MANUAL_LIVE_AT=Date.now();return row}
    const detail=(d.errors||{})[c];if(detail)throw Error(detail);
  }catch(e){console.warn('[LITTO] 종목 직접조회 실패',c,e)}
  return findStock(c)||WATCH_MANUAL_LIVE[c]||null;
}
function ensureGeneralChartUi(){
  const modal=$('#chartModal'),box=modal?.querySelector('.chartbox'),actions=modal?.querySelector('.chartactions');
  if(box){
    box.style.marginTop='1.2vh';
    box.style.marginBottom='0';
    box.style.height='min(880px,96vh)';
  }
  if(actions){
    const close=$('#chartClose');
    const frames=[['m1','1분봉'],['m3','3분봉'],['m15','15분봉'],['daily','일봉']];
    frames.forEach(([tf,label])=>{
      let b=actions.querySelector(`.charttf[data-tf="${tf}"]`);
      if(!b){
        b=document.createElement('button');b.type='button';b.className='ghost charttf';b.dataset.tf=tf;b.textContent=label;
        actions.insertBefore(b,close);
      }else b.textContent=label;
    });
    // Keep one button per timeframe and show in intraday -> daily order.
    const seen=new Set();
    [...actions.querySelectorAll('.charttf')].forEach(b=>{
      const tf=String(b.dataset.tf||'');
      if(!['m1','m3','m15','daily'].includes(tf)||seen.has(tf))b.remove();else seen.add(tf);
    });
    for(const tf of ['m1','m3','m15','daily']){
      const b=actions.querySelector(`.charttf[data-tf="${tf}"]`);if(b)actions.insertBefore(b,close);
    }
    let splitBtn=actions.querySelector('#chartSplit4');
    if(!splitBtn){splitBtn=document.createElement('button');splitBtn.id='chartSplit4';splitBtn.type='button';splitBtn.className='ghost';splitBtn.textContent='4분할';splitBtn.title='일봉 · 15분봉 · 3분봉 · 1분봉 동시 보기';actions.insertBefore(splitBtn,close)}
    let fzBtn=actions.querySelector('#chartFzoneToggle');
    if(!fzBtn){fzBtn=document.createElement('button');fzBtn.id='chartFzoneToggle';fzBtn.type='button';fzBtn.className='ghost';fzBtn.title='1·3·15분봉 F존 표시 ON/OFF';fzBtn.onclick=()=>setChartFzoneEnabled(!CHART_FZONE_ENABLED);actions.insertBefore(fzBtn,close)}
    syncChartFzoneButtons();
    actions.querySelectorAll('.charttf').forEach(b=>b.onclick=async()=>{const next=b.dataset.tf||'daily';CHART_SPLIT_MODE=false;syncChartSplitUi();if(!(await ensureGeneralChartTimeframe(next)))return;chartTf=next;actions.querySelectorAll('.charttf').forEach(x=>x.classList.toggle('active',x===b));splitBtn.classList.remove('active');drawChart()});
    splitBtn.onclick=()=>openChartSplit4();
  }
  ensureChartSplitUi();
}

function ensureChartSplitUi(){
  const modal=$('#chartModal'),box=modal?.querySelector('.chartbox'),wrap=modal?.querySelector('.canvaswrap');
  if(!modal||!box||!wrap)return;
  if(!$('#chartSplitStyle')){
    const st=document.createElement('style');st.id='chartSplitStyle';st.textContent=`
      #chartSplitGrid{display:none;grid-template-columns:1fr 1fr;grid-template-rows:1fr 1fr;gap:8px;height:calc(100% - 2px);min-height:620px}
      #chartSplitGrid.open{display:grid}
      .chart-split-cell{position:relative;min-width:0;min-height:0;border:1px solid #18384d;border-radius:10px;background:#07131d;overflow:hidden}
      .chart-split-head{position:absolute;z-index:2;left:10px;top:8px;display:flex;gap:8px;align-items:center;padding:3px 7px;border-radius:6px;background:rgba(4,15,24,.78);font-size:11px;color:#8fa4b8;pointer-events:none}
      .chart-split-head b{color:#e7f2fb;font-size:12px}
      .chart-split-cell canvas{display:block;width:100%;height:100%}
      @media(max-width:900px){#chartSplitGrid{grid-template-columns:1fr;grid-template-rows:repeat(4,minmax(260px,1fr));min-height:1080px}}
    `;document.head.appendChild(st);
  }
  if(!$('#chartSplitGrid')){
    const g=document.createElement('div');g.id='chartSplitGrid';
    g.innerHTML=[
      ['daily','일봉'],['m15','15분봉'],['m3','3분봉'],['m1','1분봉']
    ].map(([tf,label])=>`<div class="chart-split-cell" data-split-tf="${tf}"><div class="chart-split-head"><b>${label}</b><span data-split-meta>대기</span></div><canvas></canvas></div>`).join('');
    wrap.insertAdjacentElement('afterend',g);
  }
}
function syncChartSplitUi(){
  ensureChartSplitUi();
  const grid=$('#chartSplitGrid'),wrap=$('#chartModal .canvaswrap'),legend=$('#chartLegend');
  if(grid)grid.classList.toggle('open',!!CHART_SPLIT_MODE);
  if(wrap)wrap.style.display=CHART_SPLIT_MODE?'none':'';
  if(legend)legend.style.display=CHART_SPLIT_MODE?'none':'';
  const b=$('#chartSplit4');if(b)b.classList.toggle('active',!!CHART_SPLIT_MODE);
}
function chartSplitBars(tf){
  if(!chartStock)return[];
  const all=(tf==='daily'?chartStock.daily:tf==='m1'?chartStock.m1:tf==='m3'?chartStock.m3:chartStock.m15)||[];
  const max=tf==='daily'?100:120;
  return all.slice(-Math.min(max,all.length));
}

function chartSplitLabelText(tf, bar){
  if(!bar)return '';
  if(tf==='daily'){
    const raw=String(bar.date||'').trim();
    if(/^\d{4}-\d{2}-\d{2}$/.test(raw))return raw.slice(5).replace('-', '/');
    if(/^\d{8}$/.test(raw))return raw.slice(4,6)+'/'+raw.slice(6,8);
    return raw;
  }
  const raw=String(bar.time||bar.date||'').trim();
  if(!raw)return '';
  const d=new Date(raw);
  if(!Number.isNaN(d.getTime()))return String(d.getHours()).padStart(2,'0')+':'+String(d.getMinutes()).padStart(2,'0');
  const m=raw.match(/(\d{2}):(\d{2})/);
  if(m)return m[1]+':'+m[2];
  const d14=raw.match(/(\d{2})(\d{2})(\d{2})$/);
  if(d14)return d14[1]+':'+d14[2];
  return raw;
}
function drawChartSplitXAxis(ctx,bars,tf,pad,w,volTop,volH,xStep){
  if(!bars?.length)return;
  const baseY=volTop+volH+1;
  const tickY=baseY+4;
  const textY=baseY+16;
  ctx.save();
  ctx.strokeStyle='#173041';
  ctx.fillStyle='#6f8798';
  ctx.font='10px sans-serif';
  ctx.textAlign='center';
  ctx.beginPath();
  ctx.moveTo(pad.l, baseY);
  ctx.lineTo(w-pad.r, baseY);
  ctx.stroke();
  const seed=[0, Math.round((bars.length-1)*0.25), Math.round((bars.length-1)*0.5), Math.round((bars.length-1)*0.75), bars.length-1];
  const idxs=[];
  for(const n of seed){
    const i=Math.max(0, Math.min(bars.length-1, n));
    if(!idxs.includes(i))idxs.push(i);
  }
  let lastX=-1e9;
  for(const i of idxs){
    const x=pad.l+xStep*(i+0.5);
    const label=chartSplitLabelText(tf,bars[i]);
    ctx.beginPath();
    ctx.moveTo(x, baseY);
    ctx.lineTo(x, tickY);
    ctx.stroke();
    if(label && x-lastX>38){
      ctx.fillText(label,x,textY);
      lastX=x;
    }
  }
  ctx.restore();
}
function drawChartSplitCanvas(cell,tf){
  const canvas=cell?.querySelector('canvas'),meta=cell?.querySelector('[data-split-meta]');
  if(!canvas)return;
  const bars=chartSplitBars(tf);
  const all=(tf==='daily'?chartStock?.daily:tf==='m1'?chartStock?.m1:tf==='m3'?chartStock?.m3:chartStock?.m15)||[];
  if(meta)meta.textContent=bars.length?`${bars.length}봉 · 전체 ${all.length}`:'불러오는 중';
  const r=cell.getBoundingClientRect(),dpr=window.devicePixelRatio||1,w=Math.max(260,Math.floor(r.width)),h=Math.max(220,Math.floor(r.height));
  canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr);canvas.style.width=w+'px';canvas.style.height=h+'px';
  const ctx=canvas.getContext('2d');ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,w,h);
  ctx.fillStyle='#07131d';ctx.fillRect(0,0,w,h);
  if(!bars.length){ctx.fillStyle='#6f8798';ctx.font='12px sans-serif';ctx.fillText('데이터 준비 중...',14,42);return}
  const pad={l:52,r:12,t:34,b:38},volH=Math.max(38,h*.18),priceH=Math.max(80,h-pad.t-pad.b-volH-8);
  const highs=bars.map(b=>Number(b.high)).filter(Number.isFinite),lows=bars.map(b=>Number(b.low)).filter(Number.isFinite);
  let maxP=Math.max(...highs),minP=Math.min(...lows);const rr=Math.max(1,maxP-minP),mg=rr*.035;maxP+=mg;minP-=mg;const range=Math.max(1,maxP-minP);
  const y=v=>pad.t+(maxP-Number(v))/range*priceH;
  const xStep=(w-pad.l-pad.r)/Math.max(1,bars.length),body=Math.max(1,Math.min(5,xStep*.58));
  ctx.strokeStyle='#173041';ctx.lineWidth=1;ctx.fillStyle='#6f8798';ctx.font='10px sans-serif';
  for(let i=0;i<=3;i++){const yy=pad.t+priceH*i/3;ctx.beginPath();ctx.moveTo(pad.l,yy);ctx.lineTo(w-pad.r,yy);ctx.stroke();ctx.fillText(Math.round(maxP-range*i/3).toLocaleString('ko-KR'),3,yy+3)}
  const maxV=Math.max(1,...bars.map(b=>Number(b.volume)||0)),volTop=pad.t+priceH+8;
  bars.forEach((b,i)=>{
    const x=pad.l+xStep*(i+.5),o=Number(b.open),c=Number(b.close),hi=Number(b.high),lo=Number(b.low),up=c>=o;
    const col=up?'#ff6677':'#55a7ff';
    ctx.strokeStyle=col;ctx.fillStyle=col;ctx.beginPath();ctx.moveTo(x,y(hi));ctx.lineTo(x,y(lo));ctx.stroke();
    const yy=Math.min(y(o),y(c)),hh=Math.max(1,Math.abs(y(c)-y(o)));ctx.fillRect(x-body/2,yy,body,hh);
    const vh=((Number(b.volume)||0)/maxV)*volH;ctx.globalAlpha=.35;ctx.fillRect(x-body/2,volTop+volH-vh,body,vh);ctx.globalAlpha=1;
  });
  drawChartSplitXAxis(ctx,bars,tf,pad,w,volTop,volH,xStep);
  const last=Number(bars[bars.length-1]?.close);
  if(Number.isFinite(last)){const yy=y(last);ctx.save();ctx.setLineDash([4,3]);ctx.strokeStyle='#f4d35e';ctx.beginPath();ctx.moveTo(pad.l,yy);ctx.lineTo(w-pad.r,yy);ctx.stroke();ctx.restore()}
}
function drawChartSplit(){
  if(!CHART_SPLIT_MODE||!chartStock)return;
  syncChartSplitUi();
  $('#chartTitle').textContent=`${chartStock.name} (${chartStock.code})`;
  $('#chartSub').textContent=`${chartStock.sector||'미분류'} · 4분할 · 일봉 / 15분봉 / 3분봉 / 1분봉`;
  for(const tf of ['daily','m15','m3','m1']){
    const cell=document.querySelector(`#chartSplitGrid [data-split-tf="${tf}"]`);
    if(cell)drawChartSplitCanvas(cell,tf);
  }
  $('#chartFoot').textContent=CHART_SPLIT_LOADING?'4분할 준비 중 · 캐시 우선 / 없는 분봉만 순차 조회':'4분할 · 캐시 우선 표시';
}
async function loadChartSplitMissingFrames(){
  if(CHART_SPLIT_LOADING||!chartStock)return;
  CHART_SPLIT_LOADING=true;drawChartSplit();
  const code=String(chartStock.code||'');
  try{
    for(const tf of ['m15','m3','m1']){
      if(!CHART_SPLIT_MODE||!chartStock||String(chartStock.code||'')!==code)return;
      if(!generalChartHas300(tf)){
        try{await ensureGeneralChartTimeframe(tf)}catch(_e){}
        if(CHART_SPLIT_MODE)drawChartSplit();
        await new Promise(r=>setTimeout(r,700));
      }
    }
  }finally{
    CHART_SPLIT_LOADING=false;
    if(CHART_SPLIT_MODE)drawChartSplit();
  }
}
function openChartSplit4(){
  if(!chartStock)return;
  CHART_SPLIT_MODE=true;
  $$('.charttf').forEach(b=>b.classList.remove('active'));
  syncChartSplitUi();
  drawChartSplit();
  loadChartSplitMissingFrames();
}

async function ensureGeneralChartTimeframe(tf){
  if(!chartStock||tf==='daily')return true;
  const key=tf==='m1'?'m1':tf==='m3'?'m3':'m15';
  const existing=Array.isArray(chartStock[key])?chartStock[key]:[];
  if(existing.length>=300)return true;
  const minutes=tf==='m1'?'1':tf==='m3'?'3':'15',cacheKey=String(chartStock.code||'')+'|'+minutes;
  const cached=GENERAL_CHART_CACHE.get(cacheKey);
  if(cached&&Date.now()-cached.ts<GENERAL_CHART_CACHE_TTL&&Array.isArray(cached.bars)&&cached.bars.length>=existing.length){
    chartStock[key]=cached.bars;
    if(chartStock[key].length>=300)return true;
  }
  try{
    const r=await fetch('/api/orderbook-mini-chart?code='+encodeURIComponent(chartStock.code)+'&tf='+minutes,{cache:'no-store'});
    const d=await r.json();if(!r.ok)throw Error(d.error||'분봉 조회 실패');
    const incoming=Array.isArray(d.bars)?d.bars:[];
    if(incoming.length>=existing.length)chartStock[key]=incoming;
    if(chartStock[key].length)GENERAL_CHART_CACHE.set(cacheKey,{ts:Date.now(),bars:chartStock[key]});
    return chartStock[key].length>0;
  }catch(e){
    console.warn('[LITTO] 일반 차트 분봉 조회',tf,e);
    if(existing.length)return true;
    alert((tf==='m1'?'1분봉':tf==='m3'?'3분봉':'15분봉')+' 데이터를 불러오지 못했습니다. '+e.message);
    return false;
  }
}

const GENERAL_CHART_PREFETCHING=new Set();
function generalChartHas300(tf){
  if(!chartStock)return false;
  const key=tf==='m1'?'m1':tf==='m3'?'m3':'m15';
  return Array.isArray(chartStock[key])&&chartStock[key].length>=300;
}
async function prefetchGeneralMinuteFrames300(code){
  const c=String(code||'').trim();
  if(!c||!chartStock||String(chartStock.code||'')!==c)return;
  // Do not compete with the user's latency-critical views.
  // Orderbook / flow / news always keep priority over background chart warming.
  const frames=['m1','m15','m3'];
  for(const tf of frames){
    if(!chartStock||String(chartStock.code||'')!==c)return;
    if(!$('#chartModal')?.classList.contains('open'))return;
    if(typeof latencyCriticalViewOpen==='function'&&latencyCriticalViewOpen())return;
    if(generalChartHas300(tf))continue;
    const key=`${c}|${tf}`;
    if(GENERAL_CHART_PREFETCHING.has(key))continue;
    GENERAL_CHART_PREFETCHING.add(key);
    try{
      await ensureGeneralChartTimeframe(tf);
    }catch(_e){
    }finally{
      GENERAL_CHART_PREFETCHING.delete(key);
    }
    // Yield between provider calls so normal LITTO work is not starved.
    await new Promise(r=>setTimeout(r,700));
  }
}

async function prefetchGeneralDailyHistory(code){
  if(!chartStock||String(chartStock.code||'')!==String(code||''))return;
  if(Array.isArray(chartStock.daily)&&chartStock.daily.length>=300)return;
  const cacheKey=String(code||'')+'|daily-history';
  const cached=GENERAL_CHART_CACHE.get(cacheKey);
  if(cached&&Date.now()-cached.ts<GENERAL_CHART_CACHE_TTL&&Array.isArray(cached.bars)&&cached.bars.length){
    if(chartStock&&String(chartStock.code||'')===String(code||'')){
      const cur=Array.isArray(chartStock.daily)?chartStock.daily:[];
      if(cached.bars.length>cur.length){chartStock.daily=cached.bars;drawChart()}
    }
    if(cached.bars.length>=300)return;
  }
  try{
    const r=await fetch('/api/chart-daily-history?code='+encodeURIComponent(code),{cache:'no-store'});
    const d=await r.json();if(!r.ok)throw Error(d.error||'일봉 과거데이터 조회 실패');
    const bars=Array.isArray(d.daily)?d.daily:[];
    if(bars.length)GENERAL_CHART_CACHE.set(cacheKey,{ts:Date.now(),bars});
    if(chartStock&&String(chartStock.code||'')===String(code||'')&&bars.length>(chartStock.daily?.length||0)){
      chartStock.daily=bars;
      if(chartTf==='daily')drawChart();
    }
  }catch(e){console.warn('[LITTO] 일봉 과거데이터 보강',e)}
}
async function openChart(code){const cm=$('#chartModal');if(cm)cm.style.zIndex='220000';const c=String(code||'').trim();let s=findStock(c)||WATCH_MANUAL_LIVE[c]||null;if(!s)s=await ensureDirectStockSnapshot(c,true);if(!s){alert('종목 차트 데이터를 불러오지 못했습니다. 키움 연결 상태를 확인한 뒤 다시 시도하세요.');return}chartStock=s;chartTf='daily';CHART_SPLIT_MODE=false;CHART_SPLIT_LOADING=false;CHART_ZOOM_BARS.daily=90;CHART_ZOOM_BARS.m1=120;CHART_ZOOM_BARS.m3=120;CHART_ZOOM_BARS.m15=120;CHART_PAN_OFFSET.daily=0;CHART_PAN_OFFSET.m1=0;CHART_PAN_OFFSET.m3=0;CHART_PAN_OFFSET.m15=0;ensureGeneralChartUi();ensureChartLineControls();installChartLineCanvas();setChartLineMode(null);$('#chartModal').classList.add('open');$('#chartModal').setAttribute('aria-hidden','false');$$('.charttf').forEach(b=>b.classList.toggle('active',b.dataset.tf==='daily'));drawChart();setTimeout(()=>prefetchGeneralDailyHistory(String(s.code||c)),700);setTimeout(()=>prefetchGeneralMinuteFrames300(String(s.code||c)),1400)}
function closeChart(){setChartLineMode(null);CHART_GEOM=null;CHART_SPLIT_MODE=false;CHART_SPLIT_LOADING=false;syncChartSplitUi();chartStock=null;$('#chartModal').classList.remove('open');$('#chartModal').setAttribute('aria-hidden','true')}
function maSeries(bars,n){let out=new Array(bars.length).fill(null),sum=0;for(let i=0;i<bars.length;i++){sum+=Number(bars[i].close);if(i>=n)sum-=Number(bars[i-n].close);if(i>=n-1)out[i]=sum/n}return out}
function intradayParts(bar){
  const raw=String(bar?.time||bar?.date||'').trim();
  if(!raw)return {date:'',hm:'',minutes:null};
  let m=raw.match(/^(20\d{2})[-\/.]?(\d{2})[-\/.]?(\d{2})[T\s]?(\d{2}):?(\d{2})(?::?(\d{2}))?/);
  if(m){const hh=Number(m[4]),mm=Number(m[5]);return {date:`${m[1]}-${m[2]}-${m[3]}`,hm:`${m[4]}:${m[5]}`,minutes:hh*60+mm}}
  m=raw.match(/^(20\d{2})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})?$/);
  if(m){const hh=Number(m[4]),mm=Number(m[5]);return {date:`${m[1]}-${m[2]}-${m[3]}`,hm:`${m[4]}:${m[5]}`,minutes:hh*60+mm}}
  m=raw.match(/(?:^|\s)(\d{2}):(\d{2})(?::\d{2})?$/);
  if(m){const hh=Number(m[1]),mm=Number(m[2]);return {date:'',hm:`${m[1]}:${m[2]}`,minutes:hh*60+mm}}
  m=raw.match(/^(\d{2})(\d{2})(\d{2})$/);
  if(m){const hh=Number(m[1]),mm=Number(m[2]);return {date:'',hm:`${m[1]}:${m[2]}`,minutes:hh*60+mm}}
  const d=new Date(raw);
  if(!Number.isNaN(d.getTime())){const yy=d.getFullYear(),mo=String(d.getMonth()+1).padStart(2,'0'),dd=String(d.getDate()).padStart(2,'0'),hh=String(d.getHours()).padStart(2,'0'),mm=String(d.getMinutes()).padStart(2,'0');return {date:`${yy}-${mo}-${dd}`,hm:`${hh}:${mm}`,minutes:Number(hh)*60+Number(mm)}}
  return {date:'',hm:'',minutes:null}
}
function intradayMarkerHM(bar){return intradayParts(bar).hm}
function intradayMarkerDateKey(bar){return intradayParts(bar).date}
function findVisible2000Markers(bars,tf){
  const tolerance=tf==='m1'||tf==='1'?1:tf==='m3'||tf==='3'?3:tf==='m15'||tf==='15'?15:0;
  const byDate=new Map();
  (bars||[]).forEach((b,i)=>{const p=intradayParts(b);if(!p.date||!Number.isFinite(p.minutes))return;const cur=byDate.get(p.date)||[];cur.push({index:i,bar:b,minutes:p.minutes,date:p.date});byDate.set(p.date,cur)});
  const out=[];
  for(const rows of byDate.values()){
    let best=null,bestDiff=Infinity;
    for(const r of rows){const diff=Math.abs(r.minutes-1200);if(diff<bestDiff){best=r;bestDiff=diff}}
    if(best&&bestDiff<=tolerance)out.push(best);
  }
  return out
}
function fmtTime(b,tf){if(tf==='daily')return String(b.date||'').slice(5);const p=intradayParts(b);return p.date&&p.hm?`${p.date.slice(5).replace('-','/')} ${p.hm}`:(p.hm||String(b.time||''))}
function find1530Close(bars){let hit=null;(bars||[]).forEach((b,i)=>{if(intradayMarkerHM(b)==='15:30'&&Number.isFinite(Number(b.close)))hit={price:Number(b.close),index:i,bar:b}});return hit}
function chart1530BadgeHtml(bars){if(!CHART_MARKERS_ENABLED||chartTf==='daily'||!Array.isArray(bars)||!bars.length)return'';const hit=find1530Close(bars);if(!hit)return'';const lastClose=Number(bars[bars.length-1]?.close||0);const state=lastClose>hit.price?'up':lastClose<hit.price?'down':'flat';const color=state==='up'?'#ff6677':state==='down'?'#55a7ff':'#facc15';return `<span class="chart-leg close1530 ${state}" style="margin-left:auto;color:${color};font-weight:950"><i style="background:#facc15"></i>15:30 종가 ${Math.round(hit.price).toLocaleString('ko-KR')}</span>`}
function drawIntradayTimeMarkers(ctx,bars,pad,priceH,volH,xStep,gap,tf,y,plotRight,showInlineLabel=true){if(!CHART_MARKERS_ENABLED||tf==='daily'||!Array.isArray(bars)||!bars.length)return;const bottom=pad.t+priceH+gap+volH;ctx.save();const close1530=find1530Close(bars);const close2000List=findVisible2000Markers(bars,tf);bars.forEach((b,i)=>{const hm=intradayMarkerHM(b);if(hm!=='15:00'&&hm!=='15:30')return;const xx=pad.l+xStep*(i+.5);ctx.beginPath();ctx.lineWidth=1;ctx.strokeStyle=hm==='15:00'?'rgba(255,255,255,0.84)':'rgba(148,163,184,0.76)';ctx.moveTo(xx,pad.t);ctx.lineTo(xx,bottom);ctx.stroke()});close2000List.forEach(hit=>{const xx=pad.l+xStep*(hit.index+.5);ctx.beginPath();ctx.lineWidth=1.6;ctx.strokeStyle='rgba(248,81,73,0.98)';ctx.setLineDash([]);ctx.moveTo(xx,pad.t);ctx.lineTo(xx,bottom);ctx.stroke()});if(close1530&&typeof y==='function'){const yy=y(close1530.price);if(Number.isFinite(yy)&&yy>=pad.t&&yy<=pad.t+priceH){ctx.strokeStyle='rgba(250,204,21,0.96)';ctx.lineWidth=1.35;ctx.setLineDash([]);ctx.beginPath();ctx.moveTo(pad.l,yy);ctx.lineTo(Number.isFinite(plotRight)?plotRight:pad.l+xStep*bars.length,yy);ctx.stroke();if(showInlineLabel){ctx.fillStyle='#facc15';ctx.font='bold 10px sans-serif';const label=`15:30 종가 ${Math.round(close1530.price).toLocaleString('ko-KR')}`;const tw=ctx.measureText(label).width;const right=Number.isFinite(plotRight)?plotRight:pad.l+xStep*bars.length;ctx.fillText(label,Math.max(pad.l+4,right-tw-4),Math.max(pad.t+11,yy-4))}}}ctx.restore()}
function drawChart(){if(!chartStock)return;if(CHART_SPLIT_MODE){drawChartSplit();return;}const all=(chartTf==='daily'?chartStock.daily:chartTf==='m1'?chartStock.m1:chartTf==='m3'?chartStock.m3:chartStock.m15)||[];const defLimit=chartTf==='daily'?90:120;const limit=Math.max(1,Math.min(all.length||defLimit,Number(CHART_ZOOM_BARS[chartTf]||defLimit)));const maxPan=Math.max(0,all.length-limit);const panOffset=Math.max(0,Math.min(maxPan,Math.trunc(Number(CHART_PAN_OFFSET[chartTf]||0))));CHART_PAN_OFFSET[chartTf]=panOffset;const endIndex=Math.max(0,all.length-panOffset);const startIndex=Math.max(0,endIndex-limit);const bars=all.slice(startIndex,endIndex);$('#chartTitle').textContent=`${chartStock.name} (${chartStock.code})`;$ ('#chartSub').textContent=`${chartStock.sector||'미분류'} · ${chartTf==='daily'?'일봉':chartTf==='m1'?'1분봉':chartTf==='m3'?'3분봉':'15분봉'} · 표시 ${bars.length} / 전체 ${all.length}봉`;const fz=findFZone(chartStock.code);const baseSetup=findBaseSetup(chartStock.code);const legend=[`<span class="chart-leg candle-up"><i></i>양봉</span>`,`<span class="chart-leg candle-down"><i></i>음봉</span>`,`<span class="chart-leg volume"><i></i>거래량</span>`,`<span class="chart-leg ma5"><i></i>MA5</span>`,`<span class="chart-leg ma10"><i></i>MA10</span>`,`<span class="chart-leg ma20"><i></i>MA20</span>`,`<span class="chart-leg ma60"><i></i>MA60</span>`];if(chartTf!=='daily'&&CHART_FZONE_ENABLED&&fz?.levels?.B1&&fz?.levels?.B2&&fz?.levels?.B3)legend.push(`<span class="chart-leg fzone"><i></i>F존 B1/B2/B3</span>`);if(chartTf==='daily'&&baseSetup)legend.push(`<span class="chart-leg base"><i></i>${esc(baseSetup.name)} D-1 기준봉</span>`);const userLevels=chartLevels(chartStock.code);if(userLevels.length)legend.push(`<span class="chart-leg userline"><i></i>사용자 수평선 ${userLevels.length}개</span>`);const close1530Badge=chart1530BadgeHtml(bars);if(close1530Badge)legend.push(close1530Badge);$('#chartLegend').innerHTML=legend.join('');if(!bars.length){$('#chartFoot').textContent='차트 데이터가 없습니다.';return}const c=$('#stockChart'),wrap=c.parentElement,dpr=window.devicePixelRatio||1,w=Math.max(500,wrap.clientWidth),h=Math.max(420,wrap.clientHeight);c.width=Math.round(w*dpr);c.height=Math.round(h*dpr);c.style.width=w+'px';c.style.height=h+'px';const ctx=c.getContext('2d');ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,w,h);const pad={l:70,r:36,t:22,b:38},volH=Math.max(70,h*.20),priceH=h-pad.t-pad.b-volH-12;const highs=bars.map(b=>Number(b.high)),lows=bars.map(b=>Number(b.low));const fzLevels=fz?.levels||{};const overlayPrices=chartTf!=='daily'&&CHART_FZONE_ENABLED?[fzLevels.B1,fzLevels.B2,fzLevels.B3].map(Number).filter(Number.isFinite):[];const maDefs=[[5,'#ff4d5f'],[10,'#3b82f6'],[20,'#ffd43b'],[60,'#67d6ff']];const maVisible=maDefs.map(([n,color])=>({n,color,vals:maSeries(all,n).slice(startIndex,endIndex)}));const maPrices=maVisible.flatMap(m=>m.vals.filter(v=>Number.isFinite(v)));let maxP=Math.max(...highs,...(maPrices.length?maPrices:[-Infinity])),minP=Math.min(...lows,...(maPrices.length?maPrices:[Infinity]));if(overlayPrices.length){maxP=Math.max(maxP,...overlayPrices);minP=Math.min(minP,...overlayPrices)}if(userLevels.length){maxP=Math.max(maxP,...userLevels);minP=Math.min(minP,...userLevels)}const rawRange=Math.max(1,maxP-minP),yMargin=rawRange*.035;maxP+=yMargin;minP-=yMargin;const range=Math.max(1,maxP-minP);const y=p=>pad.t+(maxP-p)/range*priceH;const xStep=(w-pad.l-pad.r)/bars.length;const xAt=i=>pad.l+xStep*(i+.5);CHART_GEOM={maxP,minP,range,padTop:pad.t,padLeft:pad.l,padRight:pad.r,priceH,w,h,xStep,xAt,bars,all,startIndex};const bodyW=Math.max(2,Math.min(10,xStep*.62));if(chartTf==='daily'&&baseSetup){const bi=bars.findIndex(b=>String(b.date||'')===baseSetup.date);if(bi>=0){const bx=pad.l+xStep*bi;ctx.save();ctx.fillStyle='rgba(163,113,247,0.10)';ctx.fillRect(bx,pad.t,xStep,priceH);ctx.strokeStyle='rgba(163,113,247,0.9)';ctx.setLineDash([4,3]);ctx.beginPath();ctx.moveTo(bx+xStep/2,pad.t);ctx.lineTo(bx+xStep/2,pad.t+priceH);ctx.stroke();ctx.setLineDash([]);ctx.fillStyle='#a371f7';ctx.font='bold 11px sans-serif';ctx.fillText(`${baseSetup.name} D-1 기준봉`,Math.max(pad.l+4,Math.min(w-pad.r-120,bx)),pad.t+13);ctx.restore()}}ctx.strokeStyle='#21262d';ctx.lineWidth=1;ctx.fillStyle='#8b949e';ctx.font='11px sans-serif';for(let i=0;i<=4;i++){const yy=pad.t+priceH*i/4;ctx.beginPath();ctx.moveTo(pad.l,yy);ctx.lineTo(w-pad.r,yy);ctx.stroke();const pv=maxP-range*i/4;ctx.fillText(Math.round(pv).toLocaleString(),4,yy+4)}drawIntradayTimeMarkers(ctx,bars,pad,priceH,volH,xStep,12,chartTf,y,w-pad.r,false);if(overlayPrices.length===3){const b1=Number(fzLevels.B1),b2=Number(fzLevels.B2),b3=Number(fzLevels.B3);const topY=Math.min(y(b1),y(b3)),bottomY=Math.max(y(b1),y(b3));ctx.save();ctx.fillStyle='rgba(210,153,34,0.10)';ctx.fillRect(pad.l,topY,w-pad.l-pad.r,bottomY-topY);const levels=[['B1',b1],['B2',b2],['B3',b3]];levels.forEach(([lab,val],idx)=>{const yy=y(val);ctx.setLineDash(idx===1?[3,3]:[7,4]);ctx.strokeStyle=idx===1?'rgba(210,153,34,0.95)':'rgba(210,153,34,0.72)';ctx.lineWidth=idx===1?1.5:1;ctx.beginPath();ctx.moveTo(pad.l,yy);ctx.lineTo(w-pad.r,yy);ctx.stroke();ctx.setLineDash([]);ctx.fillStyle='#d29922';ctx.font='bold 11px sans-serif';ctx.fillText(`F존 ${lab} ${Math.round(val).toLocaleString()}`,Math.max(pad.l+6,w-pad.r-150),Math.max(pad.t+11,yy-4))});ctx.restore()}if(userLevels.length){ctx.save();ctx.strokeStyle='rgba(255,255,255,0.92)';ctx.fillStyle='#ffffff';ctx.lineWidth=1.35;ctx.font='bold 11px sans-serif';userLevels.forEach(val=>{if(val<minP||val>maxP)return;const yy=y(val);ctx.setLineDash([]);ctx.beginPath();ctx.moveTo(0,yy);ctx.lineTo(w,yy);ctx.stroke();const label=Math.round(val).toLocaleString();const tw=ctx.measureText(label).width;ctx.fillStyle='rgba(7,15,25,0.82)';ctx.fillRect(w-pad.r-tw-12,yy-9,tw+10,16);ctx.fillStyle='#ffffff';ctx.fillText(label,w-pad.r-tw-7,yy+4)});ctx.restore()}if(CHART_LINE_MODE==='add'&&Number.isFinite(CHART_HOVER_PRICE)&&CHART_HOVER_PRICE>=minP&&CHART_HOVER_PRICE<=maxP){ctx.save();const yy=y(CHART_HOVER_PRICE);ctx.strokeStyle='rgba(255,255,255,0.88)';ctx.lineWidth=1.25;ctx.setLineDash([6,4]);ctx.beginPath();ctx.moveTo(0,yy);ctx.lineTo(w,yy);ctx.stroke();ctx.setLineDash([]);const label=`${Math.round(CHART_HOVER_PRICE).toLocaleString()} · 클릭하여 확정`;ctx.font='bold 11px sans-serif';const tw=ctx.measureText(label).width;ctx.fillStyle='rgba(7,15,25,0.92)';ctx.fillRect(w-pad.r-tw-14,yy-10,tw+12,18);ctx.fillStyle='#ffffff';ctx.fillText(label,w-pad.r-tw-8,yy+4);ctx.restore()}const maxV=Math.max(...bars.map(b=>Number(b.volume||0)),1);bars.forEach((b,i)=>{const xx=xAt(i),o=Number(b.open),cl=Number(b.close),hi=Number(b.high),lo=Number(b.low),up=cl>=o;ctx.strokeStyle=up?'#f85149':'#58a6ff';ctx.fillStyle=ctx.strokeStyle;ctx.beginPath();ctx.moveTo(xx,y(hi));ctx.lineTo(xx,y(lo));ctx.stroke();const top=Math.min(y(o),y(cl)),bh=Math.max(1,Math.abs(y(o)-y(cl)));ctx.fillRect(xx-bodyW/2,top,bodyW,bh);const vh=Number(b.volume||0)/maxV*volH;ctx.globalAlpha=.45;ctx.fillRect(xx-bodyW/2,pad.t+priceH+12+volH-vh,bodyW,vh);ctx.globalAlpha=1});maVisible.forEach(({n,color,vals})=>{ctx.strokeStyle=color;ctx.lineWidth=1.25;ctx.beginPath();let started=false;vals.forEach((v,i)=>{if(v==null||!Number.isFinite(v))return;const xx=xAt(i),yy=y(v);if(!started){ctx.moveTo(xx,yy);started=true}else ctx.lineTo(xx,yy)});if(started)ctx.stroke()});ctx.fillStyle='#8b949e';const marks=5;for(let m=0;m<marks;m++){const i=Math.min(bars.length-1,Math.round(m*(bars.length-1)/(marks-1))),xx=xAt(i),lab=fmtTime(bars[i],chartTf);ctx.save();ctx.textAlign='center';ctx.fillText(lab,xx,h-10);ctx.restore()}const last=bars[bars.length-1];const chg=bars.length>1?(Number(last.close)/Number(bars[bars.length-2].close)-1)*100:null;const fzText=chartTf!=='daily'&&CHART_FZONE_ENABLED&&overlayPrices.length===3?` · ${fz?.status||'F존 적용 가능'} · F존 B1 ${money(fzLevels.B1)} / B2 ${money(fzLevels.B2)} / B3 ${money(fzLevels.B3)}${fzLevels.peak?' · 활성기준고점 '+money(fzLevels.peak):''}${fzLevels.formula_mode?` · ${fzLevels.formula_mode}`:''}${fzLevels.reset_count?` · 반등 이벤트 ${fzLevels.reset_count}회 (${fzLevels.reset_timeframe||''})`:''}${fz?.other_setup?` · 주의: 현재 ${fz.other_setup} 구조 우선`:''}`:'';const baseText=baseSetup?` · ${baseSetup.name} 기준봉 ${baseSetup.date}`:'';$('#chartFoot').textContent=`최근 ${fmtTime(last,chartTf)} · O ${money(last.open)} H ${money(last.high)} L ${money(last.low)} C ${money(last.close)} · ${chg==null?'':pct(chg)} · 거래량 ${money(last.volume)}${last.value!=null?' · 거래대금 '+money(Number(last.value)/1e8)+'억':''}${baseText}${fzText}`}
function lookupTags(code){const ps=STATE?.report?.search_panels?.panels||{};const out=[];for(const name of ['주도주 종배','주도주 상따','끼도주 종배','종배 우선순위','전일 후보','피뢰침','하트존','F존','오늘의 상한가','약상매매 후보']){if((ps[name]?.rows||[]).some(x=>String(x.code)===String(code)))out.push(name)}return out}
function rankMoveLabel(x){if(x.new)return '<span class="rank-move rank-new">NEW</span>';const m=Number(x.move||0);if(m>0)return `<span class="rank-move rank-up">↑${m}</span>`;if(m<0)return `<span class="rank-move rank-down">↓${Math.abs(m)}</span>`;return '<span class="rank-move rank-flat">―</span>'}
function ensureRealtimeRankSectorStyle(){
  if(document.getElementById('realtimeRankSectorStyle'))return;
  const st=document.createElement('style');st.id='realtimeRankSectorStyle';
  st.textContent=`
    #realtime-rank .live-rank-name,
    #realtimeRankDailyPanel .live-rank-name{
      display:flex!important;
      align-items:center!important;
      justify-content:space-between!important;
      gap:8px!important;
      min-width:0!important;
    }
    #realtime-rank .live-rank-name .stock-title-line,
    #realtimeRankDailyPanel .live-rank-name .stock-title-line{
      min-width:0!important;
      flex:0 1 auto!important;
    }
    #realtime-rank .rank-sector,
    #realtimeRankDailyPanel .rank-sector{
      flex:0 1 110px;
      min-width:54px;
      max-width:110px;
      margin-left:auto;
      padding:3px 8px;
      border:1px solid #1f4058;
      border-radius:999px;
      background:#0b1b29;
      color:#7fa8c8;
      font-size:11px;
      line-height:1.2;
      white-space:nowrap;
      overflow:hidden;
      text-overflow:ellipsis;
      text-align:center;
    }
    @media(max-width:1180px){
      #realtime-rank .rank-sector,
      #realtimeRankDailyPanel .rank-sector{
        max-width:82px;
        flex-basis:82px;
      }
    }
  `;
  document.head.appendChild(st);
}
function rankRowHtml(x,compact=false){const tags=lookupTags(x.code);const hot=!x.new&&Number(x.move||0)>=3;const tagHtml=[...(hot?['급상승']:[]),...tags].map((t,i)=>`<span class="rank-tag ${i===0&&hot?'hot':'hit'}">${esc(t)}</span>`).join('');const live=findStock(x.code)||{};const sector=String(x.sector||live.sector||'기타').trim()||'기타';return `<div class="live-rank-row" data-stock-action-code="${esc(x.code)}" data-stock-action-name="${esc(x.name||x.code)}" title="클릭하면 차트 · 수급 · 호가 · 메모를 선택합니다"><div class="live-rank-no">${x.rank}</div><div class="live-rank-name"><div class="stock-title-line"><b class="stock-name">${esc(x.name||x.code)}</b>${watchStarHtml({...x,sector})}${newsButtonHtml(x.code,x.name||x.code)}${disclosureButtonHtml(x.code,x.name||x.code)}</div><span class="rank-sector" title="${esc(sector)}">${esc(sector)}</span></div><div>${rankMoveLabel(x)}</div><div class="rank-change ${cls(x.change)}">${pct(x.change)}</div>${compact?'':`<div class="rank-price">${money(x.price)}</div>`}<div class="rank-tags">${tagHtml||'<span class="rank-tag">-</span>'}</div></div>`}
function renderPrioritySectorSummary(root){
  const head=root?.previousElementSibling;
  if(head?.classList?.contains('rank-subhead')){
    const b=head.querySelector('b'),s=head.querySelector('span');
    if(b)b.textContent='오늘 종배순위 · 섹터별';
    if(s)s.innerHTML=`종배 우선순위 · <span class="sector-sort-toolbar sector-sort-toolbar-inline" data-sector-sort-toolbar><span>정렬</span><button type="button" data-sector-sort="value" class="${SECTOR_SORT_MODE==='value'?'active':''}">거래순</button><button type="button" data-sector-sort="change" class="${SECTOR_SORT_MODE==='change'?'active':''}">상승률순</button></span>`;bindSectorSortButtons(head);
  }
  const rows=STATE?.report?.search_panels?.panels?.['종배 우선순위']?.rows||[];
  root.classList.remove('compact-rank');
  root.classList.add('priority-sector-list');
  if(!rows.length){root.innerHTML='<div class="empty">오늘 종배 우선순위 종목이 아직 없습니다.</div>';return}
  const groups=new Map();
  rows.forEach((x,i)=>{
    const live=findStock(x.code)||{};
    const sector=String(live.sector||x.sector||'기타').trim()||'기타';
    if(!groups.has(sector))groups.set(sector,[]);
    groups.get(sector).push({...x,_priorityRank:i+1,_live:live});
  });
  const sectors=sectorSortGroups([...groups.entries()].map(([sector,items])=>{const sorted=sectorSortItems(items);const changes=sorted.map(x=>sectorSortChange(x)).filter(Number.isFinite).filter(x=>x>-999000);return {sector,items:sorted,totalValue:sorted.reduce((s,x)=>s+Math.max(0,sectorSortValue(x)),0),avg:changes.length?changes.reduce((a,b)=>a+b,0)/changes.length:null}}));
  const valueText=v=>{const n=Number(v)||0;if(n>=10000)return `${(n/10000).toLocaleString('ko-KR',{maximumFractionDigits:1})}조`;return `${Math.round(n).toLocaleString('ko-KR')}억`};
  root.innerHTML=sectors.map((g,si)=>`<section class="priority-sector-card${si===0?' top':''}"><div class="priority-sector-head"><b>${esc(g.sector)}</b><span>${g.items.length}종목 · ${valueText(g.totalValue)}</span></div><div class="priority-sector-body">${g.items.map(x=>{const q=liveCardQuote(x),v=Number(x._live?.value_eok??x.value_eok??0)||0;return `<button type="button" class="priority-sector-row" data-priority-code="${esc(x.code)}" data-priority-name="${esc(x.name||x.code)}"><span class="priority-sector-rank">${x._priorityRank}</span><span class="priority-sector-stock"><b>${esc(x.name||x.code)}</b><small>거래대금 ${valueText(v)}</small></span><span class="priority-sector-change ${cls(q?.change)}">${pct(q?.change)}</span></button>`}).join('')}</div></section>`).join('');
  root.querySelectorAll('[data-priority-code]').forEach(btn=>btn.onclick=()=>openStockAction(btn.dataset.priorityCode,btn.dataset.priorityName));
}
function renderRealtimeRank(){ensureRealtimeRankSectorStyle();const rows=LIVE_RANK?.rows||[];const dailyRows=LIVE_RANK?.daily_rows||[];const root=$('#realtimeRankRows'),risers=$('#realtimeRankRisers');if(!root||!risers)return;const daily=ensureDailyRankPanel();const source=$('#realtimeRankSource'),updated=$('#realtimeRankUpdated');if(source)source.textContent=(LIVE_RANK.source||'키움 ka00198 · 2초')+(LIVE_RANK.error?` · ${LIVE_RANK.error}`:'');if(updated)updated.textContent=LIVE_RANK.updated_at?new Date(LIVE_RANK.updated_at).toLocaleTimeString():'대기';const current=rows.slice(0,20);root.innerHTML=current.map(x=>rankRowHtml(x,true)).join('')||'<div class="empty">키움 연결 후 자동으로 표시됩니다.</div>';if(daily){/* 같은 종목은 30초 실시간 화면의 등락률을 재사용해 두 패널의 표시 퍼센트를 일치시킨다. 순위 자체는 각각 키움 qry_tp=5/4 원본을 유지한다. */const liveChange=new Map(rows.map(x=>[String(x.code||''),x.change]));const cumulative=dailyRows.slice(0,20).map(x=>({...x,change:liveChange.has(String(x.code||''))?liveChange.get(String(x.code||'')):x.change,new:false,move:0}));daily.innerHTML=cumulative.map(x=>rankRowHtml(x,true)).join('')||'<div class="empty">키움 당일 누적순위 데이터가 없습니다.</div>'}renderPrioritySectorSummary(risers);renderRealtimeRankSectorStrip();bindNewsButtons();bindWatchStars();bindSectorEdits();bindStockActionClicks()}

let MARKET_MOVERS={up:[],down:[],sector_groups:[],updated_at:null,error:null};

function mmToolButtonsHtml(row){
  const code=String(row?.code||'');
  const name=String(row?.name||code||'-');
  const sector=String(row?.sector||'기타');
  return `<span class="mm-tools">
    ${watchStarHtml({code,name,sector})}
    <button class="watch-sector-edit sector-edit mm-sector-edit" type="button"
      data-sector-code="${esc(code)}" data-sector-current="${esc(sector)}"
      title="섹터 수정: ${esc(sector)}" aria-label="섹터 수정">✎</button>
    ${newsButtonHtml(code,name)}
    ${disclosureButtonHtml(code,name)}
  </span>`;
}

function ensureMarketMoversBoard(){
  let sec=$('#market-movers-0177');
  if(sec)return sec;
  const anchor=$('#realtime-rank');
  if(!anchor)return null;

  sec=document.createElement('section');
  sec.id='market-movers-0177';
  sec.className='card market-movers-card';
  sec.innerHTML=`
    <div class="mm-head">
      <div>
        <div class="eyebrow">KIWOOM 0177 + REALTIME RANK</div>
        <h2>0177 · 실시간 조회순위</h2>
        <div id="marketMoversMeta" class="muted">키움 통합시세 · 불러오는 중...</div>
      </div>
      <button id="marketMoversRefresh" class="ghost" type="button">새로고침</button>
    </div>

    <div class="mm-three-columns">
      <div class="mm-column">
        <div class="mm-section-title up">0177 상승 20위</div>
        <div id="marketMoversUp" class="mm-vertical-list"><div class="empty">키움 연결 후 표시됩니다.</div></div>
      </div>

      <div class="mm-column">
        <div class="mm-section-title down">0177 하락 20위</div>
        <div id="marketMoversDown" class="mm-vertical-list"><div class="empty">키움 연결 후 표시됩니다.</div></div>
      </div>

      <div class="mm-column">
        <div class="mm-section-title">실시간 조회순위 20위 · 섹터별</div>
        <div id="marketMoversSectors" class="mm-sector-vertical"><div class="empty">실시간 조회순위 TOP20을 섹터별로 묶습니다.</div></div>
      </div>
    </div>`;

  anchor.insertAdjacentElement('afterend',sec);

  if(!$('#marketMoversStyle')){
    const st=document.createElement('style');
    st.id='marketMoversStyle';
    st.textContent=`
      .market-movers-card{margin-top:14px;padding:0!important;overflow:hidden}
      .mm-head{display:flex;align-items:center;justify-content:space-between;gap:16px;padding:16px 18px;border-bottom:1px solid #1c3042}
      .mm-head h2{margin:3px 0 2px;font-size:19px}
      .mm-three-columns{display:grid;grid-template-columns:repeat(3,minmax(0,1fr));gap:0;align-items:start}
      .mm-column{min-width:0;padding:8px 6px 10px;border-right:1px solid #1c3042;overflow:hidden}
      .mm-column:last-child{border-right:0}
      .mm-section-title{font-weight:800;font-size:15px;color:#dce8f4;margin:0 0 9px 2px;position:sticky;top:0;z-index:2;background:#111821;padding:4px 0;height:30px;line-height:22px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;box-sizing:border-box}
      .mm-section-title.up{color:#ff6873}.mm-section-title.down{color:#5ca7ff}

      .mm-vertical-list{display:grid;grid-template-columns:1fr;gap:6px}
      .mm-row{display:grid;grid-template-columns:22px minmax(82px,1fr) minmax(44px,64px) 104px 56px;gap:4px;align-items:center;min-height:36px;padding:4px 6px;border:1px solid #1c3448;border-radius:8px;background:#081522;cursor:pointer;overflow:hidden;box-sizing:border-box}
      .mm-row:hover{background:#0d1e2d;border-color:#31526c}
      .mm-rank{font-weight:800;color:#6f8ca5;text-align:center;font-variant-numeric:tabular-nums;font-size:10px;white-space:nowrap}
      .mm-stock-name{min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-size:11px;font-weight:800}.mm-sector-inline{min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:#6f859a;font-size:9px;text-align:left}
      .mm-tools{display:flex;align-items:center;justify-content:flex-start;gap:1px;flex-wrap:nowrap;min-width:0;overflow:hidden}
      .mm-tools button,.mm-sector-tools button{position:static!important;margin:0!important;flex:0 0 auto!important}.mm-tools .watch-star,.mm-sector-tools .watch-star{width:20px!important;height:20px!important;min-width:20px!important;font-size:14px!important}.mm-tools .news-btn,.mm-tools .disclosure-btn,.mm-sector-tools .news-btn,.mm-sector-tools .disclosure-btn{height:20px!important;min-height:20px!important;padding:0 3px!important;font-size:9px!important}.mm-sector-edit{width:20px!important;height:20px!important;min-width:20px!important;padding:0!important;border:1px solid #28445b!important;border-radius:6px!important;background:#0d1d2b!important;color:#9bb4c8!important;font-size:10px!important;cursor:pointer}
      .mm-price{display:none}
      .mm-change{text-align:right;font-weight:800;font-size:10px;font-variant-numeric:tabular-nums;white-space:nowrap;min-width:0}
      .mm-change.up{color:#ff5964}.mm-change.down{color:#4e9dff}

      .mm-sector-vertical{display:grid;grid-template-columns:1fr;gap:8px}
      .mm-sector-card{border:0;background:transparent;border-radius:0;padding:0;min-width:0}
      .mm-sector-head{display:flex;justify-content:space-between;gap:8px;align-items:center;margin:2px 2px 7px;min-width:0}
      .mm-sector-head b{font-size:13px;min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
      .mm-sector-count{display:inline-flex;min-width:24px;height:22px;align-items:center;justify-content:center;border-radius:999px;background:#11283a;color:#8fd7ff;font-size:10px;font-weight:800}
      .mm-sector-stocks{display:grid;grid-template-columns:1fr;gap:5px}
      .mm-sector-stock{display:grid;grid-template-columns:30px minmax(72px,1fr) minmax(42px,62px) auto 58px;gap:4px;align-items:center;min-height:38px;padding:5px 6px;border:1px solid #1c3448;border-radius:8px;background:#081522;cursor:pointer;overflow:hidden;box-sizing:border-box}
      .mm-sector-stock:hover{background:#173249}
      .mm-sector-rank{font-weight:800;color:#6f8ca5;text-align:center;font-size:10px;white-space:nowrap}
      .mm-sector-name{min-width:0;max-width:100%;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-size:11px;font-weight:800}.mm-sector-label{min-width:0;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;color:#6f859a;font-size:9px}
      .mm-sector-tools{display:flex;align-items:center;gap:2px;flex-wrap:nowrap;min-width:0;overflow:visible}
      .mm-sector-change{text-align:right;font-weight:800;font-size:11px;font-variant-numeric:tabular-nums;white-space:nowrap}
      .mm-sector-change.up{color:#ff6873}.mm-sector-change.down{color:#5ca7ff}.mm-sector-stock .mm-sector-tools{min-width:0;overflow:hidden}.mm-sector-stock .mm-sector-tools button{max-width:52px}

      @media(max-width:1180px){.mm-row{grid-template-columns:20px minmax(72px,1fr) minmax(40px,56px) 96px 52px}.mm-stock-name{font-size:10px}.mm-sector-inline{font-size:8.5px}.mm-change{font-size:9.5px}}
      @media(max-width:1280px){.mm-row{grid-template-columns:24px minmax(78px,1fr) minmax(44px,62px) 104px 58px}.mm-tools{gap:1px}.mm-tools .news-btn,.mm-tools .disclosure-btn{padding:0 3px!important}}
      @media(max-width:860px){
        .mm-three-columns{grid-template-columns:1fr}
        .mm-column{border-right:0;border-bottom:1px solid #1c3042}
        .mm-column:last-child{border-bottom:0}
        .mm-row{grid-template-columns:34px minmax(140px,1fr) auto 78px 68px}
        .mm-sector-stock{grid-template-columns:38px minmax(130px,1fr) auto 68px}
      }
      @media(max-width:680px){
        .mm-row{grid-template-columns:30px minmax(110px,1fr) auto 64px}
        .mm-row .mm-price{display:none}
        .mm-sector-stock{grid-template-columns:34px minmax(100px,1fr) auto 62px}
      }
    `;
    document.head.appendChild(st);
  }

  $('#marketMoversRefresh').onclick=()=>{
    refreshMarketMovers(true);
    refreshRealtimeRank(true);
  };
  return sec;
}

function marketMoverRowHtml(x){
  const change=Number(x.change_rate);
  const changeOk=Number.isFinite(change);
  const changeClass=changeOk?(change>0?'up':change<0?'down':''):'';
  const code=String(x.code||'');
  const name=String(x.name||code||'-');
  const sector=String(x.sector||'기타');

  return `<div class="mm-row" data-stock-action-code="${esc(code)}" data-stock-action-name="${esc(name)}">
    <span class="mm-rank">${Number(x.rank||0)||'-'}</span>
    <span class="mm-stock-name" title="${esc(name)}">${esc(name)}</span>
    <span class="mm-sector-inline" title="${esc(sector)}">${esc(sector)}</span>
    ${mmToolButtonsHtml({code,name,sector})}
    <span class="mm-change ${changeClass}">${changeOk?pct(change):'-'}</span>
  </div>`;
}

function realtimeRankSectorGroups(){
  const rows=(LIVE_RANK?.rows||[]).slice(0,20);
  const groups=new Map();

  rows.forEach((x,i)=>{
    const live=findStock(x.code)||{};
    const sector=String(live.sector||x.sector||'기타').trim()||'기타';
    const tags=[...new Set(sector.split(/[,;/|]+/).map(s=>s.trim()).filter(Boolean))];
    const used=tags.length?tags:['기타'];

    used.forEach(tag=>{
      if(!groups.has(tag))groups.set(tag,[]);
      groups.get(tag).push({...x,_rank:i+1,_sector:tag});
    });
  });

  return sectorSortGroups([...groups.entries()]
    .map(([sector,stocks])=>{const sorted=sectorSortItems(stocks);const changes=sorted.map(x=>sectorSortChange(x)).filter(Number.isFinite).filter(x=>x>-999000);return {sector,stocks:sorted,count:sorted.length,bestRank:Math.min(...sorted.map(x=>x._rank||999)),totalValue:sorted.reduce((a,x)=>a+Math.max(0,sectorSortValue(x)),0),avg:changes.length?changes.reduce((a,b)=>a+b,0)/changes.length:null}}));
}

function renderRealtimeRankSectorStrip(){
  const root=$('#marketMoversSectors');
  if(!root)return;
  const groups=realtimeRankSectorGroups();

  root.innerHTML=groups.map(g=>{
    const stocks=g.stocks.map(x=>{
      const code=String(x.code||'');
      const name=String(x.name||code||'-');
      const sector=String(g.sector||x._sector||'기타');
      const ch=Number(x.change);
      const cc=Number.isFinite(ch)?(ch>0?'up':ch<0?'down':''):'';

      return `<div class="mm-sector-stock" data-stock-action-code="${esc(code)}" data-stock-action-name="${esc(name)}">
        <span class="mm-sector-rank">${x._rank}위</span>
        <span class="mm-sector-name" title="${esc(name)}">${esc(name)}</span>
        <span class="mm-sector-label" title="${esc(sector)}">${esc(sector)}</span>
        <span class="mm-sector-tools">${watchStarHtml({code,name,sector})}<button class="watch-sector-edit sector-edit mm-sector-edit" type="button" data-sector-code="${esc(code)}" data-sector-current="${esc(sector)}" title="섹터 수정: ${esc(sector)}" aria-label="섹터 수정">✎</button>${newsButtonHtml(code,name)}${disclosureButtonHtml(code,name)}</span>
        <span class="mm-sector-change ${cc}">${Number.isFinite(ch)?pct(ch):'-'}</span>
      </div>`;
    }).join('');

    return `<div class="mm-sector-card">
      <div class="mm-sector-head"><b>${esc(g.sector)}</b><span class="mm-sector-count">${g.count}</span></div>
      <div class="mm-sector-stocks">${stocks}</div>
    </div>`;
  }).join('')||'<div class="empty">실시간 조회순위 TOP20 데이터가 없습니다.</div>';
}

function renderMarketMovers(){
  ensureMarketMoversBoard();
  const up=$('#marketMoversUp'),down=$('#marketMoversDown'),meta=$('#marketMoversMeta');
  if(!up||!down)return;

  const ups=(MARKET_MOVERS?.up||[]).slice(0,20);
  const downs=(MARKET_MOVERS?.down||[]).slice(0,20);

  up.innerHTML=ups.map(marketMoverRowHtml).join('')||'<div class="empty">상승 종목 데이터가 없습니다.</div>';
  down.innerHTML=downs.map(marketMoverRowHtml).join('')||'<div class="empty">하락 종목 데이터가 없습니다.</div>';

  renderRealtimeRankSectorStrip();

  if(meta){
    const t=MARKET_MOVERS?.updated_at?new Date(MARKET_MOVERS.updated_at).toLocaleTimeString():'대기';
    meta.textContent=`0177 거래대금순 상승·하락(ETF·ETN·스팩 제외) + 실시간 조회순위 TOP20 섹터 · ${t}${MARKET_MOVERS?.error?' · '+MARKET_MOVERS.error:''}`;
    meta.title=MARKET_MOVERS?.source||'';
  }

  bindNewsButtons();
  bindWatchStars();
  bindSectorEdits();
  if(typeof bindDisclosureButtons==='function')bindDisclosureButtons();
  bindStockActionClicks();
}

async function refreshMarketMovers(force=false){
  ensureMarketMoversBoard();
  if(!STATE?.connected){
    MARKET_MOVERS={up:[],down:[],sector_groups:[],updated_at:null,error:'키움 미연결'};
    renderMarketMovers();
    return;
  }
  try{
    const r=await fetch('/api/market-movers'+(force?'?force=1':''));
    const d=await r.json();
    if(!r.ok)throw Error(d.error||'0177 상승/하락 요청 실패');
    MARKET_MOVERS=d;
    renderMarketMovers();
  }catch(e){
    MARKET_MOVERS={...MARKET_MOVERS,error:e.message};
    renderMarketMovers();
  }
}

async function refreshRealtimeRank(force=false){if(!STATE?.connected){LIVE_RANK={rows:[],updated_at:null,source:'키움 ka00198 · 2초 확인',error:'키움 미연결'};renderRealtimeRank();return}try{const url='/api/realtime-rank'+(force?'?force=1':'');const r=await fetch(url);const d=await r.json();if(!r.ok)throw Error(d.error||'조회순위 요청 실패');LIVE_RANK=d;renderRealtimeRank();renderPanel();renderMain()}catch(e){LIVE_RANK={...LIVE_RANK,error:e.message};renderRealtimeRank()}}
async function refresh(force=false){return littoRefreshOnce('refresh',()=>refreshRead(force))}
async function refreshRead(){try{const r=await fetch('/api/state');const d=await r.json();render(d);const cs=$('#credentialStatus');const bc=loadBrowserCredentials();if(cs){const ver=d.autologin_version||'AUTOLOGIN';const fs=d.credential_files||{};const flag=(fs.native?'N':'')+(fs.powershell?'P':'');cs.textContent=d.connected?`${ver} · 자동 로그인 유지 중 · 저장됨${flag?' ['+flag+']':''}`:(d.credential_saved||bc)?`${ver} · 인증정보 저장됨 · 자동 로그인 준비${flag?' ['+flag+']':''}`:`${ver} · 저장된 인증정보 없음`;cs.title=d.credential_error||''}if(!d.connected)browserAutoLogin(d)}catch(e){$('#progress').textContent=e.message}}

let MARKET_ACTIONS={groups:{risk_designated:[],halt_preview:[],short_overheat_designated:[],warning_release_judgment:[],warning_preview_judgment:[],short_preview_judgment:[],warning_designated:[],warning_preview:[],short_overheat_preview:[]},updated_at:null,error:null};
function ensureMarketActionsBoard(){
  let sec=$('#market-actions');if(sec)return sec;
  const anchor=$('#realtime-rank')||$('#scanner');if(!anchor)return null;
  sec=document.createElement('section');sec.id='market-actions';sec.className='card market-actions-card';
  sec.innerHTML=`<div class="market-actions-head"><div><div class="eyebrow">KRX MARKET ACTIONS</div><h2>시장조치 · 오늘 유효상태</h2><div id="marketActionMeta" class="muted">1페이지 2초 상태동기화 · 공시 원천은 캐시 보호</div></div><button id="marketActionRefresh" class="ghost" type="button">새로고침</button></div>
  <div class="market-action-topgrid">
    <div class="market-action-col ma-risk"><div class="market-action-title">⚠ 투자위험 지정 <span id="maCountRisk">0</span></div><div id="maRisk" class="market-action-list"></div></div>
    <div class="market-action-col ma-halt"><div class="market-action-title">ⓘ 거래정지 예고 <span id="maCountHalt">0</span></div><div id="maHalt" class="market-action-list"></div></div>
    <div class="market-action-col ma-short-designated"><div class="market-action-title">● 단기과열 지정 <span id="maCountShortDesignated">0</span></div><div id="maShortDesignated" class="market-action-list"></div></div>
    <div class="market-action-col ma-judgment"><div class="judgment-block"><b>⏱ 투자경고 해제 판단일</b><div id="maWarningReleaseJudge" class="judgment-list"></div></div><div class="judgment-block"><b>▣ 투자경고 예고 판단일</b><div id="maWarningPreviewJudge" class="judgment-list"></div></div><div class="judgment-block"><b>↗ 단기과열 예고 판단일</b><div id="maShortPreviewJudge" class="judgment-list"></div></div></div>
  </div>
  <div class="market-action-bottomgrid">
    <div class="market-action-col ma-designated"><div class="market-action-title">● 투자경고 지정 종목 <span id="maCountDesignated">0</span></div><div id="maDesignated" class="market-action-list"></div></div>
    <div class="market-action-col ma-preview"><div class="market-action-title">● 투자경고 예고 종목 <span id="maCountPreview">0</span></div><div id="maPreview" class="market-action-list"></div></div>
    <div class="market-action-col ma-short"><div class="market-action-title">↗ 단기과열 예고 종목 <span id="maCountShort">0</span></div><div id="maShort" class="market-action-list"></div></div>
  </div>`;
  // Low-priority information board: keep it at the very bottom of the main content.
  anchor.parentElement.appendChild(sec);
  $('#marketActionRefresh').onclick=()=>refreshMarketActions(true);
  return sec;
}
function isKindUrl(u){try{const x=new URL(String(u||''));return x.protocol==='https:'&&(x.hostname==='kind.krx.co.kr'||x.hostname.endsWith('.kind.krx.co.kr'))}catch(_){return false}}
function kindCompanyUrl(code,name,sourceUrl){
  // 실제 KIND 공시 원문 URL이 있으면 그 원문을 그대로 연다.
  if(isKindUrl(sourceUrl))return String(sourceUrl);

  // 원문 링크가 없으면 KIND 종목 간편검색으로 이동한다.
  // 회사요약 URL을 임의 조립하지 않고, 종목코드 식별값과 종목명을 같이 넘긴다.
  const digits=String(code||'').replace(/\D/g,'').padStart(6,'0').slice(-6);
  const corp=String(name||'').trim();
  if(/^\d{6}$/.test(digits)&&digits!=='000000'){
    const isurCd=digits.slice(0,5);
    return `https://kind.krx.co.kr/disclosureSimpleSearch.do?method=disclosureSimpleSearchMain&isurCd=${encodeURIComponent(isurCd)}&searchCorpName=${encodeURIComponent(corp)}`;
  }
  return 'https://kind.krx.co.kr/disclosure/searchdisclosurebycorp.do?method=searchDisclosureByCorpMain';
}
function marketActionRow(x){const name=esc(x.name||'-'),rawName=String(x.name||''),code=String(x.code||''),day=x.day_no?`<b>${x.day_no}일차</b>`:'';const exact=isKindUrl(x.url);const kindUrl=kindCompanyUrl(code,rawName,x.url);const kind=`<a class="ma-kind" href="${esc(kindUrl)}" target="_blank" rel="noopener noreferrer" onclick="event.stopPropagation()" title="${name} ${exact?'KIND 해당 공시 원문':'KIND 회사정보'} 보기">KIND</a>`;const tools=code?`${newsButtonHtml(code,x.name)}${disclosureButtonHtml(code,x.name)}`:'';return `<div class="market-action-row" ${code?`data-chart-code="${esc(code)}" data-chart-name="${esc(rawName)}" title="클릭하면 차트 · 수급 · 호가 · 메모를 선택합니다"`:''}><div class="ma-main"><span class="ma-name stock-name">${name}</span>${day}${tools}</div><div class="ma-sub"><span>${esc(x.date||'')}</span><span>${esc(x.title||'')}</span>${kind}</div></div>`}
function judgmentText(rows){return (rows||[]).map(x=>`<div class="judgment-row"><strong>${Number(x.day_no||10)}일</strong><span>${esc(x.name||'-')}</span></div>`).join('')||'<div class="judgment-row empty-judge"><strong>10일</strong><span>-</span></div>'}
function renderMarketActions(){ensureMarketActionsBoard();const g=MARKET_ACTIONS?.groups||{};const paint=(id,countId,rows)=>{const el=$(id);if(!el)return;el.innerHTML=(rows||[]).map(marketActionRow).join('')||'<div class="empty ma-empty">-</div>';const c=$(countId);if(c)c.textContent=String((rows||[]).length)};
  paint('#maRisk','#maCountRisk',g.risk_designated||[]);
  paint('#maHalt','#maCountHalt',g.halt_preview||[]);
  paint('#maShortDesignated','#maCountShortDesignated',g.short_overheat_designated||[]);
  paint('#maDesignated','#maCountDesignated',g.warning_designated||[]);
  paint('#maPreview','#maCountPreview',g.warning_preview||[]);
  paint('#maShort','#maCountShort',g.short_overheat_preview||[]);
  const a=$('#maWarningReleaseJudge');if(a)a.innerHTML=judgmentText(g.warning_release_judgment||[]);
  const b=$('#maWarningPreviewJudge');if(b)b.innerHTML=judgmentText(g.warning_preview_judgment||[]);
  const c=$('#maShortPreviewJudge');if(c)c.innerHTML=judgmentText(g.short_preview_judgment||[]);
  const meta=$('#marketActionMeta');if(meta){const v=MARKET_ACTIONS.verification||{};const vt=v.date?(v.fallback_used?' · 09/16 검증값 보정':' · 09/16 검증 일치'):'';meta.textContent=`오늘 유효상태 · ${MARKET_ACTIONS.updated_at?new Date(MARKET_ACTIONS.updated_at).toLocaleTimeString():'대기'} · ${MARKET_ACTIONS.day_basis||'일차'}${vt}${MARKET_ACTIONS.error?' · '+MARKET_ACTIONS.error:''}`};bindChartClicks();bindNewsButtons()}
async function refreshMarketActions(force=false){ensureMarketActionsBoard();try{const r=await fetch('/api/market-actions'+(force?'?force=1':''));const d=await r.json();if(!r.ok)throw Error(d.error||'시장조치 조회 실패');MARKET_ACTIONS=d;renderMarketActions()}catch(e){MARKET_ACTIONS={...MARKET_ACTIONS,error:e.message};renderMarketActions()}}



/* LITTO daily screener history */
(function installScreenerHistory(){
  if(window.__littoScreenerHistoryInstalled)return;
  window.__littoScreenerHistoryInstalled=true;
  window.LITTO_SCREENER_HISTORY_ACTIVE=false;
  const escH=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
  const fmtMoney=v=>{const n=Number(v);if(!Number.isFinite(n))return '-';return Math.round(n).toLocaleString('ko-KR')+'억'};
  const fmtPrice=v=>{const n=Number(v);if(!Number.isFinite(n))return '-';return Math.round(n).toLocaleString('ko-KR')};
  const fmtPct=v=>{const n=Number(v);if(!Number.isFinite(n))return '-';return `${n>0?'+':''}${n.toFixed(2)}%`};
  let currentPanel='all';

  function ensureStyle(){
    if(document.getElementById('screenerHistoryStyle'))return;
    const st=document.createElement('style');st.id='screenerHistoryStyle';st.textContent=`
      .screener-history-sidebar-nav span{color:#7fd3ff}
      #screener-history-page{padding:0!important;overflow:hidden}
      .sh-head{display:flex;align-items:flex-start;justify-content:space-between;gap:18px;padding:20px 22px;border-bottom:1px solid #1c3042}
      .sh-head h2{margin:4px 0 4px;font-size:22px}.sh-head .muted{font-size:12px}
      .sh-controls{display:flex;align-items:center;gap:8px;flex-wrap:wrap}
      .sh-controls input{min-height:36px;padding:7px 10px;border:1px solid #2b4358;border-radius:9px;background:#091622;color:#dce8f3;color-scheme:dark}
      .sh-controls button{min-height:36px;padding:7px 12px;border:1px solid #2b4358;border-radius:9px;background:#0d1c2a;color:#dce8f3;font-weight:800;cursor:pointer}
      .sh-summary{display:flex;align-items:center;justify-content:space-between;gap:14px;padding:12px 22px;border-bottom:1px solid #172b3c;background:#081521}
      .sh-summary b{font-size:13px}.sh-summary span{color:#72879a;font-size:11px}
      .sh-panel-tabs{display:flex;gap:7px;flex-wrap:wrap;padding:12px 22px;border-bottom:1px solid #172b3c}
      .sh-panel-tab{border:1px solid #263e52;background:#0a1825;color:#8ea2b5;border-radius:999px;padding:6px 10px;font-size:11px;font-weight:800;cursor:pointer}
      .sh-panel-tab.active{border-color:#3e8cc5;background:#0e2a3e;color:#bfeaff}
      .sh-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px;padding:14px 16px 20px}
      .sh-row{min-width:0;border:1px solid #1f3548;border-radius:12px;background:#091722;padding:12px 13px}
      .sh-row-top{display:flex;align-items:center;gap:8px;min-width:0}
      .sh-panel-badge{flex:0 0 auto;padding:3px 7px;border-radius:999px;border:1px solid #31516a;background:#0d2233;color:#8dd5ff;font-size:10px;font-weight:900}
      .sh-stock{min-width:0;font-size:14px;color:#eef5fb;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
      .sh-code{color:#667d91;font-size:10px;flex:0 0 auto}.sh-sector{margin-left:auto;color:#8ca0b2;font-size:10px;white-space:nowrap}
      .sh-metrics{display:grid;grid-template-columns:repeat(4,minmax(0,1fr));gap:7px;margin-top:10px}
      .sh-metric{min-width:0;padding:7px 8px;border-radius:8px;background:#0d1d2a}
      .sh-metric span{display:block;color:#6d8294;font-size:9px;margin-bottom:2px}.sh-metric b{font-size:12px;color:#dce8f3;white-space:nowrap}
      .sh-metric b.up{color:#ff6978}.sh-metric b.down{color:#61a1ff}
      .sh-times{display:flex;justify-content:space-between;gap:10px;margin-top:8px;color:#62778a;font-size:9px}
      .sh-empty,.sh-loading{padding:55px 20px;text-align:center;color:#6f8396}
      @media(max-width:1050px){.sh-grid{grid-template-columns:1fr}.sh-head{flex-direction:column}.sh-metrics{grid-template-columns:repeat(2,minmax(0,1fr))}}
    `;document.head.appendChild(st);
  }

  function ensureSidebar(){
    const side=document.querySelector('.sidebar .side-nav');if(!side)return null;
    let btn=document.querySelector('.screener-history-sidebar-nav');if(btn)return btn;
    btn=document.createElement('button');btn.type='button';btn.className='nav-item screener-history-sidebar-nav';
    btn.innerHTML='<span>▤</span><b>검색 이력</b>';
    // 검색 이력은 스캐너 메뉴들의 가장 아래에 배치한다.
    side.appendChild(btn);
    btn.addEventListener('click',e=>{e.preventDefault();e.stopPropagation();openHistory()});
    return btn;
  }

  function ensurePage(){
    ensureStyle();
    const main=document.querySelector('.workspace main')||document.querySelector('main');if(!main)return null;
    let sec=document.getElementById('screener-history-page');if(sec)return sec;
    sec=document.createElement('section');sec.id='screener-history-page';sec.className='card litto-page-hidden';
    sec.innerHTML=`<div class="sh-head"><div><div class="eyebrow">DAILY SCREENER HISTORY · SQLITE</div><h2>검색 이력</h2><div class="muted">매일 스크리너에 잡힌 종목을 자동 누적 저장합니다.</div></div><div class="sh-controls"><input id="shDate" type="date"><button id="shToday" type="button">최근 날짜</button><button id="shRefresh" type="button">새로고침</button></div></div><div class="sh-summary"><b id="shSummary">저장 데이터 확인 중</b><span id="shStorage">AppData · LITTO</span></div><div id="shPanelTabs" class="sh-panel-tabs"></div><div id="shRows" class="sh-grid"><div class="sh-loading">검색 이력을 불러오는 중...</div></div>`;
    main.insertBefore(sec,main.firstElementChild?.nextSibling||null);
    sec.querySelector('#shDate').addEventListener('change',()=>{currentPanel='all';refreshHistory()});
    sec.querySelector('#shToday').addEventListener('click',()=>{sec.querySelector('#shDate').value='';currentPanel='all';refreshHistory()});
    sec.querySelector('#shRefresh').addEventListener('click',()=>refreshHistory());
    return sec;
  }

  function timeOnly(v){if(!v)return '-';try{return new Date(v).toLocaleTimeString('ko-KR',{hour:'2-digit',minute:'2-digit'})}catch(_e){return String(v).slice(11,16)}}

  function render(data){
    const sec=ensurePage();if(!sec)return;
    const date=sec.querySelector('#shDate');
    if(data.date)date.value=data.date;
    const panels=Array.isArray(data.panels)?data.panels:[];
    const total=panels.reduce((s,x)=>s+Number(x.count||0),0);
    sec.querySelector('#shSummary').textContent=data.date?`${data.date} · 전체 ${total}종목 · 현재 ${data.count||0}건`:'아직 저장된 검색 이력이 없습니다.';
    if(data.db_path)sec.querySelector('#shStorage').textContent='저장: '+data.db_path;
    sec.querySelector('#shPanelTabs').innerHTML=[`<button type="button" class="sh-panel-tab ${currentPanel==='all'?'active':''}" data-sh-panel="all">전체 ${total}</button>`,...panels.map(x=>`<button type="button" class="sh-panel-tab ${currentPanel===x.panel_name?'active':''}" data-sh-panel="${escH(x.panel_name)}">${escH(x.panel_name)} ${x.count}</button>`)].join('');
    sec.querySelectorAll('[data-sh-panel]').forEach(b=>b.onclick=()=>{currentPanel=b.dataset.shPanel;refreshHistory()});
    const rows=Array.isArray(data.rows)?data.rows:[],root=sec.querySelector('#shRows');
    if(!rows.length){root.innerHTML='<div class="sh-empty">선택한 날짜/검색기의 저장 결과가 없습니다.</div>';return}
    root.innerHTML=rows.map(r=>{const ch=Number(r.change_rate),cc=Number.isFinite(ch)?(ch>0?'up':ch<0?'down':''):'';return `<article class="sh-row"><div class="sh-row-top"><span class="sh-panel-badge">${escH(r.panel_name)}</span><b class="sh-stock">${escH(r.stock_name||r.stock_code)}</b><span class="sh-code">${escH(r.stock_code)}</span><span class="sh-sector">${escH(r.sector||'미분류')}</span></div><div class="sh-metrics"><div class="sh-metric"><span>당시 가격</span><b>${fmtPrice(r.price)}</b></div><div class="sh-metric"><span>등락률</span><b class="${cc}">${fmtPct(r.change_rate)}</b></div><div class="sh-metric"><span>거래대금</span><b>${fmtMoney(r.value_eok)}</b></div><div class="sh-metric"><span>포착 횟수</span><b>${Number(r.hit_count||1).toLocaleString('ko-KR')}회</b></div></div><div class="sh-times"><span>첫 포착 ${timeOnly(r.first_seen_at)}</span><span>마지막 ${timeOnly(r.last_seen_at)}</span></div></article>`}).join('');
  }

  async function refreshHistory(){
    const sec=ensurePage();if(!sec)return;
    sec.querySelector('#shRows').innerHTML='<div class="sh-loading">검색 이력을 불러오는 중...</div>';
    const q=new URLSearchParams(),day=sec.querySelector('#shDate').value;
    if(day)q.set('date',day);if(currentPanel!=='all')q.set('panel',currentPanel);q.set('limit','2000');
    try{const r=await fetch('/api/screener-history?'+q.toString(),{cache:'no-store'}),d=await r.json();if(!r.ok)throw Error(d.error||'검색 이력 조회 실패');render(d)}
    catch(e){sec.querySelector('#shRows').innerHTML=`<div class="sh-empty">${escH(e.message)}</div>`}
  }

  function openHistory(){
    if(typeof LITTO_PAGE!=='undefined'&&LITTO_PAGE!=='trade'&&typeof switchLittoPage==='function')switchLittoPage('trade');
    window.LITTO_SCREENER_HISTORY_ACTIVE=true;try{SCANNER_RESULTS_ACTIVE=false}catch(_e){}
    ensurePage();applyTradeSubtab();
    document.querySelectorAll('.sidebar .nav-item,.sidebar .watch-sidebar-nav').forEach(x=>x.classList.remove('active'));
    ensureSidebar()?.classList.add('active');window.scrollTo({top:0,behavior:'smooth'});refreshHistory();
  }

  function init(){
    ensureSidebar();ensurePage();
    document.addEventListener('click',e=>{
      if(!window.LITTO_SCREENER_HISTORY_ACTIVE)return;
      if(e.target.closest?.('.screener-history-sidebar-nav,#screener-history-page'))return;
      const nav=e.target.closest?.('.sidebar .nav-item,.sidebar .watch-sidebar-nav[data-trade-watch],.litto-pagebtn');
      if(!nav)return;
      leaveScreenerHistory();
      // 이벤트는 막지 않는다. 실제 이동은 기존 메뉴 로직이 처리한다.
    },true);
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();


function leaveScreenerHistory(){
  try{window.LITTO_SCREENER_HISTORY_ACTIVE=false}catch(_e){}
  try{document.getElementById('screener-history-page')?.classList.add('litto-page-hidden')}catch(_e){}
}

function restoreMainScannerView(){
  try{if(typeof closeAccountScreen==='function')closeAccountScreen()}catch(_e){}
  leaveScreenerHistory();
  try{document.getElementById('screener-history-page')?.classList.add('litto-page-hidden')}catch(_e){}

  try{
    if(typeof LITTO_PAGE!=='undefined' && LITTO_PAGE!=='trade' && typeof switchLittoPage==='function'){
      switchLittoPage('trade');
    }
  }catch(_e){}

  try{
    TRADE_SUBTAB='scanner';
    localStorage.setItem('litto_trade_subtab_v1','scanner');
  }catch(_e){}

  try{SCANNER_RESULTS_ACTIVE=false}catch(_e){}
  try{if(typeof ensureTradeSubtabs==='function')ensureTradeSubtabs()}catch(_e){}
  try{if(typeof applyTradeSubtab==='function')applyTradeSubtab()}catch(_e){}
  try{if(typeof syncTradeSidebarNav==='function')syncTradeSidebarNav()}catch(_e){}

  // applyTradeSubtab 이후에도 history가 혹시 다시 보이는 경우를 차단.
  try{
    document.getElementById('screener-history-page')?.classList.add('litto-page-hidden');
    document.getElementById('watchlist-page')?.classList.add('litto-page-hidden');
    document.getElementById('scanner-results-page')?.classList.add('litto-page-hidden');
  }catch(_e){}

  try{window.scrollTo({top:0,behavior:'smooth'})}catch(_e){}
}

function ensurePremarketSitesUI(){
  const loginBtn=document.getElementById('kiwoomLoginBtn');
  if(!loginBtn)return;

  if(!document.getElementById('premarketSitesStyle')){
    const st=document.createElement('style');
    st.id='premarketSitesStyle';
    st.textContent=`
      #premarketSitesBtn{
        display:inline-flex;align-items:center;gap:7px;
        margin-left:8px;padding:8px 12px;
        border:1px solid #2c4359;border-radius:10px;
        background:#0b1825;color:#d7e4ef;
        font-size:12px;font-weight:800;cursor:pointer;
        white-space:nowrap;transition:.16s ease;
      }
      #premarketSitesBtn:hover{border-color:#4d718e;background:#102338;transform:translateY(-1px)}
      #premarketSitesBtn::before{content:'↗';color:#74c7ff;font-size:13px}

      #premarketSitesModal{position:fixed;inset:0;z-index:5200;display:none;align-items:center;justify-content:center;padding:24px}
      #premarketSitesModal.open{display:flex}
      .premarket-sites-backdrop{position:absolute;inset:0;background:rgba(2,6,12,.76);backdrop-filter:blur(5px)}
      .premarket-sites-dialog{
        position:relative;width:min(1040px,96vw);max-height:86vh;overflow:hidden;
        display:flex;flex-direction:column;
        background:#08131f;border:1px solid #294158;border-radius:18px;
        box-shadow:0 28px 80px rgba(0,0,0,.62)
      }
      .premarket-sites-head{
        display:flex;align-items:center;justify-content:space-between;gap:18px;
        padding:20px 22px 16px;border-bottom:1px solid #1b3042
      }
      .premarket-sites-head .eyebrow{margin-bottom:5px}
      .premarket-sites-head h2{margin:0;font-size:21px}
      .premarket-sites-head p{margin:5px 0 0;color:#74889d;font-size:12px}
      .premarket-sites-close{
        width:38px;height:38px;border:1px solid #2d465d;border-radius:10px;
        background:#0d1b29;color:#d7e4ef;font-size:18px;cursor:pointer
      }
      .premarket-sites-body{overflow:auto;padding:18px 20px 22px}
      .premarket-group{margin-bottom:20px}
      .premarket-group:last-child{margin-bottom:0}
      .premarket-group-title{
        display:flex;align-items:center;gap:9px;margin:0 0 10px;
        color:#9eb3c7;font-size:12px;font-weight:900;letter-spacing:.04em
      }
      .premarket-group-title::before{content:'';width:5px;height:16px;border-radius:4px;background:#54a9df}
      .premarket-site-grid{display:grid;grid-template-columns:repeat(2,minmax(0,1fr));gap:10px}
      .premarket-site{
        display:flex;align-items:center;gap:13px;min-width:0;padding:13px 14px;
        border:1px solid #21384b;border-radius:13px;background:#0b1723;
        color:inherit;text-decoration:none;transition:.15s ease
      }
      .premarket-site:hover{border-color:#3c6787;background:#102131;transform:translateY(-1px)}
      .premarket-site-icon{
        flex:0 0 38px;height:38px;border-radius:11px;
        display:flex;align-items:center;justify-content:center;
        border:1px solid #29445c;background:#102236;color:#8fd6ff;
        font-size:11px;font-weight:900;letter-spacing:.02em
      }
      .premarket-site-copy{min-width:0;display:flex;flex-direction:column;gap:3px}
      .premarket-site-copy b{color:#eef5fb;font-size:14px}
      .premarket-site-copy span{color:#8799aa;font-size:11px;line-height:1.45}
      .premarket-site-go{margin-left:auto;color:#5e7d97;font-size:18px;flex:0 0 auto}
      @media(max-width:760px){
        .premarket-site-grid{grid-template-columns:1fr}
        #premarketSitesModal{padding:10px}
        .premarket-sites-dialog{max-height:92vh}
      }
    `;
    document.head.appendChild(st);
  }

  let btn=document.getElementById('premarketSitesBtn');
  if(!btn){
    btn=document.createElement('button');
    btn.id='premarketSitesBtn';
    btn.type='button';
    btn.textContent='장전 확인 사이트';
    loginBtn.insertAdjacentElement('afterend',btn);
  }

  let modal=document.getElementById('premarketSitesModal');
  if(!modal){
    modal=document.createElement('div');
    modal.id='premarketSitesModal';
    modal.setAttribute('aria-hidden','true');
    modal.innerHTML=`
      <div class="premarket-sites-backdrop" data-premarket-close></div>
      <div class="premarket-sites-dialog" role="dialog" aria-modal="true" aria-labelledby="premarketSitesTitle">
        <div class="premarket-sites-head">
          <div>
            <div class="eyebrow">PRE-MARKET CHECKLIST</div>
            <h2 id="premarketSitesTitle">장전 확인 사이트</h2>
            <p>장 시작 전·주말·미국시장 흐름을 빠르게 확인하는 바로가기</p>
          </div>
          <button type="button" class="premarket-sites-close" data-premarket-close>✕</button>
        </div>
        <div class="premarket-sites-body">
          <section class="premarket-group">
            <h3 class="premarket-group-title">미국시장 · 심리</h3>
            <div class="premarket-site-grid">
              <a class="premarket-site" href="https://finviz.com/" target="_blank" rel="noopener noreferrer">
                <span class="premarket-site-icon">FV</span><span class="premarket-site-copy"><b>핀비즈</b><span>대표 미국주식 종목 상승·하락을 한눈에 확인</span></span><span class="premarket-site-go">↗</span>
              </a>
              <a class="premarket-site" href="https://edition.cnn.com/markets/fear-and-greed" target="_blank" rel="noopener noreferrer">
                <span class="premarket-site-icon">F&G</span><span class="premarket-site-copy"><b>Fear & Greed</b><span>미국시장 공포·탐욕 심리지표 확인</span></span><span class="premarket-site-go">↗</span>
              </a>
            </div>
          </section>

          <section class="premarket-group">
            <h3 class="premarket-group-title">국내시장 · 24시간 참고</h3>
            <div class="premarket-site-grid">
              <a class="premarket-site" href="https://kospilab.com/" target="_blank" rel="noopener noreferrer">
                <span class="premarket-site-icon">KL</span><span class="premarket-site-copy"><b>코스피랩</b><span>국내주식 시세 비교 대시보드 · SK하이닉스 24시간 토큰 움직임 참고</span></span><span class="premarket-site-go">↗</span>
              </a>
            </div>
          </section>

          <section class="premarket-group">
            <h3 class="premarket-group-title">주말시장</h3>
            <div class="premarket-site-grid">
              <a class="premarket-site" href="https://www.ig.com/en/indices/markets-indices/weekend-us-tech-100-e1" target="_blank" rel="noopener noreferrer">
                <span class="premarket-site-icon">NQ</span><span class="premarket-site-copy"><b>Weekend US Tech 100</b><span>주말 나스닥 계열 움직임 참고</span></span><span class="premarket-site-go">↗</span>
              </a>
              <a class="premarket-site" href="https://www.ig.com/en/indices/markets-indices/weekend-oil---us-crude" target="_blank" rel="noopener noreferrer">
                <span class="premarket-site-icon">OIL</span><span class="premarket-site-copy"><b>Weekend Oil</b><span>주말 미국 원유 움직임 참고</span></span><span class="premarket-site-go">↗</span>
              </a>
            </div>
          </section>

          <section class="premarket-group">
            <h3 class="premarket-group-title">개장 전 · 장중 미국시장</h3>
            <div class="premarket-site-grid">
              <a class="premarket-site" href="https://kr.investing.com/equities/pre-market" target="_blank" rel="noopener noreferrer">
                <span class="premarket-site-icon">PRE</span><span class="premarket-site-copy"><b>미국주식 프리마켓</b><span>개장 전 주요 미국주식 움직임 확인</span></span><span class="premarket-site-go">↗</span>
              </a>
              <a class="premarket-site" href="https://kr.investing.com/indices/nq-100-futures?cid=1175151" target="_blank" rel="noopener noreferrer">
                <span class="premarket-site-icon">NQ</span><span class="premarket-site-copy"><b>나스닥100 선물</b><span>장중 나스닥 선물 실시간 흐름 확인</span></span><span class="premarket-site-go">↗</span>
              </a>
            </div>
          </section>
        </div>
      </div>
    `;
    document.body.appendChild(modal);
  }

  const open=()=>{modal.classList.add('open');modal.setAttribute('aria-hidden','false')};
  const close=()=>{modal.classList.remove('open');modal.setAttribute('aria-hidden','true')};

  btn.onclick=open;
  modal.querySelectorAll('[data-premarket-close]').forEach(x=>x.onclick=close);
  if(!modal.dataset.keyBound){
    modal.dataset.keyBound='1';
    window.addEventListener('keydown',e=>{if(e.key==='Escape'&&modal.classList.contains('open'))close()});
  }
}

function openKiwoomLoginModal(){
  const m=$('#kiwoomLoginModal');if(!m)return;
  m.classList.add('open');m.setAttribute('aria-hidden','false');document.body.classList.add('kiwoom-login-open');
  setTimeout(()=>$('#appkey')?.focus(),50);
}
function closeKiwoomLoginModal(){
  const m=$('#kiwoomLoginModal');if(!m)return;
  m.classList.remove('open');m.setAttribute('aria-hidden','true');document.body.classList.remove('kiwoom-login-open');
}
const _kiwoomClose=$('#kiwoomLoginClose');if(_kiwoomClose)_kiwoomClose.onclick=closeKiwoomLoginModal;
$$('[data-kiwoom-close]').forEach(x=>x.onclick=closeKiwoomLoginModal);
window.addEventListener('keydown',e=>{if(e.key==='Escape'&&$('#kiwoomLoginModal')?.classList.contains('open'))closeKiwoomLoginModal()});

$('#connect').onclick=async()=>{const appkey=$('#appkey').value.trim(),secretkey=$('#secret').value.trim();try{const next=await api('/api/connect',{appkey,secretkey,mock:false,remember:true});saveBrowserCredentials(appkey,secretkey);AUTOLOGIN_TRIED=true;render(next);$('#appkey').value='';$('#secret').value='';const cs=$('#credentialStatus');if(cs)cs.textContent='자동 로그인 유지 중 · App Key / Secret Key 저장됨';setTimeout(()=>refreshRealtimeRank(true),300)}catch(e){alert(e.message)}};$('#disconnect').onclick=async()=>{try{render(await api('/api/disconnect',{}))}catch(e){alert(e.message)}};$('#forgetCredentials').onclick=async()=>{if(!confirm('이 PC에 저장된 App Key / Secret Key를 삭제할까요?'))return;try{clearBrowserCredentials();AUTOLOGIN_TRIED=true;render(await api('/api/forget-credentials',{}));$('#credentialStatus').textContent='저장된 인증정보 없음'}catch(e){alert(e.message)}};$('#demo').onclick=async()=>{try{render(await api('/api/demo',{}))}catch(e){alert(e.message)}};$('#scan').onclick=()=>{runScan(false)};$('#cancel').onclick=async()=>{try{render(await api('/api/cancel',{}))}catch(e){alert(e.message)}};$('#sectorSync').onclick=async()=>{if(!confirm('전 종목 업종을 자동 동기화할까요? 최초 실행은 몇 분 걸릴 수 있습니다. 사용자 직접 지정 섹터는 유지됩니다.'))return;try{render(await api('/api/sector-sync',{}))}catch(e){alert(e.message)}};$('#q').oninput=renderMain;$('#sector').onchange=renderMain;$('#chartClose').onclick=closeChart;$$('[data-close-chart]').forEach(x=>x.onclick=closeChart);$$('.charttf').forEach(b=>b.onclick=async()=>{const next=b.dataset.tf||'daily';if(!(await ensureGeneralChartTimeframe(next)))return;chartTf=next;$$('.charttf').forEach(x=>x.classList.toggle('active',x===b));drawChart()});window.addEventListener('resize',()=>{if(chartStock)drawChart()});window.addEventListener('keydown',e=>{if(e.key==='Escape'){if(chartStock)closeChart();closeNews()}});const rr=$('#rankRefresh');if(rr)rr.onclick=()=>refreshRealtimeRank(true);installAutoScanButton();hideFullAnalysisResult();ensureInlineScannerHidden();ensureV12HeaderPolish();applyLittoV12Branding();function latencyCriticalViewOpen(){
  const ob=$('#orderbookModal');
  const flow=$('#investorFlowModal');
  const news=$('#newsModal');
  const watchAdd=$('#watchManualModal');
  return !!(
    (ob && !ob.hidden) ||
    (flow && !flow.hidden && (flow.classList.contains('open') || getComputedStyle(flow).display!=='none')) ||
    (news && news.classList.contains('open')) ||
    (watchAdd && watchAdd.classList.contains('open'))
  );
}
refresh();
setInterval(()=>{if(!latencyCriticalViewOpen())refresh()},3000);
setTimeout(()=>refreshRealtimeRank(true),1200);
setInterval(()=>{if(!latencyCriticalViewOpen())refreshRealtimeRank(false)},30000);
setTimeout(()=>refreshMarketMovers(true),1600);
setInterval(()=>{if(!latencyCriticalViewOpen())refreshMarketMovers(false)},30000);
setInterval(()=>{if(!latencyCriticalViewOpen())autoScanTick()},500);
setInterval(ensureV12HeaderPolish,5000);
setInterval(updateLittoHeaderClock,1000);
setTimeout(()=>refreshMarketActions(true),1800);
setInterval(()=>{if(!latencyCriticalViewOpen())refreshMarketActions(false)},10000);

function scrollRealtimeRankToTop(){
  const target=document.querySelector('#realtime-rank');
  if(!target)return;
  const sticky=document.querySelector('.litto-sticky-marketbar');
  const tradeTabs=document.querySelector('#tradeSubtabs, .trade-subtabs');
  const stickyH=sticky?.getBoundingClientRect().height||0;
  const tabsH=tradeTabs?.getBoundingClientRect().height||0;
  const offset=Math.max(150,stickyH+tabsH+18);
  const top=target.getBoundingClientRect().top+window.scrollY-offset;
  window.scrollTo({top:Math.max(0,top),behavior:'smooth'});
}
$$('[data-panel-jump]').forEach(b=>b.onclick=()=>activatePanel(b.dataset.panelJump));
$$('[data-jump="scanner"]').forEach(b=>b.onclick=()=>{
  restoreMainScannerView();
  $$('.nav-item').forEach(x=>x.classList.toggle('active',x.dataset.jump==='scanner'));
});
$$('[data-jump="realtime-rank"]').forEach(b=>b.onclick=()=>{
  restoreMainScannerView();
  setTimeout(()=>scrollRealtimeRankToTop(),0);
  $$('.nav-item').forEach(x=>x.classList.toggle('active',x.dataset.jump==='realtime-rank'));
});


// --- LITTO v1.2 관심종목: 실전매매 내부 서브탭 ---
const WATCHLIST_KEY='litto_watchlist_v1';
const WATCH_MEMO_KEY='litto_stock_memos_v1';
const LEGACY_WATCH_MEMO_KEY='litto_watch_memos_v1';
let TRADE_SUBTAB=localStorage.getItem('litto_trade_subtab_v1')||'scanner';
function loadWatchlist(){try{const raw=JSON.parse(localStorage.getItem(WATCHLIST_KEY)||'[]');return Array.isArray(raw)?raw:[]}catch(e){return []}}
function saveWatchlist(rows){localStorage.setItem(WATCHLIST_KEY,JSON.stringify(rows||[]))}
let WATCH_MANUAL_LIVE={};
let WATCH_MANUAL_LIVE_BUSY=false;
let WATCH_MANUAL_LIVE_AT=0;
function watchLive(item){const c=String(item?.code||item||'');return findStock(c)||WATCH_MANUAL_LIVE[c]||null}
async function refreshManualWatchLive(force=false){
  const missing=loadWatchlist().map(x=>String(x.code||'')).filter(Boolean).filter(c=>!findStock(c));
  if(!missing.length)return;
  const now=Date.now();if(WATCH_MANUAL_LIVE_BUSY||(!force&&now-WATCH_MANUAL_LIVE_AT<30000))return;
  WATCH_MANUAL_LIVE_BUSY=true;
  try{const r=await fetch('/api/watch-manual-live?codes='+encodeURIComponent(missing.join(','))+(force?'&force=1':''));const d=await r.json();if(!r.ok)throw Error(d.error||'관심종목 시세 조회 실패');(d.rows||[]).forEach(x=>{if(x?.code)WATCH_MANUAL_LIVE[String(x.code)]=x});WATCH_MANUAL_LIVE_AT=Date.now();renderWatchlistPage()}catch(e){console.warn('[LITTO] 수동 관심종목 시세 조회',e)}finally{WATCH_MANUAL_LIVE_BUSY=false}
}
function ensureWatchManualModal(){
  let modal=document.getElementById('watchManualModal');if(modal)return modal;
  modal=document.createElement('div');modal.id='watchManualModal';modal.className='watch-manual-modal';modal.innerHTML=`<div class="watch-manual-backdrop" data-watch-manual-close></div><div class="watch-manual-dialog"><div class="watch-manual-title"><div><b>+ 관심종목 수동 추가</b><span>종목명 또는 6자리 종목코드로 검색</span></div><button type="button" data-watch-manual-close>×</button></div><div class="watch-manual-search"><input id="watchManualQuery" type="text" autocomplete="off" placeholder="예: NAVER 또는 035420"><button id="watchManualSearchBtn" type="button">검색</button></div><div id="watchManualResults" class="watch-manual-results"><div class="watch-manual-empty">추가할 종목을 검색하세요.</div></div></div>`;
  document.body.appendChild(modal);
  modal.querySelectorAll('[data-watch-manual-close]').forEach(x=>x.onclick=()=>modal.classList.remove('open'));
  const input=modal.querySelector('#watchManualQuery'),btn=modal.querySelector('#watchManualSearchBtn');
  btn.onclick=()=>searchWatchManualStock();input.onkeydown=e=>{if(e.key==='Enter')searchWatchManualStock()};return modal
}
function openWatchManualAdd(){const m=ensureWatchManualModal();m.classList.add('open');const i=m.querySelector('#watchManualQuery');i.value='';m.querySelector('#watchManualResults').innerHTML='<div class="watch-manual-empty">추가할 종목을 검색하세요.</div>';setTimeout(()=>i.focus(),30)}
async function searchWatchManualStock(){const m=ensureWatchManualModal(),q=m.querySelector('#watchManualQuery').value.trim(),root=m.querySelector('#watchManualResults');if(!q){root.innerHTML='<div class="watch-manual-empty">종목명 또는 종목코드를 입력하세요.</div>';return}root.innerHTML='<div class="watch-manual-empty">검색 중...</div>';try{const url='/api/stock-search?q='+encodeURIComponent(q);let r;try{r=await fetch(url,{cache:'no-store'})}catch(e){await new Promise(res=>setTimeout(res,250));r=await fetch(url,{cache:'no-store'})}const d=await r.json();if(!r.ok)throw Error(d.error||'종목 검색 실패');const rows=d.rows||[];if(!rows.length){root.innerHTML='<div class="watch-manual-empty">검색 결과가 없습니다.</div>';return}root.innerHTML=rows.map(x=>{const on=isWatched(x.code);return `<div class="watch-manual-result"><div class="watch-manual-result-info" data-stock-action-code="${esc(x.code)}" data-stock-action-name="${esc(x.name)}" title="클릭하면 차트 · 수급 · 호가 · 체크리스트 · 메모를 선택합니다"><b>${esc(x.name)}</b><span>${esc(x.code)} · ${esc(x.sector||'기타')}</span></div><button type="button" data-watch-manual-code="${esc(x.code)}" data-watch-manual-name="${esc(x.name)}" data-watch-manual-sector="${esc(x.sector||'기타')}" ${on?'disabled':''}>${on?'추가됨':'+ 추가'}</button></div>`}).join('');bindStockActionClicks();root.querySelectorAll('[data-watch-manual-code]').forEach(b=>b.onclick=e=>{e.stopPropagation();const row={code:b.dataset.watchManualCode,name:b.dataset.watchManualName,sector:b.dataset.watchManualSector};if(!isWatched(row.code))toggleWatch(row);b.disabled=true;b.textContent='추가됨';refreshManualWatchLive(true)})}catch(e){root.innerHTML=`<div class="watch-manual-empty">${esc(e.message)}</div>`}}
function loadWatchMemos(){try{let txt=localStorage.getItem(WATCH_MEMO_KEY);if(!txt){const legacy=localStorage.getItem(LEGACY_WATCH_MEMO_KEY);if(legacy){txt=legacy;localStorage.setItem(WATCH_MEMO_KEY,legacy)}}const raw=JSON.parse(txt||'{}');return raw&&typeof raw==='object'&&!Array.isArray(raw)?raw:{}}catch(e){return {}}}
function watchMemo(code){const m=loadWatchMemos();return String(m[String(code)]||'')}
function saveWatchMemo(code,text){const c=String(code||'').trim();if(!c)return;const m=loadWatchMemos();m[c]=String(text||'').trim();localStorage.setItem(WATCH_MEMO_KEY,JSON.stringify(m));renderWatchlistPage()}
function deleteWatchMemo(code){const c=String(code||'').trim();if(!c)return;const m=loadWatchMemos();delete m[c];localStorage.setItem(WATCH_MEMO_KEY,JSON.stringify(m));renderWatchlistPage()}
function ensureWatchMemoModal(){let m=document.getElementById('watchMemoModal');if(m)return m;m=document.createElement('div');m.id='watchMemoModal';m.className='watch-memo-modal';m.innerHTML=`<div class="watch-memo-backdrop" data-watch-memo-close></div><div class="watch-memo-dialog"><div class="watch-memo-head"><div><b id="watchMemoTitle">종목 메모</b><span>어느 화면의 종목이든 메모할 수 있으며, 직접 삭제하기 전까지 이 PC에 계속 저장됩니다.</span></div><button type="button" data-watch-memo-close>×</button></div><textarea id="watchMemoText" maxlength="500" placeholder="예: 20일선 지지 확인 / 18만원 부근 1차 지지 / 실적 발표 전 추격 금지"></textarea><div class="watch-memo-actions"><button id="watchMemoDelete" class="danger" type="button">메모 삭제</button><div><button type="button" data-watch-memo-close>취소</button><button id="watchMemoSave" class="primary" type="button">저장</button></div></div></div>`;document.body.appendChild(m);m.querySelectorAll('[data-watch-memo-close]').forEach(x=>x.onclick=()=>m.classList.remove('open'));return m}
function openWatchMemo(code,name){const c=String(code||'');if(!c)return;const m=ensureWatchMemoModal();m.style.zIndex='220000';m.dataset.code=c;m.querySelector('#watchMemoTitle').textContent=`${name||c} 메모`;const t=m.querySelector('#watchMemoText');t.value=watchMemo(c);m.querySelector('#watchMemoSave').onclick=()=>{saveWatchMemo(c,t.value);m.classList.remove('open')};m.querySelector('#watchMemoDelete').onclick=()=>{if(!watchMemo(c)){m.classList.remove('open');return}if(confirm('이 종목의 메모를 삭제할까요?')){deleteWatchMemo(c);m.classList.remove('open')}};m.classList.add('open');setTimeout(()=>{t.focus();t.setSelectionRange(t.value.length,t.value.length)},30)}
function bindWatchMemoButtons(root=document){root.querySelectorAll?.('[data-watch-memo]').forEach(btn=>{btn.onclick=e=>{e.preventDefault();e.stopPropagation();openWatchMemo(btn.dataset.watchMemo,btn.dataset.watchMemoName)}})}
function isWatched(code){return loadWatchlist().some(x=>String(x.code)===String(code))}
function watchSnapshot(row){const s=findStock(row?.code)||row||{};return {code:String(s.code||row?.code||''),name:String(s.name||row?.name||s.code||''),sector:String(s.sector||row?.sector||'기타'),added_at:new Date().toISOString()}}
function toggleWatch(row){const code=String(row?.code||'');if(!code)return;let rows=loadWatchlist();const idx=rows.findIndex(x=>String(x.code)===code);if(idx>=0)rows.splice(idx,1);else rows.unshift(watchSnapshot(row));saveWatchlist(rows);syncWatchStars();renderWatchlistPage()}
function watchStarHtml(row){const code=String(row?.code||'');if(!code)return '';const on=isWatched(code);return `<button class="watch-star${on?' active':''}" type="button" data-watch-code="${esc(code)}" data-watch-name="${esc(row?.name||code)}" data-watch-sector="${esc(row?.sector||'기타')}" title="${on?'관심종목에서 제거':'관심종목에 추가'}" aria-label="${on?'관심종목에서 제거':'관심종목에 추가'}">${on?'★':'☆'}</button>`}
function bindWatchStars(root=document){root.querySelectorAll?.('[data-watch-code]').forEach(btn=>{btn.onclick=e=>{e.preventDefault();e.stopPropagation();toggleWatch({code:btn.dataset.watchCode,name:btn.dataset.watchName,sector:btn.dataset.watchSector})}})}
function syncWatchStars(){document.querySelectorAll('[data-watch-code]').forEach(btn=>{const on=isWatched(btn.dataset.watchCode);btn.classList.toggle('active',on);btn.textContent=on?'★':'☆';btn.title=on?'관심종목에서 제거':'관심종목에 추가'})}
function ensureTradeHeaderMarkets(){
  const host=$('#littoPageBar')||document.querySelector('.topbar');if(!host)return null;
  let strip=$('#headerMarketStrip');
  if(!strip){
    strip=document.createElement('div');strip.id='headerMarketStrip';strip.className='header-market-strip';
  }
  strip.classList.remove('trade-market-strip');
  const ensure=(id,label)=>{
    let b=$('#'+id);
    if(b)return b;
    const item=document.createElement('div');item.className='header-market-item';item.innerHTML=`<span>${label}</span><b id="${id}">--</b>`;
    const tm=$('#headerMarketTime');
    if(tm)strip.insertBefore(item,tm);else strip.appendChild(item);
    return item.querySelector('b');
  };
  ensure('headerKospi','KOSPI');
  ensure('headerKosdaq','KOSDAQ');
  ensure('headerKospiFutures','KOSPI200 선물');
  ensure('headerKosdaqFutures','KOSDAQ150 선물');
  ensure('headerNasdaqFutures','NASDAQ 선물');
  let tm=$('#headerMarketTime');if(!tm){tm=document.createElement('small');tm.id='headerMarketTime';tm.textContent='업데이트';strip.appendChild(tm)}
  if(strip.parentElement!==host)host.appendChild(strip);
  return strip;
}
function syncTradeStickyTop(){
  const t=$('#tradeSubtabs');if(!t)return;
  const p=$('#littoPageBar');
  let top=0;
  if(p){
    const r=p.getBoundingClientRect();
    if(r.bottom>0&&r.top<=window.innerHeight)top=Math.max(0,Math.round(r.bottom-1));
  }
  t.style.top=top+'px';
}
function ensureTradeStickyStyle(){
  if($('#tradeStickyV12Style'))return;
  const st=document.createElement('style');st.id='tradeStickyV12Style';st.textContent=`
    #tradeSubtabs.trade-subtabs{display:none!important}
    #littoPageBar #headerMarketStrip{display:flex!important}
    .watch-sidebar-nav b{display:flex;align-items:center;justify-content:space-between;gap:8px;width:100%}
    .watch-sidebar-count{display:inline-grid;place-items:center;min-width:20px;height:18px;padding:0 6px;border-radius:999px;background:#102a3c;color:#69d8ff;font-size:10px;font-weight:800;line-height:1}
  `;document.head.appendChild(st);
}
function ensureTradeSubtabs(){const main=document.querySelector('.workspace main')||document.querySelector('main');if(!main)return null;ensureTradeStickyStyle();let bar=$('#tradeSubtabs');if(!bar){bar=document.createElement('div');bar.id='tradeSubtabs';bar.className='trade-subtabs';bar.setAttribute('aria-hidden','true');bar.innerHTML=`<span id="watchCount" class="watch-count">0</span>`;const first=main.firstElementChild;main.insertBefore(bar,first)}ensureTradeHeaderMarkets();ensureWatchlistPage();bindTradeSidebarWatch();syncTradeSidebarNav();return bar}
function bindTradeSidebarWatch(){const btn=document.querySelector('.watch-sidebar-nav[data-trade-watch]');if(!btn||btn.dataset.bound==='1')return;btn.dataset.bound='1';btn.addEventListener('click',e=>{e.preventDefault();if(typeof LITTO_PAGE!=='undefined'&&LITTO_PAGE!=='trade'&&typeof switchLittoPage==='function')switchLittoPage('trade');switchTradeSubtab('watch');window.scrollTo({top:0,behavior:'smooth'})})}
function syncTradeSidebarNav(){const watch=document.querySelector('.watch-sidebar-nav[data-trade-watch]');const scanner=document.querySelector('.nav-item[data-jump="scanner"]');const isTrade=(typeof LITTO_PAGE==='undefined'||LITTO_PAGE==='trade');const isWatch=isTrade&&TRADE_SUBTAB==='watch';watch?.classList.toggle('active',isWatch);if(isWatch)scanner?.classList.remove('active')}
function ensureWatchlistPage(){const main=document.querySelector('.workspace main')||document.querySelector('main');if(!main)return null;let sec=$('#watchlist-page');if(sec)return sec;sec=document.createElement('section');sec.id='watchlist-page';sec.className='card watchlist-page litto-page-hidden';sec.innerHTML=`<div class="watch-head"><div><div class="eyebrow">MY WATCHLIST</div><div class="watch-title-row"><h2>★ 관심종목</h2><button id="watchManualAddBtn" class="watch-manual-add-btn" type="button">+ 종목 추가</button></div><div class="muted">섹터 · 거래대금 · 프로그램 · 변화 · 강도 · 전일비교를 한 화면에서 봅니다.</div></div><div class="watch-head-meta"><b id="watchTotal">0종목</b><span>이 PC에 저장</span></div></div><div id="watchSectors" class="watch-sectors"></div><div class="watch-intel-grid"><section class="watch-intel-card watch-alert-card"><div class="watch-intel-head"><b>⚡ 오늘 변화</b><span id="watchAlertCount">0건</span></div><div id="watchAlerts" class="watch-intel-body"><div class="watch-intel-empty">변화 감지 대기</div></div></section><section class="watch-intel-card"><div class="watch-intel-head"><b>🏁 관심종목 강도 TOP</b><span>100점 기준</span></div><div id="watchScoreTop" class="watch-intel-body"></div></section><section class="watch-intel-card"><div class="watch-intel-head"><b>↔ 전일 대비</b><span id="watchPrevDayLabel">전일</span></div><div id="watchPrevCompare" class="watch-intel-body"></div></section></div>`;main.insertBefore(sec,main.firstElementChild?.nextSibling||null);const addBtn=sec.querySelector('#watchManualAddBtn');if(addBtn)addBtn.onclick=openWatchManualAdd;return sec}
let SCANNER_RESULTS_ACTIVE=false;
function switchTradeSubtab(tab){
  try{if(typeof closeAccountScreen==='function')closeAccountScreen()}catch(_e){}leaveScreenerHistory();SCANNER_RESULTS_ACTIVE=false;TRADE_SUBTAB=tab==='watch'?'watch':'scanner';localStorage.setItem('litto_trade_subtab_v1',TRADE_SUBTAB);ensureTradeSubtabs();applyTradeSubtab();syncTradeSidebarNav();if(TRADE_SUBTAB==='watch')renderWatchlistPage()}
function applyTradeSubtab(){if(typeof LITTO_PAGE!=='undefined'&&LITTO_PAGE!=='trade')return;const main=document.querySelector('.workspace main')||document.querySelector('main');if(!main)return;const historyActive=!!window.LITTO_SCREENER_HISTORY_ACTIVE;const special=new Set(['tradeSubtabs','watchlist-page','scanner-results-page','screener-history-page','market-actions','market-overview','us-market','journal-page']);const hideNormal=TRADE_SUBTAB==='watch'||SCANNER_RESULTS_ACTIVE||historyActive;[...main.children].forEach(el=>{if(special.has(el.id))return;el.classList.toggle('litto-page-hidden',hideNormal)});$('#watchlist-page')?.classList.toggle('litto-page-hidden',TRADE_SUBTAB!=='watch'||SCANNER_RESULTS_ACTIVE||historyActive);$('#scanner-results-page')?.classList.toggle('litto-page-hidden',!SCANNER_RESULTS_ACTIVE||historyActive);$('#screener-history-page')?.classList.toggle('litto-page-hidden',!historyActive);$('#tradeSubtabs')?.classList.remove('litto-page-hidden')}
function watchDisplayRow(item){const live=watchLive(item);const q=live?liveCardQuote(live):null;const name=live?.name||item.name||item.code, sector=live?.sector||item.sector||'기타', change=q?.change, price=q?.price, value=live?.value_eok, tags=lookupTags(item.code);return `<div class="watch-row" data-watch-row="${esc(item.code)}"><button class="watch-star active" type="button" data-watch-code="${esc(item.code)}" data-watch-name="${esc(name)}" data-watch-sector="${esc(sector)}" title="관심종목에서 제거">★</button><div class="watch-stock-main-wrap"><button class="watch-stock-main" type="button" data-watch-open="${esc(item.code)}"><b>${esc(name)}</b><small>${esc(item.code)}</small></button><div class="stock-title-line">${newsButtonHtml(item.code,name)}${disclosureButtonHtml(item.code,name)}</div></div><div class="watch-price"><span>현재가</span><b>${Number.isFinite(Number(price))&&Number(price)>0?money(price):'-'}</b></div><div class="watch-change ${change==null?'':cls(change)}"><span>등락률</span><b>${change==null?'-':pct(change)}</b></div><div class="watch-value"><span>거래대금</span><b>${value!=null?`${money(value)}억`:'-'}</b></div><div class="watch-tags">${tags.length?tags.map(t=>`<span>${esc(t)}</span>`).join(''):'<span class="muted-tag">현재 검색식 없음</span>'}</div></div>`}
function watchChangeValue(item){const live=watchLive(item);const q=live?liveCardQuote(live):null;const n=Number(q?.change);return Number.isFinite(n)?n:null}
function watchValueEok(item){const live=watchLive(item);const n=Number(live?.value_eok);return Number.isFinite(n)&&n>0?n:0}
function watchCompactValueText(v){const n=Number(v);if(!Number.isFinite(n)||n<=0)return '-';if(n>=10000)return `${(n/10000).toFixed(n>=100000?0:1)}조`;return `${money(n)}억`}
let WATCH_PROGRAM_DATA={};
let WATCH_PROGRAM_FETCH_AT=0;
let WATCH_PROGRAM_FAIL_AT=0;
let WATCH_PROGRAM_BUSY=false;
let WATCH_PROGRAM_META={};
function watchProgramText(v){
  const n=Number(v);
  if(!Number.isFinite(n))return '프로그램 -';
  const sign=n>0?'+':'';
  const a=Math.abs(n);
  const body=a>=10000?`${(a/10000).toFixed(a>=100000?0:1)}조`:a>=1000?`${Math.round(a).toLocaleString('ko-KR')}억`:a>=10?`${Math.round(a).toLocaleString('ko-KR')}억`:`${a.toFixed(1)}억`;
  return `프로그램 ${sign}${body}`;
}
function watchProgramRatio(netEok,totalValueEok){
  const net=Number(netEok),total=Number(totalValueEok);
  if(!Number.isFinite(net)||!Number.isFinite(total)||total<=0)return null;
  return (net/total)*100;
}
function watchProgramFullText(netEok,totalValueEok){
  const base=watchProgramText(netEok);
  const ratio=watchProgramRatio(netEok,totalValueEok);
  if(ratio==null)return base;
  const sign=ratio>0?'+':'';
  const digits=Math.abs(ratio)>=10?1:2;
  return `${base} · ${sign}${ratio.toFixed(digits)}%`;
}
function paintWatchProgramFlow(){
  document.querySelectorAll('[data-watch-program-code]').forEach(el=>{
    const code=String(el.dataset.watchProgramCode||'');
    const row=WATCH_PROGRAM_DATA[code];
    const n=row?Number(row.program_net_eok):NaN;
    const total=watchValueEok({code});
    el.textContent=row?watchProgramFullText(n,total):'프로그램 -';
    el.title=row&&total>0?'프로그램 순매수/순매도 금액 ÷ 종목 전체 거래대금':'프로그램 순매수/순매도';
    el.classList.toggle('up',Number.isFinite(n)&&n>0);
    el.classList.toggle('down',Number.isFinite(n)&&n<0);
  });
}
async function refreshWatchProgramFlow(force=false){
  const codes=loadWatchlist().map(x=>String(x.code||'').trim()).filter(Boolean);
  if(!codes.length){WATCH_PROGRAM_DATA={};paintWatchProgramFlow();return}
  const now=Date.now();
  if(WATCH_PROGRAM_BUSY)return;
  if(!force&&now-WATCH_PROGRAM_FETCH_AT<20000){paintWatchProgramFlow();return}
  // A failed provider call can be temporary (weekend lookup, token refresh, rate gate).
  // Do not hammer Kiwoom on every re-render; keep any last good data visible.
  if(!force&&WATCH_PROGRAM_FAIL_AT&&now-WATCH_PROGRAM_FAIL_AT<15000){paintWatchProgramFlow();return}
  WATCH_PROGRAM_BUSY=true;
  const loadOnce=async(forceQuery=false)=>{
    const r=await fetch(`/api/program-flow-watch?codes=${encodeURIComponent(codes.join(','))}${forceQuery?'&force=1':''}`);
    let d={};
    try{d=await r.json()}catch(_){d={}}
    if(!r.ok)throw Error(d.error||`프로그램 수급 조회 실패 (${r.status})`);
    return d;
  };
  try{
    let d;
    try{d=await loadOnce(force)}catch(firstErr){
      // One forced retry only. This recovers stale cache/token/provider hiccups
      // without turning a watchlist render into repeated API traffic.
      await new Promise(resolve=>setTimeout(resolve,450));
      try{d=await loadOnce(true)}catch(secondErr){
        secondErr.message=`${secondErr.message}${firstErr?.message&&firstErr.message!==secondErr.message?` / 1차: ${firstErr.message}`:''}`;
        throw secondErr;
      }
    }
    WATCH_PROGRAM_DATA=d.rows||{};WATCH_PROGRAM_META=d||{};WATCH_PROGRAM_FETCH_AT=Date.now();WATCH_PROGRAM_FAIL_AT=0;
    if(Array.isArray(d.errors) && d.errors.length)console.warn('[LITTO] 관심종목 프로그램 수급 조회', d.errors);
    paintWatchProgramFlow();
    updateWatchIntelligence();
    const failed=new Set((d.failed_codes||[]).map(String));
    document.querySelectorAll('[data-watch-program-code]').forEach(el=>{
      const c=String(el.dataset.watchProgramCode||'');
      if(failed.has(c) && !WATCH_PROGRAM_DATA[c]){
        el.textContent='프로그램 조회실패';
        el.title=(d.errors||[]).slice(-3).join(' / ')||'키움 프로그램매매 응답에 해당 종목 데이터가 없습니다.';
      }
    });
  }catch(e){
    WATCH_PROGRAM_META={error:e.message};WATCH_PROGRAM_FAIL_AT=Date.now();
    console.warn('[LITTO] 관심종목 프로그램 수급 오류',e);
    // If we have a last successful snapshot, keep it on screen instead of
    // replacing every row with an error label.
    if(Object.keys(WATCH_PROGRAM_DATA||{}).length){
      paintWatchProgramFlow();
      document.querySelectorAll('[data-watch-program-code]').forEach(el=>{el.title=`최근 성공 데이터 유지 · 새 조회 실패: ${e.message||'프로그램 수급 조회 실패'}`});
    }else{
      document.querySelectorAll('[data-watch-program-code]').forEach(el=>{el.textContent='프로그램 재조회중';el.title=e.message||'프로그램 수급 조회 실패'});
      setTimeout(()=>refreshWatchProgramFlow(true),9000);
    }
  } finally{WATCH_PROGRAM_BUSY=false}
}

const WATCH_EVENTS_KEY='litto_watch_events_v2';
const WATCH_INTRADAY_KEY='litto_watch_intraday_v2';
const WATCH_DAILY_SNAPSHOT_KEY='litto_watch_daily_snapshot_v2';
const WATCH_PREV_SNAPSHOT_KEY='litto_watch_prev_snapshot_v2';
const WATCH_CHECK_KEY='litto_watch_check_v1';
const WATCH_TRACK_TAGS=['주도주 종배','주도주 상따','끼도주 종배','종배 우선순위','피뢰침','하트존','F존'];
function watchTradingDayKey(){try{const raw=STATE?.report?.asof;const d=raw?new Date(raw):new Date();if(Number.isNaN(d.getTime()))throw Error();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`}catch(e){return rankDayKey()}}
function watchJsonGet(k,fallback){try{const v=JSON.parse(localStorage.getItem(k)||'null');return v??fallback}catch(e){return fallback}}
function watchJsonSet(k,v){try{localStorage.setItem(k,JSON.stringify(v))}catch(e){}}
function watchPriorityRank(code){const p=STATE?.report?.search_panels?.panels?.['종배 우선순위']?.rows||[];const i=p.findIndex(x=>String(x.code)===String(code));return i>=0?i+1:null}
function watchMAs(stock){const bars=Array.isArray(stock?.daily)?stock.daily:[];const close=bars.map(x=>Number(x.close)).filter(Number.isFinite);const ma=n=>close.length>=n?close.slice(-n).reduce((a,b)=>a+b,0)/n:null;return {ma5:ma(5),ma20:ma(20),ma60:ma(60)}}
function watchPrevBear(stock){const bars=Array.isArray(stock?.daily)?stock.daily:[];if(bars.length<2)return null;const b=bars[bars.length-2];const o=Number(b?.open),c=Number(b?.close);return Number.isFinite(o)&&Number.isFinite(c)?c<o:null}
function watchSparkline(item){const s=watchLive(item)||{};let bars=Array.isArray(s.m15)&&s.m15.length?s.m15:Array.isArray(s.daily)?s.daily:[];bars=bars.slice(-24);const vals=bars.map(x=>Number(x.close)).filter(Number.isFinite);if(vals.length<2)return '<div class="watch-spark-empty">-</div>';const w=86,h=30,p=2,min=Math.min(...vals),max=Math.max(...vals),range=Math.max(1,max-min);const pts=vals.map((v,i)=>`${(p+i*(w-2*p)/(vals.length-1)).toFixed(1)},${(h-p-(v-min)/range*(h-2*p)).toFixed(1)}`).join(' ');const up=vals[vals.length-1]>=vals[0];return `<svg class="watch-spark ${up?'up':'down'}" viewBox="0 0 ${w} ${h}" preserveAspectRatio="none" aria-label="최근 미니차트"><polyline points="${pts}" fill="none" vector-effect="non-scaling-stroke"/></svg>`}
function watchMetric(item,sectorAvg=0,valueMax=1){const live=watchLive(item)||item||{},q=liveCardQuote(live)||{},change=Number(q.change),value=watchValueEok(item),tags=lookupTags(item.code),pf=WATCH_PROGRAM_DATA[String(item.code)]||{},pn=Number(pf.program_net_eok),pr=watchProgramRatio(pn,value);let score=0;const valuePart=valueMax>0?Math.min(25,25*Math.sqrt(Math.max(0,value)/valueMax)):0;score+=valuePart;const programPart=Number.isFinite(pr)?Math.max(0,Math.min(25,pr*5)):0;score+=programPart;let tagPart=0;if(tags.includes('종배 우선순위'))tagPart+=8;if(tags.includes('주도주 종배'))tagPart+=7;if(tags.includes('주도주 상따'))tagPart+=5;if(tags.includes('끼도주 종배'))tagPart+=3;if(tags.includes('하트존'))tagPart+=1;if(tags.includes('F존'))tagPart+=1;score+=Math.min(25,tagPart);const secPart=Math.max(0,Math.min(15,Number(sectorAvg||0)*1.5));score+=secPart;const momPart=Number.isFinite(change)?Math.max(0,Math.min(10,change)):0;score+=momPart;return {code:String(item.code),name:live.name||item.name||item.code,sector:live.sector||item.sector||'기타',change:Number.isFinite(change)?change:null,value,programNet:Number.isFinite(pn)?pn:null,programRatio:Number.isFinite(pr)?pr:null,tags,priorityRank:watchPriorityRank(item.code),score:Math.round(Math.min(100,score)),parts:{value:Math.round(valuePart),program:Math.round(programPart),tag:Math.round(Math.min(25,tagPart)),sector:Math.round(secPart),momentum:Math.round(momPart)}}}
function watchSnapshotRows(metrics){return Object.fromEntries(metrics.map(m=>[m.code,{code:m.code,name:m.name,sector:m.sector,change:m.change,value:m.value,programNet:m.programNet,programRatio:m.programRatio,tags:m.tags,priorityRank:m.priorityRank,score:m.score,at:Date.now()}]))}
function rotateWatchDailySnapshot(metrics){const day=watchTradingDayKey(),cur=watchJsonGet(WATCH_DAILY_SNAPSHOT_KEY,null);if(cur&&cur.day&&cur.day!==day){watchJsonSet(WATCH_PREV_SNAPSHOT_KEY,cur);watchJsonSet(WATCH_DAILY_SNAPSHOT_KEY,{day,rows:watchSnapshotRows(metrics),updated_at:Date.now()})}else{watchJsonSet(WATCH_DAILY_SNAPSHOT_KEY,{day,rows:watchSnapshotRows(metrics),updated_at:Date.now()})}}
function pushWatchEvent(ev){let pack=watchJsonGet(WATCH_EVENTS_KEY,{day:watchTradingDayKey(),rows:[]});const day=watchTradingDayKey();if(pack.day!==day)pack={day,rows:[]};const dedupe=`${ev.code}|${ev.type}|${ev.key||''}`;if(pack.rows.some(x=>x.dedupe===dedupe))return;pack.rows.unshift({...ev,dedupe,at:Date.now()});pack.rows=pack.rows.slice(0,40);watchJsonSet(WATCH_EVENTS_KEY,pack)}
function detectWatchChanges(metrics,sectorRankMap){const day=watchTradingDayKey();let prev=watchJsonGet(WATCH_INTRADAY_KEY,{day,rows:{},sectorRanks:{}});if(prev.day!==day)prev={day,rows:{},sectorRanks:{}};for(const m of metrics){const p=prev.rows?.[m.code];if(!p)continue;for(const t of WATCH_TRACK_TAGS){if(m.tags.includes(t)&&!(p.tags||[]).includes(t))pushWatchEvent({code:m.code,name:m.name,type:'signal',key:t,text:`${t} 신규 진입`})}if(m.priorityRank&&p.priorityRank&&m.priorityRank<p.priorityRank)pushWatchEvent({code:m.code,name:m.name,type:'rank',key:`${p.priorityRank}-${m.priorityRank}`,text:`종배 우선순위 ${p.priorityRank}위 → ${m.priorityRank}위`});if(Number.isFinite(m.programNet)&&Number.isFinite(p.programNet)&&p.programNet<=0&&m.programNet>0)pushWatchEvent({code:m.code,name:m.name,type:'program',key:'positive',text:`프로그램 순매수 전환 ${watchProgramText(m.programNet).replace('프로그램 ','')}`});if(Number.isFinite(m.programRatio)&&Number.isFinite(p.programRatio)&&m.programRatio-p.programRatio>=1)pushWatchEvent({code:m.code,name:m.name,type:'program_ratio',key:String(Math.floor(m.programRatio)),text:`프로그램 비중 ${m.programRatio.toFixed(2)}%로 확대`});if(m.value>0&&p.value>0&&m.value>=p.value*1.2&&m.value-p.value>=100)pushWatchEvent({code:m.code,name:m.name,type:'value',key:String(Math.floor(m.value/500)),text:`거래대금 ${watchCompactValueText(m.value)}로 증가`})}for(const [sector,rank] of Object.entries(sectorRankMap||{})){const pr=prev.sectorRanks?.[sector];if(pr&&rank<pr)pushWatchEvent({code:'',name:sector,type:'sector',key:`${pr}-${rank}`,text:`${sector} 관심섹터 ${pr}위 → ${rank}위`})}watchJsonSet(WATCH_INTRADAY_KEY,{day,rows:watchSnapshotRows(metrics),sectorRanks:sectorRankMap,updated_at:Date.now()})}
function renderWatchAlerts(){const root=$('#watchAlerts');if(!root)return;const pack=watchJsonGet(WATCH_EVENTS_KEY,{day:watchTradingDayKey(),rows:[]});const rows=pack.day===watchTradingDayKey()?(pack.rows||[]):[];$('#watchAlertCount').textContent=`${rows.length}건`;root.innerHTML=rows.slice(0,7).map(x=>`<button class="watch-event" type="button" ${x.code?`data-stock-action-code="${esc(x.code)}" data-stock-action-name="${esc(x.name||x.code)}"`:''}><time>${new Date(x.at).toLocaleTimeString('ko-KR',{hour:'2-digit',minute:'2-digit'})}</time><b>${esc(x.name||'섹터')}</b><span>${esc(x.text)}</span></button>`).join('')||'<div class="watch-intel-empty">아직 새 변화가 없습니다.</div>';bindStockActionClicks()}
function renderWatchScoreTop(metrics){const root=$('#watchScoreTop');if(!root)return;const rows=[...metrics].sort((a,b)=>b.score-a.score).slice(0,5);root.innerHTML=rows.map((m,i)=>`<button class="watch-score-row" type="button" data-stock-action-code="${esc(m.code)}" data-stock-action-name="${esc(m.name)}"><span>${i+1}</span><b>${esc(m.name)}</b><div class="watch-score-bar"><i style="width:${m.score}%"></i></div><strong>${m.score}</strong></button>`).join('')||'<div class="watch-intel-empty">점수 계산 대기</div>';bindStockActionClicks()}
function renderWatchPrevCompare(metrics){const root=$('#watchPrevCompare');if(!root)return;const prev=watchJsonGet(WATCH_PREV_SNAPSHOT_KEY,null);if(!prev?.rows){root.innerHTML='<div class="watch-intel-empty">전일 데이터가 아직 없습니다. 다음 거래일부터 자동 비교됩니다.</div>';$('#watchPrevDayLabel').textContent='전일 저장 없음';return}$('#watchPrevDayLabel').textContent=prev.day||'전일';const changes=[];for(const m of metrics){const p=prev.rows[m.code];if(!p)continue;const rankNow=m.priorityRank,rankPrev=p.priorityRank;const progNow=m.programNet,progPrev=p.programNet;let weight=0,parts=[];if(rankNow&&rankPrev&&rankNow!==rankPrev){parts.push(`종배 ${rankPrev}→${rankNow}위`);weight+=Math.abs(rankPrev-rankNow)*3}if(Number.isFinite(progNow)&&Number.isFinite(progPrev)){const d=progNow-progPrev;if(Math.abs(d)>=1){parts.push(`프로그램 ${d>=0?'+':''}${watchCompactValueText(Math.abs(d)).replace('-','')}`);weight+=Math.min(20,Math.abs(d)/100)}}if(Number.isFinite(m.change)&&Number.isFinite(p.change)){const d=m.change-p.change;if(Math.abs(d)>=0.3){parts.push(`등락 ${d>=0?'+':''}${d.toFixed(1)}%p`);weight+=Math.abs(d)}}if(parts.length)changes.push({m,parts,weight})}changes.sort((a,b)=>b.weight-a.weight);root.innerHTML=changes.slice(0,5).map(x=>`<button class="watch-prev-row" type="button" data-stock-action-code="${esc(x.m.code)}" data-stock-action-name="${esc(x.m.name)}"><b>${esc(x.m.name)}</b><span>${esc(x.parts.join(' · '))}</span></button>`).join('')||'<div class="watch-intel-empty">전일 대비 큰 변화가 없습니다.</div>';bindStockActionClicks()}
function updateWatchIntelligence(sectorsInput){const rows=loadWatchlist();if(!rows.length)return;let sectors=sectorsInput;if(!sectors){const groups=new Map();rows.forEach(item=>{const live=watchLive(item),sector=String(live?.sector||item.sector||'기타').trim()||'기타';if(!groups.has(sector))groups.set(sector,[]);groups.get(sector).push(item)});sectors=[...groups.entries()].map(([sector,items])=>{const vals=items.map(watchChangeValue).filter(v=>v!=null);return {sector,items,avg:vals.length?vals.reduce((a,b)=>a+b,0)/vals.length:0,totalValue:items.reduce((a,b)=>a+watchValueEok(b),0)}}).sort((a,b)=>b.totalValue-a.totalValue)}const valueMax=Math.max(1,...rows.map(watchValueEok));const secAvg=Object.fromEntries(sectors.map(x=>[x.sector,Number(x.avg||0)]));const metrics=rows.map(x=>watchMetric(x,secAvg[(watchLive(x)?.sector||x.sector||'기타')]||0,valueMax));const sectorRankMap=Object.fromEntries(sectors.map((x,i)=>[x.sector,i+1]));detectWatchChanges(metrics,sectorRankMap);rotateWatchDailySnapshot(metrics);renderWatchAlerts();renderWatchScoreTop(metrics);renderWatchPrevCompare(metrics)}
let WATCH_CHECK_LIVE_TIMER=null;
function ensureWatchChecklistModal(){let m=$('#watchChecklistModal');if(m)return m;m=document.createElement('div');m.id='watchChecklistModal';m.className='watch-check-modal';m.hidden=true;m.innerHTML=`<div class="watch-check-backdrop" data-watch-check-close></div><div class="watch-check-dialog"><button class="watch-check-x" data-watch-check-close type="button">✕</button><div class="eyebrow">CLOSING BET CHECKLIST</div><h2 id="watchCheckTitle">종배 체크리스트</h2><div id="watchCheckMeta" class="muted"></div><div id="watchCheckBody"></div><div class="watch-check-note">자동항목은 현재 LITTO 데이터 기준이며, 최종 매매 판단은 직접 확인합니다.</div></div>`;document.body.appendChild(m);m.querySelectorAll('[data-watch-check-close]').forEach(x=>x.onclick=()=>{m.hidden=true;if(WATCH_CHECK_LIVE_TIMER){clearInterval(WATCH_CHECK_LIVE_TIMER);WATCH_CHECK_LIVE_TIMER=null}});return m}
function watchManualChecks(){return watchJsonGet(WATCH_CHECK_KEY,{})}
function openWatchChecklist(code,name){const m=ensureWatchChecklistModal();m.style.zIndex='220000';const s=findStock(code)||{},q=liveCardQuote(s)||{},change=Number(q.change),tags=lookupTags(code),mas=watchMAs(s),prevBear=watchPrevBear(s),aligned=[mas.ma5,mas.ma20,mas.ma60].every(Number.isFinite)&&mas.ma5>mas.ma20&&mas.ma20>mas.ma60,valueRank=watchValueRankForCode({code,...s,...q});const auto=[{label:'주도주 종배 또는 종배 우선순위',ok:tags.includes('주도주 종배')||tags.includes('종배 우선순위'),detail:tags.filter(x=>['주도주 종배','종배 우선순위'].includes(x)).join(' · ')||'미충족'},{label:'종가 강도 +5% 이상',ok:Number.isFinite(change)&&change>=5,detail:Number.isFinite(change)?pct(change):'데이터 없음'},{label:'5·20·60 이동평균 정배열',ok:aligned,detail:[mas.ma5,mas.ma20,mas.ma60].every(Number.isFinite)?`5 ${money(mas.ma5)} · 20 ${money(mas.ma20)} · 60 ${money(mas.ma60)}`:'데이터 부족'},{label:'전일 음봉/눌림 구조',ok:prevBear===true,detail:prevBear==null?'데이터 부족':prevBear?'전일 음봉':'전일 양봉'},{label:'거래대금 순위 상위 35',ok:Number.isFinite(valueRank)&&valueRank>0&&valueRank<=35,detail:Number.isFinite(valueRank)&&valueRank>0?`현재 ${Math.round(valueRank)}위`:'TOP50 밖 또는 순위 없음'}];const day=watchTradingDayKey(),all=watchManualChecks(),key=`${day}|${code}`,manual=all[key]||{};const manualRows=[['index20','지수 20일선 위 확인'],['noChase','장중 상따·추격 진입 아님'],['stop3','손절 기준 3% 설정']];const passed=auto.filter(x=>x.ok).length+manualRows.filter(([k])=>manual[k]).length,total=auto.length+manualRows.length;$('#watchCheckTitle').textContent=`${name||s.name||code} · 종배 체크리스트`;$('#watchCheckMeta').textContent=`${code} · ${passed}/${total} 확인`;$('#watchCheckBody').innerHTML=`<div class="watch-check-score"><strong>${passed}/${total}</strong><span>확인 완료</span></div><div class="watch-check-list">${auto.map(x=>`<div class="watch-check-item ${x.ok?'ok':'no'}"><span>${x.ok?'✓':'–'}</span><div><b>${esc(x.label)}</b><small>${esc(x.detail)}</small></div></div>`).join('')}${manualRows.map(([k,label])=>`<label class="watch-check-item manual ${manual[k]?'ok':''}"><input type="checkbox" data-watch-manual="${k}" ${manual[k]?'checked':''}><div><b>${esc(label)}</b><small>직접 확인</small></div></label>`).join('')}</div>`;$('#watchCheckBody').querySelectorAll('[data-watch-manual]').forEach(cb=>cb.onchange=()=>{const all2=watchManualChecks();const cur={...(all2[key]||{})};cur[cb.dataset.watchManual]=cb.checked;all2[key]=cur;watchJsonSet(WATCH_CHECK_KEY,all2);openWatchChecklist(code,name)});m.hidden=false;if(WATCH_CHECK_LIVE_TIMER)clearInterval(WATCH_CHECK_LIVE_TIMER);WATCH_CHECK_LIVE_TIMER=setInterval(()=>{if(m.hidden){clearInterval(WATCH_CHECK_LIVE_TIMER);WATCH_CHECK_LIVE_TIMER=null;return}const cur=findStock(code)||{},cq=liveCardQuote(cur)||{};const vr=watchValueRankForCode({code,...cur,...cq});const meta=$('#watchCheckMeta');const body=$('#watchCheckBody');const row=[...body.querySelectorAll('.watch-check-item')].find(x=>x.querySelector('b')?.textContent==='거래대금 순위 상위 35');if(row){const ok=Number.isFinite(vr)&&vr>0&&vr<=35;row.classList.toggle('ok',ok);row.classList.toggle('no',!ok);const icon=row.querySelector(':scope > span');if(icon)icon.textContent=ok?'✓':'–';const sm=row.querySelector('small');if(sm)sm.textContent=Number.isFinite(vr)&&vr>0?`현재 ${Math.round(vr)}위`:'TOP50 밖 또는 순위 없음';}},2000)}
function watchCompactItem(item,rank){
  const live=watchLive(item);
  const q=live?liveCardQuote(live):null;
  const name=live?.name||item.name||item.code;
  const sector=live?.sector||item.sector||'기타';
  const change=q?.change,price=q?.price,value=watchValueEok(item),tags=lookupTags(item.code);
  const hotTags=tags.filter(t=>WATCH_TRACK_TAGS.includes(t)).slice(0,2);
  const pf=WATCH_PROGRAM_DATA[String(item.code)]||null;
  const pn=pf?Number(pf.program_net_eok):NaN;
  const memo=watchMemo(item.code);
  const memoIcon=memo?`<button class="watch-memo-icon" type="button" data-watch-memo="${esc(item.code)}" data-watch-memo-name="${esc(name)}" title="${esc(memo)}" aria-label="메모 있음">📝</button>`:'';
  const sectorEdit=`<button class="watch-sector-edit sector-edit" type="button" data-sector-code="${esc(item.code)}" data-sector-current="${esc(sector)}" title="섹터 수정: ${esc(sector)}" aria-label="섹터 수정">✎</button>`;
  const tools=`<span class="watch-mini-tools">${newsButtonHtml(item.code,name)}${disclosureButtonHtml(item.code,name)}${memoIcon}${sectorEdit}</span>`;
  const programText=pf?watchProgramFullText(pn,value):'프로그램 -';
  const tagText=hotTags.length?hotTags.map(t=>esc(t.replace('주도주 ','').replace('종배 우선순위','우선'))).join(' · '):'';

  return `<div class="watch-mini-row${rank===1?' top':''}" data-watch-row="${esc(item.code)}" data-stock-action-code="${esc(item.code)}" data-stock-action-name="${esc(name)}">
    <span class="watch-mini-rank">${rank}</span>

    <div class="watch-mini-main">
      <div class="watch-mini-name-line"><b title="${esc(name)}">${esc(name)}</b><span class="watch-mini-program watch-mini-program-inline ${Number.isFinite(pn)?cls(pn):''}" data-watch-program-code="${esc(item.code)}">${programText}</span></div>
    </div>

    <div class="watch-mini-spark">${watchSparkline(item)}</div>

    <div class="watch-mini-quote">
      <span class="watch-mini-price" title="현재가">${Number.isFinite(Number(price))&&Number(price)>0?money(price):'-'}</span>
      <span class="watch-mini-change ${change==null?'':cls(change)}" title="등락률">${change==null?'-':pct(change)}</span>
    </div>

    <button class="watch-star active compact watch-row-star" type="button" data-watch-code="${esc(item.code)}" data-watch-name="${esc(name)}" data-watch-sector="${esc(sector)}" title="관심종목에서 제거">★</button>

    <div class="watch-mini-meta">
      <div class="watch-mini-meta-left">
        ${watchRankCompactHtml(item)}
        <span class="watch-mini-sector">${esc(sector)}</span>
        ${tagText?`<span class="watch-mini-tags">${tagText}</span>`:''}
        ${tools}
      </div>
      <div class="watch-mini-meta-right">
        <span class="watch-mini-trade">거래 <b>${watchCompactValueText(value)}</b></span>
      </div>
    </div>
  </div>`;
}
function ensureWatchlistRowAlignmentStyle(){
  let st=document.getElementById('watchlistRowAlignmentStyle');
  if(!st){
    st=document.createElement('style');
    st.id='watchlistRowAlignmentStyle';
    document.head.appendChild(st);
  }

  st.textContent=`
    /* 카드가 2열일 때도 절대 겹치지 않도록 1행 요소 수를 최소화 */
    #watchlist-page .watch-mini-row{
      display:grid!important;
      grid-template-columns:28px minmax(0,1fr) 70px 162px 30px!important;
      grid-template-rows:auto auto!important;
      column-gap:8px!important;
      row-gap:2px!important;
      align-items:center!important;
      min-width:0!important;
      overflow:hidden!important;
      box-sizing:border-box!important;
      padding:7px 10px!important;
    }

    #watchlist-page .watch-mini-rank{
      grid-column:1!important;
      grid-row:1 / span 2!important;
      width:28px!important;
      min-width:28px!important;
      text-align:center!important;
      align-self:center!important;
    }

    #watchlist-page .watch-mini-main{
      grid-column:2!important;
      grid-row:1!important;
      min-width:0!important;
      overflow:hidden!important;
    }

    #watchlist-page .watch-mini-name-line{
      display:block!important;
      min-width:0!important;
      overflow:hidden!important;
    }

    #watchlist-page .watch-mini-name-line b{
      display:block!important;
      width:100%!important;
      min-width:0!important;
      white-space:nowrap!important;
      overflow:hidden!important;
      text-overflow:ellipsis!important;
      font-size:13px!important;
      letter-spacing:-.1px!important;
    }

    #watchlist-page .watch-mini-name-line b.watch-name-long{
      font-size:12px!important;
    }

    #watchlist-page .watch-mini-subline{
      display:flex!important;
      align-items:center!important;
      gap:7px!important;
      min-width:0!important;
      margin-top:3px!important;
      font-size:10px!important;
      color:#6f859a!important;
      white-space:nowrap!important;
      overflow:hidden!important;
    }

    #watchlist-page .watch-mini-sector,
    #watchlist-page .watch-mini-tags{
      overflow:hidden!important;
      text-overflow:ellipsis!important;
      white-space:nowrap!important;
    }

    #watchlist-page .watch-mini-spark{
      grid-column:3!important;
      grid-row:1!important;
      width:70px!important;
      min-width:70px!important;
      max-width:70px!important;
    }

    #watchlist-page .watch-mini-quote{
      grid-column:4!important;
      grid-row:1!important;
      width:162px!important;
      min-width:162px!important;
      display:grid!important;
      grid-template-columns:92px 64px!important;
      column-gap:6px!important;
      align-items:center!important;
      justify-content:end!important;
      overflow:visible!important;
      box-sizing:border-box!important;
    }

    #watchlist-page .watch-mini-price{
      width:92px!important;
      min-width:92px!important;
      max-width:92px!important;
      text-align:right!important;
      white-space:nowrap!important;
      overflow:visible!important;
      padding:0!important;
    }

    #watchlist-page .watch-mini-change{
      width:64px!important;
      min-width:64px!important;
      max-width:64px!important;
      text-align:right!important;
      white-space:nowrap!important;
      overflow:visible!important;
      padding:0!important;
      font-size:16px!important;
      line-height:1!important;
    }

    #watchlist-page .watch-row-star{
      grid-column:5!important;
      grid-row:1 / span 2!important;
      display:flex!important;
      visibility:visible!important;
      opacity:1!important;
      position:static!important;
      justify-self:center!important;
      align-self:center!important;
      width:28px!important;
      min-width:28px!important;
      height:30px!important;
      align-items:center!important;
      justify-content:center!important;
      font-size:21px!important;
      line-height:1!important;
      margin:0!important;
      overflow:visible!important;
    }

    #watchlist-page .watch-mini-meta{
      grid-column:2 / 5!important;
      grid-row:2!important;
      display:flex!important;
      align-items:center!important;
      gap:7px!important;
      min-width:0!important;
      overflow:hidden!important;
      white-space:nowrap!important;
      font-size:10px!important;
      line-height:1.15!important;
    }

    #watchlist-page .watch-mini-meta .watch-ranks-inline{
      flex:0 0 auto!important;
      display:inline-flex!important;
      align-items:center!important;
      gap:4px!important;
      margin:0 2px 0 0!important;
    }

    #watchlist-page .watch-mini-meta .watch-mini-sector,
    #watchlist-page .watch-mini-meta .watch-mini-tags{
      flex:0 0 auto!important;
      color:#6f859a!important;
    }

    #watchlist-page .watch-mini-tools{
      display:flex!important;
      align-items:center!important;
      gap:4px!important;
      flex:0 0 auto!important;
      white-space:nowrap!important;
    }

    #watchlist-page .watch-mini-tools .news-btn,
    #watchlist-page .watch-mini-tools .disclosure-btn,
    #watchlist-page .watch-mini-tools .watch-memo-icon,
    #watchlist-page .watch-mini-tools .watch-sector-edit{
      position:static!important;
      margin:0!important;
      flex:0 0 auto!important;
    }

    #watchlist-page .watch-mini-trade{
      flex:0 0 auto!important;
      color:#6f859a!important;
    }

    #watchlist-page .watch-mini-trade b{
      color:#83c8ff!important;
      font-weight:800!important;
    }

    #watchlist-page .watch-mini-program{
      flex:1 1 auto!important;
      min-width:0!important;
      overflow:hidden!important;
      text-overflow:ellipsis!important;
      white-space:nowrap!important;
      font-weight:800!important;
    }

    #watchlist-page .watch-mini-value{display:none!important;}

    /* 2열 카드가 좁아지는 경우에는 quote 폭을 유지하고 차트/이름만 조금 양보 */
    @media(max-width:1450px){
      #watchlist-page .watch-mini-row{
        grid-template-columns:26px minmax(0,1fr) 64px 154px 30px!important;
        column-gap:6px!important;
        padding-left:8px!important;
        padding-right:8px!important;
      }

      #watchlist-page .watch-mini-spark{
        width:64px!important;
        min-width:64px!important;
        max-width:64px!important;
      }

      #watchlist-page .watch-mini-quote{
        width:154px!important;
        min-width:154px!important;
        grid-template-columns:88px 60px!important;
        column-gap:6px!important;
      }

      #watchlist-page .watch-mini-price{
        width:88px!important;
        min-width:88px!important;
        max-width:88px!important;
      }

      #watchlist-page .watch-mini-change{
        width:60px!important;
        min-width:60px!important;
        max-width:60px!important;
        font-size:15px!important;
      }

      #watchlist-page .watch-mini-meta{
        gap:8px!important;
        font-size:10px!important;
      }
    }

    /* v1.22 priority layout: 핵심가격은 1행, 보조정보는 좌/우 두 그룹 */
    #watchlist-page .watch-mini-meta{
      justify-content:space-between!important;
      gap:10px!important;
    }
    #watchlist-page .watch-mini-meta-left,
    #watchlist-page .watch-mini-meta-right{
      display:flex!important;
      align-items:center!important;
      white-space:nowrap!important;
      min-width:0!important;
    }
    #watchlist-page .watch-mini-meta-left{
      gap:6px!important;
      flex:1 1 auto!important;
      overflow:hidden!important;
    }
    #watchlist-page .watch-mini-meta-right{
      gap:8px!important;
      flex:0 0 auto!important;
      margin-left:auto!important;
    }
    #watchlist-page .watch-mini-name-line .watch-mini-program-inline{
      margin-left:10px!important;
      white-space:nowrap!important;
      font-size:10.5px!important;
      font-weight:700!important;
    }
    #watchlist-page .watch-mini-meta-left .watch-mini-sector,
    #watchlist-page .watch-mini-meta-left .watch-mini-tags{
      overflow:hidden!important;
      text-overflow:ellipsis!important;
      max-width:84px!important;
    }
    #watchlist-page .watch-mini-meta-right .watch-mini-program{
      flex:0 0 auto!important;
      max-width:170px!important;
    }
    @media(max-width:1280px){
      #watchlist-page .watch-mini-meta-left .watch-mini-tags{display:none!important;}
      #watchlist-page .watch-mini-meta{gap:6px!important;}
      #watchlist-page .watch-mini-meta-right{gap:5px!important;}
    }
  
  /* v1.22: true 2-line watch row; VISUAL ONLY */
  #watchlist-page .watch-mini-name-line{
    display:flex!important;
    align-items:center!important;
    gap:8px!important;
    min-width:0!important;
    overflow:hidden!important;
    white-space:nowrap!important;
  }
  #watchlist-page .watch-mini-name-line > b{
    display:block!important;
    width:auto!important;
    max-width:none!important;
    flex:0 0 auto!important;
    min-width:0!important;
    white-space:nowrap!important;
    overflow:hidden!important;
    text-overflow:ellipsis!important;
  }
  #watchlist-page .watch-mini-program-inline{
    display:inline-block!important;
    flex:0 0 auto!important;
    min-width:0!important;
    max-width:none!important;
    margin-left:0!important;
    white-space:nowrap!important;
    overflow:visible!important;
    text-overflow:clip!important;
  }
`;
}


function ensureWatchQuoteNoOverlapStyle(){
  let st=document.getElementById('watchQuoteNoOverlapStyle');
  if(!st){
    st=document.createElement('style');
    st.id='watchQuoteNoOverlapStyle';
    document.head.appendChild(st);
  }
  st.textContent=`
    /* 최종 우선순위: 관심종목 현재가/등락률 겹침 방지 */
    #watchlist-page .watch-mini-quote{
      position:static!important;
      float:none!important;
      transform:none!important;
      display:flex!important;
      align-items:center!important;
      justify-content:flex-end!important;
      gap:14px!important;
      width:170px!important;
      min-width:170px!important;
      max-width:170px!important;
      overflow:visible!important;
      white-space:nowrap!important;
      box-sizing:border-box!important;
    }

    #watchlist-page .watch-mini-quote > .watch-mini-price,
    #watchlist-page .watch-mini-quote > .watch-mini-change{
      position:static!important;
      float:none!important;
      transform:none!important;
      inset:auto!important;
      left:auto!important;
      right:auto!important;
      top:auto!important;
      bottom:auto!important;
      margin:0!important;
      padding:0!important;
      display:block!important;
      white-space:nowrap!important;
      overflow:visible!important;
      text-overflow:clip!important;
      box-sizing:border-box!important;
      line-height:1.1!important;
    }

    #watchlist-page .watch-mini-quote > .watch-mini-price{
      flex:0 0 92px!important;
      width:92px!important;
      min-width:92px!important;
      max-width:92px!important;
      text-align:right!important;
    }

    #watchlist-page .watch-mini-quote > .watch-mini-change{
      flex:0 0 66px!important;
      width:66px!important;
      min-width:66px!important;
      max-width:66px!important;
      text-align:right!important;
      font-size:16px!important;
      font-weight:800!important;
    }

    /* quote 폭 증가분은 미니차트에서만 조금 회수. 이름 영역은 유지 */
    #watchlist-page .watch-mini-row{
      grid-template-columns:28px minmax(0,1fr) 52px 170px 30px!important;
      column-gap:8px!important;
    }

    #watchlist-page .watch-mini-spark{
      width:52px!important;
      min-width:52px!important;
      max-width:52px!important;
    }

    @media(max-width:1450px){
      #watchlist-page .watch-mini-row{
        grid-template-columns:26px minmax(0,1fr) 44px 164px 30px!important;
        column-gap:6px!important;
      }

      #watchlist-page .watch-mini-spark{
        width:44px!important;
        min-width:44px!important;
        max-width:44px!important;
      }

      #watchlist-page .watch-mini-quote{
        width:164px!important;
        min-width:164px!important;
        max-width:164px!important;
        gap:6px!important;
      }

      #watchlist-page .watch-mini-quote > .watch-mini-price{
        flex-basis:90px!important;
        width:90px!important;
        min-width:90px!important;
        max-width:90px!important;
      }

      #watchlist-page .watch-mini-quote > .watch-mini-change{
        flex-basis:66px!important;
        width:66px!important;
        min-width:66px!important;
        max-width:66px!important;
        font-size:15px!important;
      }
    }
  `;
}

function markLongWatchNames(){
  document.querySelectorAll('#watchlist-page .watch-mini-name-line b').forEach(el=>{
    const txt=(el.textContent||'').trim();
    el.classList.toggle('watch-name-long',txt.length>=8);
    if(txt)el.title=txt;
  });
}

function renderWatchlistPage(){ensureWatchlistRowAlignmentStyle();ensureWatchQuoteNoOverlapStyle();ensureTradeSubtabs();const root=$('#watchSectors');if(!root)return;const rows=loadWatchlist();$('#watchTotal').textContent=`${rows.length}종목`;const wc=$('#watchCount');if(wc)wc.textContent=String(rows.length);const swc=$('#watchSidebarCount');if(swc)swc.textContent=String(rows.length);if(!rows.length){root.innerHTML='<div class="watch-empty"><strong>아직 관심종목이 없습니다.</strong><span>뉴하트 스캐너에서 종목명 옆 ☆를 누르면 여기에 추가됩니다.</span></div>';$('#watchAlerts').innerHTML='<div class="watch-intel-empty">관심종목을 추가하세요.</div>';$('#watchScoreTop').innerHTML='<div class="watch-intel-empty">관심종목을 추가하세요.</div>';$('#watchPrevCompare').innerHTML='<div class="watch-intel-empty">관심종목을 추가하세요.</div>';const addBtn=document.getElementById('watchManualAddBtn');if(addBtn)addBtn.onclick=openWatchManualAdd;return}const groups=new Map();rows.forEach(item=>{const live=findStock(item.code),sector=String(live?.sector||item.sector||'기타').trim()||'기타';if(!groups.has(sector))groups.set(sector,[]);groups.get(sector).push(item)});const sectors=[...groups.entries()].map(([sector,items])=>{const sorted=[...items].sort((a,b)=>{const av=watchChangeValue(a),bv=watchChangeValue(b);if(av==null&&bv==null)return String(a.name||a.code).localeCompare(String(b.name||b.code),'ko');if(av==null)return 1;if(bv==null)return-1;return bv-av});const vals=sorted.map(watchChangeValue).filter(v=>v!=null);const avg=vals.length?vals.reduce((s,v)=>s+v,0)/vals.length:null;const totalValue=sorted.reduce((s,item)=>s+watchValueEok(item),0);return {sector,items:sorted,avg,totalValue}}).sort((a,b)=>{if(b.totalValue!==a.totalValue)return b.totalValue-a.totalValue;if(a.avg==null&&b.avg==null)return a.sector.localeCompare(b.sector,'ko');if(a.avg==null)return 1;if(b.avg==null)return-1;return b.avg-a.avg});root.classList.add('watch-overview-grid');root.innerHTML=sectors.map((g,si)=>`<section class="watch-overview-card${si===0?' strongest':''}"><div class="watch-overview-head"><div class="watch-overview-title">${si===0?'<span class="watch-overview-star">★</span>':''}<b>${esc(g.sector)}</b><small>${g.items.length}</small></div><div class="watch-overview-metrics"><strong class="watch-overview-avg ${g.avg==null?'':cls(g.avg)}">${g.avg==null?'-':pct(g.avg)}</strong><span class="watch-overview-money">${g.totalValue>0?`${money(g.totalValue)}억`:'-'}</span></div></div><div class="watch-overview-body">${g.items.map((item,ii)=>watchCompactItem(item,ii+1)).join('')}</div></section>`).join('');bindWatchStars(root);bindWatchMemoButtons(root);bindSectorEdits();bindStockActionClicks();bindNewsButtons();const addBtn=document.getElementById('watchManualAddBtn');if(addBtn)addBtn.onclick=openWatchManualAdd;updateWatchIntelligence(sectors);refreshWatchProgramFlow(false);refreshManualWatchLive(false);markLongWatchNames()}
setTimeout(()=>{ensureTradeSubtabs();switchTradeSubtab(TRADE_SUBTAB);syncWatchStars();renderWatchlistPage()},2600);

// --- 5-page UI: 실전매매 / 주의·경고 / 시장종합 / 미국시장 / 매매일지 ---
let LITTO_PAGE=localStorage.getItem('litto_page_v1')||'trade';
let MARKET_OVERVIEW={markets:{},updated_at:null,error:null};
let MARKET_SECTOR_CALENDAR={days:[],monthly_sectors:[],updated_at:null,error:null};
let MARKET_SUBTAB=localStorage.getItem('litto_market_subtab')||'overview';
let MARKET_SECTOR_MONTH=localStorage.getItem('litto_market_sector_month')||new Date().toISOString().slice(0,7);
let US_MARKET={sections:{},errors:{},updated_at:null};
let US_RANK_LIVE={};
let US_RANK_LIVE_META={};
let US_RANK_LIVE_LOADING=false;
const US_WATCHLIST_DATA={"etfs":[{"ticker":"XLK","en":"Information Technology","ko":"정보기술 (IT)"},{"ticker":"XLC","en":"Communication Services","ko":"커뮤니케이션서비스"},{"ticker":"XLY","en":"Consumer Discretionary","ko":"경기소비재 (임의소비재)"},{"ticker":"XLI","en":"Industrials","ko":"산업재"},{"ticker":"XLB","en":"Materials","ko":"소재 (원자재)"},{"ticker":"XLE","en":"Energy","ko":"에너지"},{"ticker":"XLP","en":"Consumer Staples","ko":"필수소비재"},{"ticker":"XLV","en":"Health Care","ko":"헬스케어 (의료)"},{"ticker":"XLU","en":"Utilities","ko":"유틸리티 (공공·기간산업)"},{"ticker":"XLRE","en":"Real Estate","ko":"부동산 (리츠)"},{"ticker":"XLF","en":"Financials","ko":"금융"}],"stocks":[{"no":1,"sector":"지수","ticker":"SPX","en":"S&P 500 Index","ko":"S&P 500 지수","note":"미국 대형주 500개"},{"no":2,"sector":"지수","ticker":"DJI","en":"Dow Jones Industrial Average","ko":"다우존스 산업평균지수","note":"우량주 30개"},{"no":3,"sector":"지수","ticker":"IXIC","en":"Nasdaq Composite","ko":"나스닥 종합지수","note":""},{"no":4,"sector":"지수","ticker":"RUT","en":"Russell 2000","ko":"러셀 2000","note":"미국 소형주"},{"no":5,"sector":"반도체","ticker":"NVDA","en":"NVIDIA","ko":"엔비디아","note":""},{"no":6,"sector":"반도체","ticker":"SKHY","en":"SK hynix (ADR)","ko":"SK하이닉스","note":"2026.7 나스닥 ADR 상장 (국내 000660)"},{"no":7,"sector":"반도체","ticker":"MU","en":"Micron Technology","ko":"마이크론","note":""},{"no":8,"sector":"반도체","ticker":"SNDK","en":"SanDisk","ko":"샌디스크","note":""},{"no":9,"sector":"반도체장비","ticker":"LRCX","en":"Lam Research","ko":"램리서치","note":""},{"no":10,"sector":"반도체장비","ticker":"AMAT","en":"Applied Materials","ko":"어플라이드 머티리얼즈","note":""},{"no":11,"sector":"반도체장비","ticker":"ASML","en":"ASML Holding","ko":"ASML","note":"네덜란드 기업"},{"no":12,"sector":"하이퍼스케일러","ticker":"AMZN","en":"Amazon","ko":"아마존","note":"AWS"},{"no":13,"sector":"하이퍼스케일러","ticker":"GOOGL","en":"Alphabet (Class A)","ko":"알파벳(구글)","note":"Google Cloud"},{"no":14,"sector":"하이퍼스케일러","ticker":"MSFT","en":"Microsoft","ko":"마이크로소프트","note":"Azure"},{"no":15,"sector":"전력","ticker":"GEV","en":"GE Vernova","ko":"GE 버노바","note":""},{"no":16,"sector":"전력","ticker":"PWR","en":"Quanta Services","ko":"콴타 서비스","note":""},{"no":17,"sector":"전력","ticker":"ETN","en":"Eaton","ko":"이튼","note":""},{"no":18,"sector":"연료전지","ticker":"BE","en":"Bloom Energy","ko":"블룸에너지","note":""},{"no":19,"sector":"원전","ticker":"OKLO","en":"Oklo","ko":"오클로","note":"SMR"},{"no":20,"sector":"원전","ticker":"SMR","en":"NuScale Power","ko":"뉴스케일 파워","note":"SMR"},{"no":21,"sector":"원전","ticker":"CEG","en":"Constellation Energy","ko":"컨스텔레이션 에너지","note":""},{"no":22,"sector":"2차전지","ticker":"TSLA","en":"Tesla","ko":"테슬라","note":"로봇 업종에도 포함"},{"no":23,"sector":"2차전지","ticker":"ALB","en":"Albemarle","ko":"앨버말","note":"리튬"},{"no":24,"sector":"2차전지","ticker":"FLNC","en":"Fluence Energy","ko":"플루언스 에너지","note":"ESS"},{"no":25,"sector":"태양광","ticker":"FSLR","en":"First Solar","ko":"퍼스트 솔라","note":""},{"no":26,"sector":"태양광","ticker":"ENPH","en":"Enphase Energy","ko":"엔페이즈 에너지","note":""},{"no":27,"sector":"태양광","ticker":"RUN","en":"Sunrun","ko":"선런","note":""},{"no":28,"sector":"광통신","ticker":"LITE","en":"Lumentum","ko":"루멘텀","note":""},{"no":29,"sector":"광통신","ticker":"COHR","en":"Coherent","ko":"코히런트","note":""},{"no":30,"sector":"광통신","ticker":"CIEN","en":"Ciena","ko":"시에나","note":""},{"no":31,"sector":"로봇","ticker":"TSLA","en":"Tesla","ko":"테슬라","note":"2차전지 업종에도 포함"},{"no":32,"sector":"로봇","ticker":"ISRG","en":"Intuitive Surgical","ko":"인튜이티브 서지컬","note":"수술로봇"},{"no":33,"sector":"로봇","ticker":"TER","en":"Teradyne","ko":"테라다인","note":""},{"no":34,"sector":"양자컴","ticker":"IONQ","en":"IonQ","ko":"아이온큐","note":""},{"no":35,"sector":"양자컴","ticker":"RGTI","en":"Rigetti Computing","ko":"리게티 컴퓨팅","note":""},{"no":36,"sector":"양자컴","ticker":"QBTS","en":"D-Wave Quantum","ko":"디웨이브 퀀텀","note":""},{"no":37,"sector":"방산","ticker":"LMT","en":"Lockheed Martin","ko":"록히드 마틴","note":""},{"no":38,"sector":"방산","ticker":"GE","en":"GE Aerospace","ko":"GE 에어로스페이스","note":""},{"no":39,"sector":"방산","ticker":"RTX","en":"RTX Corp","ko":"RTX (레이시온)","note":""},{"no":40,"sector":"우주항공","ticker":"SPCX","en":"SpaceX","ko":"스페이스X","note":"2026.6 나스닥 상장"},{"no":41,"sector":"우주항공","ticker":"RKLB","en":"Rocket Lab","ko":"로켓랩","note":""},{"no":42,"sector":"우주항공","ticker":"ECHO","en":"EchoStar","ko":"에코스타","note":"2026.6 티커 변경 (SATS→ECHO)"},{"no":43,"sector":"보안","ticker":"PANW","en":"Palo Alto Networks","ko":"팔로알토 네트웍스","note":""},{"no":44,"sector":"보안","ticker":"CRWD","en":"CrowdStrike","ko":"크라우드스트라이크","note":""},{"no":45,"sector":"보안","ticker":"FTNT","en":"Fortinet","ko":"포티넷","note":""},{"no":46,"sector":"스테이블코인","ticker":"CRCL","en":"Circle Internet Group","ko":"서클","note":"USDC 발행사"},{"no":47,"sector":"스테이블코인","ticker":"HOOD","en":"Robinhood Markets","ko":"로빈후드","note":""},{"no":48,"sector":"스테이블코인","ticker":"COIN","en":"Coinbase Global","ko":"코인베이스","note":""},{"no":49,"sector":"바이오","ticker":"LLY","en":"Eli Lilly","ko":"일라이 릴리","note":""},{"no":50,"sector":"바이오","ticker":"MRNA","en":"Moderna","ko":"모더나","note":""},{"no":51,"sector":"바이오","ticker":"NVO","en":"Novo Nordisk (ADR)","ko":"노보 노디스크","note":"덴마크 기업"},{"no":52,"sector":"생활","ticker":"NFLX","en":"Netflix","ko":"넷플릭스","note":""},{"no":53,"sector":"생활","ticker":"COKE","en":"Coca-Cola Consolidated","ko":"코카콜라 컨솔리데이티드","note":"보틀러 ※ 코카콜라 본사는 KO"},{"no":54,"sector":"생활","ticker":"MCD","en":"McDonald's","ko":"맥도날드","note":""},{"no":55,"sector":"생활","ticker":"CVX","en":"Chevron","ko":"쉐브론","note":"석유 메이저 (에너지)"}],"sectorOrder":["지수","반도체","반도체장비","하이퍼스케일러","전력","연료전지","원전","2차전지","태양광","광통신","로봇","양자컴","방산","우주항공","보안","스테이블코인","바이오","생활"]};
let JOURNAL={rows:[],stats:{},imports:[],db_path:''};
let JOURNAL_YEAR=Number(localStorage.getItem('litto_journal_year'))||new Date().getFullYear();
let JOURNAL_MONTH=Number(localStorage.getItem('litto_journal_month'))||(new Date().getMonth()+1);
let MARKET_CALENDAR={events:[],sources:[],errors:[],updated_at:null};
let MARKET_CAL_RANGE=localStorage.getItem('litto_market_cal_range')||'30d';
let MARKET_CAL_COUNTRY=localStorage.getItem('litto_market_cal_country')||'ALL';
let MARKET_CAL_TYPE=localStorage.getItem('litto_market_cal_type')||'ALL';
let US_WATCH_QUOTES={};
let US_WATCH_META={updated_at:null,errors:{}};
let US_WATCH_LOADING=false;
function ensurePageBar(){
  let bar=$('#littoPageBar');
  const main=document.querySelector('.workspace main')||document.querySelector('main'); if(!main)return null;
  if(!bar){
    bar=document.createElement('div');bar.id='littoPageBar';bar.className='litto-pagebar';
    main.parentElement.insertBefore(bar,main);
  }
  const required=[['trade','실전매매'],['alerts','주의·경고'],['market','시장종합'],['us','미국시장'],['journal','매매일지']];
  required.forEach(([page,label])=>{
    let b=bar.querySelector(`[data-page="${page}"]`);
    if(!b){b=document.createElement('button');b.className='litto-pagebtn';b.dataset.page=page;b.textContent=label;bar.appendChild(b)}
    b.onclick=()=>switchLittoPage(page);
  });
  return bar;
}
function ensureMarketOverview(){
  let sec=$('#market-overview');if(sec)return sec;
  const main=document.querySelector('.workspace main')||document.querySelector('main');if(!main)return null;
  sec=document.createElement('section');sec.id='market-overview';sec.className='card market-overview-card';
  sec.innerHTML=`<div class="market-overview-head"><div><div class="eyebrow">MARKET OVERVIEW</div><h2>시장종합</h2><div id="marketOverviewMeta" class="muted">키움 연결 후 30초 자동갱신</div></div><button id="marketOverviewRefresh" class="ghost">전체 새로고침</button></div>
  <div class="market-subtabs"><button class="market-subtab active" data-market-tab="overview" type="button">시장종합</button><button class="market-subtab" data-market-tab="sector" type="button">주도섹터 이력</button></div>
  <div id="marketTabOverview" class="market-tabpane active"><div id="marketOverviewSummary" class="market-overview-summary"></div><div id="marketOverviewGrid" class="market-overview-grid"></div><div class="market-overview-note">현물 지수·시장폭·수급·거래대금·15분 차트는 키움 공식 REST 기준.</div><div id="marketCalendarMount"></div></div>
  <div id="marketTabSector" class="market-tabpane"><div id="sectorStrengthCalendarMount"></div></div>`;
  main.appendChild(sec);$('#marketOverviewRefresh').onclick=()=>refreshMarketPage(true);sec.querySelectorAll('.market-subtab').forEach(b=>b.onclick=()=>switchMarketSubtab(b.dataset.marketTab));ensureMarketCalendar();ensureSectorStrengthCalendar();switchMarketSubtab(MARKET_SUBTAB);return sec;
}
function ensureSectorCalendarStyles(){
  if(document.getElementById('sectorStrengthCalendarStyles'))return;
  const st=document.createElement('style');st.id='sectorStrengthCalendarStyles';st.textContent=`
  .market-subtabs{display:flex;gap:8px;margin:16px 0 18px;padding:5px;background:rgba(10,22,36,.7);border:1px solid rgba(82,137,181,.18);border-radius:12px}.market-subtab{border:0;background:transparent;color:#8fa9bd;padding:10px 16px;border-radius:9px;font-weight:800;cursor:pointer}.market-subtab.active{background:#123451;color:#fff;box-shadow:inset 0 0 0 1px rgba(63,181,255,.28)}.market-tabpane{display:none}.market-tabpane.active{display:block}
  .ssc-wrap{margin-top:4px}.ssc-head{display:flex;justify-content:space-between;align-items:flex-start;gap:18px;margin-bottom:14px}.ssc-head h3{margin:2px 0 5px}.ssc-controls{display:flex;align-items:center;gap:8px}.ssc-month{min-width:105px;text-align:center;font-size:17px;font-weight:900}.ssc-summary{display:flex;gap:8px;flex-wrap:wrap;margin:10px 0 15px}.ssc-summary span{padding:6px 9px;border-radius:999px;background:#0d273b;border:1px solid #1c4967;font-size:12px}.ssc-week,.ssc-grid{display:grid;grid-template-columns:repeat(7,minmax(0,1fr));gap:7px}.ssc-week div{text-align:center;color:#69869a;font-size:11px;font-weight:800;padding:5px}.ssc-day{min-height:128px;background:#091724;border:1px solid #17354a;border-radius:11px;padding:9px;cursor:pointer;transition:.14s}.ssc-day:hover{border-color:#28698f;transform:translateY(-1px)}.ssc-day.empty{opacity:.28;cursor:default}.ssc-day.today{border-color:#21a1df;box-shadow:inset 0 0 0 1px rgba(33,161,223,.22)}.ssc-date{display:flex;justify-content:space-between;align-items:center;font-weight:900;margin-bottom:7px}.ssc-total{font-size:10px;color:#7d9bad;font-weight:700}.ssc-sector{display:flex;justify-content:space-between;align-items:center;gap:6px;padding:4px 6px;margin-top:4px;border-radius:7px;background:#0d2737;font-size:11px}.ssc-sector b{color:#dcecf6;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;min-width:0}.ssc-sector-name{display:flex;align-items:center;gap:5px;min-width:0;flex:1}.ssc-sector-rank{display:inline-flex;align-items:center;justify-content:center;font-size:10px;font-weight:900;line-height:1}.ssc-sector-count{color:#5ed2ff;font-weight:900}.ssc-sector.rank-1{background:linear-gradient(90deg,rgba(69,50,8,.95),rgba(35,47,17,.95));border:1px solid rgba(255,196,77,.34);padding:5px 7px;font-size:12px;box-shadow:inset 0 0 0 1px rgba(255,214,102,.08)}.ssc-sector.rank-1 b{color:#fff6d6;font-size:12px}.ssc-sector.rank-1 .ssc-sector-rank{color:#ffd76a;text-shadow:0 0 10px rgba(255,206,92,.28);font-size:12px}.ssc-sector.rank-1 .ssc-sector-count{color:#ffe39a;font-size:12px}.ssc-sector.rank-1::before{content:'★';color:#ffd76a;font-size:12px;font-weight:900;line-height:1;filter:drop-shadow(0 0 4px rgba(255,215,106,.25))}.ssc-more{font-size:10px;color:#6f8c9f;margin-top:5px}.ssc-detail{margin-top:14px;border:1px solid #1b4058;border-radius:12px;background:#091724;padding:14px}.ssc-detail-head{display:flex;justify-content:space-between;align-items:center;margin-bottom:10px}.ssc-detail-sector{padding:10px 0;border-top:1px solid rgba(80,130,160,.14)}.ssc-detail-sector:first-of-type{border-top:0}.ssc-detail-sector h4{margin:0 0 6px}.ssc-stockchips{display:flex;gap:6px;flex-wrap:wrap}.ssc-stockchip{padding:5px 7px;border-radius:7px;background:#102638;color:#bdd0dc;font-size:11px}.ssc-empty{color:#648093;padding:40px 10px;text-align:center}.ssc-rankbar{display:flex;gap:7px;flex-wrap:wrap}.ssc-rankbar span{font-size:11px;background:#102c3e;border:1px solid #1b506c;padding:6px 8px;border-radius:8px}@media(max-width:900px){.ssc-week,.ssc-grid{gap:4px}.ssc-day{min-height:105px;padding:6px}.ssc-sector{font-size:10px;padding:3px 4px}.ssc-sector.rank-1{font-size:11px;padding:4px 5px}.ssc-sector.rank-1 b,.ssc-sector.rank-1 .ssc-sector-count,.ssc-sector.rank-1 .ssc-sector-rank,.ssc-sector.rank-1::before{font-size:11px}.ssc-head{flex-direction:column}.ssc-controls{width:100%;justify-content:space-between}}
  

  /* calendar grid alignment / weekday / Korea holiday */
  .ssc-calendar-blank{
    grid-column:auto !important;
    min-height:128px !important;
    padding:0 !important;
    background:rgba(6,16,25,.24) !important;
    border:1px dashed rgba(40,76,102,.20) !important;
    opacity:.38 !important;
    cursor:default !important;
  }
  .ssc-calendar-blank:hover{transform:none !important;border-color:rgba(40,76,102,.20) !important}
  .ssc-date{align-items:flex-start !important}
  .ssc-date-main{display:flex;align-items:center;gap:5px;min-width:0;flex-wrap:wrap}
  .ssc-date-side{display:flex;align-items:center;justify-content:flex-end;gap:5px;flex-wrap:wrap}
  .ssc-daynum{font-size:14px;font-weight:950}
  .ssc-weekday{font-size:10px;font-weight:900;color:#718ba0}
  .ssc-day.sunday .ssc-daynum,.ssc-day.sunday .ssc-weekday{color:#ff6b78}
  .ssc-day.saturday .ssc-daynum,.ssc-day.saturday .ssc-weekday{color:#5aa9ff}
  .ssc-day.holiday{border-color:rgba(255,95,109,.48);background:linear-gradient(145deg,#101824,#17131a)}
  .ssc-holiday{font-size:9px;font-weight:900;color:#ff8792;background:#2b1219;border:1px solid #5c2833;border-radius:999px;padding:2px 5px}
  .ssc-weekend{font-size:9px;color:#6f8297}
  .ssc-closed{font-size:8px;font-weight:900;color:#ff8792;background:#261219;border:1px solid #51252e;border-radius:5px;padding:2px 5px}
`;document.head.appendChild(st);
}
function ensureSectorStrengthCalendar(){
  const mount=$('#sectorStrengthCalendarMount');if(!mount)return null;ensureSectorCalendarStyles();if($('#sectorStrengthCalendar'))return $('#sectorStrengthCalendar');
  const box=document.createElement('section');box.id='sectorStrengthCalendar';box.className='ssc-wrap';box.innerHTML=`<div class="ssc-head"><div><div class="eyebrow">DAILY SECTOR STRENGTH</div><h3>월간 주도섹터 이력</h3><div id="sscMeta" class="muted">일별 후보 데이터를 집계합니다.</div></div><div class="ssc-controls"><button id="sscPrev" class="ghost" type="button">‹</button><div id="sscMonth" class="ssc-month"></div><button id="sscNext" class="ghost" type="button">›</button><button id="sscToday" class="ghost" type="button">이번달</button></div></div><div id="sscSummary" class="ssc-summary"></div><div class="ssc-week"><div>일</div><div>월</div><div>화</div><div>수</div><div>목</div><div>금</div><div>토</div></div><div id="sscGrid" class="ssc-grid"></div><div id="sscDetail" class="ssc-detail litto-page-hidden"></div>`;
  mount.appendChild(box);$('#sscPrev').onclick=()=>shiftSectorMonth(-1);$('#sscNext').onclick=()=>shiftSectorMonth(1);$('#sscToday').onclick=()=>{MARKET_SECTOR_MONTH=new Date().toISOString().slice(0,7);saveSectorMonth();refreshSectorStrengthCalendar()};return box;
}
function saveSectorMonth(){localStorage.setItem('litto_market_sector_month',MARKET_SECTOR_MONTH)}
function shiftSectorMonth(delta){const [y,m]=MARKET_SECTOR_MONTH.split('-').map(Number),d=new Date(y,m-1+(Number(delta)||0),1);MARKET_SECTOR_MONTH=`${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}`;saveSectorMonth();refreshSectorStrengthCalendar()}
function switchMarketSubtab(tab){const sec=ensureMarketOverview();if(!sec)return;MARKET_SUBTAB=tab==='sector'?'sector':'overview';localStorage.setItem('litto_market_subtab',MARKET_SUBTAB);sec.querySelectorAll('.market-subtab').forEach(b=>b.classList.toggle('active',b.dataset.marketTab===MARKET_SUBTAB));$('#marketTabOverview')?.classList.toggle('active',MARKET_SUBTAB==='overview');$('#marketTabSector')?.classList.toggle('active',MARKET_SUBTAB==='sector');const btn=$('#marketOverviewRefresh');if(btn)btn.onclick=()=>MARKET_SUBTAB==='sector'?refreshSectorStrengthCalendar(true):refreshMarketPage(true);if(MARKET_SUBTAB==='sector')refreshSectorStrengthCalendar(false)}
function sectorMonthLabel(s){const [y,m]=String(s||'').split('-');return `${y}년 ${Number(m)}월`}
function renderSectorStrengthDetail(day){const detail=$('#sscDetail');if(!detail)return;if(!day){detail.classList.add('litto-page-hidden');detail.innerHTML='';return}detail.classList.remove('litto-page-hidden');detail.innerHTML=`<div class="ssc-detail-head"><div><b>${esc(day.date)} 강한 섹터</b><div class="muted">후보 ${day.candidate_count||0}종목 · 섹터분류 ${day.classified_count||0}종목</div></div><button class="ghost" id="sscDetailClose">닫기</button></div>${(day.sectors||[]).map(x=>`<div class="ssc-detail-sector"><h4>${esc(x.sector)} <span class="up">${x.count}개</span></h4><div class="ssc-stockchips">${(x.stocks||[]).map(st=>`<span class="ssc-stockchip" data-stock-action-code="${esc(st.code)}" data-stock-action-name="${esc(st.name||st.code)}" title="클릭하면 차트 · 수급 · 호가 · 메모를 선택합니다">${esc(st.name)} <small>${esc(st.code)}</small></span>`).join('')}</div></div>`).join('')||'<div class="ssc-empty">분류된 강한 섹터가 없습니다.</div>'}`;$('#sscDetailClose').onclick=()=>renderSectorStrengthDetail(null);bindStockActionClicks();detail.scrollIntoView({behavior:'smooth',block:'nearest'})}

function sectorCalendarLocalDateKey(dt=new Date()){
  const y=dt.getFullYear(),m=String(dt.getMonth()+1).padStart(2,'0'),d=String(dt.getDate()).padStart(2,'0');
  return `${y}-${m}-${d}`;
}
function sectorCalendarDayInfo(y,m,day){
  const dt=new Date(y,m-1,day);
  const w=dt.getDay();
  const names=['일','월','화','수','목','금','토'];
  const date=`${y}-${String(m).padStart(2,'0')}-${String(day).padStart(2,'0')}`;
  const holidays={
    '2026-01-01':'신정',
    '2026-02-16':'설날 연휴',
    '2026-02-17':'설날',
    '2026-02-18':'설날 연휴',
    '2026-03-01':'삼일절',
    '2026-03-02':'삼일절 대체',
    '2026-05-01':'노동절',
    '2026-05-05':'어린이날',
    '2026-05-24':'부처님오신날',
    '2026-05-25':'부처님오신날 대체',
    '2026-06-03':'지방선거일',
    '2026-06-06':'현충일',
    '2026-07-17':'제헌절',
    '2026-08-15':'광복절',
    '2026-08-17':'광복절 대체',
    '2026-09-24':'추석 연휴',
    '2026-09-25':'추석',
    '2026-09-26':'추석 연휴',
    '2026-09-28':'추석 대체',
    '2026-10-03':'개천절',
    '2026-10-05':'개천절 대체',
    '2026-10-09':'한글날',
    '2026-12-25':'성탄절',
    '2026-12-31':'연말 휴장',
  };
  const holiday=holidays[date]||'';
  const weekend=(w===0||w===6);
  return {date,weekday:names[w],w,holiday,weekend,isClosed:weekend||!!holiday};
}

function renderSectorStrengthCalendar(){
  ensureSectorStrengthCalendar();
  const d=MARKET_SECTOR_CALENDAR||{},grid=$('#sscGrid');
  if(!grid)return;
  $('#sscMonth').textContent=sectorMonthLabel(d.month||MARKET_SECTOR_MONTH);
  const top=(d.monthly_sectors||[]).slice(0,8);
  $('#sscSummary').innerHTML=top.length
    ?`<span><b>월간 누적</b></span>`+top.map((x,i)=>`<span>${i+1}. <b>${esc(x.sector)}</b> ${x.count}회</span>`).join('')
    :'<span>아직 저장된 섹터 데이터가 없습니다.</span>';

  const [y,m]=String(d.month||MARKET_SECTOR_MONTH).split('-').map(Number);
  const first=new Date(y,m-1,1);
  const last=new Date(y,m,0).getDate();
  const by=Object.fromEntries((d.days||[]).map(x=>[x.date,x]));
  const cells=[];

  // Calendar starts on Sunday. Keep leading/trailing blanks as real grid cells.
  for(let i=0;i<first.getDay();i++){
    cells.push('<div class="ssc-day ssc-calendar-blank" aria-hidden="true"></div>');
  }

  const today=sectorCalendarLocalDateKey();
  for(let day=1;day<=last;day++){
    const info=sectorCalendarDayInfo(y,m,day);
    const date=info.date;
    // Closed days must never display candidate/sector data, even if stale history exists.
    const x=info.isClosed?null:by[date];
    const sectors=(x?.sectors||[]).slice(0,4);
    const cls=[
      'ssc-day',
      date===today?'today':'',
      info.w===0?'sunday':'',
      info.w===6?'saturday':'',
      info.holiday?'holiday':''
    ].filter(Boolean).join(' ');

    const holidayLabel=info.holiday
      ?`<span class="ssc-holiday">${esc(info.holiday)}</span>`
      :(info.weekend?'<span class="ssc-weekend">주말</span>':'');

    const closeLabel=info.isClosed
      ?'<span class="ssc-closed">휴장</span>'
      :'';

    cells.push(`<div class="${cls}" data-ssc-date="${date}">
      <div class="ssc-date">
        <div class="ssc-date-main"><span class="ssc-daynum">${day}</span><span class="ssc-weekday">${info.weekday}</span>${holidayLabel}</div>
        <div class="ssc-date-side">${closeLabel}${x?`<span class="ssc-total">후보 ${x.candidate_count||0}</span>`:''}</div>
      </div>
      ${sectors.map((s,i)=>`<div class="ssc-sector${i===0?' rank-1':''}">
        <div class="ssc-sector-name">${i===0?'<span class="ssc-sector-rank">1위</span>':''}<b>${esc(s.sector)}</b></div>
        <span class="ssc-sector-count">${s.count}개</span>
      </div>`).join('')}
      ${x&&x.sectors?.length>4?`<div class="ssc-more">+ ${x.sectors.length-4}개 섹터</div>`:(!x?'<div class="ssc-more">기록 없음</div>':'')}
    </div>`);
  }

  const used=first.getDay()+last;
  const tail=(7-(used%7))%7;
  for(let i=0;i<tail;i++){
    cells.push('<div class="ssc-day ssc-calendar-blank" aria-hidden="true"></div>');
  }

  grid.innerHTML=cells.join('');
  grid.querySelectorAll('[data-ssc-date]').forEach(el=>el.onclick=()=>renderSectorStrengthDetail(by[el.dataset.sscDate]||null));
  const meta=$('#sscMeta');
  if(meta)meta.textContent=`${d.source||'LITTO 일별 후보'} · ${d.rule||''} · 저장 ${d.history_days||0}일${d.error?' · '+d.error:''}`;
}
async function refreshSectorStrengthCalendar(force=false){ensureSectorStrengthCalendar();try{const r=await fetch('/api/sector-strength-calendar?month='+encodeURIComponent(MARKET_SECTOR_MONTH)+(force?'&force=1':''));const d=await r.json();if(!r.ok)throw Error(d.error||'강한 섹터 달력 조회 실패');MARKET_SECTOR_CALENDAR=d;MARKET_SECTOR_MONTH=d.month||MARKET_SECTOR_MONTH;saveSectorMonth();renderSectorStrengthCalendar()}catch(e){MARKET_SECTOR_CALENDAR={...MARKET_SECTOR_CALENDAR,month:MARKET_SECTOR_MONTH,error:e.message};renderSectorStrengthCalendar()}}

function ensureUSMarket(){
  let sec=$('#us-market');if(sec)return sec;
  const main=document.querySelector('.workspace main')||document.querySelector('main');if(!main)return null;
  sec=document.createElement('section');sec.id='us-market';sec.className='card us-market-card';
  sec.innerHTML=`<div class="us-market-head"><div><div class="eyebrow">U.S. MARKET · KIWOOM REST</div><h2>미국시장</h2><div id="usMarketMeta" class="muted">순위 30초 재선정 · 가격/등락률 2초 실시간 반영</div></div><button id="usMarketRefresh" class="ghost" type="button">새로고침</button></div>
  <div class="us-subtabs"><button class="us-subtab active" data-us-tab="rank" type="button">미국시장 순위</button><button class="us-subtab" data-us-tab="watch" type="button">업종별 대표종목</button><span class="us-patch-badge">US-2TAB 적용</span></div>
  <div id="usTabRank" class="us-tabpane active">
    <div class="us-market-note">키움 미국주식 REST만 사용 · 카드별 TR이 독립적으로 동작합니다.</div>
    <div id="usMarketStatus" class="us-market-status"></div>
    <div class="us-market-grid">
      <div class="us-rank-card"><div class="us-rank-title"><b>🔥 인기 종목 TOP 20</b><span>실시간 조회순위</span></div><div id="usPopularRows" class="us-rank-rows"></div></div>
      <div class="us-rank-card"><div class="us-rank-title"><b>🚀 상승률 TOP 20</b><span>전일대비</span></div><div id="usGainerRows" class="us-rank-rows"></div></div>
      <div class="us-rank-card"><div class="us-rank-title"><b>💰 거래대금 TOP 20</b><span>당일 거래대금</span></div><div id="usValueRows" class="us-rank-rows"></div></div>
      <div class="us-rank-card"><div class="us-rank-title"><b>⚡ 강한 업종</b><span>업종 등락률</span></div><div id="usSectorRows" class="us-rank-rows"></div></div>
    </div>
  </div>
  <div id="usTabWatch" class="us-tabpane"><div id="usWatchlistMount"></div></div>`;
  main.appendChild(sec);
  $('#usMarketRefresh').onclick=()=>refreshUSMarket(true);
  sec.querySelectorAll('.us-subtab').forEach(b=>b.onclick=()=>switchUSSubtab(b.dataset.usTab));
  renderUSWatchlist();
  return sec;
}
function switchUSSubtab(tab){
  const sec=ensureUSMarket();if(!sec)return;
  const t=tab==='watch'?'watch':'rank';
  localStorage.setItem('litto_us_subtab',t);
  sec.querySelectorAll('.us-subtab').forEach(b=>b.classList.toggle('active',b.dataset.usTab===t));
  $('#usTabRank')?.classList.toggle('active',t==='rank');
  $('#usTabWatch')?.classList.toggle('active',t==='watch');
  $('#usMarketRefresh')?.classList.remove('litto-page-hidden');
  $('#usMarketRefresh').onclick=()=>t==='watch'?refreshUSWatchlist(true):refreshUSMarket(true);
  if(t==='watch')refreshUSWatchlist(false);
}
function usWatchPct(ticker){
  const q=US_WATCH_QUOTES[String(ticker||'').toUpperCase()]||{};
  // IMPORTANT: Number(null) and Number('') are 0 in JavaScript.  A missing
  // Kiwoom flu_rt must therefore be detected before numeric conversion;
  // otherwise failed/missing quotes are falsely displayed as 0.00%.
  const raw=q.change_rate;
  if(raw===null||raw===undefined||raw==='')return '<span class="us-watch-pct muted">-</span>';
  const pct=Number(raw);if(!Number.isFinite(pct))return '<span class="us-watch-pct muted">-</span>';
  const cls=pct>0?'up':pct<0?'down':'flat';return `<span class="us-watch-pct ${cls}">${pct>0?'+':''}${pct.toFixed(2)}%</span>`;
}
function usFmtWatchPrice(q){
  const n=Number(q?.price);if(!Number.isFinite(n))return '-';
  if(q?.is_index)return n.toLocaleString(undefined,{minimumFractionDigits:2,maximumFractionDigits:2});
  return '$'+n.toLocaleString(undefined,{minimumFractionDigits:n<10?2:0,maximumFractionDigits:n<10?4:2});
}
function usWatchPrice(ticker){const q=US_WATCH_QUOTES[String(ticker||'').toUpperCase()]||{};return `<span class="us-watch-price${q.is_index?' us-index-price':''}">${usFmtWatchPrice(q)}</span>`}
async function refreshUSWatchlist(force=false){
  if(US_WATCH_LOADING)return;US_WATCH_LOADING=true;
  const tickers=[...new Set([...(US_WATCHLIST_DATA.etfs||[]).map(x=>x.ticker),...(US_WATCHLIST_DATA.stocks||[]).map(x=>x.ticker)].filter(Boolean))];
  const mount=$('#usWatchlistMount');if(mount&&!Object.keys(US_WATCH_QUOTES).length)mount.insertAdjacentHTML('afterbegin','<div id="usWatchLoading" class="us-watch-loading">키움 현재가·등락률 불러오는 중...</div>');
  try{const r=await fetch('/api/us-watchlist?symbols='+encodeURIComponent(tickers.join(','))+(force?'&force=1':''));const d=await r.json();if(!r.ok)throw Error(d.error||'미국 대표종목 시세 조회 실패');US_WATCH_QUOTES=Object.fromEntries((d.quotes||[]).map(x=>[String(x.code||'').toUpperCase(),x]));US_WATCH_META=d;renderUSWatchlist()}
  catch(e){US_WATCH_META={...US_WATCH_META,errors:{...(US_WATCH_META.errors||{}),all:e.message}};renderUSWatchlist()}finally{US_WATCH_LOADING=false;$('#usWatchLoading')?.remove()}
}
function renderUSWatchlist(){
  const mount=$('#usWatchlistMount');if(!mount)return;
  const d=US_WATCHLIST_DATA;
  const etfs=(d.etfs||[]).map((x,i)=>`<div class="us-etf-chip"><span>${i+1}</span><b>${esc(x.ticker)}</b><div><strong>${esc(x.ko)}</strong><small>${esc(x.en)}</small></div><div class="us-watch-quote">${usWatchPrice(x.ticker)}${usWatchPct(x.ticker)}</div></div>`).join('');
  const groups=(d.sectorOrder||[]).map(sec=>{
    const rows=(d.stocks||[]).filter(x=>x.sector===sec);
    return `<section class="us-watch-sector"><div class="us-watch-sector-head"><b>${esc(sec)}</b><span>${rows.length}종목</span></div><div class="us-watch-table"><div class="us-watch-tr us-watch-th"><span>티커</span><span>종목명</span><span>현재가</span><span>등락률</span><span>비고</span></div>${rows.map(x=>`<div class="us-watch-tr"><b class="us-watch-ticker">${esc(x.ticker)}</b><span>${esc(x.ko)}<small class="us-watch-en">${esc(x.en)}</small></span>${usWatchPrice(x.ticker)}${usWatchPct(x.ticker)}<span class="us-watch-note">${esc(x.note||'')}</span></div>`).join('')}</div></section>`;
  }).join('');
  const errs=US_WATCH_META.errors||{};const errKeys=Object.keys(errs).filter(k=>k!=='all');const errCount=errKeys.length;const quoteCount=Object.keys(US_WATCH_QUOTES).length;const liveMeta=quoteCount?` · 시세 ${quoteCount}종목${errCount?` · 미조회 ${errCount}`:''}`:' · 시세 대기';
  const rt=US_WATCH_META.realtime||{};const rtOk=!!rt.connected;const rtText=rtOk?`FE 실시간 연결 · 수신 ${Number(rt.live_count||0)}종목`:`FE ${esc(rt.state||'대기')}${rt.error?' · '+esc(rt.error):''}`;
  const rtBadge=`<span class="us-status-${rtOk?'ok':'warn'}">${rtText}</span>`;
  const errBox=errCount?`<div class="us-watch-errors"><b>미조회 티커 ${errCount}개</b><span>${errKeys.map(esc).join(', ')}</span><small>거래소 매핑/상장 상태/API 호출 제한을 확인할 수 있도록 미조회 티커를 표시함</small></div>`:'';
  mount.innerHTML=`<div class="us-watch-intro"><div><div class="eyebrow">U.S. SECTOR WATCHLIST · FE REALTIME</div><h3>미국 업종별 대표종목</h3><p>사용자 제공 엑셀 기준 · 11대 섹터 ETF와 업종별 대표종목 55개${liveMeta}</p><div class="us-market-status">${rtBadge}</div><small>주식·ETF는 키움 FE/REST를 사용함. 지수 4종은 ETF 대용값이 아니라 실제 현물지수 포인트·등락률을 표시함. 지수는 달러($)가 아닌 포인트 단위임.</small></div><div class="us-watch-count"><b>${(d.stocks||[]).length}</b><span>대표종목</span></div></div>${errBox}<div class="us-etf-block"><div class="us-watch-block-title"><b>📌 미국 11대 섹터 ETF</b><span>현재가 · 등락률</span></div><div class="us-etf-grid">${etfs}</div></div><div class="us-watch-sectors">${groups}</div>`;
  switchUSSubtab(localStorage.getItem('litto_us_subtab')||'rank');
}
function usFmtNum(v,d=2){const n=Number(v);return Number.isFinite(n)?n.toLocaleString(undefined,{maximumFractionDigits:d}):'-'}
function usFmtPrice(v){const n=Number(v);return Number.isFinite(n)?'$'+n.toLocaleString(undefined,{minimumFractionDigits:n<10?2:0,maximumFractionDigits:n<10?4:2}):'-'}
function usFmtTradingValue(v){const n=Number(v);if(!Number.isFinite(n))return '-';const a=Math.abs(n);if(a>=1e9)return '$'+(n/1e9).toFixed(a>=1e10?1:2)+'B';if(a>=1e6)return '$'+(n/1e6).toFixed(a>=1e7?1:2)+'M';if(a>=1e3)return '$'+(n/1e3).toFixed(a>=1e4?1:2)+'K';return '$'+n.toLocaleString(undefined,{maximumFractionDigits:0})}
function usRankLiveQuote(code){return US_RANK_LIVE[String(code||'').trim().toUpperCase()]||null}
function usRankRows(rows,kind,error){
  if(error&&!rows?.length)return `<div class="us-card-error">${esc(error)}</div>`;
  const a=(rows||[]).slice(0,20);if(!a.length)return '<div class="empty">현재 표시할 데이터가 없습니다.</div>';
  return a.map((x,i)=>{const l=kind==='sector'?null:usRankLiveQuote(x.code);const livePct=l&&l.change_rate!==null&&l.change_rate!==undefined&&l.change_rate!==''?Number(l.change_rate):Number(x.change_rate);const livePrice=l&&Number.isFinite(Number(l.price))?Number(l.price):Number(x.price);const pct=livePct,pctTxt=Number.isFinite(pct)?`${pct>0?'+':''}${pct.toFixed(2)}%`:'-';const cls=pct>0?'up':pct<0?'down':'';const metric=kind==='value'?`거래대금 ${usFmtTradingValue(x.trading_value)}`:kind==='sector'?pctTxt:usFmtPrice(livePrice);const name=esc(x.name||x.name_en||x.code||'-');const code=esc(x.code||'');return `<div class="us-rank-row"><span class="us-rank-no">${x.rank||i+1}</span><div class="us-rank-stock"><b>${name}</b><span>${code}${x.exchange?' · '+esc(x.exchange):''}</span></div><div class="us-rank-metric ${kind==='sector'?cls:''}">${metric}</div>${kind!=='sector'?`<div class="us-rank-pct ${cls}">${pctTxt}</div>`:''}</div>`}).join('');
}
function renderUSMarket(){
  ensureUSMarket();const s=US_MARKET.sections||{},e=US_MARKET.errors||{};
  const meta=$('#usMarketMeta');if(meta){const rt=US_RANK_LIVE_META.realtime||{};const rtTxt=rt.connected?` · FE LIVE ${Number(rt.live_count||0)}종목`:' · FE 연결 대기';meta.textContent=`${US_MARKET.source||'키움 미국주식 REST'} · 순위 ${US_MARKET.updated_at?new Date(US_MARKET.updated_at).toLocaleTimeString():'대기'}${rtTxt}`;}
  const st=$('#usMarketStatus');if(st){const errs=Object.entries(e).filter(([,v])=>v);st.innerHTML=errs.length?errs.map(([k,v])=>`<span class="us-status-warn">${esc(k==='all'?'연결':k)} · ${esc(v)}</span>`).join(''):'<span class="us-status-ok">키움 미국주식 데이터 연결 정상</span>';}
  $('#usPopularRows').innerHTML=usRankRows(s.popular,'popular',e.popular||e.all);
  $('#usGainerRows').innerHTML=usRankRows(s.gainers,'gainers',e.gainers||e.all);
  $('#usValueRows').innerHTML=usRankRows(s.value||s.volume,'value',e.value||e.volume||e.all);
  $('#usSectorRows').innerHTML=usRankRows(s.sectors,'sector',e.sectors||e.all);
}
async function refreshUSMarket(force=false){return littoRefreshOnce('refreshUSMarket',()=>refreshUSMarketRead(force))}
async function refreshUSMarketRead(force=false){ensureUSMarket();try{const r=await fetch('/api/us-market'+(force?'?force=1':''));const d=await r.json();if(!r.ok)throw Error(d.error||'미국시장 조회 실패');US_MARKET=d;renderUSMarket();refreshUSRankLive()}catch(e){US_MARKET={...US_MARKET,errors:{...(US_MARKET.errors||{}),all:e.message}};renderUSMarket()}}
async function refreshUSRankLive(){
  if(US_RANK_LIVE_LOADING)return;
  const s=US_MARKET.sections||{};const codes=[...(s.popular||[]),...(s.gainers||[]),...(s.value||s.volume||[])].map(x=>String(x.code||'').trim().toUpperCase()).filter(Boolean);
  const symbols=[...new Set(codes)].slice(0,60);if(!symbols.length)return;
  US_RANK_LIVE_LOADING=true;
  try{const r=await fetch('/api/us-watchlist?symbols='+encodeURIComponent(symbols.join(',')));const d=await r.json();if(!r.ok)throw Error(d.error||'미국 순위 실시간 조회 실패');US_RANK_LIVE=Object.fromEntries((d.quotes||[]).filter(x=>!x.is_index).map(x=>[String(x.code||'').toUpperCase(),x]));US_RANK_LIVE_META=d;renderUSMarket()}catch(e){US_RANK_LIVE_META={errors:{all:e.message}}}finally{US_RANK_LIVE_LOADING=false}
}
function switchLittoPage(page){
  try{if(typeof closeAccountScreen==='function')closeAccountScreen()}catch(_e){}
  if(!['trade','alerts','market','us','journal'].includes(page))page='trade';LITTO_PAGE=page;localStorage.setItem('litto_page_v1',page);ensurePageBar();ensureMarketActionsBoard();ensureMarketOverview();ensureUSMarket();ensureJournal();
  document.querySelectorAll('#littoPageBar [data-page]').forEach(b=>b.classList.toggle('active',b.dataset.page===page));
  const main=document.querySelector('.workspace main')||document.querySelector('main');
  [...main.children].forEach(el=>{if(['market-actions','market-overview','us-market','journal-page'].includes(el.id))return;el.classList.toggle('litto-page-hidden',page!=='trade')});
  $('#market-actions')?.classList.toggle('litto-page-hidden',page!=='alerts');
  $('#market-overview')?.classList.toggle('litto-page-hidden',page!=='market');
  $('#us-market')?.classList.toggle('litto-page-hidden',page!=='us');
  $('#journal-page')?.classList.toggle('litto-page-hidden',page!=='journal');
  if(page==='trade'){ensureTradeSubtabs();switchTradeSubtab(TRADE_SUBTAB)}if(page==='alerts')refreshMarketActions(false);if(page==='market'){switchMarketSubtab(MARKET_SUBTAB);if(MARKET_SUBTAB==='sector')refreshSectorStrengthCalendar(false);else refreshMarketPage(false)}if(page==='us')refreshUSMarket(false);if(page==='journal')refreshJournal();window.scrollTo({top:0,behavior:'smooth'});
}
function journalDateRange(){
  const y=Number(JOURNAL_YEAR)||new Date().getFullYear(), m=Math.min(12,Math.max(1,Number(JOURNAL_MONTH)||1));
  const pad=n=>String(n).padStart(2,'0');
  const last=new Date(y,m,0).getDate();
  return {start:`${y}-${pad(m)}-01`,end:`${y}-${pad(m)}-${pad(last)}`};
}
function journalMonthLabel(){return `${JOURNAL_YEAR}년 ${JOURNAL_MONTH}월`}
function setJournalMonth(month){JOURNAL_MONTH=Number(month);localStorage.setItem('litto_journal_month',String(JOURNAL_MONTH));localStorage.setItem('litto_journal_year',String(JOURNAL_YEAR));refreshJournal()}
function shiftJournalYear(delta){JOURNAL_YEAR+=Number(delta)||0;localStorage.setItem('litto_journal_year',String(JOURNAL_YEAR));refreshJournal()}
function journalMoney(v){const n=Number(v);return Number.isFinite(n)?Math.round(n).toLocaleString()+'원':'-'}
function journalPct(v){const n=Number(v);return Number.isFinite(n)?`${n>0?'+':''}${n.toFixed(2)}%`:'-'}
function ensureJournal(){
  let sec=$('#journal-page');if(sec)return sec;
  const main=document.querySelector('.workspace main')||document.querySelector('main');if(!main)return null;
  sec=document.createElement('section');sec.id='journal-page';sec.className='journal-page card';
  sec.innerHTML=`<div class="journal-head"><div><div class="eyebrow">TRADING JOURNAL · SQLITE</div><h2>매매일지 & 복기</h2><div id="journalMeta" class="muted">키움 체결/실현손익 자동수집 · 사용자 복기는 DB에 영구 저장</div></div><div class="journal-actions"><input id="journalImportDate" type="date"><button id="journalImport" class="primary-cta" type="button">오늘 체결 불러오기</button><button id="journalManual" class="ghost" type="button">직접 추가</button><button id="journalStorage" class="ghost" type="button">저장위치 변경</button><button id="journalStorageReset" class="ghost" type="button">기본위치</button><a id="journalExport" class="button ghost" href="/api/journal/export">CSV</a><button id="journalRefresh" class="ghost" type="button">새로고침</button></div></div>
  <div class="journal-filterbar journal-monthbar"><div class="journal-year-nav"><button id="journalPrevYear" type="button" aria-label="이전 연도">‹</button><b id="journalYearLabel">${JOURNAL_YEAR}년</b><button id="journalNextYear" type="button" aria-label="다음 연도">›</button></div><div class="journal-month-tabs">${Array.from({length:12},(_,i)=>`<button data-jmonth="${i+1}" type="button">${i+1}월</button>`).join('')}</div><span id="journalDb" class="journal-db"></span></div>
  <div id="journalStats" class="journal-stats"></div>
  <div class="journal-body"><div class="journal-list-wrap"><div class="journal-subhead"><b>매매 기록</b><span id="journalCount">0건</span></div><div id="journalRows" class="journal-rows"></div></div><div class="journal-side"><div class="journal-subhead"><b>전략별 통계</b><span>복기 전략 기준</span></div><div id="journalStrategyStats" class="journal-strategy-stats"></div><div class="journal-import-log"><div class="journal-subhead"><b>자동수집 기록</b><span>최근 10회</span></div><div id="journalImportLog"></div></div></div></div>`;
  main.appendChild(sec);
  const date=$('#journalImportDate');if(date){date.value=new Date().toISOString().slice(0,10);const openCalendar=()=>{try{if(typeof date.showPicker==='function')date.showPicker()}catch(_){}};date.addEventListener('click',openCalendar);date.addEventListener('focus',openCalendar);}
  $('#journalImport').onclick=()=>importJournalDate();$('#journalRefresh').onclick=()=>refreshJournal();$('#journalManual').onclick=()=>manualJournalAdd();$('#journalStorage').onclick=()=>changeJournalStorage();$('#journalStorageReset').onclick=()=>resetJournalStorage();
  $('#journalPrevYear').onclick=()=>shiftJournalYear(-1);$('#journalNextYear').onclick=()=>shiftJournalYear(1);
  sec.querySelectorAll('[data-jmonth]').forEach(b=>b.onclick=()=>setJournalMonth(b.dataset.jmonth));
  return sec;
}
async function refreshJournal(){
  ensureJournal();const {start,end}=journalDateRange();const q=new URLSearchParams();if(start)q.set('start',start);if(end)q.set('end',end);q.set('limit','1000');
  try{const r=await fetch('/api/journal?'+q.toString());const d=await r.json();if(!r.ok)throw Error(d.error||'매매일지 조회 실패');JOURNAL=d;renderJournal()}catch(e){const rows=$('#journalRows');if(rows)rows.innerHTML=`<div class="journal-error">${esc(e.message)}</div>`}
}
async function changeJournalStorage(){
  const current=JOURNAL.storage_dir||'';
  const value=prompt('복기/매매일지를 저장할 폴더의 전체 경로를 입력하세요.\n예: D:\\LITTO_DATA\n\n현재 위치: '+(current||'기본 위치'),current||'');
  if(value===null)return;const directory=String(value).trim();if(!directory)return alert('저장 폴더 경로를 입력하세요.');
  if(!confirm('저장 위치를 변경하면 기존 복기 데이터도 새 폴더로 복사합니다.\n\n'+directory+'\n\n계속할까요?'))return;
  const btn=$('#journalStorage');if(btn){btn.disabled=true;btn.textContent='이전 중...'}
  try{const r=await api('/api/journal/storage',{directory,migrate:true});JOURNAL=r.journal||JOURNAL;renderJournal();alert('저장 위치를 변경했습니다.\n'+(r.storage?.db_path||JOURNAL.db_path||''));}
  catch(e){alert('저장 위치 변경 실패: '+e.message)}
  finally{if(btn){btn.disabled=false;btn.textContent='저장위치 변경'}}
}
async function resetJournalStorage(){
  if(!confirm('기본 저장 위치로 되돌릴까요?\n현재 복기 데이터도 기본 위치로 복사합니다.'))return;
  const btn=$('#journalStorageReset');if(btn){btn.disabled=true;btn.textContent='이전 중...'}
  try{const r=await api('/api/journal/storage-reset',{migrate:true});JOURNAL=r.journal||JOURNAL;renderJournal();alert('기본 저장 위치로 변경했습니다.\n'+(r.storage?.db_path||JOURNAL.db_path||''));}
  catch(e){alert('기본 위치 변경 실패: '+e.message)}
  finally{if(btn){btn.disabled=false;btn.textContent='기본위치'}}
}
async function ensureJournalStorageReady(){
  if(JOURNAL.storage_configured)return true;
  const current=JOURNAL.storage_dir||'';
  const choose=confirm('복기/매매일지 저장 위치가 아직 지정되지 않았습니다.\n\n[확인] 원하는 저장 폴더를 지정\n[취소] 현재 기본 위치를 사용\n\n현재 기본 위치:\n'+(current||'확인 중'));
  if(choose){
    const value=prompt('복기/매매일지를 저장할 폴더의 전체 경로를 입력하세요.\n예: D:\\LITTO_DATA',current||'');
    if(value===null)return false;
    const directory=String(value).trim();
    if(!directory){alert('저장 폴더 경로를 입력하세요.');return false;}
    try{
      const r=await api('/api/journal/storage',{directory,migrate:true});
      JOURNAL=r.journal||JOURNAL;renderJournal();
      alert('저장 위치를 지정했습니다.\n'+(r.storage?.db_path||JOURNAL.db_path||''));
      return true;
    }catch(e){alert('저장 위치 지정 실패: '+e.message);return false;}
  }
  try{
    const r=await api('/api/journal/storage-confirm-default',{});
    JOURNAL=r.journal||JOURNAL;renderJournal();
    alert('기본 저장 위치를 사용합니다.\n'+(r.storage?.db_path||JOURNAL.db_path||''));
    return true;
  }catch(e){alert('저장 위치 확인 실패: '+e.message);return false;}
}

async function importJournalDate(){
  if(!(await ensureJournalStorageReady()))return;
  const d=$('#journalImportDate')?.value||new Date().toISOString().slice(0,10),btn=$('#journalImport');if(btn){btn.disabled=true;btn.textContent='수집 중...'}
  try{const r=await api('/api/journal/import',{date:d});const parts=String(d).split('-');if(parts.length>=2){JOURNAL_YEAR=Number(parts[0])||JOURNAL_YEAR;JOURNAL_MONTH=Number(parts[1])||JOURNAL_MONTH;localStorage.setItem('litto_journal_year',String(JOURNAL_YEAR));localStorage.setItem('litto_journal_month',String(JOURNAL_MONTH));}await refreshJournal();const msg=`${r.date} · ${r.source} · ${r.rows}건 · 신규 ${r.inserted} / 갱신 ${r.updated}${r.message?'\n'+r.message:''}`;alert(msg)}catch(e){alert('자동수집 실패: '+e.message)}finally{if(btn){btn.disabled=false;btn.textContent='오늘 체결 불러오기'}}
}
async function manualJournalAdd(){
  if(!(await ensureJournalStorageReady()))return;
  const name=prompt('종목명');if(name===null||!name.trim())return;const code=prompt('종목코드(선택)','')||'';const date=prompt('매매일 YYYY-MM-DD',new Date().toISOString().slice(0,10));if(!date)return;
  const buy=prompt('평균 매수가','')||'',sell=prompt('평균 매도가','')||'',qty=prompt('매매 수량','')||'',ret=prompt('수익률 %(선택)','')||'',pnl=prompt('손익금액 원(선택)','')||'';
  api('/api/journal/manual',{trade:{trade_date:date,stock_code:code,stock_name:name,buy_avg:buy,sell_avg:sell,buy_qty:qty,sell_qty:qty,return_rate:ret,pnl}}).then(async()=>{const p=String(date).split('-');if(p.length>=2){JOURNAL_YEAR=Number(p[0])||JOURNAL_YEAR;JOURNAL_MONTH=Number(p[1])||JOURNAL_MONTH;localStorage.setItem('litto_journal_year',String(JOURNAL_YEAR));localStorage.setItem('litto_journal_month',String(JOURNAL_MONTH));}await refreshJournal()}).catch(e=>alert(e.message));
}
function triSelect(name,value,label){const v=value===true?'1':value===false?'0':'';return `<label>${label}<select name="${name}"><option value="" ${v===''?'selected':''}>미확인</option><option value="1" ${v==='1'?'selected':''}>예</option><option value="0" ${v==='0'?'selected':''}>아니오</option></select></label>`}
function openJournalReview(id){
  const row=(JOURNAL.rows||[]).find(x=>Number(x.id)===Number(id));if(!row)return;
  let ov=$('#journalReviewOverlay');if(!ov){ov=document.createElement('div');ov.id='journalReviewOverlay';ov.className='journal-review-overlay';document.body.appendChild(ov)}
  ov.innerHTML=`<div class="journal-review-box"><div class="journal-review-head"><div><div class="eyebrow">REVIEW</div><h2>${esc(row.stock_name)} <small>${esc(row.trade_date)}</small></h2><div>${journalPct(row.return_rate)} · ${journalMoney(row.pnl)}</div></div><button id="journalReviewClose" class="ghost">닫기</button></div><form id="journalReviewForm"><div class="journal-review-meta"><label class="journal-sector-field">섹터<input name="sector_name" value="${esc(row.saved_sector||row.sector_name||'미분류')}" readonly></label><fieldset class="journal-stock-class"><legend>종목 구분</legend>${['개별','섹터','테마'].map(x=>`<label class="journal-class-chip"><input type="radio" name="stock_class" value="${x}" ${(row.stock_class||'')===x?'checked':''}><span>${x}</span></label>`).join('')}</fieldset></div><div class="journal-review-grid"><label>매매유형<select name="strategy"><option value="">미분류</option>${['종배','상따','끼도주','눌림','돌파','기타'].map(x=>`<option ${row.strategy===x?'selected':''}>${x}</option>`).join('')}</select></label>${triSelect('rule_followed',row.rule_followed,'원칙 준수')}${triSelect('leader_stock',row.leader_stock,'주도주')}${triSelect('sector_strong',row.sector_strong,'강한 섹터')}${triSelect('heartzone',row.heartzone,'하트존')}${triSelect('lightning',row.lightning,'피뢰침')}${triSelect('chasing',row.chasing,'추격매수')}${triSelect('averaging_down',row.averaging_down,'물타기')}</div><label>진입 이유<textarea name="entry_reason">${esc(row.entry_reason||'')}</textarea></label><label>매도 이유<textarea name="exit_reason">${esc(row.exit_reason||'')}</textarea></label><div class="journal-review-two"><label>잘한 점<textarea name="good">${esc(row.good||'')}</textarea></label><label>잘못한 점<textarea name="bad">${esc(row.bad||'')}</textarea></label></div><label>다음 매매에서 바꿀 점<textarea name="next_action">${esc(row.next_action||'')}</textarea></label><label>태그<input name="tags" value="${esc(row.tags||'')}" placeholder="예: 반도체, 종배, 추격금지"></label><div class="journal-review-actions"><button type="submit" class="primary-cta">복기 저장</button><button type="button" id="journalDelete" class="danger">기록 삭제</button></div></form></div>`;
  ov.classList.add('open');$('#journalReviewClose').onclick=()=>ov.classList.remove('open');ov.onclick=e=>{if(e.target===ov)ov.classList.remove('open')};
  $('#journalReviewForm').onsubmit=async e=>{e.preventDefault();if(!(await ensureJournalStorageReady()))return;const f=new FormData(e.target),review={};for(const [k,v] of f.entries()){if(['rule_followed','leader_stock','sector_strong','fzone','heartzone','lightning','chasing','averaging_down'].includes(k))review[k]=v===''?null:v==='1';else review[k]=v}try{const r=await api('/api/journal/review',{id,review});JOURNAL=r.journal||JOURNAL;renderJournal();ov.classList.remove('open')}catch(err){alert(err.message)}};
  $('#journalDelete').onclick=async()=>{if(!confirm('이 매매 기록을 삭제할까요?'))return;try{const r=await api('/api/journal/delete',{id});JOURNAL=r.journal||JOURNAL;renderJournal();ov.classList.remove('open')}catch(err){alert(err.message)}};
}
function renderJournal(){
  ensureJournal();const rows=JOURNAL.rows||[],st=JOURNAL.stats||{};$('#journalCount').textContent=journalMonthLabel()+' · '+rows.length+'건';$('#journalDb').textContent=JOURNAL.db_path?((JOURNAL.storage_is_default?'기본 저장':'사용자 지정')+' · '+JOURNAL.db_path):'';$('#journalDb').title=JOURNAL.db_path||'';
  const yl=$('#journalYearLabel');if(yl)yl.textContent=JOURNAL_YEAR+'년';document.querySelectorAll('[data-jmonth]').forEach(b=>b.classList.toggle('active',Number(b.dataset.jmonth)===Number(JOURNAL_MONTH)));const {start,end}=journalDateRange();const exp=$('#journalExport');if(exp)exp.href='/api/journal/export?'+new URLSearchParams({start,end}).toString();
  $('#journalStats').innerHTML=[['매매',st.count??0,'건'],['승률',st.win_rate??0,'%'],['실현손익',Math.round(Number(st.pnl||0)).toLocaleString(),'원'],['평균수익률',st.avg_return??'-','%'],['손익비',st.profit_factor??'-','']].map(x=>`<div class="journal-stat"><span>${x[0]}</span><b>${x[1]}${x[2]}</b></div>`).join('');
  $('#journalRows').innerHTML=rows.length?rows.map(r=>{const rv=Number(r.return_rate),cl=Number(r.pnl||0)>0?'up':Number(r.pnl||0)<0?'down':(rv>0?'up':rv<0?'down':'');const reviewed=!!(r.review_updated_at||r.entry_reason||r.good||r.bad||r.strategy);const sellAmount=Number(r.sell_amount!=null?r.sell_amount:(Number(r.sell_qty||0)*Number(r.sell_avg||0)));return `<div class="journal-row" data-jid="${r.id}"><div class="journal-row-main journal-sell-only"><span class="journal-date">${esc(r.trade_date)}</span><div class="journal-stock"><b>${esc(r.stock_name||r.stock_code)}</b><small>${esc(r.stock_code||'')}${r.saved_sector?` · <span class="journal-saved-sector">${esc(r.saved_sector)}</span>`:''} · 당일 매도 합산</small></div><div class="journal-sell-amount"><span>총 매도금액</span><b>${journalMoney(sellAmount)}</b><small>${money(r.sell_qty)}주 · 평균 ${money(r.sell_avg)}</small></div><div class="journal-pnl ${cl}"><span>실현손익</span><b>${journalMoney(r.pnl)}</b><small>${journalPct(r.return_rate)}</small></div><div class="journal-row-actions"><button class="journal-review-btn ${reviewed?'done':''}" data-review-id="${r.id}">${reviewed?'복기완료':'복기하기'}</button><button class="journal-delete-btn" type="button" data-jdelete-id="${r.id}">삭제</button></div></div>${r.strategy||r.entry_reason?`<div class="journal-row-review"><span>${esc(r.strategy||'미분류')}</span>${r.entry_reason?`<p>${esc(r.entry_reason)}</p>`:''}${r.bad?`<p class="bad">실수: ${esc(r.bad)}</p>`:''}${r.next_action?`<p class="next">다음: ${esc(r.next_action)}</p>`:''}</div>`:''}</div>`}).join(''):'<div class="empty">매도 완료 내역이 없습니다. 키움 연결 후 “오늘 체결 불러오기”를 눌러보세요.</div>';
  document.querySelectorAll('[data-review-id]').forEach(b=>b.onclick=()=>openJournalReview(Number(b.dataset.reviewId)));
  document.querySelectorAll('[data-jdelete-id]').forEach(b=>b.onclick=async()=>{
    const id=Number(b.dataset.jdeleteId);
    const row=(JOURNAL.rows||[]).find(x=>Number(x.id)===id);
    const label=row?`${row.trade_date} ${row.stock_name||row.stock_code||''}`:'이 매매 기록';
    if(!confirm(`${label}\n\n삭제할까요? 삭제 후에는 되돌릴 수 없습니다.`))return;
    try{
      const r=await api('/api/journal/delete',{id});
      JOURNAL=r.journal||JOURNAL;
      renderJournal();
    }catch(err){alert('삭제 실패: '+err.message)}
  });
  const ss=st.strategies||[];$('#journalStrategyStats').innerHTML=ss.length?ss.map(x=>`<div class="journal-strategy-row"><b>${esc(x.strategy)}</b><span>${x.count}회</span><span>승률 ${x.win_rate}%</span><span class="${Number(x.pnl)>0?'up':Number(x.pnl)<0?'down':''}">${journalMoney(x.pnl)}</span></div>`).join(''):'<div class="empty">복기에서 매매유형을 지정하면 통계가 쌓입니다.</div>';
  $('#journalImportLog').innerHTML=(JOURNAL.imports||[]).map(x=>`<div class="journal-import-item"><b>${esc(x.trade_date)}</b><span>${esc(x.source)} · ${x.row_count}건</span>${x.message?`<small>${esc(x.message)}</small>`:''}</div>`).join('')||'<div class="empty">자동수집 기록 없음</div>';
}
function marketNum(v){return v==null?'-':Number(v).toLocaleString(undefined,{maximumFractionDigits:2})}
function krwValue(v){const n=Number(v);if(!Number.isFinite(n))return '-';if(n>=1e12)return (n/1e12).toLocaleString(undefined,{maximumFractionDigits:2})+'조';if(n>=1e8)return (n/1e8).toLocaleString(undefined,{maximumFractionDigits:0})+'억';if(n>=1e4)return (n/1e4).toLocaleString(undefined,{maximumFractionDigits:0})+'만';return Math.round(n).toLocaleString()}
function flowNum(v){if(v==null)return'-';const n=Number(v);return `${n>0?'+':''}${Math.round(n).toLocaleString()}`}
function drawMarketChart(id,points){
  const c=document.getElementById(id);if(!c)return;
  const arr=(Array.isArray(points)?points:[]).filter(p=>Number.isFinite(Number(p?.close)));
  const wrap=c.parentElement,dpr=window.devicePixelRatio||1,w=Math.max(320,wrap?.clientWidth||640),h=Math.max(220,wrap?.clientHeight||280);
  c.width=Math.round(w*dpr);c.height=Math.round(h*dpr);c.style.width=w+'px';c.style.height=h+'px';
  const ctx=c.getContext('2d');ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,w,h);
  if(arr.length<2){ctx.fillStyle='#718198';ctx.font='12px sans-serif';ctx.textAlign='center';ctx.fillText('15분 차트 데이터 대기중',w/2,h/2);ctx.textAlign='start';return;}
  const vals=arr.map(p=>Number(p.close)),hi=Math.max(...vals),lo=Math.min(...vals),range=Math.max(.01,hi-lo);
  const pad={l:54,r:12,t:16,b:26},pw=w-pad.l-pad.r,ph=h-pad.t-pad.b;
  const x=i=>pad.l+(arr.length===1?0:i/(arr.length-1))*pw,y=v=>pad.t+(hi-v)/range*ph;
  ctx.strokeStyle='#1c2a3c';ctx.lineWidth=1;ctx.fillStyle='#718198';ctx.font='10px sans-serif';
  for(let i=0;i<=4;i++){const yy=pad.t+ph*i/4;ctx.beginPath();ctx.moveTo(pad.l,yy);ctx.lineTo(w-pad.r,yy);ctx.stroke();const pv=hi-range*i/4;ctx.fillText(pv.toLocaleString(undefined,{maximumFractionDigits:2}),4,yy+3)}
  const first=vals[0],last=vals[vals.length-1];ctx.strokeStyle=last>=first?'#f85149':'#58a6ff';ctx.lineWidth=2;ctx.beginPath();arr.forEach((p,i)=>{const xx=x(i),yy=y(Number(p.close));if(i===0)ctx.moveTo(xx,yy);else ctx.lineTo(xx,yy)});ctx.stroke();
  ctx.lineTo(x(arr.length-1),pad.t+ph);ctx.lineTo(x(0),pad.t+ph);ctx.closePath();ctx.globalAlpha=.08;ctx.fillStyle=last>=first?'#f85149':'#58a6ff';ctx.fill();ctx.globalAlpha=1;
  ctx.fillStyle='#8b949e';ctx.font='10px sans-serif';const marks=Math.min(5,arr.length);for(let m=0;m<marks;m++){const i=Math.round(m*(arr.length-1)/Math.max(1,marks-1));let t=String(arr[i]?.time||'');if(t.length>=12)t=t.slice(-6,-4)+':'+t.slice(-4,-2);else if(t.length>=4)t=t.slice(-4,-2)+':'+t.slice(-2);ctx.fillText(t,Math.max(pad.l,x(i)-14),h-7)}
  const ly=y(last);ctx.setLineDash([4,3]);ctx.strokeStyle='#53657a';ctx.beginPath();ctx.moveTo(pad.l,ly);ctx.lineTo(w-pad.r,ly);ctx.stroke();ctx.setLineDash([]);ctx.fillStyle='#c9d1d9';ctx.fillText(last.toLocaleString(undefined,{maximumFractionDigits:2}),Math.max(pad.l,w-pad.r-62),Math.max(12,ly-5));
}
let MARKET_FLOW_MODAL_BUSY=false;
function marketFlowAmount(v){const n=Number(v);if(!Number.isFinite(n))return '-';return `${n>0?'+':''}${Math.round(n).toLocaleString()}억`}
function ensureMarketFlowModal(){
  let m=$('#marketFlowModal');if(m)return m;
  m=document.createElement('div');m.id='marketFlowModal';m.className='market-flow-modal';
  m.innerHTML=`<div class="market-flow-dialog" role="dialog" aria-modal="true" aria-labelledby="marketFlowTitle"><div class="market-flow-head"><div><div class="eyebrow">10 TRADING DAYS · INVESTOR FLOW</div><h2 id="marketFlowTitle">시장 수급</h2><div id="marketFlowMeta" class="muted">키움 수급 조회</div></div><button id="marketFlowClose" class="market-flow-close" type="button">×</button></div><div id="marketFlowBody" class="market-flow-body"><div class="empty">조회 중...</div></div></div>`;
  document.body.appendChild(m);
  $('#marketFlowClose').onclick=()=>m.classList.remove('show');
  m.addEventListener('click',e=>{if(e.target===m)m.classList.remove('show')});
  document.addEventListener('keydown',e=>{if(e.key==='Escape')m.classList.remove('show')});
  return m;
}
async function openMarketFlow(market,force=false){
  const key=market==='kosdaq'?'kosdaq':'kospi',m=ensureMarketFlowModal();m.classList.add('show');
  $('#marketFlowTitle').textContent=key==='kospi'?'코스피 최근 10거래일 수급':'코스닥 최근 10거래일 수급';
  $('#marketFlowMeta').textContent='개인 · 외국인 · 기관 순매수 금액';
  $('#marketFlowBody').innerHTML='<div class="empty">최근 10거래일 수급 조회 중...</div>';
  if(MARKET_FLOW_MODAL_BUSY)return;MARKET_FLOW_MODAL_BUSY=true;
  try{
    const q=new URLSearchParams({market:key,days:'10'});if(force)q.set('force','1');
    const r=await fetch('/api/market-investor-history?'+q.toString()),d=await r.json();if(!r.ok)throw Error(d.error||'수급 조회 실패');
    const rows=Array.isArray(d.rows)?d.rows:[],t=d.totals||{};
    $('#marketFlowMeta').textContent=`${d.source||'키움 공식 REST'} · ${rows.length}거래일${d.error?' · '+d.error:''}`;
    $('#marketFlowBody').innerHTML=`<div class="market-flow-summary"><div><span>개인 10일 누적</span><b class="${cls(Number(t.personal||0))}">${marketFlowAmount(t.personal)}</b></div><div><span>외국인 10일 누적</span><b class="${cls(Number(t.foreign||0))}">${marketFlowAmount(t.foreign)}</b></div><div><span>기관 10일 누적</span><b class="${cls(Number(t.institution||0))}">${marketFlowAmount(t.institution)}</b></div></div><div class="market-flow-table"><div class="market-flow-tr market-flow-th"><span>날짜</span><span>개인</span><span>외국인</span><span>기관</span></div>${rows.slice().reverse().map(x=>`<div class="market-flow-tr"><span>${esc(String(x.date||'').slice(5).replace('-','.'))}</span><b class="${cls(Number(x.personal||0))}">${marketFlowAmount(x.personal)}</b><b class="${cls(Number(x.foreign||0))}">${marketFlowAmount(x.foreign)}</b><b class="${cls(Number(x.institution||0))}">${marketFlowAmount(x.institution)}</b></div>`).join('')||'<div class="empty">수급 데이터가 없습니다.</div>'}</div><button class="ghost market-flow-refresh" type="button">다시 조회</button>`;
    m.querySelector('.market-flow-refresh')?.addEventListener('click',()=>openMarketFlow(key,true));
  }catch(e){$('#marketFlowBody').innerHTML=`<div class="empty">수급 조회 실패 · ${esc(e.message)}</div>`}finally{MARKET_FLOW_MODAL_BUSY=false}
}
function bindMarketFlowClicks(){
  const hk=$('#headerKospi'),hq=$('#headerKosdaq');
  if(hk&&!hk.dataset.flowBound){hk.dataset.flowBound='1';const target=hk.closest('.header-market-item')||hk;target.classList.add('market-flow-clickable');target.addEventListener('click',()=>openMarketFlow('kospi'))}
  if(hq&&!hq.dataset.flowBound){hq.dataset.flowBound='1';const target=hq.closest('.header-market-item')||hq;target.classList.add('market-flow-clickable');target.addEventListener('click',()=>openMarketFlow('kosdaq'))}
  document.querySelectorAll('[data-market-flow]').forEach(el=>{if(el.dataset.flowBound)return;el.dataset.flowBound='1';el.addEventListener('click',()=>openMarketFlow(el.dataset.marketFlow))})
}

function renderMarketOverview(){
  const sec=ensureMarketOverview(),grid=$('#marketOverviewGrid');if(!sec||!grid)return;const mk=MARKET_OVERVIEW.markets||{};
  const total=MARKET_OVERVIEW.total_trading_value_krw;const kv=mk.kospi?.trading_value_krw,kq=mk.kosdaq?.trading_value_krw;const summary=$('#marketOverviewSummary');
  if(summary)summary.innerHTML=`<div class="market-total-value"><span>오늘 양시장 거래대금</span><b>${krwValue(total)}</b></div><div class="market-value-split"><span>KOSPI <b>${krwValue(kv)}</b></span><span>KOSDAQ <b>${krwValue(kq)}</b></span></div>`;
  grid.innerHTML=['kospi','kosdaq'].map(k=>{const x=mk[k]||{},i=x.investor||{},b=x.breadth||{};const tv=x.trading_value_krw??(x.trading_value!=null?Number(x.trading_value)*1e6:null);return `<div class="market-snapshot market-flow-clickable" data-market-flow="${k}" title="클릭하면 최근 10거래일 개인 · 외국인 · 기관 수급을 봅니다"><h3>${esc(x.name||k.toUpperCase())}</h3><div class="market-index-line"><strong>${marketNum(x.price)}</strong><span class="${cls(Number(x.change_rate||0))}">${pct(Number(x.change_rate||0))}</span><span>${marketNum(x.change)}</span></div><div class="market-money-box"><span>거래대금</span><b>${krwValue(tv)}</b></div><div class="market-flow-grid"><div class="market-mini"><span>개인 순매수</span><b class="${cls(Number(i.personal||0))}">${flowNum(i.personal)}</b></div><div class="market-mini"><span>외국인 순매수</span><b class="${cls(Number(i.foreign||0))}">${flowNum(i.foreign)}</b></div><div class="market-mini"><span>기관 순매수</span><b class="${cls(Number(i.institution||0))}">${flowNum(i.institution)}</b></div></div><div class="market-breadth-grid"><div class="market-mini"><span>상승</span><b class="up">${b.up??'-'}</b></div><div class="market-mini"><span>보합</span><b>${b.flat??'-'}</b></div><div class="market-mini"><span>하락</span><b class="down">${b.down??'-'}</b></div></div><div class="market-chart-wrap"><canvas class="market-chart" id="marketChart_${k}"></canvas></div><div class="muted" style="margin-top:7px">거래량 ${marketNum(x.volume)} · 상한 ${b.upper??'-'} / 하한 ${b.lower??'-'}</div></div>`}).join('')||'<div class="empty">키움 연결 후 시장 데이터가 표시됩니다.</div>';
  const meta=$('#marketOverviewMeta');if(meta)meta.textContent=`${MARKET_OVERVIEW.source||'키움 공식 REST'} · ${MARKET_OVERVIEW.updated_at?new Date(MARKET_OVERVIEW.updated_at).toLocaleTimeString():'대기'}${MARKET_OVERVIEW.error?' · '+MARKET_OVERVIEW.error:''}`;
  ['kospi','kosdaq'].forEach(k=>drawMarketChart(`marketChart_${k}`,mk[k]?.chart||[]));bindMarketFlowClicks();
}


function ensureMarketCalendar(){
  const mount=$('#marketCalendarMount');if(!mount||$('#marketCalendar'))return $('#marketCalendar');
  const box=document.createElement('section');box.id='marketCalendar';box.className='market-calendar';
  box.innerHTML=`<div class="market-calendar-head"><div><div class="eyebrow">MARKET & INDUSTRY CALENDAR</div><h2>마켓 일정 · 경제 + 기업 + 산업행사</h2><div id="marketCalendarMeta" class="muted">공식 일정 수집 대기</div></div><button id="marketCalendarRefresh" class="ghost" type="button">일정 새로고침</button></div>
  <div class="market-calendar-toolbar"><div class="market-calendar-filter-block"><span class="cal-filter-label">기간</span><div class="market-calendar-filters" id="marketCalendarRanges"><button data-range="today">오늘</button><button data-range="week">이번 주</button><button data-range="30d">30일</button><button data-range="90d">90일</button><button data-range="180d">6개월</button></div></div><div class="market-calendar-filter-block"><span class="cal-filter-label">국가</span><div class="market-calendar-filters country" id="marketCalendarCountries"><button data-country="ALL">전체</button><button data-country="KR">한국</button><button data-country="US">미국</button><button data-country="CN">중국</button><button data-country="JP">일본</button><button data-country="EU">유럽</button></div></div></div>
  <div class="market-calendar-toolbar compact"><div class="market-calendar-filter-block"><span class="cal-filter-label">일정 종류</span><div class="market-calendar-filters type" id="marketCalendarTypes"><button data-type="ALL">전체</button><button data-type="macro">경제·금리</button><button data-type="corporate">상장·기업</button><button data-type="industry">전시·산업행사</button></div></div></div>
  <div class="market-calendar-legend"><span><i class="cal-dot critical"></i>최중요</span><span><i class="cal-dot high"></i>중요</span><span><i class="cal-dot medium"></i>일반</span><span class="cal-kst">공식 일정 우선 · 시각은 한국시간(KST)</span></div>
  <div id="marketCalendarRows" class="market-calendar-rows"><div class="empty">일정을 불러오는 중입니다.</div></div>
  <div id="marketCalendarSources" class="market-calendar-sources"></div>`;
  mount.appendChild(box);
  $('#marketCalendarRefresh').onclick=()=>refreshMarketCalendar(true);
  box.querySelectorAll('[data-range]').forEach(b=>b.onclick=()=>{MARKET_CAL_RANGE=b.dataset.range;localStorage.setItem('litto_market_cal_range',MARKET_CAL_RANGE);renderMarketCalendar()});
  box.querySelectorAll('[data-country]').forEach(b=>b.onclick=()=>{MARKET_CAL_COUNTRY=b.dataset.country;localStorage.setItem('litto_market_cal_country',MARKET_CAL_COUNTRY);renderMarketCalendar()});
  box.querySelectorAll('[data-type]').forEach(b=>b.onclick=()=>{MARKET_CAL_TYPE=b.dataset.type;localStorage.setItem('litto_market_cal_type',MARKET_CAL_TYPE);renderMarketCalendar()});
  return box;
}
function marketCalDate(s){const p=String(s||'').split('-').map(Number);return p.length===3?new Date(p[0],p[1]-1,p[2]):null}
function marketCalDayLabel(s){const d=marketCalDate(s);if(!d)return s||'-';const today=new Date();today.setHours(0,0,0,0);const dd=Math.round((d-today)/86400000);const tag=dd===0?'오늘':dd===1?'내일':dd===-1?'어제':'';return `${String(d.getMonth()+1).padStart(2,'0')}.${String(d.getDate()).padStart(2,'0')} (${['일','월','화','수','목','금','토'][d.getDay()]})${tag?' · '+tag:''}`}
function marketCalCountryLabel(c){return ({KR:'한국',US:'미국',CN:'중국',JP:'일본',EU:'유럽'})[c]||c||'-'}
function marketCalWindow(events){
  const today=new Date();today.setHours(0,0,0,0);let start=new Date(today),end=new Date(today);
  if(MARKET_CAL_RANGE==='week'){const day=(today.getDay()+6)%7;start.setDate(today.getDate()-day);end=new Date(start);end.setDate(start.getDate()+6)}
  else if(MARKET_CAL_RANGE==='30d')end.setDate(today.getDate()+29);
  else if(MARKET_CAL_RANGE==='90d')end.setDate(today.getDate()+89);
  else if(MARKET_CAL_RANGE==='180d')end.setDate(today.getDate()+179);
  return (events||[]).filter(e=>{const d=marketCalDate(e.date_kst);if(!d)return false;const countryOk=MARKET_CAL_COUNTRY==='ALL'||e.country===MARKET_CAL_COUNTRY;const type=e.event_type||'macro',typeOk=MARKET_CAL_TYPE==='ALL'||type===MARKET_CAL_TYPE;return d>=start&&d<=end&&countryOk&&typeOk})
}
function marketCalDday(s){const d=marketCalDate(s),t=new Date();t.setHours(0,0,0,0);if(!d)return'';const n=Math.round((d-t)/86400000);return n===0?'D-DAY':n>0?`D-${n}`:`D+${Math.abs(n)}`}
function marketCalTypeLabel(t){return ({macro:'경제',corporate:'기업',industry:'산업행사'})[t]||'경제'}
function marketCalEventRow(e){const imp=esc(e.importance||'medium'),url=e.url?`<a class="cal-source-link" href="${esc(e.url)}" target="_blank" rel="noopener noreferrer">${esc(e.source||'출처')}</a>`:`<span>${esc(e.source||'')}</span>`;const tags=(e.sector_tags||[]).map(x=>`<span class="cal-sector">${esc(x)}</span>`).join('');const end=e.end_date_kst&&e.end_date_kst!==e.date_kst?`<span>${esc(e.date_kst.slice(5).replace('-','/'))}~${esc(e.end_date_kst.slice(5).replace('-','/'))}</span>`:'';const venue=e.venue?`<span>📍 ${esc(e.venue)}</span>`:'';return `<div class="market-calendar-event ${esc(e.event_type||'macro')}"><div class="cal-side"><div class="cal-time">${esc(e.time_kst||'시간 미정')}</div><span class="cal-dday">${esc(marketCalDday(e.date_kst))}</span></div><i class="cal-dot ${imp}"></i><div class="cal-event-main"><div class="cal-event-title"><span class="cal-country">${esc(marketCalCountryLabel(e.country))}</span><span class="cal-type">${esc(marketCalTypeLabel(e.event_type||'macro'))}</span><b>${esc(e.title||'-')}</b><span class="cal-category">${esc(e.category||'')}</span></div>${tags?`<div class="cal-sectors">${tags}</div>`:''}<div class="cal-event-sub">${url}${venue}${end}${e.note?`<span>${esc(e.note)}</span>`:''}</div></div></div>`}
function renderMarketCalendar(){
  ensureMarketCalendar();const rows=$('#marketCalendarRows');if(!rows)return;
  document.querySelectorAll('#marketCalendarRanges [data-range]').forEach(b=>b.classList.toggle('active',b.dataset.range===MARKET_CAL_RANGE));
  document.querySelectorAll('#marketCalendarCountries [data-country]').forEach(b=>b.classList.toggle('active',b.dataset.country===MARKET_CAL_COUNTRY));
  document.querySelectorAll('#marketCalendarTypes [data-type]').forEach(b=>b.classList.toggle('active',b.dataset.type===MARKET_CAL_TYPE));
  const events=marketCalWindow(MARKET_CALENDAR.events||[]),groups={};events.forEach(e=>(groups[e.date_kst]??=[]).push(e));
  rows.innerHTML=Object.keys(groups).sort().map(day=>{const g=groups[day],industries=g.filter(x=>(x.event_type||'macro')==='industry').length,critical=g.filter(x=>x.importance==='critical').length;return `<div class="market-calendar-day"><div class="cal-day-head"><b>${esc(marketCalDayLabel(day))}</b><div class="cal-day-stats">${critical?`<span class="hot">최중요 ${critical}</span>`:''}${industries?`<span>산업행사 ${industries}</span>`:''}<span>${g.length}건</span></div></div><div class="cal-day-events">${g.map(marketCalEventRow).join('')}</div></div>`}).join('')||'<div class="empty">선택한 기간에 표시할 주요 일정이 없습니다.</div>';
  const allSrc=MARKET_CALENDAR.sources||[],good=allSrc.filter(x=>x.ok),cached=allSrc.filter(x=>!x.ok&&x.fallback),bad=allSrc.filter(x=>!x.ok&&!x.fallback);const meta=$('#marketCalendarMeta');if(meta)meta.textContent=`공식소스 ${good.length}/${allSrc.length} 실시간 · 캐시 ${cached.length} · ${MARKET_CALENDAR.updated_at?new Date(MARKET_CALENDAR.updated_at).toLocaleTimeString():'대기'} · 일정 ${(MARKET_CALENDAR.events||[]).length}건${bad.length?' · 미수집 '+bad.length:''}`;
  const src=$('#marketCalendarSources');if(src)src.innerHTML=allSrc.map(x=>`<span class="${x.ok?'ok':x.fallback?'cached':'fail'}" title="${esc(x.error||'')}">${esc(x.name)} ${x.ok?'✓':x.fallback?'△':'!'}</span>`).join('')+(MARKET_CALENDAR.source_note?`<small>${esc(MARKET_CALENDAR.source_note)}</small>`:'');
}
async function refreshMarketCalendar(force=false){return littoRefreshOnce('refreshMarketCalendar',()=>refreshMarketCalendarRead(force))}
async function refreshMarketCalendarRead(force=false){ensureMarketCalendar();try{const r=await fetch('/api/market-calendar'+(force?'?force=1':''));const d=await r.json();if(!r.ok)throw Error(d.error||'마켓 일정 조회 실패');MARKET_CALENDAR=d;renderMarketCalendar()}catch(e){MARKET_CALENDAR={...MARKET_CALENDAR,errors:[e.message]};renderMarketCalendar();const meta=$('#marketCalendarMeta');if(meta)meta.textContent='마켓 일정 조회 실패 · '+e.message}}
async function refreshMarketPage(force=false){await Promise.allSettled([refreshMarketOverview(force),refreshMarketCalendar(force)])}

async function refreshMarketOverview(force=false){return littoRefreshOnce('refreshMarketOverview',()=>refreshMarketOverviewRead(force))}
async function refreshMarketOverviewRead(force=false){ensureMarketOverview();try{const r=await fetch('/api/market-overview'+(force?'?force=1':''));const d=await r.json();if(!r.ok)throw Error(d.error||'시장종합 조회 실패');MARKET_OVERVIEW=d;renderMarketOverview()}catch(e){MARKET_OVERVIEW={...MARKET_OVERVIEW,error:e.message};renderMarketOverview()}}

let NASDAQ_FUTURES_POPUP_OPEN=false;
let NASDAQ_FUTURES_POPUP_DATA=null;
let NASDAQ_FUTURES_REFRESH_TIMER=null;
function ensureNasdaqFuturesPopup(){
  let m=document.getElementById('nasdaqFuturesPopup');
  if(m)return m;
  if(!document.getElementById('nasdaqFuturesPopupStyle')){
    const st=document.createElement('style');st.id='nasdaqFuturesPopupStyle';st.textContent=`
      #headerNasdaqFutures{cursor:pointer}
      #headerNasdaqFutures:hover{text-decoration:underline;text-underline-offset:3px}
      .nqf-modal{position:fixed;inset:0;z-index:360500;display:flex;align-items:center;justify-content:center;padding:24px}
      .nqf-modal[hidden]{display:none}.nqf-backdrop{position:absolute;inset:0;background:rgba(1,5,10,.78);backdrop-filter:blur(3px)}
      .nqf-dialog{position:relative;width:min(920px,94vw);background:#07111d;border:1px solid #274158;border-radius:16px;box-shadow:0 28px 80px rgba(0,0,0,.65);overflow:hidden}
      .nqf-head{display:flex;align-items:center;justify-content:space-between;gap:16px;padding:15px 18px;border-bottom:1px solid #193148}.nqf-title b{font-size:17px}.nqf-title span{display:block;margin-top:3px;font-size:11px;color:#7890a6}.nqf-close{width:34px;height:34px;border-radius:9px;border:1px solid #31506a;background:#0c1b29;color:#e9f2f8;font-size:18px;cursor:pointer}
      .nqf-summary{display:flex;align-items:baseline;gap:12px;padding:14px 18px 4px}.nqf-price{font-size:25px;font-weight:900;font-variant-numeric:tabular-nums}.nqf-rate{font-size:15px;font-weight:800}.nqf-rate.up{color:#ff5f70}.nqf-rate.down{color:#5aa8ff}.nqf-rate.flat{color:#a9b7c5}
      .nqf-chartwrap{height:470px;padding:8px 14px 12px}.nqf-chartwrap canvas{width:100%;height:100%;display:block;background:#060d15;border:1px solid #172a3c;border-radius:10px}
      .nqf-foot{display:flex;justify-content:space-between;gap:12px;padding:0 18px 14px;color:#71869a;font-size:10px}
      @media(max-width:700px){.nqf-modal{padding:6px}.nqf-chartwrap{height:68vh}.nqf-foot{flex-direction:column}}
    `;document.head.appendChild(st)
  }
  m=document.createElement('div');m.id='nasdaqFuturesPopup';m.className='nqf-modal';m.hidden=true;
  m.innerHTML=`<div class="nqf-backdrop" data-nqf-close></div><div class="nqf-dialog" role="dialog" aria-modal="true" aria-label="나스닥 선물 차트"><div class="nqf-head"><div class="nqf-title"><b>NASDAQ 100 선물</b><span id="nqfMeta">차트 준비</span></div><button type="button" class="nqf-close" data-nqf-close>×</button></div><div class="nqf-summary"><span id="nqfPrice" class="nqf-price">--</span><span id="nqfRate" class="nqf-rate flat">--</span></div><div class="nqf-chartwrap"><canvas id="nqfCanvas"></canvas></div><div class="nqf-foot"><span>당일 1분봉 · 팝업을 열었을 때만 조회</span><span id="nqfSource">--</span></div></div>`;
  document.body.appendChild(m);
  m.querySelectorAll('[data-nqf-close]').forEach(x=>x.onclick=closeNasdaqFuturesPopup);
  window.addEventListener('resize',()=>{if(NASDAQ_FUTURES_POPUP_OPEN&&NASDAQ_FUTURES_POPUP_DATA)drawNasdaqFuturesChart(NASDAQ_FUTURES_POPUP_DATA)});
  return m
}
function closeNasdaqFuturesPopup(){const m=document.getElementById('nasdaqFuturesPopup');if(m)m.hidden=true;NASDAQ_FUTURES_POPUP_OPEN=false;if(NASDAQ_FUTURES_REFRESH_TIMER){clearInterval(NASDAQ_FUTURES_REFRESH_TIMER);NASDAQ_FUTURES_REFRESH_TIMER=null}}
function drawNasdaqFuturesChart(d){
  const cv=document.getElementById('nqfCanvas');if(!cv)return;const bars=(d?.bars||[]).filter(x=>[x.o,x.h,x.l,x.c].every(v=>Number.isFinite(Number(v))));const ctx=cv.getContext('2d');
  const rect=cv.getBoundingClientRect(),dpr=Math.max(1,window.devicePixelRatio||1),W=Math.max(300,Math.floor(rect.width)),H=Math.max(220,Math.floor(rect.height));cv.width=Math.floor(W*dpr);cv.height=Math.floor(H*dpr);ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,W,H);ctx.fillStyle='#060d15';ctx.fillRect(0,0,W,H);
  if(bars.length<2){ctx.fillStyle='#7990a4';ctx.font='13px sans-serif';ctx.textAlign='center';ctx.fillText(d?.error||'차트 데이터가 없습니다.',W/2,H/2);return}
  const pad={l:12,r:72,t:14,b:28};const lo=Math.min(...bars.map(x=>Number(x.l))),hi=Math.max(...bars.map(x=>Number(x.h)));const span=Math.max(.01,hi-lo),min=lo-span*.06,max=hi+span*.06;const ph=H-pad.t-pad.b,pw=W-pad.l-pad.r;const y=v=>pad.t+(max-Number(v))/(max-min)*ph;
  ctx.strokeStyle='#13283a';ctx.lineWidth=1;ctx.fillStyle='#71869a';ctx.font='10px sans-serif';ctx.textAlign='left';for(let i=0;i<=4;i++){const yy=pad.t+ph*i/4;ctx.beginPath();ctx.moveTo(pad.l,yy);ctx.lineTo(W-pad.r,yy);ctx.stroke();const val=max-(max-min)*i/4;ctx.fillText(val.toLocaleString(undefined,{maximumFractionDigits:2}),W-pad.r+8,yy+3)}
  const step=pw/bars.length,body=Math.max(1,Math.min(5,step*.65));bars.forEach((b,i)=>{const x=pad.l+step*(i+.5),up=Number(b.c)>=Number(b.o);ctx.strokeStyle=up?'#ff5f70':'#5aa8ff';ctx.fillStyle=ctx.strokeStyle;ctx.beginPath();ctx.moveTo(x,y(b.h));ctx.lineTo(x,y(b.l));ctx.stroke();const yo=y(b.o),yc=y(b.c),top=Math.min(yo,yc),hh=Math.max(1,Math.abs(yc-yo));ctx.fillRect(x-body/2,top,body,hh)});
  let openIdx=bars.findIndex(b=>{const dt=new Date(Number(b.t)*1000);return dt.getHours()===22&&dt.getMinutes()===30});
  if(openIdx<0){for(let i=1;i<bars.length;i++){const prev=new Date(Number(bars[i-1].t)*1000),cur=new Date(Number(bars[i].t)*1000);const prevMin=prev.getHours()*60+prev.getMinutes(),curMin=cur.getHours()*60+cur.getMinutes();if(prevMin<22*60+30&&curMin>=22*60+30){openIdx=i;break}}}
  if(openIdx>=0){const xx=pad.l+step*(openIdx+.5);ctx.save();ctx.strokeStyle='rgba(255,72,72,.95)';ctx.lineWidth=1.5;ctx.beginPath();ctx.moveTo(xx,pad.t);ctx.lineTo(xx,H-pad.b);ctx.stroke();ctx.fillStyle='rgba(255,102,102,.95)';ctx.font='11px sans-serif';ctx.textAlign='left';ctx.fillText('22:30 미장 시작',Math.min(xx+6,W-pad.r-4),pad.t+12);ctx.restore()}
  const marks=[0,Math.floor((bars.length-1)/2),bars.length-1];if(openIdx>0&&openIdx<bars.length-1&&!marks.includes(openIdx))marks.splice(2,0,openIdx);ctx.fillStyle='#71869a';ctx.textAlign='center';marks.forEach(i=>{const dt=new Date(Number(bars[i].t)*1000);const isOpenMark=i===openIdx;const lab=isOpenMark?'22:30':dt.toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'});if(isOpenMark)ctx.fillStyle='rgba(255,102,102,.95)';else ctx.fillStyle='#71869a';ctx.fillText(lab,pad.l+step*(i+.5),H-9)});
  const last=Number(bars[bars.length-1].c);const ly=y(last);ctx.setLineDash([4,4]);ctx.strokeStyle='#c7d3de';ctx.beginPath();ctx.moveTo(pad.l,ly);ctx.lineTo(W-pad.r,ly);ctx.stroke();ctx.setLineDash([])
}
async function refreshNasdaqFuturesPopup(){
  if(!NASDAQ_FUTURES_POPUP_OPEN)return;const meta=document.getElementById('nqfMeta'),src=document.getElementById('nqfSource');
  try{const r=await fetch('/api/nasdaq-futures-chart',{cache:'no-store'}),d=await r.json();if(!r.ok)throw Error(d.error||'차트 조회 실패');if(!NASDAQ_FUTURES_POPUP_OPEN)return;NASDAQ_FUTURES_POPUP_DATA=d;const p=document.getElementById('nqfPrice'),rate=document.getElementById('nqfRate');if(p)p.textContent=Number.isFinite(Number(d.price))?Number(d.price).toLocaleString(undefined,{maximumFractionDigits:2}):'--';if(rate){const n=Number(d.change_rate);rate.textContent=Number.isFinite(n)?`${n>0?'+':''}${n.toFixed(2)}%`:'--';rate.className='nqf-rate '+(!Number.isFinite(n)?'flat':n>0?'up':n<0?'down':'flat')}if(meta){const dt=d.updated_at?new Date(d.updated_at):null;meta.textContent=`당일 1분봉${dt&&!Number.isNaN(dt.getTime())?' · '+dt.toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'}):''}${d.stale?' · 이전 데이터':''}`}if(src)src.textContent=d.source||'NQ=F';drawNasdaqFuturesChart(d)}catch(e){if(meta)meta.textContent=e.message;if(!NASDAQ_FUTURES_POPUP_DATA){NASDAQ_FUTURES_POPUP_DATA={bars:[],error:e.message};drawNasdaqFuturesChart(NASDAQ_FUTURES_POPUP_DATA)}}
}
async function openNasdaqFuturesPopup(){
  const m=ensureNasdaqFuturesPopup();m.hidden=false;NASDAQ_FUTURES_POPUP_OPEN=true;const meta=document.getElementById('nqfMeta'),src=document.getElementById('nqfSource');if(meta)meta.textContent='당일 1분봉 불러오는 중...';if(src)src.textContent='--';
  if(NASDAQ_FUTURES_REFRESH_TIMER){clearInterval(NASDAQ_FUTURES_REFRESH_TIMER);NASDAQ_FUTURES_REFRESH_TIMER=null}
  await refreshNasdaqFuturesPopup();
  if(NASDAQ_FUTURES_POPUP_OPEN)NASDAQ_FUTURES_REFRESH_TIMER=setInterval(refreshNasdaqFuturesPopup,5000)
}
function bindNasdaqFuturesPopup(){const el=document.getElementById('headerNasdaqFutures');if(!el||el.dataset.nqfBound==='1')return;el.dataset.nqfBound='1';el.title='클릭하면 NASDAQ 100 선물 당일 차트';el.addEventListener('click',openNasdaqFuturesPopup)}

let HEADER_MARKET_LOADING=false;
function headerMarketRate(v){const n=Number(v);if(!Number.isFinite(n))return '--';return `${n>0?'+':''}${n.toFixed(2)}%`}
function paintHeaderMarket(el,value){if(!el)return;const n=Number(value);el.textContent=headerMarketRate(value);el.classList.remove('up','down','flat','muted');if(!Number.isFinite(n))el.classList.add('muted');else el.classList.add(n>0?'up':n<0?'down':'flat')}
async function refreshHeaderMarkets(force=false){
  if(HEADER_MARKET_LOADING)return;HEADER_MARKET_LOADING=true;
  try{
    const r=await fetch('/api/header-indices'+(force?'?force=1':''));const d=await r.json();if(!r.ok)throw Error(d.error||'시장지수 조회 실패');
    const x=d.items||{};paintHeaderMarket($('#headerKospi'),x.kospi?.change_rate);paintHeaderMarket($('#headerKosdaq'),x.kosdaq?.change_rate);paintHeaderMarket($('#headerKospiFutures'),x.kospi_futures?.change_rate);paintHeaderMarket($('#headerKosdaqFutures'),x.kosdaq_futures?.change_rate);paintHeaderMarket($('#headerNasdaqFutures'),x.nasdaq_futures?.change_rate);
    const tm=$('#headerMarketTime');if(tm){const dt=d.updated_at?new Date(d.updated_at):null;tm.textContent=dt&&!Number.isNaN(dt.getTime())?dt.toLocaleTimeString([],{hour:'2-digit',minute:'2-digit'}):'업데이트'}
  }catch(e){const tm=$('#headerMarketTime');if(tm)tm.textContent='지수 조회 대기'}finally{HEADER_MARKET_LOADING=false}
}

const _activatePanelPage3=activatePanel;activatePanel=function(name){if(LITTO_PAGE!=='trade')switchLittoPage('trade');if(typeof switchTradeSubtab==='function'&&TRADE_SUBTAB==='watch')switchTradeSubtab('scanner');return _activatePanelPage3(name)};
setTimeout(()=>{ensurePageBar();ensureTradeSubtabs();ensureMarketOverview();ensureUSMarket();switchLittoPage(LITTO_PAGE);ensureTradeHeaderMarkets();syncTradeStickyTop();refreshHeaderMarkets(false);bindMarketFlowClicks();bindNasdaqFuturesPopup()},2200);
setInterval(()=>refreshHeaderMarkets(false),15000);
setInterval(()=>{if(LITTO_PAGE==='market' && MARKET_SUBTAB==='overview')refreshMarketOverview(false)},30000);
setInterval(()=>{if(LITTO_PAGE==='market' && MARKET_SUBTAB==='sector')refreshSectorStrengthCalendar(false)},30000);
setInterval(()=>{if(LITTO_PAGE==='market' && MARKET_SUBTAB==='overview')refreshMarketCalendar(false)},5*60*1000);
setInterval(()=>{if(LITTO_PAGE==='us')refreshUSMarket(false)},30000);
setInterval(()=>{if(LITTO_PAGE==='us' && (localStorage.getItem('litto_us_subtab')||'rank')==='rank')refreshUSRankLive()},2000);
// 미국시장 2번 탭은 백엔드 FE WebSocket 캐시를 2초마다 화면에 반영한다. REST 재조회는 kiwoom.py 내부에서 60초로 제한됨.
setInterval(()=>{if(LITTO_PAGE==='us' && (localStorage.getItem('litto_us_subtab')||'rank')==='watch')refreshUSWatchlist(true)},2000);

function syncStrongSectorCard(){
  const ps=STATE?.report?.search_panels?.panels||{};
  let strong=(ps['강한 섹터']?.rows||[])[0]||null;
  if(!strong){
    const results=STATE?.report?.results||[];
    const byCode=new Map(results.map(x=>[String(x.code||'').replace(/^(A|_AL|_NX)/,''),x]));
    const seen=new Set(),agg=new Map();
    for(const pn of ['주도주 종배','주도주 상따','끼도주 종배']){
      for(const row of (ps[pn]?.rows||[])){
        const code=String(row.code||'').replace(/^(A|_AL|_NX)/,'');
        if(!code||seen.has(code))continue;
        seen.add(code);
        const base=byCode.get(code)||{};
        const sectorValue=(row.sector&&row.sector!=='미분류')?row.sector:(base.sector||'');
        const secs=String(sectorValue||'').split(/[·,/|>]+/).map(x=>x.trim()).filter(x=>x&&x!=='미분류');
        for(const sec of secs){
          const a=agg.get(sec)||{name:sec,count:0,value_eok:0};
          a.count+=1;a.value_eok+=Number(row.value_eok ?? base.value_eok ?? 0);agg.set(sec,a);
        }
      }
    }
    const ranked=[...agg.values()].sort((a,b)=>(b.count-a.count)||(b.value_eok-a.value_eok));
    if(ranked[0])strong={name:ranked[0].name,value_eok:ranked[0].value_eok,levels:{breadth:ranked[0].count}};
  }
  const title=$('#metricSector'),sub=$('#metricSectorSub');
  if(title)title.textContent=strong?.name||'-';
  if(sub)sub.textContent=strong?`${strong?.levels?.breadth||0}종목 동반 · ${money(strong?.value_eok||0)}억`:'동반주 기준';
}
setInterval(()=>{syncMetricCardsFromRenderedTabs();syncStrongSectorCard()},2000);


// 2026-09-18: metric card jump hardening.
// Use capture-phase pointerup so the summary cards still work even if another
// handler lower in the tree stops click propagation.
(function installMetricCardCaptureJump(){
  if(window.__littoMetricCaptureJumpInstalled)return;
  window.__littoMetricCaptureJumpInstalled=true;
  const idMap={
    metricClose:'주도주 종배',
    metricLimit:'주도주 상따',
    metricKki:'끼도주 종배',
    metricPriority:'종배 우선순위',
    metricPrev:'전일 후보',
    metricLightning:'피뢰침',
    metricHeart:'하트존',
    metricFzone:'F존',
    metricSector:'강한 섹터',
    metricClosingTop5:'종배 TOP5'
  };
  const labelMap={
    '주도주 종배':'주도주 종배',
    '주도주 상따':'주도주 상따',
    '끼도주 종배':'끼도주 종배',
    '종배 우선순위':'종배 우선순위',
    '전일 후보':'전일 후보',
    '피뢰침':'피뢰침',
    '하트존':'하트존',
    'F존':'F존'
  };
  const jump=(panel)=>{
    if(!panel)return;
    // v1.2 HTS형: 요약카드도 아래로 스크롤하지 않고 플로팅 결과창으로 연다.
    try{
      if(typeof openScannerFloating==='function'){
        openScannerFloating(panel);
        return;
      }
    }catch(_e){}
    // 예외 시에만 기존 인라인 렌더를 사용한다.
    try{
      if(typeof switchLittoPage==='function' && typeof LITTO_PAGE!=='undefined' && LITTO_PAGE!=='trade')switchLittoPage('trade');
    }catch(_e){}
    try{ activePanel=panel; }catch(_e){}
    try{ if(typeof renderTabs==='function')renderTabs(); }catch(_e){}
    try{ if(typeof renderPanel==='function')renderPanel(); }catch(_e){}
  };
  document.addEventListener('pointerup',function(e){
    if(e.button!==undefined && e.button!==0)return;
    const card=e.target?.closest?.('.hero-grid .metric-card');
    if(!card)return;
    const strong=card.querySelector('strong[id]');
    let panel=idMap[strong?.id||''];
    if(!panel){
      const label=String(card.querySelector('span')?.textContent||'').trim();
      panel=labelMap[label];
    }
    if(!panel)return;
    e.preventDefault();
    jump(panel);
  },true);
})();

// 2026-09-19: 관심종목 -> 뉴하트 스캐너/좌측 패널 이동 hard fix.
// 기존 data-jump="scanner" 핸들러는 숨겨진 #scanner로 scroll만 시도하므로
// 관심종목 상태를 완전히 해제하지 못할 수 있다. 좌측 메뉴 경로를 capture 단계에서
// 통일하여 항상 'trade + scanner' 상태를 먼저 복구한 뒤 패널을 연다.
(function installWatchlistSidebarNavigationHardFix(){
  if(window.__littoWatchSidebarNavHardFixInstalled)return;
  window.__littoWatchSidebarNavHardFixInstalled=true;

  function forceTradeScannerView(){
    restoreMainScannerView();
  }

  function scrollScanner(){
    requestAnimationFrame(()=>requestAnimationFrame(()=>{
      const scanner=document.getElementById('scanner');
      if(scanner)scanner.scrollIntoView({behavior:'smooth',block:'start'});
    }));
  }

  function openPanel(panel){
    // v1.2 HTS형: 좌측 검색 메뉴는 페이지를 아래로 이동하지 않고 플로팅 결과창으로 연다.
    try{ if(typeof openScannerFloating==='function'){openScannerFloating(panel);return;} }catch(_e){}
    // 예외 시에만 기존 인라인 방식으로 복구.
    forceTradeScannerView();
    try{ activePanel=panel; }catch(_e){}
    try{ if(typeof renderTabs==='function')renderTabs(); }catch(_e){}
    try{ if(typeof renderPanel==='function')renderPanel(); }catch(_e){}
    scrollScanner();
  }

  document.addEventListener('click',function(e){
    // 검색 이력 화면에서 좌측 메뉴를 누른 경우,
    // 이 hard-fix가 검색이력 init 리스너보다 먼저 등록되어 실행될 수 있다.
    // 따라서 여기서 가장 먼저 검색이력 상태를 해제해야 한다.
    const historyExitNav=e.target?.closest?.(
      '.sidebar .nav-item, .sidebar .watch-sidebar-nav[data-trade-watch]'
    );
    if(historyExitNav && window.LITTO_SCREENER_HISTORY_ACTIVE){
      leaveScreenerHistory();
    }

    // 관심종목 버튼은 과거 UI 패치에서 scanner용 data-jump 속성을 함께 가진 경우가 있다.
    // 이 경우 아래 scanner hard-fix가 먼저 이벤트를 먹어 관심종목이 먹통이 되므로
    // 관심종목을 최우선으로 판별해 여기서 바로 전환한다.
    const rawNav=e.target?.closest?.('.sidebar .nav-item, .watch-sidebar-nav[data-trade-watch]');
    const isWatchNav=!!rawNav && (
      rawNav.matches?.('.watch-sidebar-nav[data-trade-watch]') ||
      String(rawNav.textContent||'').replace(/\s+/g,'').includes('관심종목')
    );
    if(isWatchNav){
      e.preventDefault();
      e.stopPropagation();
      if(typeof e.stopImmediatePropagation==='function')e.stopImmediatePropagation();
      try{
        if(typeof LITTO_PAGE!=='undefined' && LITTO_PAGE!=='trade' && typeof switchLittoPage==='function')switchLittoPage('trade');
      }catch(_e){}
      try{ SCANNER_RESULTS_ACTIVE=false; }catch(_e){}
      try{
        TRADE_SUBTAB='watch';
        localStorage.setItem('litto_trade_subtab_v1','watch');
      }catch(_e){}
      try{ if(typeof ensureTradeSubtabs==='function')ensureTradeSubtabs(); }catch(_e){}
      try{ if(typeof applyTradeSubtab==='function')applyTradeSubtab(); }catch(_e){}
      try{ if(typeof renderWatchlistPage==='function')renderWatchlistPage(); }catch(_e){}
      try{ if(typeof syncTradeSidebarNav==='function')syncTradeSidebarNav(); }catch(_e){}
      try{
        document.getElementById('scanner-results-page')?.classList.add('litto-page-hidden');
        document.getElementById('watchlist-page')?.classList.remove('litto-page-hidden');
        document.querySelectorAll('.sidebar .nav-item').forEach(x=>x.classList.remove('active'));
        rawNav.classList.add('active');
      }catch(_e){}
      try{ window.scrollTo({top:0,behavior:'smooth'}); }catch(_e){}
      return;
    }

    const panelBtn=e.target?.closest?.('.nav-item[data-panel-jump]');
    const scannerBtn=e.target?.closest?.('.nav-item[data-jump="scanner"]');
    if(!panelBtn && !scannerBtn)return;

    // 아래쪽에 이미 등록된 onclick이 다시 실행되며 상태를 덮는 것을 막는다.
    e.preventDefault();
    e.stopPropagation();
    if(typeof e.stopImmediatePropagation==='function')e.stopImmediatePropagation();

    if(panelBtn){
      openPanel(panelBtn.dataset.panelJump);
      return;
    }

    forceTradeScannerView();
    try{
      document.querySelectorAll('.nav-item').forEach(x=>x.classList.toggle('active',x===scannerBtn));
    }catch(_e){}
    scrollScanner();
  },true);
})();

/* 2026-09-19: LITTO UI zoom (Ctrl + mouse wheel / keyboard), persisted per PC */
(function installLittoUiZoom(){
  if(window.__littoUiZoomInstalled) return;
  window.__littoUiZoomInstalled = true;

  const STORAGE_KEY = 'litto_ui_zoom_percent_v1';
  const MIN_ZOOM = 80;
  const MAX_ZOOM = 150;
  const STEP = 10;
  let zoomPercent = 100;
  let hideTimer = null;

  function clampZoom(v){
    v = Math.round(Number(v) || 100);
    return Math.max(MIN_ZOOM, Math.min(MAX_ZOOM, v));
  }

  function ensureIndicator(){
    let el = document.getElementById('littoZoomIndicator');
    if(el) return el;
    el = document.createElement('div');
    el.id = 'littoZoomIndicator';
    el.className = 'litto-zoom-indicator';
    el.setAttribute('aria-live','polite');
    document.body.appendChild(el);
    return el;
  }

  function showIndicator(persistent){
    const el = ensureIndicator();
    el.textContent = `화면 ${zoomPercent}%`;
    el.classList.add('show');
    if(hideTimer) clearTimeout(hideTimer);
    if(!persistent){
      hideTimer = setTimeout(()=>el.classList.remove('show'), 1100);
    }
  }

  function applyZoom(value, opts={}){
    zoomPercent = clampZoom(value);
    const factor = zoomPercent / 100;
    const root = document.documentElement;

    // Windows pywebview(Edge/Chromium)에서는 CSS zoom이 전체 UI 비율을 가장 안정적으로 조절한다.
    root.style.zoom = String(factor);
    root.dataset.littoZoom = String(zoomPercent);

    try{ localStorage.setItem(STORAGE_KEY, String(zoomPercent)); }catch(_e){}
    if(opts.show !== false) showIndicator(false);

    try{
      window.dispatchEvent(new CustomEvent('litto-ui-zoom-change', {detail:{percent:zoomPercent,factor}}));
      window.dispatchEvent(new Event('resize'));
    }catch(_e){}
  }

  function stepZoom(direction){
    applyZoom(zoomPercent + (direction > 0 ? STEP : -STEP));
  }

  try{
    const saved = parseInt(localStorage.getItem(STORAGE_KEY) || '100', 10);
    zoomPercent = clampZoom(saved);
  }catch(_e){ zoomPercent = 100; }

  // DOM 생성 후 적용하면 초기 레이아웃 깜빡임과 일부 canvas 크기 오류를 줄일 수 있다.
  function init(){
    applyZoom(zoomPercent, {show:false});
  }
  if(document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init, {once:true});
  else init();

  // Ctrl + 마우스 휠: 위=확대, 아래=축소. 일반 휠은 기존 스크롤 그대로 둔다.
  window.addEventListener('wheel', function(e){
    if(!e.ctrlKey) return;
    e.preventDefault();
    if(e.deltaY < 0) stepZoom(+1);
    else if(e.deltaY > 0) stepZoom(-1);
  }, {passive:false, capture:true});

  // 키보드도 같이 지원: Ctrl +/- , Ctrl+0
  window.addEventListener('keydown', function(e){
    if(!e.ctrlKey) return;
    const key = e.key;
    if(key === '0'){
      e.preventDefault();
      applyZoom(100);
      return;
    }
    if(key === '+' || key === '=' || key === 'Add'){
      e.preventDefault();
      stepZoom(+1);
      return;
    }
    if(key === '-' || key === '_' || key === 'Subtract'){
      e.preventDefault();
      stepZoom(-1);
    }
  }, true);

  // 필요 시 다른 코드에서도 사용할 수 있도록 최소 API 공개
  window.LITTO_UI_ZOOM = {
    get: ()=>zoomPercent,
    set: (v)=>applyZoom(v),
    reset: ()=>applyZoom(100),
    min: MIN_ZOOM,
    max: MAX_ZOOM,
    step: STEP
  };
})();


/* v1.2 isolated intraday investor-flow panel.
   This module does not modify LITTO's scan/login/render initialization chain. */
(function(){
  'use strict';

  const CARD_ID='intradayFlowCard';
  const CANVAS_ID='intradayFlowCanvas';
  const STORE_KEY='litto_intraday_investor_flow_v2';
  const MARKET_KEY='litto_intraday_flow_market_v1';
  let ACTIVE_MARKET=localStorage.getItem(MARKET_KEY)==='kosdaq'?'kosdaq':'kospi';
  let timer=null;
  let lastPayload=null;

  function byId(id){ return document.getElementById(id); }
  function todayKey(){
    const d=new Date();
    return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`;
  }
  function storeKey(market){
    return `${STORE_KEY}_${market==='kosdaq'?'kosdaq':'kospi'}`;
  }
  function loadStore(market=ACTIVE_MARKET){
    try{
      let raw=localStorage.getItem(storeKey(market));
      // 기존 버전의 코스피 누적 데이터는 최초 한 번 그대로 이어받는다.
      if(!raw && market==='kospi')raw=localStorage.getItem(STORE_KEY);
      const x=JSON.parse(raw||'{}');
      if(!x || x.date!==todayKey() || !Array.isArray(x.rows)) return {date:todayKey(),rows:[]};
      return x;
    }catch(_e){ return {date:todayKey(),rows:[]}; }
  }
  function saveStore(x,market=ACTIVE_MARKET){
    try{ localStorage.setItem(storeKey(market),JSON.stringify(x)); }catch(_e){}
  }
  function n(v){
    const x=Number(v);
    return Number.isFinite(x)?x:null;
  }
  function amount(v){
    const x=n(v);
    if(x===null)return '-';
    return `${x>0?'+':''}${Math.round(x).toLocaleString('ko-KR')}억`;
  }
  function pct(v){
    const x=n(v);
    if(x===null)return '-';
    return `${x>0?'+':''}${x.toFixed(2)}%`;
  }
  function parseMinute(v){
    const raw=String(v||'').trim();
    const m1=raw.match(/(\d{1,2}):(\d{2})/);
    if(m1)return Number(m1[1])*60+Number(m1[2]);
    const s=raw.replace(/\D/g,'');
    if(s.length>=6){
      const hh=Number(s.slice(-6,-4)),mm=Number(s.slice(-4,-2));
      if(hh>=0&&hh<=23&&mm>=0&&mm<=59)return hh*60+mm;
    }
    if(s.length>=4){
      const hh=Number(s.slice(-4,-2)),mm=Number(s.slice(-2));
      if(hh>=0&&hh<=23&&mm>=0&&mm<=59)return hh*60+mm;
    }
    return null;
  }

  function record(payload){
    try{
      const now=new Date();
      const minute=now.getHours()*60+now.getMinutes();
      // 장중 수급선은 정규장(09:00~15:30) 데이터만 누적한다.
      // 장 전/장 마감 후 현재 수급값이 30초마다 쌓여 수평선처럼 보이는 것을 방지한다.
      if(minute<540 || minute>930)return;
      const time=`${String(now.getHours()).padStart(2,'0')}:${String(now.getMinutes()).padStart(2,'0')}`;
      ['kospi','kosdaq'].forEach(market=>{
        const inv=payload?.markets?.[market]?.investor||{};
        const personal=n(inv.personal),foreign=n(inv.foreign),institution=n(inv.institution);
        if(personal===null||foreign===null||institution===null)return;
        const s=loadStore(market);
        const row={time,personal,foreign,institution};
        if(s.rows.length && s.rows[s.rows.length-1].time===time)s.rows[s.rows.length-1]=row;
        else s.rows.push(row);
        if(s.rows.length>480)s.rows.splice(0,s.rows.length-480);
        saveStore(s,market);
      });
    }catch(_e){}
  }

  function paintText(payload,market=ACTIVE_MARKET){
    const k=payload?.markets?.[market]||{};
    const inv=k.investor||{};
    const set=(id,val)=>{const e=byId(id);if(e)e.textContent=val};
    const marketName=market==='kosdaq'?'KOSDAQ':'KOSPI';
    set('intradayFlowMarketName', marketName);
    const card=byId(CARD_ID);
    const legend=card?.querySelector('.intraday-flow-legend .index');
    if(legend)legend.textContent=`━ ${marketName} 지수`;
    const foot=card?.querySelector('.intraday-flow-foot');
    if(foot)foot.textContent=`수급은 정규장 09:00~15:30 LITTO 실행 중 자동 누적 · 5분 누적 후 표시 · 지수는 당일 ${marketName} 흐름`;
    set('intradayFlowIndex', n(k.price)!==null ? Number(k.price).toLocaleString('ko-KR',{maximumFractionDigits:2}) : '-');
    set('intradayFlowRate', pct(k.change_rate));
    set('intradayFlowPersonal',amount(inv.personal));
    set('intradayFlowForeign',amount(inv.foreign));
    set('intradayFlowInstitution',amount(inv.institution));
    const rt=byId('intradayFlowRate'),rate=n(k.change_rate);
    if(rt){rt.classList.remove('up','down'); if(rate!==null)rt.classList.add(rate>0?'up':rate<0?'down':'');}
    const u=byId('intradayFlowUpdated');
    if(u){
      const d=payload?.updated_at?new Date(payload.updated_at):new Date();
      u.textContent=Number.isNaN(d.getTime())?'대기':d.toLocaleTimeString('ko-KR',{hour:'2-digit',minute:'2-digit'});
    }
  }

  function draw(payload,market=ACTIVE_MARKET){
    const c=byId(CANVAS_ID);
    if(!c)return;
    const rect=c.getBoundingClientRect();
    const W=Math.max(420,Math.round(rect.width||700));
    const H=Math.max(180,Math.round(rect.height||205));
    const dpr=Math.max(1,window.devicePixelRatio||1);
    c.width=Math.round(W*dpr);c.height=Math.round(H*dpr);
    const ctx=c.getContext('2d');
    ctx.setTransform(dpr,0,0,dpr,0,0);
    ctx.clearRect(0,0,W,H);

    const pad={l:42,r:42,t:10,b:23};
    const pw=W-pad.l-pad.r,ph=H-pad.t-pad.b;
    const OPEN=540,CLOSE=930;
    const xFor=m=>pad.l+((Math.max(OPEN,Math.min(CLOSE,m))-OPEN)/(CLOSE-OPEN))*pw;

    ctx.strokeStyle='rgba(110,140,165,.13)';
    ctx.lineWidth=1;
    for(let i=0;i<=4;i++){
      const y=pad.t+ph*i/4;
      ctx.beginPath();ctx.moveTo(pad.l,y);ctx.lineTo(W-pad.r,y);ctx.stroke();
    }

    const store=loadStore(market);
    const storedRows=(store.rows||[])
      .map(r=>({...r,_m:parseMinute(r.time)}))
      .filter(r=>r._m!==null && r._m>=OPEN && r._m<=CLOSE);

    // White KOSPI index line: use the latest trading date actually present
    // in the Kiwoom ka20005 response. This is important after market close,
    // on weekends, and on holidays when the latest trading day != calendar today.
    function parseChartStamp(row){
      const raw=String(row?.time ?? row?.datetime ?? row?.date ?? row?.dt ?? '').trim();
      const digits=raw.replace(/\D/g,'');
      let date=null, minute=parseMinute(raw);

      // LITTO market_overview passes Kiwoom cntr_tm through as `time`.
      // It may be YYYYMMDDHHMMSS / YYYYMMDDHHMM or only HHMMSS.
      if(digits.length>=12 && Number(digits.slice(0,4))>=2000){
        date=digits.slice(0,8);
        const hh=Number(digits.slice(8,10));
        const mm=Number(digits.slice(10,12));
        if(hh>=0&&hh<=23&&mm>=0&&mm<=59)minute=hh*60+mm;
      }else if(digits.length===8 && Number(digits.slice(0,4))>=2000){
        date=digits;
      }
      return {date,minute};
    }

    const parsedIdx=[];
    for(const r of ((payload?.markets?.[market]?.chart)||[])){
      const s=parseChartStamp(r);
      const v=n(r.close);
      if(v===null||v<=0||s.minute===null||s.minute<OPEN||s.minute>CLOSE)continue;
      parsedIdx.push({date:s.date,m:s.minute,v});
    }

    // Pick the most recent date contained in the response.
    const dated=parsedIdx.filter(r=>r.date);
    const latestTradingDate=dated.length
      ? dated.map(r=>r.date).sort().at(-1)
      : null;

    // 로컬 수급 누적 날짜와 실제 키움 지수 차트의 최신 거래일이 같을 때만
    // 개인/외국인/기관 선을 허용한다. 주말·휴일에 과거에 잘못 쌓인 로컬값이
    // 금요일 지수 위에 수평선으로 겹쳐 보이는 문제를 막는다.
    const storeDateDigits=String(store?.date||'').replace(/\D/g,'');
    const sameTradingDate=!!latestTradingDate && storeDateDigits===latestTradingDate;
    const rows=sameTradingDate?storedRows:[];
    const uniqueFlowMinutes=new Set(rows.map(r=>r._m)).size;
    const showInvestorLines=sameTradingDate && uniqueFlowMinutes>=5;

    const vals=[];
    rows.forEach(r=>['personal','foreign','institution'].forEach(k=>{
      const v=n(r[k]);if(v!==null)vals.push(v);
    }));

    // KOSPI는 키움 HTS 당일추이 화면처럼 수급의 실제 당일 고점/저점 범위로
    // 세로축을 잡는다. 개인 순매도가 크게 음수일 때 0선을 무조건 중앙에 두면
    // 기관선이 과도하게 아래로 내려가 지수선이 위에 떠 보이는 문제가 있었다.
    // KOSDAQ은 기존 표시가 HTS와 맞으므로 기존 대칭축을 그대로 유지한다.
    let zero,yInv;
    if(market==='kospi' && vals.length){
      let lo=Math.min(0,...vals),hi=Math.max(0,...vals);
      let span=Math.max(100,hi-lo);
      const margin=span*.08;
      lo-=margin; hi+=margin; span=hi-lo;
      const topY=pad.t+ph*.06, bottomY=pad.t+ph*.94;
      const usable=bottomY-topY;
      yInv=v=>bottomY-((Number(v||0)-lo)/span)*usable;
      zero=yInv(0);
    }else{
      const maxAbs=Math.max(100,...vals.map(v=>Math.abs(v)))*1.1;
      zero=pad.t+ph/2;
      yInv=v=>zero-(Number(v||0)/maxAbs)*(ph*.43);
    }

    ctx.strokeStyle='rgba(235,242,247,.28)';
    ctx.beginPath();ctx.moveTo(pad.l,zero);ctx.lineTo(W-pad.r,zero);ctx.stroke();

    if(showInvestorLines){
      [['personal','#e7c54a'],['foreign','#ff6577'],['institution','#62aaff']].forEach(([key,color])=>{
        const pts=rows.map(r=>({x:xFor(r._m),y:yInv(r[key])})).filter(p=>Number.isFinite(p.y));
        if(pts.length<2)return;
        ctx.strokeStyle=color;ctx.lineWidth=2.2;ctx.lineJoin='round';ctx.lineCap='round';ctx.beginPath();
        pts.forEach((p,i)=>i?ctx.lineTo(p.x,p.y):ctx.moveTo(p.x,p.y));
        ctx.stroke();
      });
    }

    const idxMap=new Map();
    for(const r of parsedIdx){
      if(latestTradingDate && r.date && r.date!==latestTradingDate)continue;
      idxMap.set(r.m,{m:r.m,v:r.v});
    }
    const idx=[...idxMap.values()].sort((a,b)=>a.m-b.m);

    if(idx.length){
      // 지수선은 KOSPI/KOSDAQ 모두 실제 당일 1분봉 고저 범위를 사용한다.
      // 고정 ±% 축은 작은 장중 움직임을 눌러 평평하게 보이게 하므로 사용하지 않는다.
      const lo=Math.min(...idx.map(r=>r.v)),hi=Math.max(...idx.map(r=>r.v)),span=Math.max(.01,hi-lo);
      const yIdx=v=>pad.t+ph*.90-((v-lo)/span)*(ph*.80);
      ctx.strokeStyle='#ffffff';ctx.lineWidth=2.8;ctx.lineJoin='round';ctx.lineCap='round';ctx.beginPath();
      idx.forEach((p,i)=>i?ctx.lineTo(xFor(p.m),yIdx(p.v)):ctx.moveTo(xFor(p.m),yIdx(p.v)));
      ctx.stroke();
    }

    ctx.fillStyle='#60778b';ctx.font='9px sans-serif';
    [['09:00',540],['10:30',630],['12:00',720],['13:30',810],['15:30',930]].forEach(([label,m],i,a)=>{
      ctx.textAlign=i===0?'left':i===a.length-1?'right':'center';
      ctx.fillText(label,xFor(m),H-4);
    });

    if(!showInvestorLines){
      ctx.fillStyle='#6f8396';ctx.font='10px sans-serif';ctx.textAlign='center';
      const msg=!sameTradingDate
        ? '최근 거래일과 수급 누적일이 달라 수급선을 숨겼습니다.'
        : uniqueFlowMinutes===0
          ? '장중 수급선은 09:00 이후 LITTO 실행 중 자동 누적됩니다.'
          : `장중 수급 데이터 누적 중 · ${uniqueFlowMinutes}/5분`;
      ctx.fillText(msg,W/2,pad.t+ph*.60);
    }
  }

  async function refresh(){
    if(!byId(CARD_ID))return;
    try{
      const r=await fetch('/api/market-overview');
      if(!r.ok)return;
      const d=await r.json();
      lastPayload=d;
      record(d);
      paintText(d,ACTIVE_MARKET);
      draw(d,ACTIVE_MARKET);
    }catch(_e){
      // Deliberately isolated: graph failure must not affect LITTO.
    }
  }

  function syncMarketTabs(){
    document.querySelectorAll('#intradayFlowMarketTabs [data-flow-market]').forEach(btn=>{
      btn.classList.toggle('active',btn.dataset.flowMarket===ACTIVE_MARKET);
    });
  }
  function bindMarketTabs(){
    const host=byId('intradayFlowMarketTabs');
    if(!host||host.dataset.bound==='1')return;
    host.dataset.bound='1';
    host.addEventListener('click',e=>{
      const btn=e.target.closest('[data-flow-market]');
      if(!btn)return;
      ACTIVE_MARKET=btn.dataset.flowMarket==='kosdaq'?'kosdaq':'kospi';
      localStorage.setItem(MARKET_KEY,ACTIVE_MARKET);
      syncMarketTabs();
      paintText(lastPayload||{markets:{}},ACTIVE_MARKET);
      draw(lastPayload||{markets:{}},ACTIVE_MARKET);
    });
    syncMarketTabs();
  }
  function init(){
    if(!byId(CARD_ID))return;
    const title=byId(CARD_ID)?.querySelector('.card-head > div');
    if(title && !byId('intradayFlowMarketTabs')){
      const tabs=document.createElement('div');
      tabs.id='intradayFlowMarketTabs';
      tabs.className='intraday-flow-market-tabs';
      tabs.innerHTML='<button type="button" data-flow-market="kospi">코스피</button><button type="button" data-flow-market="kosdaq">코스닥</button>';
      title.appendChild(tabs);
    }
    const card=byId(CARD_ID);
    const head=card?.querySelector('.card-head');
    const summary=card?.querySelector(':scope > .intraday-flow-summary');
    const updated=byId('intradayFlowUpdated');
    if(head&&summary&&summary.parentElement===card){
      head.insertBefore(summary,updated||null);
    }
    const values=summary?.querySelector('.intraday-flow-values');
    const legend=card?.querySelector(':scope > .intraday-flow-legend');
    if(values&&legend&&values.parentElement!==legend){
      legend.appendChild(values);
    }
    const marketLabel=card?.querySelector('.intraday-flow-market b');
    if(marketLabel)marketLabel.id='intradayFlowMarketName';
    bindMarketTabs();

    const empty={markets:{kospi:{},kosdaq:{}}};
    paintText(empty,ACTIVE_MARKET);
    draw(empty,ACTIVE_MARKET);
    setTimeout(refresh,1600);
    timer=setInterval(refresh,30000);
    window.addEventListener('resize',()=>draw(lastPayload||empty,ACTIVE_MARKET));
    window.addEventListener('litto-ui-zoom-change',()=>setTimeout(()=>draw(lastPayload||empty,ACTIVE_MARKET),80));
  }

  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});
  else init();
})();

/* 2026-09-20: scanner result -> watchlist sidebar click hard fix */
(function installWatchlistFromScannerResultFix(){
  if(window.__littoWatchFromScannerResultFixInstalled)return;
  window.__littoWatchFromScannerResultFixInstalled=true;

  document.addEventListener('click',function(e){
    const btn=e.target?.closest?.('.watch-sidebar-nav[data-trade-watch]');
    if(!btn)return;

    // 검색결과 전용 페이지가 떠 있는 상태에서도 관심종목 전환을 최우선 처리한다.
    e.preventDefault();
    e.stopPropagation();
    if(typeof e.stopImmediatePropagation==='function')e.stopImmediatePropagation();

    try{
      if(typeof LITTO_PAGE!=='undefined' && LITTO_PAGE!=='trade' && typeof switchLittoPage==='function'){
        switchLittoPage('trade');
      }
    }catch(_e){}

    try{ SCANNER_RESULTS_ACTIVE=false; }catch(_e){}
    try{
      TRADE_SUBTAB='watch';
      localStorage.setItem('litto_trade_subtab_v1','watch');
    }catch(_e){}

    try{ if(typeof ensureTradeSubtabs==='function')ensureTradeSubtabs(); }catch(_e){}
    try{ if(typeof applyTradeSubtab==='function')applyTradeSubtab(); }catch(_e){}
    try{ if(typeof syncTradeSidebarNav==='function')syncTradeSidebarNav(); }catch(_e){}
    try{ if(typeof renderWatchlistPage==='function')renderWatchlistPage(); }catch(_e){}

    // DOM 상태도 확실히 맞춘다.
    try{
      document.getElementById('scanner-results-page')?.classList.add('litto-page-hidden');
      document.getElementById('watchlist-page')?.classList.remove('litto-page-hidden');
      document.querySelectorAll('.nav-item').forEach(x=>x.classList.remove('active'));
      btn.classList.add('active');
    }catch(_e){}

    try{ window.scrollTo({top:0,behavior:'smooth'}); }catch(_e){}
  },true);
})();


/* 2026-09-20: 관심종목 내비게이션 최종 안정화
   - 과거 패치로 클래스/data 속성이 달라도 표시명이 '관심종목'이면 동작
   - 검색결과 전용 페이지가 활성화된 상태에서도 무조건 watch 화면으로 전환
   - capture 단계에서 처리해 기존 scanner/nav 핸들러와 충돌하지 않음 */
(function installUniversalWatchlistNavigation(){
  if(window.__littoUniversalWatchNavInstalled)return;
  window.__littoUniversalWatchNavInstalled=true;

  function watchNavElement(target){
    let el=target?.closest?.('button,a,[role="button"],.nav-item');
    if(!el)return null;
    // 종목별 별표 버튼은 내비게이션이 아니다.
    if(el.matches?.('[data-watch-code],.watch-star,.watch-manual-add-btn'))return null;
    const txt=String(el.textContent||'').replace(/\s+/g,'');
    if(!txt.includes('관심종목'))return null;
    // 종목 카드/본문의 문구가 아니라 좌측/상단 내비게이션만 허용한다.
    if(el.closest?.('#watchlist-page,#scanner-results-page,.watch-overview-card,.watch-mini-row'))return null;
    return el;
  }

  function openWatchlist(btn){
    try{
      if(typeof LITTO_PAGE!=='undefined' && LITTO_PAGE!=='trade' && typeof switchLittoPage==='function'){
        switchLittoPage('trade');
      }
    }catch(_e){}

    try{ SCANNER_RESULTS_ACTIVE=false; }catch(_e){}
    try{
      TRADE_SUBTAB='watch';
      localStorage.setItem('litto_trade_subtab_v1','watch');
    }catch(_e){}

    // 떠 있는 예전 스캐너 창도 닫아 결과 화면이 다시 덮지 않게 한다.
    try{
      const fw=document.getElementById('scannerFloatWindow');
      if(fw){fw.hidden=true;fw.classList.add('scanner-float-closed');}
    }catch(_e){}

    try{ if(typeof ensureTradeSubtabs==='function')ensureTradeSubtabs(); }catch(_e){}
    try{ if(typeof applyTradeSubtab==='function')applyTradeSubtab(); }catch(_e){}
    try{ if(typeof renderWatchlistPage==='function')renderWatchlistPage(); }catch(_e){}
    try{ if(typeof syncTradeSidebarNav==='function')syncTradeSidebarNav(); }catch(_e){}

    try{
      document.getElementById('scanner-results-page')?.classList.add('litto-page-hidden');
      document.getElementById('watchlist-page')?.classList.remove('litto-page-hidden');
      document.querySelectorAll('.sidebar .nav-item').forEach(x=>x.classList.remove('active'));
      btn?.classList?.add('active');
    }catch(_e){}

    try{window.scrollTo({top:0,behavior:'smooth'});}catch(_e){}
  }

  // pointerdown에서 먼저 처리해 기존 click 핸들러가 이벤트를 먹는 경우까지 차단한다.
  document.addEventListener('pointerdown',function(e){
    if(e.button!==undefined && e.button!==0)return;
    const btn=watchNavElement(e.target);
    if(!btn)return;
    e.preventDefault();
    e.stopPropagation();
    if(typeof e.stopImmediatePropagation==='function')e.stopImmediatePropagation();
    openWatchlist(btn);
  },true);

  // 키보드 Enter/Space 및 pointer 이벤트가 없는 환경 대비.
  document.addEventListener('click',function(e){
    const btn=watchNavElement(e.target);
    if(!btn)return;
    e.preventDefault();
    e.stopPropagation();
    if(typeof e.stopImmediatePropagation==='function')e.stopImmediatePropagation();
    openWatchlist(btn);
  },true);
})();


/* 2026-09-20: scanner results -> watchlist navigation core fix
   The scanner results page had several document-level capture handlers accumulated from prior UI patches.
   When the sidebar watch item also carried scanner navigation attributes, a scanner handler could consume
   the event before the watch handler. Handle the watch navigation at WINDOW capture phase, which runs
   before document capture, and make the transition atomic. */
(function installWatchNavWindowCaptureFix(){
  if(window.__littoWatchNavWindowCaptureFixInstalled)return;
  window.__littoWatchNavWindowCaptureFixInstalled=true;

  function normalize(v){return String(v||'').replace(/\s+/g,'');}
  function findWatchNav(ev){
    const path=typeof ev.composedPath==='function'?ev.composedPath():[];
    for(const el of path){
      if(!el || el===window || el===document || el===document.body || el===document.documentElement)continue;
      if(!(el instanceof Element))continue;
      if(el.matches?.('[data-watch-code],.watch-star,.watch-manual-add-btn'))return null;
      const txt=normalize(el.textContent);
      if(!txt.includes('관심종목'))continue;
      if(txt.length>40)continue;
      if(el.closest?.('#watchlist-page,#scanner-results-page .watch-overview-card,#scanner-results-page .watch-mini-row'))continue;
      const inNav=el.closest?.('.sidebar,.side-nav,#littoPageBar,.topbar');
      if(!inNav)continue;
      return el.closest?.('button,a,[role="button"],.nav-item,.watch-sidebar-nav') || el;
    }
    return null;
  }

  function openWatch(btn){
  try{if(typeof closeAccountScreen==='function')closeAccountScreen()}catch(_e){}
    // Search-history is a page-level visibility state. Clear it before any watch routing.
    try{ if(typeof leaveScreenerHistory==='function')leaveScreenerHistory(); else window.LITTO_SCREENER_HISTORY_ACTIVE=false; }catch(_e){}
    try{ document.getElementById('screener-history-page')?.classList.add('litto-page-hidden'); }catch(_e){}
    // Guard against the same pointer gesture reopening a scanner panel via an older handler.
    window.__littoWatchNavGuardUntil=Date.now()+450;
    try{ SCANNER_RESULTS_ACTIVE=false; }catch(_e){}
    try{
      TRADE_SUBTAB='watch';
      localStorage.setItem('litto_trade_subtab_v1','watch');
    }catch(_e){}
    try{
      if(typeof LITTO_PAGE!=='undefined' && LITTO_PAGE!=='trade' && typeof switchLittoPage==='function'){
        switchLittoPage('trade');
        // switchLittoPage may apply the previous subtab once; set watch again immediately afterwards.
        SCANNER_RESULTS_ACTIVE=false;
        TRADE_SUBTAB='watch';
      }
    }catch(_e){}
    try{ if(typeof ensureTradeSubtabs==='function')ensureTradeSubtabs(); }catch(_e){}
    try{ if(typeof applyTradeSubtab==='function')applyTradeSubtab(); }catch(_e){}
    try{ if(typeof renderWatchlistPage==='function')renderWatchlistPage(); }catch(_e){}
    try{ if(typeof syncTradeSidebarNav==='function')syncTradeSidebarNav(); }catch(_e){}
    try{
      const results=document.getElementById('scanner-results-page');
      const watch=document.getElementById('watchlist-page');
      if(results)results.classList.add('litto-page-hidden');
      if(watch)watch.classList.remove('litto-page-hidden');
      document.querySelectorAll('.sidebar .nav-item,.sidebar .watch-sidebar-nav').forEach(x=>x.classList.remove('active'));
      btn?.classList?.add('active');
    }catch(_e){}
    try{
      const fw=document.getElementById('scannerFloatWindow');
      if(fw){fw.hidden=true;fw.classList.add('scanner-float-closed');}
    }catch(_e){}
    try{window.scrollTo({top:0,behavior:'smooth'});}catch(_e){}
  }

  function intercept(e){
    if(e.button!==undefined && e.button!==0)return;
    const btn=findWatchNav(e);
    if(!btn)return;
    e.preventDefault();
    e.stopPropagation();
    if(typeof e.stopImmediatePropagation==='function')e.stopImmediatePropagation();
    openWatch(btn);
  }

  window.addEventListener('pointerdown',intercept,true);
  window.addEventListener('click',intercept,true);
})();

/* 2026-09-20: sidebar scanner-panel navigation hard fix
   Symptom: while the watchlist page is active, top sidebar items (scanner/realtime rank)
   work but data-panel-jump items from '주도주 종배' downward can be swallowed by older
   document-level handlers accumulated during UI patches. Handle only those panel items
   at WINDOW capture phase and switch atomically to the scanner-results page. */
(function installSidebarPanelNavWindowCaptureFix(){
  if(window.__littoSidebarPanelNavWindowFixInstalled)return;
  window.__littoSidebarPanelNavWindowFixInstalled=true;

  function panelButtonFromEvent(e){
    const path=typeof e.composedPath==='function'?e.composedPath():[];
    for(const el of path){
      if(!(el instanceof Element))continue;
      const btn=el.matches?.('.sidebar .nav-item[data-panel-jump]')
        ? el
        : el.closest?.('.sidebar .nav-item[data-panel-jump]');
      if(btn)return btn;
    }
    return e.target?.closest?.('.sidebar .nav-item[data-panel-jump]')||null;
  }

  function openPanelFromSidebar(btn){
  try{if(typeof closeAccountScreen==='function')closeAccountScreen()}catch(_e){}
    try{ if(typeof leaveScreenerHistory==='function')leaveScreenerHistory(); else window.LITTO_SCREENER_HISTORY_ACTIVE=false; }catch(_e){}
    try{ document.getElementById('screener-history-page')?.classList.add('litto-page-hidden'); }catch(_e){}
    const name=String(btn?.dataset?.panelJump||'').trim();
    if(!name || !Array.isArray(PANEL_ORDER) || !PANEL_ORDER.includes(name))return;

    try{
      if(typeof LITTO_PAGE!=='undefined' && LITTO_PAGE!=='trade' && typeof switchLittoPage==='function'){
        switchLittoPage('trade');
      }
    }catch(_e){}

    try{
      TRADE_SUBTAB='scanner';
      localStorage.setItem('litto_trade_subtab_v1','scanner');
      SCANNER_RESULTS_ACTIVE=true;
      activePanel=name;
    }catch(_e){}

    try{ if(typeof ensureTradeSubtabs==='function')ensureTradeSubtabs(); }catch(_e){}
    try{ if(typeof renderScannerResultsPage==='function')renderScannerResultsPage(name); }catch(_e){}
    try{ if(typeof applyTradeSubtab==='function')applyTradeSubtab(); }catch(_e){}
    try{ if(typeof syncTradeSidebarNav==='function')syncTradeSidebarNav(); }catch(_e){}

    try{
      const watch=document.getElementById('watchlist-page');
      const results=document.getElementById('scanner-results-page');
      if(watch)watch.classList.add('litto-page-hidden');
      if(results)results.classList.remove('litto-page-hidden');
      document.querySelectorAll('.sidebar .nav-item,.sidebar .watch-sidebar-nav').forEach(x=>x.classList.remove('active'));
      btn.classList.add('active');
    }catch(_e){}

    // Close legacy floating scanner if it exists; the new result page is authoritative.
    try{
      const fw=document.getElementById('scannerFloatWindow');
      if(fw){fw.hidden=true;fw.classList.add('scanner-float-closed');}
    }catch(_e){}

    try{window.scrollTo({top:0,behavior:'smooth'});}catch(_e){}
  }

  function onPointerDown(e){
    if(e.button!==undefined && e.button!==0)return;
    const btn=panelButtonFromEvent(e);
    if(!btn)return;
    window.__littoPanelNavHandledUntil=Date.now()+450;
    e.preventDefault();
    e.stopPropagation();
    if(typeof e.stopImmediatePropagation==='function')e.stopImmediatePropagation();
    openPanelFromSidebar(btn);
  }

  function onClick(e){
    const btn=panelButtonFromEvent(e);
    if(!btn)return;
    // Suppress legacy click handlers after pointerdown; keyboard click also works here.
    e.preventDefault();
    e.stopPropagation();
    if(typeof e.stopImmediatePropagation==='function')e.stopImmediatePropagation();
    if(!(window.__littoPanelNavHandledUntil && Date.now()<window.__littoPanelNavHandledUntil)){
      openPanelFromSidebar(btn);
    }
  }

  window.addEventListener('pointerdown',onPointerDown,true);
  window.addEventListener('click',onClick,true);
})();

/* 2026-09-20: scanner-results -> scanner / realtime-rank navigation fix
   When the dedicated scanner-results page is active, the legacy jump handlers can scroll
   the hidden underlying dashboard while SCANNER_RESULTS_ACTIVE keeps the results page visible.
   Clear the results state first, restore the normal trade/scanner dashboard, then perform
   the requested scanner or realtime-rank navigation. */
(function installScannerResultsBaseNavFix(){
  if(window.__littoScannerResultsBaseNavFixInstalled)return;
  window.__littoScannerResultsBaseNavFixInstalled=true;

  function navButtonFromEvent(e){
    const path=typeof e.composedPath==='function'?e.composedPath():[];
    for(const el of path){
      if(!(el instanceof Element))continue;
      const btn=el.matches?.('.sidebar .nav-item[data-jump="scanner"],.sidebar .nav-item[data-jump="realtime-rank"]')
        ? el
        : el.closest?.('.sidebar .nav-item[data-jump="scanner"],.sidebar .nav-item[data-jump="realtime-rank"]');
      if(btn)return btn;
    }
    return e.target?.closest?.('.sidebar .nav-item[data-jump="scanner"],.sidebar .nav-item[data-jump="realtime-rank"]')||null;
  }

  function restoreBaseTradeView(){
  try{if(typeof closeAccountScreen==='function')closeAccountScreen()}catch(_e){}
    // This handler runs at WINDOW capture phase and can stopImmediatePropagation().
    // Therefore history MUST be cleared here, before applyTradeSubtab reads historyActive.
    try{ if(typeof leaveScreenerHistory==='function')leaveScreenerHistory(); else window.LITTO_SCREENER_HISTORY_ACTIVE=false; }catch(_e){}
    try{ document.getElementById('screener-history-page')?.classList.add('litto-page-hidden'); }catch(_e){}
    try{ SCANNER_RESULTS_ACTIVE=false; }catch(_e){}
    try{
      TRADE_SUBTAB='scanner';
      localStorage.setItem('litto_trade_subtab_v1','scanner');
    }catch(_e){}
    try{
      if(typeof LITTO_PAGE!=='undefined' && LITTO_PAGE!=='trade' && typeof switchLittoPage==='function'){
        switchLittoPage('trade');
      }
    }catch(_e){}
    try{ if(typeof ensureTradeSubtabs==='function')ensureTradeSubtabs(); }catch(_e){}
    try{ if(typeof applyTradeSubtab==='function')applyTradeSubtab(); }catch(_e){}
    try{ if(typeof syncTradeSidebarNav==='function')syncTradeSidebarNav(); }catch(_e){}
    try{
      document.getElementById('scanner-results-page')?.classList.add('litto-page-hidden');
      document.getElementById('watchlist-page')?.classList.add('litto-page-hidden');
      document.getElementById('tradeSubtabs')?.classList.remove('litto-page-hidden');
      const scanner=document.getElementById('scanner');
      const rank=document.getElementById('realtime-rank');
      scanner?.classList.remove('litto-page-hidden');
      rank?.classList.remove('litto-page-hidden');
    }catch(_e){}
    try{
      const fw=document.getElementById('scannerFloatWindow');
      if(fw){fw.hidden=true;fw.classList.add('scanner-float-closed');}
    }catch(_e){}
  }

  function go(btn){
    const jump=String(btn?.dataset?.jump||'');
    restoreBaseTradeView();
    try{
      document.querySelectorAll('.sidebar .nav-item,.sidebar .watch-sidebar-nav').forEach(x=>x.classList.remove('active'));
      btn.classList.add('active');
    }catch(_e){}
    requestAnimationFrame(()=>requestAnimationFrame(()=>{
      if(jump==='realtime-rank'){
        try{
          if(typeof scrollRealtimeRankToTop==='function')scrollRealtimeRankToTop();
          else document.getElementById('realtime-rank')?.scrollIntoView({behavior:'smooth',block:'start'});
        }catch(_e){}
      }else{
        try{document.getElementById('scanner')?.scrollIntoView({behavior:'smooth',block:'start'});}catch(_e){}
      }
    }));
  }

  function intercept(e){
    if(e.button!==undefined && e.button!==0)return;
    const btn=navButtonFromEvent(e);
    if(!btn)return;
    // This fix is harmless on normal pages, but is especially required while result page is active.
    e.preventDefault();
    e.stopPropagation();
    if(typeof e.stopImmediatePropagation==='function')e.stopImmediatePropagation();
    go(btn);
  }

  window.addEventListener('pointerdown',intercept,true);
  window.addEventListener('click',intercept,true);
})();


/* 2026-09-20: eSignal KOSPI200 night futures card (isolated feature) */
(()=>{
  let NIGHT_TIMER=null;
  function ensureNightFuturesStyle(){
    if(document.getElementById('nightFuturesStyle'))return;
    const st=document.createElement('style');st.id='nightFuturesStyle';st.textContent=`
      .night-futures-card{min-height:330px;display:flex;flex-direction:column;gap:8px;overflow:hidden}
      .night-futures-head{display:flex;align-items:flex-start;justify-content:space-between;gap:10px;margin-bottom:0}
      .night-futures-head h2{margin:0;font-size:17px;line-height:1.15}
      .night-futures-status{display:inline-flex;align-items:center;gap:6px;padding:4px 9px;border:1px solid #2c394a;border-radius:999px;font-size:10px;color:#8d9bad;white-space:nowrap}
      .night-futures-status::before{content:'';width:7px;height:7px;border-radius:50%;background:#697789}
      .night-futures-status.live{color:#7be0ad;border-color:rgba(62,211,151,.35);background:rgba(62,211,151,.06)}
      .night-futures-status.live::before{background:#3ed397;box-shadow:0 0 9px rgba(62,211,151,.7)}
      .night-futures-quote{display:flex;align-items:flex-end;gap:10px;min-height:0;margin-top:-2px}
      .night-futures-price{font-size:28px;line-height:1;font-weight:900;letter-spacing:-0.8px;color:#edf3fb}
      .night-futures-change{display:flex;gap:6px;align-items:center;padding-bottom:2px;font-size:12px;font-weight:800}
      .night-futures-change.up{color:#ff6675}.night-futures-change.down{color:#5c9fff}.night-futures-change.flat{color:#9aa7b6}
      .night-futures-refs{display:flex;flex-wrap:wrap;gap:8px;margin-top:2px}
      .night-futures-ref{display:inline-flex;align-items:center;gap:6px;padding:4px 8px;border:1px solid #243142;border-radius:999px;background:rgba(14,20,30,.45);font-size:10px;line-height:1;color:#93a2b4}
      .night-futures-ref b{font-size:11px;color:#eef5fc}
      .night-futures-ref b.up{color:#ff6675!important}
      .night-futures-ref b.down{color:#5c9fff!important}
      .night-futures-ref b.flat{color:#c7d1dc!important}
      .night-futures-chart{height:205px;min-height:205px;flex:1 1 205px;position:relative;border:1px solid #202b39;border-radius:11px;background:linear-gradient(180deg,rgba(25,34,46,.5),rgba(8,13,20,.15));overflow:hidden}
      .night-futures-chart canvas{display:block;width:100%;height:100%}
      .night-futures-foot{display:flex;justify-content:space-between;gap:10px;align-items:center;color:#758397;font-size:10px;margin-top:2px}
      .night-futures-error{color:#d89b5b;overflow:hidden;text-overflow:ellipsis;white-space:nowrap;max-width:70%}
      .litto-live-market-row{grid-column:1/-1;display:grid;grid-template-columns:minmax(0,1fr) minmax(0,1fr);gap:16px;align-items:stretch;width:100%;min-width:0;margin:14px 0 14px}
      .litto-live-market-row>#nightFuturesCard,.litto-live-market-row>#intradayFlowCard{width:auto!important;min-width:0!important;max-width:none!important;margin:0!important;height:100%!important}
      .litto-live-market-row>#nightFuturesCard{display:flex!important;flex-direction:column!important;justify-content:flex-start!important}
      .litto-live-market-row>#intradayFlowCard{display:flex!important;flex-direction:column!important;justify-content:flex-start!important}
      .litto-live-market-row>#intradayFlowCard .eyebrow{margin-bottom:6px!important}
      .litto-live-market-row>#intradayFlowCard h2,.litto-live-market-row>#intradayFlowCard .card-title{margin-top:0!important}
      .litto-live-market-row>#intradayFlowCard{position:relative!important}
      .litto-live-market-row>#intradayFlowCard>.card-head{display:grid!important;grid-template-columns:minmax(190px,.8fr) minmax(0,1.7fr) auto!important;align-items:center!important;column-gap:12px!important;width:100%!important;min-width:0!important}
      .litto-live-market-row>#intradayFlowCard>.card-head>div:first-child{min-width:0!important}
      .litto-live-market-row>#intradayFlowCard>.card-head>.intraday-flow-summary{grid-column:2!important;display:flex!important;align-items:center!important;justify-content:flex-start!important;gap:10px!important;margin:0!important;min-width:0!important;max-width:100%!important;overflow:visible!important}
      .litto-live-market-row>#intradayFlowCard>.card-head>.intraday-flow-summary .intraday-flow-market{display:flex!important;align-items:baseline!important;gap:7px!important;white-space:nowrap!important;min-width:max-content!important}
      .litto-live-market-row>#intradayFlowCard>.card-head>.intraday-flow-summary .intraday-flow-market strong{font-size:24px!important}
      .litto-live-market-row>#intradayFlowCard>.intraday-flow-legend{display:flex!important;align-items:center!important;gap:14px!important;min-width:0!important}
      .litto-live-market-row>#intradayFlowCard>.intraday-flow-legend .intraday-flow-values{display:flex!important;align-items:center!important;gap:14px!important;margin-left:auto!important;white-space:nowrap!important;font-size:12px!important;min-width:0!important}
      .litto-live-market-row>#intradayFlowCard>.intraday-flow-legend .intraday-flow-values span{white-space:nowrap!important}
      .litto-live-market-row>#intradayFlowCard>.card-head>#intradayFlowUpdated{grid-column:3!important;justify-self:end!important}
      .litto-live-market-row>#intradayFlowCard>.intraday-flow-summary{display:none!important}
      .litto-live-market-row>#intradayFlowCard .intraday-flow-legend{margin-top:2px!important;margin-bottom:4px!important}
      .litto-live-market-row>#intradayFlowCard #intradayFlowCanvas{display:block!important;width:100%!important;flex:1 1 auto!important;min-height:300px!important;height:auto!important}
      .litto-live-market-row>#intradayFlowCard .intraday-flow-foot{margin-top:4px!important}
      @media(max-width:1280px){
        .litto-live-market-row>#intradayFlowCard>.card-head{grid-template-columns:minmax(180px,.75fr) minmax(0,1.6fr) auto!important;column-gap:10px!important}
        .litto-live-market-row>#intradayFlowCard>.card-head>.intraday-flow-summary{gap:8px!important}
        .litto-live-market-row>#intradayFlowCard>.card-head>.intraday-flow-summary .intraday-flow-market strong{font-size:22px!important}
        .litto-live-market-row>#intradayFlowCard>.intraday-flow-legend{gap:10px!important}
        .litto-live-market-row>#intradayFlowCard>.intraday-flow-legend .intraday-flow-values{gap:10px!important;font-size:11px!important}
      }
      @media(max-width:980px){
        .litto-live-market-row>#intradayFlowCard>.card-head{grid-template-columns:1fr auto!important;row-gap:8px!important}
        .litto-live-market-row>#intradayFlowCard>.card-head>.intraday-flow-summary{grid-column:1/-1!important;grid-row:2!important;width:100%!important}
        .litto-live-market-row>#intradayFlowCard>.card-head>#intradayFlowUpdated{grid-column:2!important;grid-row:1!important}
      }
      .intraday-flow-market-tabs{display:flex;align-items:center;gap:12px;margin-top:6px}
      .intraday-flow-market-tabs button{appearance:none;border:0!important;background:transparent!important;padding:0 0 4px!important;color:#7e8b9a!important;font-size:12px!important;font-weight:800!important;line-height:1!important;cursor:pointer!important;border-radius:0!important;box-shadow:none!important}
      .intraday-flow-market-tabs button:hover{color:#c9d7e5!important}
      .intraday-flow-market-tabs button.active{color:#f2f6fa!important;border-bottom:2px solid #58a6ff!important}
      .litto-pagebar .litto-pagebtn::before,#littoPageBar .litto-pagebtn::before,.pagebar button::before,#pageBar button::before,.page-tab::before{content:none!important;display:none!important}
      .litto-pagebar .litto-pagebtn,.pagebar button,#pageBar button,.page-tab{background-image:none!important}
      @media(max-width:1100px){.litto-live-market-row{grid-template-columns:1fr}.night-futures-card{min-height:300px}.night-futures-price{font-size:25px}.night-futures-chart{height:180px}}
    `;document.head.appendChild(st);
  }
  function restoreScannerRealtimeNavOrder(){
    const scanner=document.querySelector('.sidebar .nav-item[data-jump="scanner"]');
    const realtime=document.querySelector('.sidebar .nav-item[data-jump="realtime-rank"]');
    if(scanner&&realtime&&scanner.parentElement===realtime.parentElement&&scanner.nextElementSibling!==realtime){
      realtime.parentElement.insertBefore(scanner,realtime);
    }
  }
  function pairLiveMarketCards(grid,night,flow){
    if(!grid||!night||!flow)return;
    let row=document.getElementById('littoLiveMarketRow');
    if(!row){
      row=document.createElement('div');row.id='littoLiveMarketRow';row.className='litto-live-market-row';
    }
    const hero=document.querySelector('.hero-grid');
    const anchor=hero||grid;
    if(anchor&&anchor.parentElement&&row.parentElement!==anchor.parentElement){
      anchor.insertAdjacentElement('afterend',row);
    }else if(anchor&&row.previousElementSibling!==anchor){
      anchor.insertAdjacentElement('afterend',row);
    }
    if(night.parentElement!==row)row.appendChild(night);
    if(flow.parentElement!==row)row.appendChild(flow);

    // 로그인/검색설정이 모달로 이동된 뒤 남은 빈 control-grid는 완전히 접는다.
    grid.style.setProperty('display','none','important');
    grid.style.setProperty('height','0','important');
    grid.style.setProperty('min-height','0','important');
    grid.style.setProperty('max-height','0','important');
    grid.style.setProperty('margin','0','important');
    grid.style.setProperty('padding','0','important');
    grid.style.setProperty('gap','0','important');
    grid.style.setProperty('border','0','important');
    grid.style.setProperty('overflow','hidden','important');
  }
  function ensureNightFuturesCard(){
    let card=document.getElementById('nightFuturesCard');if(card)return card;
    const grid=document.querySelector('.control-grid');if(!grid)return null;
    ensureNightFuturesStyle();
    card=document.createElement('section');card.id='nightFuturesCard';card.className='card night-futures-card';
    card.innerHTML=`<div class="night-futures-head"><div><div class="eyebrow">KOSPI200 NIGHT FUTURES</div><h2>야간 KOSPI200 선물</h2></div><span id="nightFuturesStatus" class="night-futures-status">연결 대기</span></div><div class="night-futures-quote"><strong id="nightFuturesPrice" class="night-futures-price">-</strong><div><div id="nightFuturesChange" class="night-futures-change flat"><span id="nightFuturesDiff">-</span><span id="nightFuturesRate">-</span></div><div class="night-futures-refs"><span class="night-futures-ref">18시 기준 <b id="nightFuturesRate1800">-</b></span><span class="night-futures-ref">20시 기준 <b id="nightFuturesRate0600Close">-</b></span></div></div></div><div class="night-futures-chart"><canvas id="nightFuturesCanvas"></canvas></div><div class="night-futures-foot"><span id="nightFuturesTime">실시간 데이터 대기</span><span id="nightFuturesError" class="night-futures-error"></span></div>`;
    const flow=document.getElementById('intradayFlowCard');
    if(flow){pairLiveMarketCards(grid,card,flow)}else{grid.appendChild(card)}
    restoreScannerRealtimeNavOrder();
    return card;
  }
  function clockMinutes(ts){
    const d=new Date(Number(ts)*1000);
    return d.getHours()*60+d.getMinutes()+d.getSeconds()/60;
  }
  function priceAtClock(rows,targetHour,targetMinute=0){
    if(!Array.isArray(rows)||!rows.length)return null;
    const target=targetHour*60+targetMinute;
    let before=null,after=null;
    for(const r of rows){
      const m=clockMinutes(r.t);
      if(m<=target && (!before || m>clockMinutes(before.t)))before=r;
      if(m>=target && (!after || m<clockMinutes(after.t)))after=r;
    }
    if(before&&after){
      const mb=clockMinutes(before.t),ma=clockMinutes(after.t);
      if(Math.abs(ma-mb)<1e-9)return {t:before.t,p:before.p};
      const ratio=(target-mb)/(ma-mb);
      return {t:before.t+(after.t-before.t)*ratio,p:before.p+(after.p-before.p)*ratio};
    }
    return before||after||null;
  }
  function calcRefRate(last,base){
    const lp=Number(last),bp=Number(base);
    if(!Number.isFinite(lp)||!Number.isFinite(bp)||bp<=0)return null;
    return ((lp-bp)/bp)*100;
  }
  function fmtRateNumber(rate){
    const n=Number(rate);
    if(!Number.isFinite(n))return '-';
    return `${n>0?'+':''}${fmtNum(n,2)}%`;
  }
  function paintRefRate(el,rate,title=''){
    if(!el)return;
    el.textContent=fmtRateNumber(rate);
    el.classList.remove('up','down','flat');
    el.classList.add(Number.isFinite(rate)?(rate>0?'up':rate<0?'down':'flat'):'flat');
    el.title=title;
  }
  function drawNightFutures(points,openingTs=null,closingTs=null){
    const canvas=document.getElementById('nightFuturesCanvas');if(!canvas)return;
    const box=canvas.parentElement.getBoundingClientRect(),dpr=Math.max(1,window.devicePixelRatio||1),w=Math.max(50,box.width),h=Math.max(40,box.height);
    canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr);const ctx=canvas.getContext('2d');ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,w,h);
    const map=new Map();(points||[]).forEach(x=>{const t=Number(x?.t),p=Number(x?.p);if(Number.isFinite(t)&&t>0&&Number.isFinite(p)&&p>0)map.set(t,p)});
    let rows=[...map.entries()].sort((a,b)=>a[0]-b[0]).map(([t,p])=>({t,p}));
    let open=Number(openingTs),close=Number(closingTs);
    if(Number.isFinite(open)&&open>1e10)open=Math.floor(open/1000);if(Number.isFinite(close)&&close>1e10)close=Math.floor(close/1000);
    if(Number.isFinite(open)&&open>0)rows=rows.filter(x=>x.t>=open);if(Number.isFinite(close)&&close>0)rows=rows.filter(x=>x.t<=close);
    const ref18El=document.getElementById('nightFuturesRate1800'),close06El=document.getElementById('nightFuturesRate0600Close');
    if(rows.length<2){
      if(ref18El)ref18El.textContent='-';if(close06El)close06El.textContent='-';
      ctx.fillStyle='#627184';ctx.font='11px sans-serif';ctx.fillText(rows.length===1?'첫 실시간 틱 수신 · 차트 이력 대기':'실시간 데이터 수신 대기',12,h/2);return
    }
    const vals=rows.map(x=>x.p),min=Math.min(...vals),max=Math.max(...vals),span=Math.max(.01,max-min),padL=58,padR=12,padT=10,padB=20;
    let minT=Number.isFinite(open)&&open>0?open:rows[0].t,maxT=Number.isFinite(close)&&close>minT?close:rows[rows.length-1].t;
    if(!(maxT>minT)){minT=rows[0].t;maxT=rows[rows.length-1].t||minT+1}
    const xOf=t=>padL+(w-padL-padR)*Math.max(0,Math.min(1,(t-minT)/(maxT-minT))),yOf=p=>h-padB-(p-min)/span*(h-padT-padB);
    ctx.strokeStyle='rgba(100,126,158,.18)';ctx.lineWidth=1;
    ctx.font='9px sans-serif';ctx.textBaseline='middle';ctx.textAlign='right';
    for(let i=0;i<=4;i++){
      const y=padT+(h-padT-padB)*i/4;
      ctx.beginPath();ctx.moveTo(padL,y);ctx.lineTo(w-padR,y);ctx.stroke();
      const price=max-(span*i/4);
      ctx.fillStyle='#738398';ctx.fillText(price.toLocaleString('ko-KR',{minimumFractionDigits:2,maximumFractionDigits:2}),padL-7,y);
    }

    // 기준선:
    // - 20:00 = 수직선
    // - 18:00 야간장 시작가격 = 수평선
    // 18시/20시 기준가격은 정확한 시각 전후 틱을 보간해서 계산한다.
    const ref18=priceAtClock(rows,18,0)||rows[0];
    const ref20=priceAtClock(rows,20,0);
    // 세션의 마지막 값이 06시 종가
    const ref06Close=rows[rows.length-1];

    if(ref20){
      const x=xOf(ref20.t);ctx.save();ctx.strokeStyle='rgba(245,193,92,.70)';ctx.setLineDash([5,4]);ctx.beginPath();ctx.moveTo(x,padT);ctx.lineTo(x,h-padB);ctx.stroke();ctx.restore();
    }
    if(ref18){
      const y=yOf(ref18.p);ctx.save();ctx.strokeStyle='rgba(88,166,255,.70)';ctx.setLineDash([5,4]);ctx.beginPath();ctx.moveTo(padL,y);ctx.lineTo(w-padR,y);ctx.stroke();ctx.restore();
    }

    const last=ref06Close.p;
    ctx.strokeStyle='#f4f7fb';ctx.lineWidth=2.1;ctx.beginPath();rows.forEach((r,i)=>{const x=xOf(r.t),y=yOf(r.p);if(i===0)ctx.moveTo(x,y);else ctx.lineTo(x,y)});ctx.stroke();
    const lr=rows[rows.length-1],lx=xOf(lr.t),ly=yOf(lr.p);ctx.fillStyle='#f4f7fb';ctx.beginPath();ctx.arc(lx,ly,3,0,Math.PI*2);ctx.fill();
    // Actual time labels, matching the source chart's session-oriented x-axis.
    ctx.fillStyle='#627184';ctx.font='9px sans-serif';ctx.textBaseline='bottom';const ticks=5;for(let i=0;i<ticks;i++){const t=minT+(maxT-minT)*i/(ticks-1),d=new Date(t*1000),lab=d.toLocaleTimeString('ko-KR',{hour:'2-digit',minute:'2-digit',hour12:false});const x=padL+(w-padL-padR)*i/(ticks-1);const tw=ctx.measureText(lab).width;ctx.fillText(lab,Math.max(2,Math.min(w-tw-2,x-tw/2)),h-2)}
    // 퍼센트는 차트로 계산하지 않는다. 백엔드에서 받은 eSignal 원본값만 사용한다.
  }
  function fmtNum(v,d=2){const n=Number(v);return Number.isFinite(n)?n.toLocaleString('ko-KR',{minimumFractionDigits:d,maximumFractionDigits:d}):'-'}
  function paintNightReferenceRates(d){
    // 시작 기준값은 전일 종가.
    // 표시 퍼센트는 오늘 종가가 18시/20시 가격에서 몇 % 움직였는지를 보여준다.
    const p18=d?.price_1800==null?NaN:Number(d.price_1800);
    const p20=d?.price_2000==null?NaN:Number(d.price_2000);
    const pc=d?.session_close_price==null?NaN:Number(d.session_close_price);

    let r18=d?.rate_open_to_close==null?NaN:Number(d.rate_open_to_close);
    let r20=d?.rate_2000_to_close==null?NaN:Number(d.rate_2000_to_close);

    if(!Number.isFinite(r18)&&Number.isFinite(p18)&&p18!==0&&Number.isFinite(pc)){
      r18=((pc-p18)/p18)*100;
    }
    if(!Number.isFinite(r20)&&Number.isFinite(p20)&&p20!==0&&Number.isFinite(pc)){
      r20=((pc-p20)/p20)*100;
    }

    const el18=document.getElementById('nightFuturesRate1800');
    const el20=document.getElementById('nightFuturesRate0600Close');

    paintRefRate(
      el18,
      Number.isFinite(r18)?r18:null,
      (Number.isFinite(p18)&&Number.isFinite(pc))
        ?`18시 ${fmtNum(p18,2)} → 오늘 종가 ${fmtNum(pc,2)}`
        :'18시/오늘 종가 원본값 대기'
    );

    paintRefRate(
      el20,
      Number.isFinite(r20)?r20:null,
      (Number.isFinite(p20)&&Number.isFinite(pc))
        ?`20시 ${fmtNum(p20,2)} → 오늘 종가 ${fmtNum(pc,2)}`
        :'20시/오늘 종가 원본값 대기'
    );
  }
    async function refreshNightFutures(){
    if(!ensureNightFuturesCard())return;
    const st=document.getElementById('nightFuturesStatus'),err=document.getElementById('nightFuturesError');
    try{
      const r=await fetch('/api/night-futures',{cache:'no-store'}),d=await r.json();if(!r.ok)throw Error(d.error||'야간선물 조회 실패');
      const p=d.price==null?NaN:Number(d.price),diff=d.change==null?NaN:Number(d.change),rate=d.change_rate==null?NaN:Number(d.change_rate),connected=!!d.connected,streaming=!!d.streaming;
      if(st){st.textContent=streaming?'실시간':connected?'연결됨 · 시세대기':'재연결 중';st.classList.toggle('live',streaming)}
      document.getElementById('nightFuturesPrice').textContent=Number.isFinite(p)&&p>0?fmtNum(p,2):'-';
      const c=document.getElementById('nightFuturesChange');if(c){c.className='night-futures-change '+(Number.isFinite(diff)?(diff>0?'up':diff<0?'down':'flat'):'flat')}
      document.getElementById('nightFuturesDiff').textContent=Number.isFinite(diff)?`${diff>0?'+':''}${fmtNum(diff,2)}`:'기준가 대기';
      document.getElementById('nightFuturesRate').textContent=Number.isFinite(rate)?`${rate>0?'+':''}${fmtNum(rate,2)}%`:'';
      const t=d.time_text||((d.updated_at&&new Date(d.updated_at).toLocaleTimeString('ko-KR'))||'');document.getElementById('nightFuturesTime').textContent=t?`${t} · eSignal 실시간`:'실시간 데이터 대기';
      if(err){err.textContent=d.last_error||'';err.title=d.last_error||''}
      paintNightReferenceRates(d);
      drawNightFutures(d.points||[],d.opening_ts,d.closing_ts);
    }catch(e){if(st){st.textContent='연결 오류';st.classList.remove('live')}if(err){err.textContent=e.message;err.title=e.message}paintNightReferenceRates({});drawNightFutures([])}
  }
  function init(){
    const card=ensureNightFuturesCard();
    const grid=document.querySelector('.control-grid'),flow=document.getElementById('intradayFlowCard');
    if(grid&&card&&flow)pairLiveMarketCards(grid,card,flow);
    restoreScannerRealtimeNavOrder();
    setTimeout(()=>{const g=document.querySelector('.control-grid'),n=document.getElementById('nightFuturesCard'),f=document.getElementById('intradayFlowCard');if(g&&n&&f)pairLiveMarketCards(g,n,f);restoreScannerRealtimeNavOrder()},500);
    refreshNightFutures();if(NIGHT_TIMER)clearInterval(NIGHT_TIMER);NIGHT_TIMER=setInterval(()=>{if(typeof latencyCriticalViewOpen!=='function'||!latencyCriticalViewOpen())refreshNightFutures()},4000);window.addEventListener('resize',()=>{try{refreshNightFutures()}catch(_e){}})
  }
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',init,{once:true});else init();
})();


// COMPLETELY INDEPENDENT ACCOUNT SCREEN ---------------------------------------
let ACCOUNT_SCREEN_ACTIVE=false;
let ACCOUNT_BUSY=false;

function acctMoney(v){
  const n=Number(v); return Number.isFinite(n)?`${Math.round(n).toLocaleString('ko-KR')}원`:'-';
}
function acctNum(v){
  const n=Number(v); return Number.isFinite(n)?Math.round(n).toLocaleString('ko-KR'):'-';
}
function acctRate(v){
  const n=Number(v); return Number.isFinite(n)?`${n>0?'+':''}${n.toFixed(2)}%`:'-';
}
function acctTone(v){
  const n=Number(v); return !Number.isFinite(n)?'flat':(n>0?'up':n<0?'down':'flat');
}
function acctNo(raw){
  const x=String(raw||'').replace(/\D/g,'');
  return x.length===10?`${x.slice(0,4)}-${x.slice(4,8)}-${x.slice(8)}`:(x||'연결 계좌');
}
function acctSet(id,text,v=null){
  const el=document.getElementById(id); if(!el)return;
  el.textContent=text;
  if(v!==null){el.classList.remove('up','down','flat');el.classList.add(acctTone(v))}
}
function renderAccountScreen(d){
  const sm=d?.summary||{}, rows=Array.isArray(d?.holdings)?d.holdings:[];
  const ident=document.getElementById('accountIdentity');
  if(ident)ident.textContent=d?.connected?`${d.mock?'모의':'실전'} · ${acctNo(d.account_no)}`:'키움 로그인 필요';

  acctSet('accountAssets',acctMoney(sm.estimated_assets));
  acctSet('accountPurchase',acctMoney(sm.total_purchase));
  acctSet('accountEvaluation',acctMoney(sm.total_evaluation));
  acctSet('accountPnl',acctMoney(sm.total_pnl),sm.total_pnl);
  acctSet('accountRate',acctRate(sm.total_profit_rate),sm.total_profit_rate);
  acctSet('accountRealized',acctMoney(d?.realized_pnl),d?.realized_pnl);

  const updated=document.getElementById('accountUpdated');
  if(updated){
    if(d?.updated_at){
      const dt=new Date(d.updated_at);
      updated.textContent=`${d.stale?'이전 자료':'LIVE'} ${dt.toLocaleTimeString('ko-KR',{hour:'2-digit',minute:'2-digit',second:'2-digit'})}`;
      updated.classList.toggle('account-live',!d.stale);
    }else{
      updated.textContent=d?.connected?'조회 중':'미연결';
      updated.classList.remove('account-live');
    }
  }
  const src=document.getElementById('accountSource');
  if(src){
    src.textContent=d?.error?`${d.source||'키움 계좌조회'} · ${d.error}`:`${d.source||'키움 kt00018'} · 1초 자동 갱신`;
    src.classList.toggle('account-error',!!d?.error);
  }
  const count=document.getElementById('accountHoldingCount');
  if(count)count.textContent=`${rows.length}종목`;

  const realizedRows=Array.isArray(d?.realized_rows)?d.realized_rows:[];
  const realizedCount=document.getElementById('accountRealizedCount');
  if(realizedCount)realizedCount.textContent=`${realizedRows.length}종목`;
  const realizedTotal=document.getElementById('accountRealizedTotal');
  if(realizedTotal){
    realizedTotal.textContent=`합계 ${acctMoney(d?.realized_pnl)}`;
    realizedTotal.classList.remove('up','down','flat');
    realizedTotal.classList.add(acctTone(d?.realized_pnl));
  }
  const realizedBody=document.getElementById('accountRealizedRows');
  if(realizedBody){
    if(!d?.connected){
      realizedBody.innerHTML='<tr><td colspan="9" class="empty">키움 로그인 연결이 필요합니다.</td></tr>';
    }else if(!realizedRows.length){
      realizedBody.innerHTML='<tr><td colspan="9" class="empty">오늘 실현된 매도 손익이 없습니다.</td></tr>';
    }else{
      realizedBody.innerHTML=realizedRows.map(r=>`
        <tr>
          <td><div class="account-stock"><b>${esc(r.name||r.code||'-')}</b><small>${esc(r.code||'')}</small></div></td>
          <td>${acctNum(r.sell_qty)}주</td>
          <td>${acctNum(r.buy_avg_price)}</td>
          <td>${acctNum(r.sell_avg_price)}</td>
          <td>${acctMoney(r.buy_amount)}</td>
          <td>${acctMoney(r.sell_amount)}</td>
          <td>${acctMoney(r.fees_tax)}</td>
          <td class="${acctTone(r.pnl)}"><b>${acctMoney(r.pnl)}</b></td>
          <td class="${acctTone(r.profit_rate)}"><b>${acctRate(r.profit_rate)}</b></td>
        </tr>`).join('');
    }
  }

  const tbody=document.getElementById('accountRows');
  if(!tbody)return;
  if(!d?.connected){
    tbody.innerHTML='<tr><td colspan="8" class="empty">키움 로그인 연결이 필요합니다.</td></tr>'; return;
  }
  if(!rows.length){
    tbody.innerHTML=`<tr><td colspan="8" class="empty">${d?.error?esc(d.error):'보유종목이 없습니다.'}</td></tr>`; return;
  }
  tbody.innerHTML=rows.map(r=>`
    <tr class="account-stock-clickable"
        data-stock-action-code="${esc(r.code||'')}"
        data-stock-action-name="${esc(r.name||r.code||'')}"
        title="클릭하면 차트 · 수급 · 호가 · 메모를 선택합니다">
      <td><div class="account-stock"><b>${esc(r.name||r.code||'-')}</b><small>${esc(r.code||'')}</small></div></td>
      <td>${acctNum(r.quantity)}주</td>
      <td>${acctNum(r.available_quantity)}주</td>
      <td>${acctNum(r.avg_price)}</td>
      <td>${acctNum(r.current_price)}</td>
      <td>${acctMoney(r.evaluation_amount)}</td>
      <td class="${acctTone(r.evaluation_pnl)}">${acctMoney(r.evaluation_pnl)}</td>
      <td class="${acctTone(r.profit_rate)}"><b>${acctRate(r.profit_rate)}</b></td>
    </tr>`).join('');
  bindStockActionClicks();
}
async function refreshAccountScreen(force=false){
  if(!ACCOUNT_SCREEN_ACTIVE || ACCOUNT_BUSY)return;
  ACCOUNT_BUSY=true;
  try{
    const r=await fetch('/api/account-status'+(force?'?force=1':''),{cache:'no-store'});
    const d=await r.json();
    if(!r.ok)throw Error(d.error||'계좌 조회 실패');
    renderAccountScreen(d);
  }catch(e){
    renderAccountScreen({connected:false,summary:{},holdings:[],source:'계좌조회',error:e.message});
  }finally{ACCOUNT_BUSY=false}
}
function openAccountScreen(){
  ACCOUNT_SCREEN_ACTIVE=true;
  document.body.classList.add('litto-account-mode');
  const root=document.getElementById('accountStandaloneRoot');
  if(root){root.setAttribute('aria-hidden','false')}
  document.getElementById('accountLaunchBanner')?.classList.add('active');
  refreshAccountScreen(true);
  window.scrollTo({top:0,behavior:'smooth'});
}
function closeAccountScreen(){
  if(!ACCOUNT_SCREEN_ACTIVE)return;
  ACCOUNT_SCREEN_ACTIVE=false;
  document.body.classList.remove('litto-account-mode');
  const root=document.getElementById('accountStandaloneRoot');
  if(root){root.setAttribute('aria-hidden','true')}
  document.getElementById('accountLaunchBanner')?.classList.remove('active');
}
function bindAccountScreen(){
  const launch=document.getElementById('accountLaunchBanner');
  if(launch && launch.dataset.bound!=='1'){
    launch.dataset.bound='1'; launch.addEventListener('click',e=>{e.preventDefault();openAccountScreen()});
  }
  const refresh=document.getElementById('accountRefresh');
  if(refresh && refresh.dataset.bound!=='1'){
    refresh.dataset.bound='1'; refresh.addEventListener('click',()=>refreshAccountScreen(true));
  }
  // Any normal navigation closes the independent account screen first.
  document.querySelectorAll('.sidebar .nav-item,.sidebar .watch-sidebar-nav,#littoPageBar [data-page],[data-trade-tab]').forEach(el=>{
    if(el.dataset.accountLeaveBound==='1')return;
    el.dataset.accountLeaveBound='1';
    el.addEventListener('click',()=>closeAccountScreen(),true);
  });
}
if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',bindAccountScreen,{once:true});
else bindAccountScreen();

// Poll ONLY while the independent account screen is open.
setInterval(()=>{if(ACCOUNT_SCREEN_ACTIVE)refreshAccountScreen(false)},1000);




// === v1.22 종배 TOP5 성과 검증 ==============================================
// Isolated review UI.  No timer, no background API polling, no change to TOP5 formula.
(function installClosingTop5Performance(){
  if(window.__littoTop5PerformanceInstalled)return;
  window.__littoTop5PerformanceInstalled=true;

  function fnum(v,d=1){const n=Number(v);return Number.isFinite(n)?`${n>=0?'+':''}${n.toFixed(d)}%`:'-'}
  function rate(v){const n=Number(v);return Number.isFinite(n)?`${n.toFixed(1)}%`:'-'}
  function safe(s){return typeof esc==='function'?esc(String(s??'')):String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}

  function ensureStyle(){
    if(document.getElementById('top5PerfStyle'))return;
    const st=document.createElement('style');st.id='top5PerfStyle';
    st.textContent=`
      .top5-perf-toolbar{display:flex;justify-content:flex-end;align-items:center;gap:8px;margin:0 0 10px}
      .top5-perf-open{border:1px solid #315673;background:#0b2235;color:#cfeaff;border-radius:9px;padding:7px 12px;font-size:11px;font-weight:900;cursor:pointer}
      #top5PerfModal{position:fixed;inset:0;z-index:230000;background:rgba(2,8,14,.72);display:flex;align-items:center;justify-content:center;padding:26px}
      #top5PerfModal[hidden]{display:none!important}
      .top5-perf-dialog{width:min(1180px,96vw);height:min(820px,92vh);background:#07131e;border:1px solid #244057;border-radius:18px;box-shadow:0 24px 80px rgba(0,0,0,.55);overflow:hidden;display:flex;flex-direction:column;color:#dce9f3}
      .top5-perf-head{display:flex;align-items:center;justify-content:space-between;padding:15px 18px;border-bottom:1px solid #1e3548;background:#091925}
      .top5-perf-head h2{font-size:18px;margin:0}.top5-perf-head small{display:block;color:#7891a5;margin-top:3px}
      .top5-perf-actions{display:flex;gap:7px}.top5-perf-actions button{border:1px solid #31526a;background:#0d2231;color:#c8d9e6;border-radius:8px;padding:7px 10px;font-weight:800;cursor:pointer}
      .top5-perf-actions .primary{border-color:#2b78a4;background:#0d3450;color:#e5f7ff}.top5-perf-actions .close{font-size:15px;padding:6px 10px}
      .top5-perf-body{padding:14px 16px 18px;overflow:auto}
      .top5-perf-info{font-size:11px;color:#718b9f;margin-bottom:10px}
      .top5-perf-cards{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:8px;margin-bottom:14px}
      .top5-perf-card{border:1px solid #1e3a4e;background:#0a1a27;border-radius:12px;padding:11px}
      .top5-perf-card span{display:block;font-size:10px;color:#6f8a9d}.top5-perf-card b{display:block;font-size:21px;margin-top:3px;font-variant-numeric:tabular-nums}
      .top5-perf-grid{display:grid;grid-template-columns:1fr 1.6fr;gap:12px}
      .top5-perf-panel{border:1px solid #1d3548;border-radius:12px;background:#081721;overflow:hidden}
      .top5-perf-panel h3{font-size:12px;margin:0;padding:10px 12px;border-bottom:1px solid #1d3548;color:#aac0d0}
      .top5-perf-rank-row{display:grid;grid-template-columns:50px 60px 1fr 1fr 1fr;gap:8px;padding:8px 12px;border-bottom:1px solid rgba(29,53,72,.55);font-size:11px;align-items:center}
      .top5-perf-rank-row.head{color:#6f899b;font-size:9px}.top5-perf-rank-row b{color:#dceaf4}
      .top5-perf-day{padding:10px 12px;border-bottom:1px solid rgba(29,53,72,.55)}
      .top5-perf-day-head{display:flex;justify-content:space-between;align-items:center;margin-bottom:6px}.top5-perf-day-head b{font-size:12px}.top5-perf-day-head span{font-size:9px;color:#6f899b}
      .top5-perf-picks{display:grid;grid-template-columns:repeat(5,minmax(0,1fr));gap:5px}
      .top5-perf-pick{border:1px solid #1b3244;border-radius:8px;padding:7px;background:#091924;min-width:0}
      .top5-perf-pick strong{display:block;font-size:10px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.top5-perf-pick small{display:block;color:#6f899b;font-size:8px;margin-top:2px}
      .top5-perf-pick em{display:block;font-style:normal;font-weight:900;font-size:12px;margin-top:4px}.top5-perf-pick em.up{color:#ff7084}.top5-perf-pick em.down{color:#61aaff}
      .top5-perf-empty{padding:28px;text-align:center;color:#718a9d;font-size:11px}
      #top5PerfStatus{min-height:18px;color:#87a3b6;font-size:10px;margin:8px 0}
      @media(max-width:980px){.top5-perf-cards{grid-template-columns:repeat(2,1fr)}.top5-perf-grid{grid-template-columns:1fr}.top5-perf-picks{grid-template-columns:1fr 1fr}}
    `;
    document.head.appendChild(st);
  }

  function ensureModal(){
    ensureStyle();
    let m=document.getElementById('top5PerfModal');if(m)return m;
    m=document.createElement('div');m.id='top5PerfModal';m.hidden=true;
    m.innerHTML=`<div class="top5-perf-dialog">
      <div class="top5-perf-head">
        <div><h2>종배 TOP5 성과</h2><small>익일 +4% 도달률 · +2% 도달률 · 종가 플러스율</small></div>
        <div class="top5-perf-actions">
          <button id="top5PerfSave" class="primary" type="button">오늘 TOP5 저장</button>
          <button id="top5PerfRefresh" type="button">결과 업데이트</button>
          <button id="top5PerfClose" class="close" type="button">✕</button>
        </div>
      </div>
      <div class="top5-perf-body">
        <div class="top5-perf-info">저장 시점 가격은 임시값입니다. 결과 업데이트 시 키움 일봉의 해당일 공식 종가를 기준가로 확정합니다. 결과 조회는 수동 실행이라 실시간 호가/수급 성능에 영향을 주지 않습니다.</div>
        <div id="top5PerfStatus"></div>
        <div id="top5PerfContent"><div class="top5-perf-empty">성과 기록을 불러오는 중…</div></div>
      </div>
    </div>`;
    document.body.appendChild(m);
    document.getElementById('top5PerfClose').onclick=()=>{m.hidden=true};
    m.addEventListener('click',e=>{if(e.target===m)m.hidden=true});
    document.getElementById('top5PerfSave').onclick=saveToday;
    document.getElementById('top5PerfRefresh').onclick=refreshResults;
    return m;
  }

  function currentRows(){
    try{computeClosingTop5()}catch(_e){}
    return (CLOSING_TOP5_ROWS||[]).slice(0,5).map((x,i)=>{
      const q=(typeof liveCardQuote==='function'?liveCardQuote(x):{})||{};
      const price=Number(q.price)>0?Number(q.price):Number(x.price||closingDayBar?.(x)?.close||0);
      return {rank:i+1,code:x.code,name:x.name,sector:x.sector,score:x.score,entry_price:price,value_eok:x.value_eok,program_ratio:x.program_ratio,parts:x.parts||{},tags:x.tags||[]};
    });
  }

  async function saveToday(){
    const rows=currentRows(),status=document.getElementById('top5PerfStatus');
    if(!rows.length){status.textContent='현재 저장할 종배 TOP5가 없습니다.';return}
    const btn=document.getElementById('top5PerfSave');btn.disabled=true;status.textContent='오늘 TOP5 저장 중…';
    try{
      const d=await api('/api/top5-performance/save',{rows});
      status.textContent='오늘 TOP5 저장 완료 · 같은 날짜를 다시 저장하면 최신 TOP5로 갱신됩니다.';
      render(d);
    }catch(e){status.textContent='저장 실패 · '+e.message}
    finally{btn.disabled=false}
  }

  async function refreshResults(){
    const btn=document.getElementById('top5PerfRefresh'),status=document.getElementById('top5PerfStatus');
    btn.disabled=true;status.textContent='키움 일봉으로 익일 결과 확인 중… 실시간 기능은 그대로 동작합니다.';
    try{
      const r=await fetch('/api/top5-performance-refresh?max_days=5',{cache:'no-store'}),d=await r.json();
      if(!r.ok)throw Error(d.error||'결과 업데이트 실패');
      status.textContent=`결과 ${Number(d.updated_picks||0)}종목 업데이트${Number(d.remaining_picks||0)>0?` · 미확정 ${d.remaining_picks}종목`:''}`;
      render(d);
    }catch(e){status.textContent='업데이트 실패 · '+e.message}
    finally{btn.disabled=false}
  }

  function rankRows(list){
    return `<div class="top5-perf-rank-row head"><span>순위</span><span>표본</span><span>+4%</span><span>종가+</span><span>평균최고</span></div>`+
      (list||[]).map(x=>`<div class="top5-perf-rank-row"><b>TOP${x.rank}</b><span>${x.count||0}</span><span>${rate(x.hit4_rate)}</span><span>${rate(x.close_positive_rate)}</span><span>${fnum(x.avg_max_return_pct)}</span></div>`).join('');
  }

  function recentDays(days){
    const rows=(days||[]).slice(0,20);
    if(!rows.length)return '<div class="top5-perf-empty">아직 저장된 TOP5가 없습니다.<br>종배 TOP5가 확정된 뒤 「오늘 TOP5 저장」을 누르면 기록이 시작됩니다.</div>';
    return rows.map(d=>`<div class="top5-perf-day"><div class="top5-perf-day-head"><b>${safe(d.date)}</b><span>${(d.rows||[]).filter(x=>x.result?.next_date).length}/5 결과확정</span></div><div class="top5-perf-picks">${(d.rows||[]).sort((a,b)=>(a.rank||0)-(b.rank||0)).map(r=>{const v=Number(r.result?.max_return_pct),c=Number(r.result?.close_return_pct);return `<div class="top5-perf-pick"><strong>TOP${r.rank} ${safe(r.name)}</strong><small>${Number(r.entry_price||0)>0?Number(r.entry_price).toLocaleString('ko-KR')+'원':'기준가 대기'}</small>${r.result?.next_date?`<em class="${v>=0?'up':'down'}">최고 ${fnum(v)}</em><small>종가 ${fnum(c)} · ${safe(r.result.next_date)}</small>`:'<em>-</em><small>익일 결과 대기</small>'}</div>`}).join('')}</div></div>`).join('');
  }

  function render(d){
    const s=d?.summary||{},box=document.getElementById('top5PerfContent');if(!box)return;
    box.innerHTML=`<div class="top5-perf-cards">
      <div class="top5-perf-card"><span>저장 거래일</span><b>${Number(s.saved_days||0)}일</b></div>
      <div class="top5-perf-card"><span>익일 +4% 도달률</span><b>${rate(s.hit4_rate)}</b></div>
      <div class="top5-perf-card"><span>익일 +2% 도달률</span><b>${rate(s.hit2_rate)}</b></div>
      <div class="top5-perf-card"><span>익일 종가 플러스율</span><b>${rate(s.close_positive_rate)}</b></div>
      <div class="top5-perf-card"><span>평균 최고수익률</span><b>${fnum(s.avg_max_return_pct)}</b></div>
    </div>
    <div class="top5-perf-grid">
      <section class="top5-perf-panel"><h3>TOP1~5 순위별 성과</h3>${rankRows(s.by_rank)}</section>
      <section class="top5-perf-panel"><h3>최근 TOP5 기록</h3>${recentDays(d?.days)}</section>
    </div>`;
  }

  async function open(){
    const m=ensureModal();m.hidden=false;
    const status=document.getElementById('top5PerfStatus');status.textContent='성과 기록 불러오는 중…';
    try{
      const r=await fetch('/api/top5-performance',{cache:'no-store'}),d=await r.json();
      if(!r.ok)throw Error(d.error||'성과 조회 실패');
      status.textContent='';render(d);
    }catch(e){status.textContent='조회 실패 · '+e.message}
  }

  window.openClosingTop5Performance=open;
})();


/* === LITTO v1.22 · orderbook side mini chart ================================
   Performance rule:
   - Never changes the orderbook WebSocket/REST loop.
   - Loads once ~800ms after orderbook opens and only when timeframe changes.
   - Cached timeframe switches are instant.
   - Between REST loads, current price comes from ORDERBOOK_LAST_CURRENT locally.
   - F-zone is drawn on 1/3/15-minute only. Daily intentionally has no F-zone.
============================================================================ */
(function installOrderbookSideMiniChart(){
  if(window.__littoOrderbookSideMiniChartInstalled)return;
  window.__littoOrderbookSideMiniChartInstalled=true;

  const cache=new Map();
  let tf='3', token=0, liveTimer=null, currentPayload=null;
  const miniZoomBars={'1':90,'3':90,'15':90,'daily':70};

  function normCode(v){return String(v||'').replace(/\D/g,'').slice(-6)}
  function key(code,frame){return normCode(code)+'|'+frame}
  function label(frame){return frame==='daily'?'일봉':frame+'분봉'}
  function escLocal(s){return String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]))}

  function ensureStyle(){
    if(document.getElementById('obMiniChartStyle'))return;
    const st=document.createElement('style');
    st.id='obMiniChartStyle';
    st.textContent=`
      #orderbookModal .orderbook-dialog.hts-orderbook{position:relative!important;}
      #orderbookModal .ob-mini-chart-dock{
        position:absolute;
        top:18px;
        right:18px;
        width:calc(33.2% - 24px);
        height:min(48vh,520px);
        min-height:330px;
        border:1px solid #20394d;
        border-radius:14px;
        background:#07131e;
        box-shadow:0 12px 30px rgba(0,0,0,.25);
        overflow:hidden;
        z-index:5;
        display:flex;
        flex-direction:column;
      }
      #orderbookModal .ob-mini-chart-head{
        flex:0 0 auto;
        display:flex;
        align-items:center;
        justify-content:space-between;
        gap:8px;
        padding:9px 10px;
        border-bottom:1px solid #183044;
        background:#091927;
      }
      #orderbookModal .ob-mini-chart-title{
        min-width:0;
        display:flex;
        align-items:baseline;
        gap:7px;
        white-space:nowrap;
      }
      #orderbookModal .ob-mini-chart-title b{font-size:12px;color:#dcecff;}
      #orderbookModal .ob-mini-chart-title span{font-size:9px;color:#68839a;overflow:hidden;text-overflow:ellipsis;}
      #orderbookModal .ob-mini-chart-tabs{display:flex;gap:4px;align-items:center;}
      #orderbookModal .ob-mini-chart-tabs button{
        border:1px solid #28445a;
        background:#0b1b28;
        color:#8ea8bc;
        border-radius:7px;
        padding:5px 8px;
        font-size:10px;
        font-weight:800;
        cursor:pointer;
      }
      #orderbookModal .ob-mini-chart-tabs button.active{
        border-color:#4ba7da;
        background:#10304a;
        color:#d9f4ff;
      }
      #orderbookModal .ob-mini-chart-tabs button.ob-mini-refresh{
        padding-left:7px;padding-right:7px;color:#8fd7b8;
      }
      #orderbookModal .ob-mini-chart-meta{
        flex:0 0 auto;
        display:flex;
        justify-content:space-between;
        gap:8px;
        padding:5px 10px;
        font-size:9px;
        color:#66849a;
        border-bottom:1px solid rgba(32,57,77,.65);
        white-space:nowrap;
        overflow:hidden;
      }
      #orderbookModal .ob-mini-chart-meta span{overflow:hidden;text-overflow:ellipsis;}
      #orderbookModal .ob-mini-chart-wrap{position:relative;flex:1 1 auto;min-height:0;}
      #orderbookModal #obMiniChartCanvas{width:100%;height:100%;display:block;}
      #orderbookModal .ob-mini-chart-loading{
        position:absolute;inset:0;display:flex;align-items:center;justify-content:center;
        font-size:11px;color:#6f8aa0;background:rgba(7,19,30,.68);pointer-events:none;
      }
      #orderbookModal .ob-mini-close1530{font-weight:900;margin-left:auto;margin-right:10px;}
      #orderbookModal .ob-mini-close1530.up{color:#ff6677!important;}
      #orderbookModal .ob-mini-close1530.down{color:#55a7ff!important;}
      #orderbookModal .ob-mini-close1530.flat{color:#9ab0c0!important;}
      #orderbookModal .ob-mini-fzone-badge{
        color:#e8b94e!important;font-weight:800;
      }
      @media(max-width:1450px){
        #orderbookModal .ob-mini-chart-dock{display:none!important;}
      }
    `;
    document.head.appendChild(st);
  }

  function ensureDock(){
    ensureStyle();
    const modal=document.getElementById('orderbookModal');
    const dialog=modal?.querySelector('.orderbook-dialog.hts-orderbook');
    if(!dialog)return null;
    let dock=document.getElementById('obMiniChartDock');
    if(dock)return dock;
    dock=document.createElement('section');
    dock.id='obMiniChartDock';
    dock.className='ob-mini-chart-dock';
    dock.innerHTML=`
      <div class="ob-mini-chart-head">
        <div class="ob-mini-chart-title"><b>호가 연동 차트</b><span id="obMiniChartName">-</span></div>
        <div class="ob-mini-chart-tabs">
          <button data-ob-chart-tf="1" type="button">1분</button>
          <button data-ob-chart-tf="3" class="active" type="button">3분</button>
          <button data-ob-chart-tf="15" type="button">15분</button>
          <button data-ob-chart-tf="daily" type="button">일봉</button>
          <button id="obMiniFzoneToggle" type="button" title="1·3·15분봉 F존 표시/숨김">F존 ON</button>
          <button id="obMiniMarkerToggle" type="button" title="장마감선 표시/숨김">마감선 ON</button>
          <button class="ob-mini-refresh" id="obMiniChartRefresh" type="button" title="차트 새로고침">↻</button>
        </div>
      </div>
      <div class="ob-mini-chart-meta">
        <span id="obMiniChartStatus">호가 우선 · 차트 대기</span>
        <span id="obMiniClose1530" class="ob-mini-close1530 flat"></span>
        <span id="obMiniChartFzone" class="ob-mini-fzone-badge"></span>
      </div>
      <div class="ob-mini-chart-wrap">
        <canvas id="obMiniChartCanvas"></canvas>
        <div id="obMiniChartLoading" class="ob-mini-chart-loading">차트 대기</div>
      </div>`;
    dialog.appendChild(dock);
    dock.querySelectorAll('[data-ob-chart-tf]').forEach(btn=>{
      btn.onclick=()=>{
        tf=btn.dataset.obChartTf||'3';
        dock.querySelectorAll('[data-ob-chart-tf]').forEach(x=>x.classList.toggle('active',x===btn));
        load(tf,false);
      };
    });
    dock.querySelector('#obMiniChartRefresh').onclick=()=>load(tf,true);
    const fzoneBtn=dock.querySelector('#obMiniFzoneToggle');if(fzoneBtn)fzoneBtn.onclick=()=>setChartFzoneEnabled(!CHART_FZONE_ENABLED);
    const markerBtn=dock.querySelector('#obMiniMarkerToggle');if(markerBtn)markerBtn.onclick=()=>setChartMarkersEnabled(!CHART_MARKERS_ENABLED);
    const miniCanvas=dock.querySelector('#obMiniChartCanvas');if(miniCanvas&&!miniCanvas.dataset.wheelZoomBound){miniCanvas.dataset.wheelZoomBound='1';miniCanvas.addEventListener('wheel',e=>{if(!currentPayload)return;e.preventDefault();const allBars=liveBars(currentPayload);if(!allBars.length)return;const minBars=tf==='daily'?20:24;const def=tf==='daily'?70:90;const current=Math.max(minBars,Math.min(allBars.length,Number(miniZoomBars[tf]||def)));const next=e.deltaY<0?Math.max(minBars,Math.floor(current*.84)):Math.min(allBars.length,Math.ceil(current*1.18));if(next!==current){miniZoomBars[tf]=next;draw(currentPayload)}},{passive:false})}
    syncChartFzoneButtons();syncChartMarkerButtons();
    return dock;
  }

  function fzone(){
    if(tf==='daily'||!CHART_FZONE_ENABLED)return null;
    try{return typeof findFZone==='function'?findFZone(ORDERBOOK_CODE):null}catch(_e){return null}
  }

  function miniClose1530(bars){
    let hit=null;
    for(const b of (bars||[])){if(intradayMarkerHM(b)==='15:30'&&Number.isFinite(Number(b.close)))hit=Number(b.close)}
    return hit;
  }
  function updateMiniClose1530Label(bars){
    const el=document.getElementById('obMiniClose1530');if(!el)return;
    if(tf==='daily'||!CHART_MARKERS_ENABLED){el.textContent='';el.className='ob-mini-close1530 flat';return}
    const close=miniClose1530(bars);if(!(close>0)){el.textContent='';el.className='ob-mini-close1530 flat';return}
    const live=Number(typeof ORDERBOOK_LAST_CURRENT!=='undefined'?ORDERBOOK_LAST_CURRENT:0);
    const state=live>close?'up':live>0&&live<close?'down':'flat';
    el.textContent='15:30 종가 '+Math.round(close).toLocaleString('ko-KR');
    el.className='ob-mini-close1530 '+state;
  }

  function liveBars(payload){
    const bars=(payload?.bars||[]).map(x=>({...x}));
    if(tf==='daily'||!bars.length)return bars;
    const live=Number(typeof ORDERBOOK_LAST_CURRENT!=='undefined'?ORDERBOOK_LAST_CURRENT:0);
    if(!(live>0))return bars;
    const last=bars[bars.length-1];
    const prevClose=Number(last.close||live);
    last.close=live;
    last.high=Math.max(Number(last.high||live),live);
    last.low=Math.min(Number(last.low||live),live);
    if(!last.open)last.open=prevClose;
    return bars;
  }

  function draw(payload){
    const canvas=document.getElementById('obMiniChartCanvas');
    if(!canvas)return;
    const wrap=canvas.parentElement;
    const allBars=liveBars(payload);
    updateMiniClose1530Label(allBars);
    const defBars=tf==='daily'?70:90;
    const visible=Math.max(1,Math.min(allBars.length||defBars,Number(miniZoomBars[tf]||defBars)));
    const bars=allBars.slice(-visible);
    const dpr=window.devicePixelRatio||1;
    const w=Math.max(420,wrap.clientWidth||600),h=Math.max(260,wrap.clientHeight||360);
    canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr);
    canvas.style.width=w+'px';canvas.style.height=h+'px';
    const ctx=canvas.getContext('2d');
    ctx.setTransform(dpr,0,0,dpr,0,0);ctx.clearRect(0,0,w,h);
    if(!bars.length){
      ctx.fillStyle='#6d879a';ctx.font='12px sans-serif';ctx.fillText('차트 데이터 없음',18,28);return;
    }
    const pad={l:54,r:12,t:16,b:25},volH=Math.max(42,h*.16),priceH=h-pad.t-pad.b-volH-8;
    const nums=a=>a.map(Number).filter(Number.isFinite);
    const highs=nums(bars.map(x=>x.high)),lows=nums(bars.map(x=>x.low));
    const fz=fzone(),lv=fz?.levels||{};
    const fzVals=tf==='daily'?[]:[lv.B1,lv.B2,lv.B3].map(Number).filter(Number.isFinite);
    const sharedLevels=chartLevels(normCode(typeof ORDERBOOK_CODE!=='undefined'?ORDERBOOK_CODE:''),tf);
    let maxP=Math.max(...highs,...(fzVals.length?fzVals:[-Infinity]),...(sharedLevels.length?sharedLevels:[-Infinity]));
    let minP=Math.min(...lows,...(fzVals.length?fzVals:[Infinity]),...(sharedLevels.length?sharedLevels:[Infinity]));
    if(!Number.isFinite(maxP)||!Number.isFinite(minP)){return}
    const margin=Math.max(1,(maxP-minP)*.05);maxP+=margin;minP-=margin;
    const range=Math.max(1,maxP-minP),y=p=>pad.t+(maxP-p)/range*priceH;
    const xStep=(w-pad.l-pad.r)/bars.length,body=Math.max(2,Math.min(7,xStep*.62));
    ctx.strokeStyle='#132a3b';ctx.lineWidth=1;ctx.fillStyle='#617d91';ctx.font='9px sans-serif';
    for(let i=0;i<=4;i++){
      const yy=pad.t+priceH*i/4;
      ctx.beginPath();ctx.moveTo(pad.l,yy);ctx.lineTo(w-pad.r,yy);ctx.stroke();
      const pv=maxP-range*i/4;ctx.fillText(Math.round(pv).toLocaleString('ko-KR'),3,yy+3);
    }
    drawIntradayTimeMarkers(ctx,bars,pad,priceH,volH,xStep,8,tf,y,w-pad.r,false);
    if(fzVals.length===3){
      const vals=[['B1',Number(lv.B1)],['B2',Number(lv.B2)],['B3',Number(lv.B3)]];
      const top=Math.min(...vals.map(x=>y(x[1]))),bot=Math.max(...vals.map(x=>y(x[1])));
      ctx.fillStyle='rgba(210,153,34,.08)';ctx.fillRect(pad.l,top,w-pad.l-pad.r,bot-top);
      vals.forEach(([name,val],i)=>{
        const yy=y(val);ctx.strokeStyle=i===1?'rgba(232,185,78,.95)':'rgba(232,185,78,.60)';
        ctx.setLineDash(i===1?[3,3]:[7,4]);ctx.beginPath();ctx.moveTo(pad.l,yy);ctx.lineTo(w-pad.r,yy);ctx.stroke();ctx.setLineDash([]);
        ctx.fillStyle='#e8b94e';ctx.font='bold 9px sans-serif';ctx.fillText(name+' '+Math.round(val).toLocaleString('ko-KR'),w-pad.r-92,Math.max(10,yy-3));
      });
    }
    if(sharedLevels.length){
      ctx.save();ctx.strokeStyle='rgba(255,255,255,.90)';ctx.fillStyle='#fff';ctx.lineWidth=1.15;ctx.font='bold 9px sans-serif';
      sharedLevels.forEach(val=>{
        if(val<minP||val>maxP)return;
        const yy=y(val);ctx.setLineDash([]);ctx.beginPath();ctx.moveTo(0,yy);ctx.lineTo(w,yy);ctx.stroke();
        const label=Math.round(val).toLocaleString('ko-KR'),tw=ctx.measureText(label).width;
        ctx.fillStyle='rgba(7,15,25,.82)';ctx.fillRect(w-pad.r-tw-9,yy-8,tw+8,14);
        ctx.fillStyle='#fff';ctx.fillText(label,w-pad.r-tw-5,yy+3);
      });
      ctx.restore();
    }
    const maxV=Math.max(1,...bars.map(x=>Number(x.volume||0)));
    bars.forEach((b,i)=>{
      const xx=pad.l+xStep*(i+.5),o=Number(b.open),cl=Number(b.close),hi=Number(b.high),lo=Number(b.low);
      if(![o,cl,hi,lo].every(Number.isFinite))return;
      const up=cl>=o;ctx.strokeStyle=up?'#ff5a70':'#4ba3ff';ctx.fillStyle=ctx.strokeStyle;
      ctx.beginPath();ctx.moveTo(xx,y(hi));ctx.lineTo(xx,y(lo));ctx.stroke();
      const top=Math.min(y(o),y(cl)),bh=Math.max(1,Math.abs(y(o)-y(cl)));ctx.fillRect(xx-body/2,top,body,bh);
      const vh=Number(b.volume||0)/maxV*volH;ctx.globalAlpha=.32;ctx.fillRect(xx-body/2,pad.t+priceH+8+volH-vh,body,vh);ctx.globalAlpha=1;
    });
    const marks=4;ctx.fillStyle='#5e7a90';ctx.font='9px sans-serif';
    for(let m=0;m<marks;m++){
      const i=Math.min(bars.length-1,Math.round(m*(bars.length-1)/(marks-1))),b=bars[i];
      const raw=fmtTime(b,tf==='daily'?'daily':tf==='1'?'m1':tf==='3'?'m3':'m15');
      const xx=pad.l+xStep*(i+.5);
      ctx.save();ctx.textAlign='center';ctx.fillText(raw,xx,h-7);ctx.restore();
    }
  }

  async function load(frame=tf,force=false){
    const code=normCode(typeof ORDERBOOK_CODE!=='undefined'?ORDERBOOK_CODE:'');
    if(!code)return;
    tf=frame;
    const dock=ensureDock();if(!dock)return;
    const name=(typeof ORDERBOOK_NAME!=='undefined'?ORDERBOOK_NAME:'')||code;
    const nameEl=document.getElementById('obMiniChartName');
    if(nameEl)nameEl.textContent=name+' · '+label(tf);
    const fzEl=document.getElementById('obMiniChartFzone');
    if(fzEl)fzEl.textContent=tf==='daily'?'일봉 F존 제외':!CHART_FZONE_ENABLED?'F존 OFF':(fzone()?.levels?.B1?'F존 표시':'F존 없음');

    const k=key(code,tf),hit=cache.get(k);
    if(hit&&!force){
      currentPayload=hit;draw(hit);
      const s=document.getElementById('obMiniChartStatus');if(s)s.textContent='캐시 · '+label(tf);
      const l=document.getElementById('obMiniChartLoading');if(l)l.style.display='none';
      return;
    }
    const my=++token;
    const l=document.getElementById('obMiniChartLoading');if(l){l.style.display='flex';l.textContent='차트 불러오는 중…'}
    try{
      const r=await fetch('/api/orderbook-mini-chart?code='+encodeURIComponent(code)+'&tf='+encodeURIComponent(tf),{cache:'no-store'});
      const d=await r.json();
      if(!r.ok)throw Error(d.error||'차트 조회 실패');
      if(my!==token||code!==normCode(ORDERBOOK_CODE))return;
      cache.set(k,d);currentPayload=d;draw(d);
      const s=document.getElementById('obMiniChartStatus');
      if(s)s.textContent=(d.cached?'캐시':'키움')+' · '+label(tf)+' · '+Number(d.count||0)+'봉';
      if(l)l.style.display='none';
    }catch(e){
      if(my!==token)return;
      const s=document.getElementById('obMiniChartStatus');if(s)s.textContent='차트 오류 · '+e.message;
      if(l){l.style.display='flex';l.textContent='차트 조회 실패'}
    }
  }

  window.addEventListener('litto-chart-marker-toggle',()=>{syncChartMarkerButtons();if(currentPayload)draw(currentPayload)});
  window.addEventListener('litto-chart-fzone-toggle',()=>{syncChartFzoneButtons();const fzEl=document.getElementById('obMiniChartFzone');if(fzEl)fzEl.textContent=tf==='daily'?'일봉 F존 제외':!CHART_FZONE_ENABLED?'F존 OFF':(fzone()?.levels?.B1?'F존 표시':'F존 없음');if(currentPayload)draw(currentPayload)});
  window.addEventListener('litto-chart-levels-changed',e=>{
    const code=normCode(typeof ORDERBOOK_CODE!=='undefined'?ORDERBOOK_CODE:'');
    if(!code||normCode(e?.detail?.code||'')!==code)return;
    const want=tf==='daily'?'daily':'minute';
    if(e?.detail?.group&&e.detail.group!==want)return;
    if(currentPayload)draw(currentPayload);
  });
  function startLivePaint(){
    if(liveTimer)clearInterval(liveTimer);
    liveTimer=setInterval(()=>{
      const modal=document.getElementById('orderbookModal');
      if(!modal||modal.hidden||!currentPayload)return;
      draw(currentPayload); // local canvas repaint only; no fetch
    },1000);
  }

  function stop(){
    token++;currentPayload=null;
    if(liveTimer){clearInterval(liveTimer);liveTimer=null}
  }

  const originalEnsure=window.ensureOrderbookModal;
  if(typeof originalEnsure==='function'){
    window.ensureOrderbookModal=function(){
      const m=originalEnsure.apply(this,arguments);
      ensureDock();
      return m;
    };
  }

  const originalOpen=window.openOrderbook;
  if(typeof originalOpen==='function'){
    window.openOrderbook=function(){
      const out=originalOpen.apply(this,arguments);
      const dock=ensureDock();
      tf='3';
      if(dock){
        dock.querySelectorAll('[data-ob-chart-tf]').forEach(x=>x.classList.toggle('active',x.dataset.obChartTf==='3'));
        const l=document.getElementById('obMiniChartLoading');if(l){l.style.display='flex';l.textContent='호가 우선 · 차트 대기'}
      }
      startLivePaint();
      // Important: give the live orderbook first priority before starting one chart REST call.
      setTimeout(()=>{
        const modal=document.getElementById('orderbookModal');
        if(modal&&!modal.hidden)load('3',false);
      },800);
      return out;
    };
  }

  const originalClose=window.closeOrderbook;
  if(typeof originalClose==='function'){
    window.closeOrderbook=function(){
      stop();
      return originalClose.apply(this,arguments);
    };
  }
})();


;try{(()=>{let st=document.getElementById('stockActionMemoFullRowStyle');if(!st){st=document.createElement('style');st.id='stockActionMemoFullRowStyle';document.head.appendChild(st)}st.textContent='.stock-action-buttons #stockActionMemo{grid-column:1 / -1!important;}';})();}catch(_e){}

/* === LITTO DEV · auto-buy reservation V7 ===============================
   Developer test:
   - Fixed trigger times: 15:00:00 / 15:10:00 / 15:19:00 KST.
   - Captures the orderbook symbol once when AUTO BUY is started.
   - Uses ONE per-round amount entered by the user.
   - At each trigger, fetches the latest orderbook/current price, calculates
     qty=floor(amount/current_price), then sends a MARKET BUY automatically.
   - No per-order confirmation dialog after the schedule is armed.
   - Existing server live-order safety latch is opened only for the request
     and immediately locked again afterward.
   - Closing the orderbook does not cancel the schedule.
============================================================================ */
(function installAutoBuyReservationV7(){
  if(window.__littoAutoBuyV7Installed)return;
  window.__littoAutoBuyV7Installed=true;

  const STORE='litto_dev_auto_buy_v7';
  const FIXED_TIMES=['15:00:00','15:10:00','15:19:00'];
  let timer=null, armed=null, firing=false;

  const $id=id=>document.getElementById(id);
  const num=v=>Number(String(v??'').replace(/[^0-9.-]/g,''));
  const money=v=>Number(v||0).toLocaleString('ko-KR');
  function code(){return String(window.ORDERBOOK_CODE||'').replace(/\D/g,'').slice(-6)}
  function name(){return String(window.ORDERBOOK_NAME||code()||'-')}
  function saveAmount(){
    try{localStorage.setItem(STORE,JSON.stringify({amount:$id('autoBuyAmount')?.value||''}))}catch(_e){}
  }
  function load(){
    try{return JSON.parse(localStorage.getItem(STORE)||'{}')}catch(_e){return {}}
  }
  function setStatus(text,kind=''){
    const el=$id('autoBuyStatus');if(!el)return;
    el.textContent=text;el.className='auto-status '+kind;
  }
  function timeToday(t){
    const m=String(t).match(/^(\d{2}):(\d{2}):(\d{2})$/);if(!m)return 0;
    const d=new Date();d.setHours(Number(m[1]),Number(m[2]),Number(m[3]),0);return d.getTime();
  }
  function fmtCountdown(ms){
    if(ms<=0)return '곧 실행';
    const s=Math.ceil(ms/1000),m=Math.floor(s/60),ss=s%60;
    return `${m}분 ${String(ss).padStart(2,'0')}초`;
  }
  function requestId(job){
    return `autobuy-${Date.now()}-${job.idx}-${Math.random().toString(36).slice(2,9)}`;
  }
  function syncSymbol(){
    const el=$id('autoBuySymbol');if(!el)return;
    el.textContent=armed?`${armed.name} · ${armed.code}`:(code()?`${name()} · ${code()}`:'호가창 종목 대기');
  }
  function updateButtons(){
    const start=$id('autoBuyStart'),cancel=$id('autoBuyCancel');
    if(start){
      start.disabled=!!armed;
      start.textContent=armed?'자동매매 실행중':'자동매매 시작';
      start.classList.toggle('active',!!armed);
    }
    if(cancel)cancel.disabled=!armed;
  }
  function updateJobs(){
    FIXED_TIMES.forEach((t,i)=>{
      const el=$id(`autoJob${i+1}`);
      if(!el)return;
      const job=armed?.jobs?.find(j=>j.idx===i+1);
      el.classList.remove('done','fail','pending');
      if(job?.done){
        el.classList.add(job.ok?'done':'fail');
        el.querySelector('.auto-job-state').textContent=job.ok?'완료':'실패/건너뜀';
      }else{
        el.classList.add('pending');
        el.querySelector('.auto-job-state').textContent=armed?'대기':'예약';
      }
    });
  }
  function stop(reason='자동매매 취소'){
    armed=null;firing=false;
    if(timer){clearInterval(timer);timer=null}
    updateButtons();updateJobs();syncSymbol();setStatus(reason,'');
  }

  async function latestReferencePrice(symbol){
    const r=await fetch(`/api/orderbook?code=${encodeURIComponent(symbol)}`,{cache:'no-store'});
    const d=await r.json();
    if(!r.ok)throw Error(d.error||'현재가 조회 실패');
    let p=Number(d.current_price||0);
    if(!(p>0)){
      const asks=Array.isArray(d.asks)?d.asks:[];
      const bids=Array.isArray(d.bids)?d.bids:[];
      p=Number(asks.find(x=>Number(x?.price)>0)?.price||bids.find(x=>Number(x?.price)>0)?.price||0);
    }
    if(!(p>0))throw Error('실시간 현재가를 확인할 수 없습니다.');
    return {price:p,data:d};
  }

  async function fire(job){
    if(!armed||job.done||firing)return;
    firing=true;
    const a=armed;
    try{
      setStatus(`${job.idx}차 · 실시간 가격 확인 중…`,'armed');

      const acctRes=await fetch('/api/account-status?force=1',{cache:'no-store'});
      const acct=await acctRes.json();
      if(!acctRes.ok)throw Error(acct.error||'계좌 조회 실패');
      if(!acct?.connected)throw Error('키움 계좌가 연결되어 있지 않습니다.');

      const snap=await latestReferencePrice(a.code);
      const refPrice=Math.round(Number(snap.price));
      const qty=Math.floor(a.amount/refPrice);
      if(!(qty>=1))throw Error(`주문금액 ${money(a.amount)}원이 현재가 ${money(refPrice)}원보다 작습니다.`);

      setStatus(`${job.idx}차 · 시장가 매수 ${money(qty)}주 전송 중…`,'armed');

      let serverArmed=false;
      try{
        const armRes=await api('/api/order/arm',{armed:true});
        serverArmed=!!armRes?.armed;
        if(!serverArmed)throw Error('주문 잠금을 해제하지 못했습니다.');

        const res=await api('/api/order/place',{
          confirm:true,
          request_id:requestId(job),
          side:'buy',
          code:a.code,
          qty,
          price:null,
          order_type:'market',
          venue:acct.mock?'KRX':'SOR'
        });

        job.done=true;job.ok=true;job.qty=qty;job.refPrice=refPrice;job.orderNo=res.order_no||'';
        setStatus(`${job.idx}차 접수 완료 · ${a.name} ${money(qty)}주 · 주문번호 ${res.order_no||'-'}`,'ready');
      }finally{
        if(serverArmed){
          try{await api('/api/order/arm',{armed:false})}catch(_e){}
        }
        const live=$id('obLiveArm');if(live)live.checked=false;
      }
    }catch(e){
      job.done=true;job.ok=false;job.error=e.message;
      setStatus(`${job.idx}차 실패 · ${e.message}`,'warn');
    }finally{
      firing=false;updateJobs();
    }
  }

  function tick(){
    if(!armed)return;
    const now=Date.now();
    const due=armed.jobs.filter(j=>!j.done&&j.when<=now).sort((a,b)=>a.when-b.when);
    if(due.length&&!firing){fire(due[0]);return}

    const pending=armed.jobs.filter(j=>!j.done).sort((a,b)=>a.when-b.when);
    if(!pending.length){
      const n=armed.name,c=armed.code;
      if(timer){clearInterval(timer);timer=null}
      armed=null;updateButtons();updateJobs();syncSymbol();
      setStatus(`오늘 자동매매 처리 완료 · ${n} (${c})`,'ready');
      return;
    }
    setStatus(`자동매매 대기 · 다음 ${pending[0].idx}차 ${pending[0].time} · ${fmtCountdown(pending[0].when-now)}`,'armed');
  }

  async function start(){
    if(armed)return;
    const c=code(),n=name(),amount=num($id('autoBuyAmount')?.value);
    if(!c){setStatus('호가창에 종목을 먼저 불러와 주세요.','warn');return}
    if(!(amount>0)){setStatus('1회 주문금액을 입력해 주세요.','warn');return}

    const now=Date.now();
    const jobs=FIXED_TIMES.map((t,i)=>({idx:i+1,time:t,when:timeToday(t),done:false,ok:false}))
                          .filter(j=>j.when>now);
    if(!jobs.length){setStatus('오늘 15:19가 지나 자동매매를 시작할 수 없습니다.','warn');return}

    // Check account before arming, but do not require the orderbook modal to remain open.
    try{
      const r=await fetch('/api/account-status?force=1',{cache:'no-store'});
      const acct=await r.json();
      if(!r.ok)throw Error(acct.error||'계좌 조회 실패');
      if(!acct?.connected)throw Error('키움 계좌 로그인이 필요합니다.');

      const mode=acct.mock?'모의계좌':'실전계좌';
      const remain=jobs.map(j=>`${j.idx}차 ${j.time}`).join(' / ');
      const ok=confirm(
        `[${mode}] 자동매매 시작\n\n`+
        `${n} (${c})\n`+
        `각 회차 주문금액 ${money(amount)}원\n`+
        `${remain}\n\n`+
        `각 시간이 되면 실시간 가격으로 수량을 계산하여\n`+
        `시장가 매수 주문을 자동 전송합니다.\n\n`+
        `시작 후에는 각 주문마다 별도 확인창이 뜨지 않습니다.\n`+
        `자동매매를 시작할까요?`
      );
      if(!ok)return;

      armed={code:c,name:n,amount,jobs,mode};
      saveAmount();updateButtons();updateJobs();syncSymbol();tick();
      timer=setInterval(tick,250);
    }catch(e){
      setStatus(`자동매매 시작 실패 · ${e.message}`,'warn');
    }
  }

  function ensurePanel(){
    const modal=$id('orderbookModal'),dialog=modal?.querySelector('.orderbook-dialog.hts-orderbook');
    if(!dialog)return null;
    let p=$id('obAutoBuyPanel');
    if(p){syncSymbol();return p}

    if(!$id('obAutoBuyStyle')){
      const st=document.createElement('style');st.id='obAutoBuyStyle';st.textContent=`
        #orderbookModal .ob-auto-buy{position:absolute;right:18px;top:calc(18px + min(48vh,520px) + 10px);bottom:18px;width:calc(33.2% - 24px);min-height:250px;border:1px solid #20394d;border-radius:14px;background:#07131e;box-shadow:0 12px 30px rgba(0,0,0,.20);z-index:5;padding:12px;display:flex;flex-direction:column;gap:10px;overflow:auto}
        #orderbookModal .auto-head{display:flex;align-items:center;justify-content:space-between;gap:8px}.auto-head b{font-size:13px;color:#e5f1fb}.auto-live{font-size:9px;font-weight:900;color:#ffbd67;border:1px solid #7c5b20;border-radius:6px;padding:3px 6px;background:#261d08}
        #orderbookModal .auto-symbol{font-size:10px;color:#a9c7dc;background:#091a27;border:1px solid #193448;border-radius:8px;padding:7px 9px}.auto-symbol strong{color:#eaf5fc}
        #orderbookModal .auto-jobs{display:grid;grid-template-columns:1fr 1fr 1fr;gap:7px}.auto-job{border:1px solid #29465b;border-radius:9px;background:#0a1b28;padding:8px;text-align:center}.auto-job b{display:block;color:#eef7fc;font-size:13px}.auto-job span{display:block;margin-top:3px;color:#7891a5;font-size:9px}.auto-job.done{border-color:#236c50;background:#0a2a20}.auto-job.done span{color:#6ee7ae}.auto-job.fail{border-color:#7a3440;background:#2a1117}.auto-job.fail span{color:#ff8994}
        #orderbookModal .auto-field{display:flex;flex-direction:column;gap:5px;font-size:9px;color:#7891a5}.auto-field input{width:100%;box-sizing:border-box;border:1px solid #29465b;border-radius:8px;background:#0a1b28;color:#eaf5fc;padding:9px;font-size:13px;font-weight:800;outline:none}.auto-field input:focus{border-color:#4ca7d8}
        #orderbookModal .auto-info{font-size:10px;color:#8ca8ba;background:#091a27;border:1px solid #193448;border-radius:8px;padding:8px 9px;line-height:1.45}
        #orderbookModal .auto-actions{display:flex;gap:7px}.auto-start{flex:1;border:1px solid #bf4359;background:#7c2030;color:#fff;border-radius:9px;padding:10px;font-weight:900;cursor:pointer}.auto-start.active{border-color:#d49a38;background:#5a3a0e}.auto-start:disabled{opacity:.78;cursor:default}.auto-cancel{border:1px solid #a33b4b;background:#35151c;color:#ff9aa6;border-radius:9px;padding:10px;font-weight:900;cursor:pointer}.auto-cancel:disabled{opacity:.35;cursor:not-allowed}
        #orderbookModal .auto-status{font-size:10px;color:#8098ab;min-height:20px}.auto-status.armed{color:#ffd479}.auto-status.ready{color:#6ee7ae}.auto-status.warn{color:#ff8591}.auto-note{margin-top:auto;font-size:9px;line-height:1.5;color:#657f91}.auto-note strong{color:#ffbc69}
        @media(max-width:1450px){#orderbookModal .ob-auto-buy{display:none!important}}
      `;document.head.appendChild(st)
    }

    const saved=load();
    p=document.createElement('section');p.id='obAutoBuyPanel';p.className='ob-auto-buy';
    p.innerHTML=`
      <div class="auto-head"><b>자동 매수</b><span class="auto-live">DEV · AUTO ORDER</span></div>
      <div class="auto-symbol">예약종목 · <strong id="autoBuySymbol">호가창 종목 대기</strong></div>
      <div class="auto-jobs">
        <div id="autoJob1" class="auto-job pending"><b>15:00</b><span class="auto-job-state">예약</span></div>
        <div id="autoJob2" class="auto-job pending"><b>15:10</b><span class="auto-job-state">예약</span></div>
        <div id="autoJob3" class="auto-job pending"><b>15:19</b><span class="auto-job-state">예약</span></div>
      </div>
      <label class="auto-field"><span>1회 주문금액</span><input id="autoBuyAmount" inputmode="numeric" value="${saved.amount||'1000000'}" placeholder="예: 1000000"></label>
      <div class="auto-info">각 시간이 되면 최신 현재가로 <b>주문가능 수량 = 주문금액 ÷ 현재가</b>를 다시 계산하고 시장가 매수합니다. 실제 체결금액은 시장 상황에 따라 입력금액과 차이가 날 수 있습니다.</div>
      <div class="auto-actions"><button id="autoBuyStart" class="auto-start" type="button">자동매매 시작</button><button id="autoBuyCancel" class="auto-cancel" type="button" disabled>자동매매 취소</button></div>
      <div id="autoBuyStatus" class="auto-status">호가창 종목 선택 후 주문금액을 입력하세요.</div>
      <div class="auto-note"><strong>자동 주문:</strong> 시작할 때 한 번만 확인합니다. 이후 15:00 / 15:10 / 15:19에 별도 확인 없이 시장가 매수 주문이 전송됩니다. 호가창을 닫아도 예약은 유지됩니다.</div>`;
    dialog.appendChild(p);

    $id('autoBuyAmount').addEventListener('input',saveAmount);
    $id('autoBuyStart').onclick=start;
    $id('autoBuyCancel').onclick=()=>{
      if(armed&&confirm(`${armed.name} (${armed.code})\n남은 자동매매 예약을 모두 취소할까요?`))stop('자동매매 예약이 취소되었습니다.');
    };
    syncSymbol();updateButtons();updateJobs();
    return p;
  }

  const prevEnsure=window.ensureOrderbookModal;
  if(typeof prevEnsure==='function')window.ensureOrderbookModal=function(){
    const out=prevEnsure.apply(this,arguments);ensurePanel();return out;
  };
  const prevOpen=window.openOrderbook;
  if(typeof prevOpen==='function')window.openOrderbook=function(){
    const out=prevOpen.apply(this,arguments);ensurePanel();syncSymbol();return out;
  };
  /* Intentionally no closeOrderbook hook: active schedule survives modal close. */
})();


/* === LITTO DEV · account watchlist VIEW ONLY V14 ===========================
   Purpose:
   - Show Kiwoom account/HTS/MTS watchlist groups and members inside LITTO.
   - Read-only only. No local edit/add/delete/reorder/apply controls.
   - Kiwoom source is never modified.
============================================================================ */
(function installAccountWatchlistViewOnlyV14(){
  if(window.__littoAccountWatchViewOnlyV14)return;
  window.__littoAccountWatchViewOnlyV14=true;

  const esc=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));

  function ensureStyle(){
    if(document.getElementById('accountWatchViewOnlyStyle'))return;
    const st=document.createElement('style');st.id='accountWatchViewOnlyStyle';st.textContent=`
      .watch-account-import-btn{margin-left:8px;border:1px solid #31536b;border-radius:10px;background:#10283a;color:#bfe8ff;padding:8px 12px;font-weight:800;cursor:pointer}
      .awv-modal{position:fixed;inset:0;z-index:260000;display:none;align-items:center;justify-content:center;padding:18px}
      .awv-modal.open{display:flex}.awv-backdrop{position:absolute;inset:0;background:rgba(0,0,0,.72)}
      .awv-dialog{position:relative;width:min(900px,96vw);max-height:86vh;display:flex;flex-direction:column;background:#07131e;border:1px solid #29465b;border-radius:16px;box-shadow:0 24px 70px rgba(0,0,0,.58);padding:15px}
      .awv-head{display:flex;align-items:flex-start;justify-content:space-between;gap:12px;padding-bottom:10px;border-bottom:1px solid #183044}
      .awv-head b{font-size:17px;color:#eef7fc}.awv-head span{display:block;margin-top:4px;color:#7891a5;font-size:11px}
      .awv-close{width:32px;height:32px;border:1px solid #31536b;border-radius:8px;background:#0d2231;color:#d8eaf6;cursor:pointer}
      .awv-toolbar{display:flex;gap:7px;margin:11px 0}
      .awv-btn{border:1px solid #31536b;border-radius:9px;background:#0c2231;color:#cce9fa;padding:8px 10px;font-size:11px;font-weight:800;cursor:pointer}
      .awv-status{padding:8px 10px;border:1px solid #193448;border-radius:9px;background:#091a27;color:#91aabc;font-size:11px;margin-bottom:10px}
      .awv-body{display:grid;grid-template-columns:230px 1fr;gap:10px;min-height:0;flex:1}
      .awv-groups{overflow:auto;border:1px solid #193448;border-radius:10px;padding:7px;background:#081722}
      .awv-group{width:100%;text-align:left;border:1px solid transparent;border-radius:8px;background:transparent;color:#dbeef9;padding:9px;cursor:pointer}
      .awv-group:hover,.awv-group.active{background:#10283a;border-color:#31536b}.awv-group small{display:block;color:#7891a5;margin-top:3px}
      .awv-listbox{min-width:0;display:flex;flex-direction:column;border:1px solid #193448;border-radius:10px;background:#081722;overflow:hidden}
      .awv-table-head,.awv-row{display:grid;grid-template-columns:46px 100px minmax(180px,1fr) 150px;gap:8px;align-items:center}
      .awv-table-head{padding:7px 8px;background:#0c1f2d;color:#6f899c;font-size:9px;font-weight:800;border-bottom:1px solid #193448}
      .awv-list{overflow:auto;min-height:320px;max-height:55vh}
      .awv-row{padding:8px;border-bottom:1px solid #102737;color:#dcecf6;font-size:11px}
      .awv-index-cell{color:#6e889b;text-align:center}.awv-code-cell{font-family:Consolas,monospace;color:#9fd7ff}.awv-sector-cell{color:#87a4b7}
      .awv-empty{padding:28px;text-align:center;color:#647f92;font-size:11px}
      .awv-footer{display:flex;justify-content:space-between;gap:8px;align-items:center;margin-top:10px;color:#6f899c;font-size:10px}
      @media(max-width:820px){.awv-body{grid-template-columns:1fr}.awv-groups{max-height:150px}.awv-table-head,.awv-row{grid-template-columns:40px 88px minmax(130px,1fr) 100px}}
    `;document.head.appendChild(st);
  }

  function setStatus(t){const e=document.getElementById('awvStatus');if(e)e.textContent=t}

  function ensureModal(){
    ensureStyle();
    let m=document.getElementById('accountWatchViewOnlyModal');if(m)return m;
    m=document.createElement('div');m.id='accountWatchViewOnlyModal';m.className='awv-modal';
    m.innerHTML=`<div class="awv-backdrop" data-close></div><div class="awv-dialog">
      <div class="awv-head"><div><b>계좌 관심종목</b><span>키움에 저장된 관심종목을 LITTO에서 조회만 합니다.</span></div><button class="awv-close" type="button" data-close>×</button></div>
      <div class="awv-toolbar"><button class="awv-btn" id="awvRefresh" type="button">새로고침</button></div>
      <div id="awvStatus" class="awv-status">준비</div>
      <div class="awv-body">
        <div id="awvGroups" class="awv-groups"></div>
        <div class="awv-listbox">
          <div class="awv-table-head"><span>순번</span><span>종목코드</span><span>종목명</span><span>섹터</span></div>
          <div id="awvList" class="awv-list"></div>
        </div>
      </div>
      <div class="awv-footer"><span>※ 읽기 전용 · LITTO/키움 관심종목은 변경되지 않습니다.</span><span id="awvCount">0종목</span></div>
    </div>`;
    document.body.appendChild(m);
    m.querySelectorAll('[data-close]').forEach(x=>x.addEventListener('click',()=>m.classList.remove('open')));
    m.querySelector('#awvRefresh').addEventListener('click',loadGroups);
    return m;
  }

  function renderGroups(groups=[]){
    const box=document.getElementById('awvGroups');if(!box)return;
    if(!groups.length){box.innerHTML='<div class="awv-empty">키움 관심종목 그룹이 없습니다.</div>';return}
    box.innerHTML=groups.map(g=>`<button type="button" class="awv-group" data-g="${esc(g.group_code)}"><b>${esc(g.group_name||g.group_code)}</b><small>그룹 ${esc(g.group_code)}</small></button>`).join('');
    box.querySelectorAll('[data-g]').forEach(b=>b.addEventListener('click',async()=>{
      box.querySelectorAll('.awv-group').forEach(x=>x.classList.remove('active'));b.classList.add('active');
      await loadGroup(b.dataset.g);
    }));
  }

  function renderRows(rows=[]){
    const box=document.getElementById('awvList'),cnt=document.getElementById('awvCount');if(!box)return;
    if(!rows.length){box.innerHTML='<div class="awv-empty">종목이 없습니다.</div>';if(cnt)cnt.textContent='0종목';return}
    box.innerHTML=rows.map((r,i)=>`<div class="awv-row">
      <span class="awv-index-cell">${i+1}</span><span class="awv-code-cell">${esc(r.code||'')}</span><span class="awv-name-cell">${esc(r.name||r.code||'')}</span><span class="awv-sector-cell">${esc(r.sector||'기타')}</span>
    </div>`).join('');
    if(cnt)cnt.textContent=`${rows.length}종목`;
  }

  async function loadGroups(){
    const m=ensureModal();setStatus('키움 관심종목 그룹 조회 중…');renderRows([]);
    const box=m.querySelector('#awvGroups');box.innerHTML='';
    try{
      const r=await fetch('/api/account-watchlist-groups',{cache:'no-store'}),d=await r.json();
      if(!r.ok||d.error)throw Error(d.error||'관심종목 그룹 조회 실패');
      const groups=d.groups||[];
      renderGroups(groups);
      setStatus(`${groups.length}개 그룹을 불러왔습니다. 왼쪽에서 그룹을 선택하세요.`);
      if(groups.length){
        const first=box.querySelector('[data-g]');
        if(first){first.classList.add('active');await loadGroup(first.dataset.g)}
      }
    }catch(e){renderGroups([]);setStatus(e.message||'키움 관심종목을 불러오지 못했습니다.')}
  }

  async function loadGroup(group){
    setStatus('관심종목 조회 중…');
    try{
      const r=await fetch('/api/account-watchlist?group='+encodeURIComponent(group),{cache:'no-store'}),d=await r.json();
      if(!r.ok||d.error)throw Error(d.error||'관심종목 상세 조회 실패');
      const rows=d.rows||[];renderRows(rows);setStatus(`${rows.length}종목 조회 완료`);
    }catch(e){renderRows([]);setStatus(e.message||'관심종목 상세를 불러오지 못했습니다.')}
  }

  async function openView(){
    const m=ensureModal();m.classList.add('open');await loadGroups();
  }

  function installButton(){
    const sec=typeof ensureWatchlistPage==='function'?ensureWatchlistPage():document.getElementById('watchlist-page');
    if(!sec)return;
    const add=sec.querySelector('#watchManualAddBtn');if(!add)return;
    let b=sec.querySelector('#watchAccountImportBtn');
    if(!b){b=document.createElement('button');b.id='watchAccountImportBtn';b.className='watch-account-import-btn';b.type='button';add.insertAdjacentElement('afterend',b)}
    b.textContent='계좌 관심종목';b.onclick=openView;
  }

  const baseEnsure=window.ensureWatchlistPage;
  if(typeof baseEnsure==='function')window.ensureWatchlistPage=function(){const out=baseEnsure.apply(this,arguments);setTimeout(installButton,0);return out};
  setTimeout(installButton,0);
})();


/* === LITTO DEV · TRADING COCKPIT V16 =======================================
   Large read/decision cockpit opened from the existing stock-action card.
   Uses existing LITTO endpoints only; no new backend route and no order action.
   Fast data: current stock snapshot + orderbook
   Slow data: account / investor flow / news / 1-minute mini chart
============================================================================ */
(function installTradingCockpitV16(){
  if(window.__littoTradingCockpitV16)return;
  window.__littoTradingCockpitV16=true;

  let CP_CODE='',CP_NAME='',CP_TOKEN=0,CP_FAST_TIMER=null,CP_SLOW_TIMER=null,CP_TF='1',CP_CHART_PAYLOAD=null,CP_AVG_PRICE=null,CP_BOOK_SNAPSHOT=null,CP_FLOW_SNAPSHOT=null,CP_PROGRAM_SNAPSHOT=null; const CP_CHART_CACHE=new Map();
  const $cp=(s,r=document)=>r.querySelector(s);
  const escCp=s=>String(s??'').replace(/[&<>"']/g,m=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[m]));
  const nCp=v=>{const n=Number(v);return Number.isFinite(n)?n:null};
  const moneyCp=v=>{const n=nCp(v);return n==null?'-':Math.round(n).toLocaleString('ko-KR')};
  const pctCp=v=>{const n=nCp(v);return n==null?'-':`${n>0?'+':''}${n.toFixed(2)}%`};
  const toneCp=v=>{const n=nCp(v);return n==null?'flat':n>0?'up':n<0?'down':'flat'};
  const eokCp=v=>{const n=nCp(v);if(n==null)return'-';return `${n>0?'+':''}${n.toLocaleString('ko-KR',{maximumFractionDigits:1})}억`};

  function ensureCockpitStyle(){
    if(document.getElementById('littoCockpitV16Style'))return;
    const st=document.createElement('style');st.id='littoCockpitV16Style';st.textContent=`
      .stock-action-buttons #stockActionCockpit{grid-column:1 / -1!important;border-color:#6b4d17!important;background:linear-gradient(135deg,#261b09,#0d1721)!important;box-shadow:inset 0 0 0 1px rgba(255,198,80,.08)}
      .stock-action-buttons #stockActionCockpit b{color:#ffd56a!important;font-size:15px!important}
      #littoCockpitModal{position:fixed;inset:0;z-index:365000;display:none;align-items:center;justify-content:center;padding:14px}
      #littoCockpitModal.open{display:flex}.cp-backdrop{position:absolute;inset:0;background:rgba(1,5,10,.82);backdrop-filter:blur(4px)}
      .cp-dialog{position:relative;width:min(1510px,98vw);height:min(900px,95vh);background:#06111b;border:1px solid #28445b;border-radius:16px;box-shadow:0 28px 90px rgba(0,0,0,.7);display:flex;flex-direction:column;overflow:hidden}
      .cp-head{min-height:70px;display:flex;align-items:center;gap:14px;padding:10px 14px;border-bottom:1px solid #173044;background:#081723}
      .cp-ident{min-width:210px}.cp-ident small{display:block;color:#658197;font-size:9px;font-weight:800;letter-spacing:.12em}.cp-ident h2{margin:2px 0 0;font-size:21px}.cp-ident h2 span{margin-left:8px;color:#678398;font:11px Consolas,monospace}
      .cp-head-metrics{display:grid;grid-template-columns:repeat(6,minmax(90px,1fr));gap:7px;flex:1}.cp-metric{min-width:0;border:1px solid #173449;border-radius:9px;background:#091a27;padding:7px 9px}.cp-metric span{display:block;color:#6f899c;font-size:9px}.cp-metric b{display:block;margin-top:2px;color:#e5f2fa;font-size:13px;white-space:nowrap;overflow:hidden;text-overflow:ellipsis}.cp-metric b.up{color:#ff6b7f}.cp-metric b.down{color:#58a9ff}
      .cp-close{width:36px;height:36px;flex:0 0 36px;border:1px solid #31536b;border-radius:9px;background:#0c2231;color:#d8e9f5;cursor:pointer}
      .cp-grid{flex:1;min-height:0;display:grid;grid-template-columns:1.5fr .92fr .92fr;grid-template-rows:1.18fr .82fr;gap:8px;padding:8px}
      .cp-card{min-width:0;min-height:0;border:1px solid #173449;border-radius:11px;background:#071722;display:flex;flex-direction:column;overflow:hidden}
      .cp-card-head{height:35px;flex:0 0 35px;padding:0 10px;display:flex;align-items:center;justify-content:space-between;border-bottom:1px solid #153044;background:#0a1b28}.cp-card-head b{font-size:11px;color:#d9eaf5}.cp-card-head span,.cp-card-head button{font-size:9px;color:#708a9d}.cp-card-head button{border:1px solid #29475c;border-radius:6px;background:#0d2231;padding:4px 7px;cursor:pointer}
      .cp-chart-card{grid-column:1;grid-row:1}.cp-tf{display:flex;gap:4px;align-items:center}.cp-tf button{border:1px solid #29475c;border-radius:6px;background:#0d2231;color:#7896aa;padding:4px 7px;cursor:pointer;font-size:9px}.cp-tf button.active{background:#173b57;border-color:#2f79aa;color:#d9f1ff}.cp-chart-wrap{position:relative;flex:1;min-height:0;padding:7px}.cp-chart-wrap canvas{width:100%;height:100%;display:block;background:#06131e;border-radius:7px}.cp-chart-overlay{position:absolute;left:15px;top:13px;padding:3px 6px;border-radius:5px;background:rgba(4,12,20,.72);color:#8ca8bb;font-size:9px}.cp-ohlc{position:absolute;right:16px;top:13px;display:flex;gap:8px;padding:4px 7px;border-radius:6px;background:rgba(4,12,20,.76);font-size:9px;color:#8ba7ba}.cp-ohlc b{color:#d8eaf5}.cp-avg-label{position:absolute;left:15px;top:37px;padding:3px 6px;border-radius:5px;background:rgba(4,12,20,.72);color:#f3d36c;font-size:9px}
      .cp-book-card{grid-column:2;grid-row:1}.cp-book{flex:1;min-height:0;display:grid;grid-template-rows:auto 1fr auto;padding:7px}.cp-book-top{display:grid;grid-template-columns:repeat(3,1fr);gap:5px;margin-bottom:5px}.cp-chip{border:1px solid #18384e;border-radius:7px;padding:6px;text-align:center}.cp-chip span{display:block;color:#68859a;font-size:8px}.cp-chip b{font-size:11px}.cp-levels{min-height:0;overflow:hidden;display:grid;grid-template-rows:repeat(10,1fr);border:1px solid #122d40;border-radius:7px}.cp-level{display:grid;grid-template-columns:1fr 1fr 1fr;align-items:center;padding:0 7px;border-bottom:1px solid #10283a;font-size:10px}.cp-level:last-child{border-bottom:0}.cp-level.ask .p{color:#58a9ff}.cp-level.bid .p{color:#ff6b7f}.cp-level .q{text-align:right;color:#8ca5b6}.cp-level .p{text-align:center;font-weight:800}.cp-level .side{color:#607e93}.cp-current{text-align:center;border-top:1px solid #153044;margin-top:5px;padding-top:5px;font-size:12px}.cp-current b{font-size:16px;margin-left:6px}
      .cp-flow-card{grid-column:3;grid-row:1}.cp-flow{padding:8px;overflow:auto}.cp-flow-row{display:grid;grid-template-columns:86px 1fr 1fr;gap:6px;align-items:center;padding:6px 4px;border-bottom:1px solid #10283a}.cp-flow-row span{color:#7590a3;font-size:9px}.cp-flow-row b{text-align:right;font-size:11px}.cp-flow-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:6px;margin-bottom:8px}.cp-flow-box{border:1px solid #18384e;border-radius:8px;padding:8px;text-align:center}.cp-flow-box span{display:block;color:#708b9f;font-size:9px}.cp-flow-box b{display:block;margin-top:3px;font-size:12px}.cp-flow-note{padding:5px 2px;color:#617c91;font-size:9px}
      .cp-market-card{grid-column:1;grid-row:2}.cp-account-body{display:grid;grid-template-columns:1.1fr 1fr;gap:8px;padding:8px;overflow:auto}.cp-unfilled{grid-column:1 / -1;border-top:1px solid #173044;padding-top:7px}.cp-unfilled-head{display:flex;justify-content:space-between;color:#6f899c;font-size:9px;margin-bottom:5px}.cp-unfilled-row{display:grid;grid-template-columns:70px 1fr 1fr 1fr;gap:6px;padding:5px 0;border-bottom:1px solid #10283a;font-size:9px}.cp-unfilled-row b{text-align:right}.cp-market-strength{padding:8px;overflow:auto;display:grid;grid-template-columns:1.15fr .85fr;gap:8px}.cp-market-main{display:grid;grid-template-columns:repeat(3,1fr);gap:6px;align-content:start}.cp-market-box{border:1px solid #18384e;border-radius:8px;padding:8px;background:#081b29}.cp-market-box span{display:block;color:#708a9d;font-size:8px}.cp-market-box b{display:block;margin-top:3px;font-size:12px}.cp-market-detail{border:1px solid #18384e;border-radius:8px;padding:6px 8px}.cp-market-row{display:grid;grid-template-columns:1fr 1fr;gap:8px;padding:5px 0;border-bottom:1px solid #10283a;font-size:9px}.cp-market-row:last-child{border-bottom:0}.cp-market-row span{color:#708a9d}.cp-market-row b{text-align:right;color:#dbeaf4}.cp-position{display:grid;grid-template-columns:repeat(3,1fr);gap:6px}.cp-posbox{border:1px solid #18384e;border-radius:8px;padding:7px}.cp-posbox span{display:block;color:#708a9d;font-size:8px}.cp-posbox b{display:block;margin-top:2px;font-size:11px}.cp-acct-summary{display:grid;grid-template-columns:repeat(2,1fr);gap:6px}.cp-acct-summary .cp-posbox{background:#081b29}
      .cp-signal-card{grid-column:2;grid-row:2}.cp-signals{padding:8px;overflow:auto}.cp-tagline{display:flex;gap:5px;flex-wrap:wrap}.cp-tag{padding:4px 7px;border:1px solid #2d4a60;border-radius:999px;background:#0b2233;color:#9ecde9;font-size:9px}.cp-signal-list{margin-top:8px;display:grid;gap:5px}.cp-signal-item{display:flex;justify-content:space-between;gap:10px;border-bottom:1px solid #10283a;padding:5px 2px;font-size:10px}.cp-signal-item span{color:#708b9f}.cp-signal-item b{color:#d9e9f4}
      .cp-news-card{grid-column:3;grid-row:2}.cp-news{padding:7px;overflow:auto}.cp-news a{display:block;padding:6px;border-bottom:1px solid #10283a;color:#d9e8f2;text-decoration:none}.cp-news a:hover{background:#0b2130}.cp-news b{display:block;font-size:10px;line-height:1.35}.cp-news small{display:block;margin-top:3px;color:#637e92;font-size:8px}.cp-empty{display:flex;align-items:center;justify-content:center;min-height:80px;color:#668196;font-size:10px}.cp-foot{height:32px;flex:0 0 32px;border-top:1px solid #173044;display:flex;align-items:center;justify-content:space-between;padding:0 12px;color:#627f93;font-size:9px;background:#081723}.cp-foot-actions{display:flex;gap:6px}.cp-foot-actions button{border:1px solid #29475c;border-radius:6px;background:#0d2231;color:#a9c5d7;padding:4px 9px;cursor:pointer}
      .cp-up{color:#ff6b7f!important}.cp-down{color:#58a9ff!important}.cp-flat{color:#a9bbc8!important}
      @media(max-width:1100px){.cp-dialog{width:99vw;height:97vh}.cp-head-metrics{grid-template-columns:repeat(3,1fr)}.cp-grid{grid-template-columns:1.25fr 1fr;grid-template-rows:1.1fr .9fr .8fr}.cp-chart-card{grid-column:1;grid-row:1}.cp-book-card{grid-column:2;grid-row:1}.cp-flow-card{grid-column:1;grid-row:2}.cp-market-card{grid-column:2;grid-row:2}.cp-signal-card{grid-column:1;grid-row:3}.cp-news-card{grid-column:2;grid-row:3}}
    `;document.head.appendChild(st);
  }

  function ensureCockpit(){
    ensureCockpitStyle();
    let m=document.getElementById('littoCockpitModal');if(m)return m;
    m=document.createElement('div');m.id='littoCockpitModal';
    m.innerHTML=`<div class="cp-backdrop" data-cp-close></div><div class="cp-dialog">
      <div class="cp-head">
        <div class="cp-ident"><small>TRADING COCKPIT</small><h2 id="cpName">- <span id="cpCode"></span></h2></div>
        <div class="cp-head-metrics">
          <div class="cp-metric"><span>현재가</span><b id="cpPrice">-</b></div>
          <div class="cp-metric"><span>등락률</span><b id="cpChange">-</b></div>
          <div class="cp-metric"><span>거래대금</span><b id="cpValue">-</b></div>
          <div class="cp-metric"><span>대금순위</span><b id="cpValueRank">-</b></div>
          <div class="cp-metric"><span>체결강도</span><b id="cpPower">-</b></div>
          <div class="cp-metric"><span>섹터</span><b id="cpSector">-</b></div>
        </div>
        <button class="cp-close" type="button" data-cp-close>✕</button>
      </div>
      <div class="cp-grid">
        <section class="cp-card cp-chart-card"><div class="cp-card-head"><b id="cpChartTitle">1분 차트 · 거래량</b><div class="cp-tf" id="cpTfButtons"><button type="button" data-cp-tf="daily">일봉</button><button type="button" class="active" data-cp-tf="1">1분</button><button type="button" data-cp-tf="3">3분</button><button type="button" data-cp-tf="15">15분</button><span id="cpChartStatus">대기</span></div></div><div class="cp-chart-wrap"><canvas id="cpChart"></canvas><div id="cpChartOverlay" class="cp-chart-overlay">최근 60봉</div><div id="cpAvgLabel" class="cp-avg-label">평단 -</div><div id="cpOhlc" class="cp-ohlc"><span>시 <b>-</b></span><span>고 <b>-</b></span><span>저 <b>-</b></span><span>종 <b>-</b></span></div></div></section>
        <section class="cp-card cp-book-card"><div class="cp-card-head"><b>호가 · 잔량</b><button id="cpOpenOrderbook" type="button">전체 호가</button></div><div id="cpBook" class="cp-book"><div class="cp-empty">호가 조회 중</div></div></section>
        <section class="cp-card cp-flow-card"><div class="cp-card-head"><b>수급</b><button id="cpOpenFlow" type="button">상세 수급</button></div><div id="cpFlow" class="cp-flow"><div class="cp-empty">수급 조회 중</div></div></section>
        <section class="cp-card cp-market-card"><div class="cp-card-head"><b>프로그램 · 시장강도</b><span id="cpMarketStatus">실시간 종합</span></div><div id="cpMarketStrength" class="cp-market-strength"><div class="cp-empty">시장강도 계산 중</div></div></section>
        <section class="cp-card cp-signal-card"><div class="cp-card-head"><b>LITTO 신호 · 현재 상태</b><button id="cpOpenChart" type="button">전체 차트</button></div><div id="cpSignals" class="cp-signals"><div class="cp-empty">신호 계산 중</div></div></section>
        <section class="cp-card cp-news-card"><div class="cp-card-head"><b>최신 뉴스</b><button id="cpOpenNews" type="button">전체 뉴스</button></div><div id="cpNews" class="cp-news"><div class="cp-empty">뉴스 조회 중</div></div></section>
      </div>
      <div class="cp-foot"><span id="cpUpdated">-</span><div class="cp-foot-actions"><button id="cpRefresh" type="button">전체 새로고침</button><button id="cpMemo" type="button">메모</button><button id="cpChecklist" type="button">종배 체크</button></div></div>
    </div>`;
    document.body.appendChild(m);
    m.querySelectorAll('[data-cp-close]').forEach(x=>x.addEventListener('click',closeTradingCockpit));
    $cp('#cpOpenOrderbook',m).onclick=()=>openOrderbook(CP_CODE,CP_NAME);
    $cp('#cpOpenFlow',m).onclick=()=>openInvestorFlow(CP_CODE,CP_NAME);
    $cp('#cpOpenChart',m).onclick=()=>openChart(CP_CODE);
    $cp('#cpOpenNews',m).onclick=()=>openNews(CP_CODE,CP_NAME);
    $cp('#cpMemo',m).onclick=()=>{openWatchMemo(CP_CODE,CP_NAME);const x=document.getElementById('watchMemoModal');if(x)x.style.zIndex='370100'};
    $cp('#cpChecklist',m).onclick=()=>{openWatchChecklist(CP_CODE,CP_NAME);const x=document.getElementById('watchChecklistModal');if(x)x.style.zIndex='370100'};
    $cp('#cpRefresh',m).onclick=()=>refreshCockpitAll(true);
    m.querySelectorAll('[data-cp-tf]').forEach(b=>b.onclick=async()=>{
      CP_TF=String(b.dataset.cpTf||'1');
      m.querySelectorAll('[data-cp-tf]').forEach(x=>x.classList.toggle('active',x===b));
      const label=CP_TF==='daily'?'일봉':CP_TF+'분';
      $cp('#cpChartTitle',m).textContent=label+' 차트 · 거래량';
      await loadChart(CP_TOKEN);
    });
    return m;
  }

  function quoteSnapshot(){
    return (typeof findStock==='function'?findStock(CP_CODE):null) || (window.WATCH_MANUAL_LIVE?.[CP_CODE]) || {};
  }

  
  function cockpitValueRank(q){
    let r=nCp(q?.value_rank??q?.rank_value??q?.trading_value_rank??q?.rank);
    if(r!=null&&r>0)return r;
    try{
      if(typeof watchValueRankForCode==='function'){
        r=nCp(watchValueRankForCode({code:CP_CODE,...(q||{})}));
        if(r!=null&&r>0)return r;
      }
    }catch(_e){}
    try{
      const candidates=[
        window.WATCH_MANUAL_LIVE,
        window.SCAN_LIVE,
        window.SEARCH_LIVE,
        window.LITTO_LIVE,
        window.ALL_STOCKS
      ];
      const code=String(CP_CODE).replace(/\D/g,'');
      for(const src of candidates){
        if(!src)continue;
        let row=null;
        if(Array.isArray(src)) row=src.find(x=>String(x?.code||'').replace(/\D/g,'')===code);
        else row=src[CP_CODE]||src[code];
        const rv=nCp(row?.value_rank??row?.rank_value??row?.trading_value_rank??row?.rank);
        if(rv!=null&&rv>0)return rv;
      }
    }catch(_e){}
    return null;
  }

function renderTop(){
    const q=quoteSnapshot();
    const price=nCp(q.price??q.current_price??q.close);
    const ch=nCp(q.change??q.change_rate??q.rate);
    const value=nCp(q.value_eok??q.trading_value_eok);
    const rank=cockpitValueRank(q);
    const power=nCp(q.power??q.execution_strength??q.strength);
    const sector=String(q.sector||'기타');
    $cp('#cpPrice').textContent=price==null?'-':moneyCp(price)+'원';
    const ce=$cp('#cpChange');ce.textContent=pctCp(ch);ce.className=toneCp(ch);
    $cp('#cpValue').textContent=value==null?'-':`${value.toLocaleString('ko-KR',{maximumFractionDigits:0})}억`;
    $cp('#cpValueRank').textContent=rank?`${Math.round(rank)}위`:'-';
    $cp('#cpPower').textContent=power==null?'-':power.toLocaleString('ko-KR',{maximumFractionDigits:1});
    $cp('#cpSector').textContent=sector;
    renderSignals(q);
  }

  function renderSignals(q){
    const tags=(typeof lookupTags==='function'?lookupTags(CP_CODE):[])||[];
    const change=nCp(q.change??q.change_rate);
    const value=nCp(q.value_eok);
    const rank=cockpitValueRank(q);
    const rows=[
      ['검색신호',tags.length?`${tags.length}개 포착`:'없음'],
      ['등락률',pctCp(change)],
      ['거래대금',value==null?'-':`${Math.round(value).toLocaleString('ko-KR')}억`],
      ['거래대금 순위',rank?`${Math.round(rank)}위`:'-'],
      ['관심종목',typeof isWatched==='function'?(isWatched(CP_CODE)?'등록됨':'미등록'):'-']
    ];
    $cp('#cpSignals').innerHTML=`<div class="cp-tagline">${tags.map(x=>`<span class="cp-tag">${escCp(x)}</span>`).join('')||'<span class="cp-tag">검색기 분류 없음</span>'}</div><div class="cp-signal-list">${rows.map(([a,b])=>`<div class="cp-signal-item"><span>${a}</span><b>${escCp(b)}</b></div>`).join('')}</div>`;
  }

  function drawMiniChart(d){
    const c=$cp('#cpChart');if(!c)return;
    const box=c.getBoundingClientRect(),ratio=Math.max(1,window.devicePixelRatio||1);
    const w=Math.max(300,Math.floor(box.width)),h=Math.max(180,Math.floor(box.height));
    c.width=Math.floor(w*ratio);c.height=Math.floor(h*ratio);
    const ctx=c.getContext('2d');ctx.setTransform(ratio,0,0,ratio,0,0);ctx.clearRect(0,0,w,h);
    const bars=(d?.bars||d?.rows||[]).slice(-60);
    if(!bars.length){ctx.fillStyle='#6d879a';ctx.font='12px sans-serif';ctx.fillText('차트 데이터 없음',20,30);return}
    const highs=bars.map(x=>nCp(x.high)).filter(x=>x!=null), lows=bars.map(x=>nCp(x.low)).filter(x=>x!=null), vols=bars.map(x=>nCp(x.volume)||0);
    const hi=Math.max(...highs),lo=Math.min(...lows),span=Math.max(1,hi-lo),maxV=Math.max(1,...vols);
    const pad={l:8,r:50,t:10,b:20},volH=Math.max(28,h*.18),priceH=h-pad.t-pad.b-volH-8;
    const y=v=>pad.t+(hi-v)/span*priceH,xStep=(w-pad.l-pad.r)/bars.length,body=Math.max(1,Math.min(7,xStep*.55));
    ctx.strokeStyle='#102a3d';ctx.lineWidth=1;
    for(let i=0;i<4;i++){const yy=pad.t+i*priceH/3;ctx.beginPath();ctx.moveTo(pad.l,yy);ctx.lineTo(w-pad.r,yy);ctx.stroke()}
    bars.forEach((b,i)=>{
      const o=nCp(b.open),cl=nCp(b.close),hh=nCp(b.high),ll=nCp(b.low);if([o,cl,hh,ll].some(v=>v==null))return;
      const xx=pad.l+xStep*(i+.5),up=cl>=o;
      ctx.strokeStyle=up?'#ff6479':'#54a8ff';ctx.fillStyle=ctx.strokeStyle;
      ctx.beginPath();ctx.moveTo(xx,y(hh));ctx.lineTo(xx,y(ll));ctx.stroke();
      const top=Math.min(y(o),y(cl)),bh=Math.max(1,Math.abs(y(o)-y(cl)));ctx.fillRect(xx-body/2,top,body,bh);
      const vh=(nCp(b.volume)||0)/maxV*volH;ctx.globalAlpha=.25;ctx.fillRect(xx-body/2,pad.t+priceH+8+volH-vh,body,vh);ctx.globalAlpha=1;
    });
    ctx.fillStyle='#678397';ctx.font='9px sans-serif';ctx.textAlign='right';
    [hi,(hi+lo)/2,lo].forEach(v=>ctx.fillText(Math.round(v).toLocaleString('ko-KR'),w-4,y(v)+3));
    const last=bars[bars.length-1],lc=nCp(last.close);
    if(lc!=null){ctx.strokeStyle='#d7b84d';ctx.setLineDash([3,3]);ctx.beginPath();ctx.moveTo(pad.l,y(lc));ctx.lineTo(w-pad.r,y(lc));ctx.stroke();ctx.setLineDash([])}
    if(Number.isFinite(CP_AVG_PRICE)&&CP_AVG_PRICE>=lo&&CP_AVG_PRICE<=hi){
      ctx.strokeStyle='#f3d36c';ctx.lineWidth=1.3;ctx.setLineDash([6,4]);ctx.beginPath();ctx.moveTo(pad.l,y(CP_AVG_PRICE));ctx.lineTo(w-pad.r,y(CP_AVG_PRICE));ctx.stroke();ctx.setLineDash([]);
    }
  }

  function renderChartPayload(frame,d){
    if(!d)return;
    CP_CHART_PAYLOAD=d;drawMiniChart(d);
    const bars=(d?.bars||d?.rows||[]),last=bars[bars.length-1]||{};
    const label=frame==='daily'?'일봉':frame+'분';
    $cp('#cpChartStatus').textContent=`${label} · ${Number(d.count||bars.length||0)}봉${d.__clientCached?' · 즉시':''}`;
    $cp('#cpChartOverlay').textContent=`${label} · 최근 ${Math.min(60,bars.length||60)}봉`;
    const q=quoteSnapshot(),intraday=bars.length?bars.slice(-Math.min(390,bars.length)):[];
    const op=nCp(q.open??q.open_price??intraday[0]?.open??last.open);
    const hi=nCp(q.high??q.high_price??(intraday.length?Math.max(...intraday.map(x=>nCp(x.high)||-Infinity)):last.high));
    const lo=nCp(q.low??q.low_price??(intraday.length?Math.min(...intraday.map(x=>nCp(x.low)||Infinity)):last.low));
    const cl=nCp(q.price??q.current_price??last.close);
    $cp('#cpOhlc').innerHTML=`<span>시 <b>${moneyCp(op)}</b></span><span>고 <b>${moneyCp(hi)}</b></span><span>저 <b>${moneyCp(lo)}</b></span><span>종 <b>${moneyCp(cl)}</b></span>`;
    renderMarketStrength();
  }
  async function fetchChartFrame(frame,token,quiet=false){
    const key=`${CP_CODE}:${frame}`,ttl=frame==='daily'?120000:30000,now=Date.now();
    const cached=CP_CHART_CACHE.get(key);
    if(cached?.data && now-cached.ts<ttl){
      const d={...cached.data,__clientCached:true};
      if(frame===CP_TF&&token===CP_TOKEN)renderChartPayload(frame,d);
      return d;
    }
    if(!quiet && frame===CP_TF)$cp('#cpChartStatus').textContent='조회 중';
    try{
      const r=await fetch(`/api/orderbook-mini-chart?code=${encodeURIComponent(CP_CODE)}&tf=${encodeURIComponent(frame)}`,{cache:'no-store'});
      const d=await r.json();if(!r.ok)throw Error(d.error||'차트 실패');if(token!==CP_TOKEN)return null;
      CP_CHART_CACHE.set(key,{ts:Date.now(),data:d});
      if(frame===CP_TF)renderChartPayload(frame,d);
      return d;
    }catch(e){
      if(!quiet&&token===CP_TOKEN&&frame===CP_TF)$cp('#cpChartStatus').textContent='차트 오류';
      return null;
    }
  }
  async function loadChart(token){return fetchChartFrame(CP_TF==='daily'?'daily':CP_TF,token,false)}
  function prefetchCockpitCharts(token){
    ['daily','1','3','15'].filter(f=>f!==CP_TF).forEach((f,i)=>setTimeout(()=>{if(token===CP_TOKEN)fetchChartFrame(f,token,true)},250+i*180));
  }

  function bookLevelsFrom(d){
    const asks=Array.isArray(d?.asks)?d.asks:[],bids=Array.isArray(d?.bids)?d.bids:[];
    return {asks:asks.slice(0,5).reverse(),bids:bids.slice(0,5)};
  }
  function levelRow(x,side){
    const p=nCp(x?.price??x?.ask_price??x?.bid_price),q=nCp(x?.qty??x?.quantity??x?.ask_qty??x?.bid_qty);
    return `<div class="cp-level ${side}"><span class="side">${side==='ask'?'매도':'매수'}</span><span class="p">${p==null?'-':moneyCp(p)}</span><span class="q">${q==null?'-':moneyCp(q)}</span></div>`;
  }
  function renderBook(d){
    const {asks,bids}=bookLevelsFrom(d);
    const cur=nCp(d?.current_price??d?.price);
    const askTotal=nCp(d?.ask_total??d?.total_ask_qty),bidTotal=nCp(d?.bid_total??d?.total_bid_qty);
    const strength=nCp(d?.execution_strength??d?.strength);
    $cp('#cpBook').innerHTML=`<div class="cp-book-top"><div class="cp-chip"><span>매도총잔량</span><b>${moneyCp(askTotal)}</b></div><div class="cp-chip"><span>체결강도</span><b>${strength==null?'-':strength.toFixed(1)}</b></div><div class="cp-chip"><span>매수총잔량</span><b>${moneyCp(bidTotal)}</b></div></div><div class="cp-levels">${asks.map(x=>levelRow(x,'ask')).join('')}${bids.map(x=>levelRow(x,'bid')).join('')}</div><div class="cp-current">현재가 <b>${cur==null?'-':moneyCp(cur)+'원'}</b></div>`;
  }
  async function loadBook(token){
    try{
      const r=await fetch(`/api/orderbook?code=${encodeURIComponent(CP_CODE)}`,{cache:'no-store'}),d=await r.json();
      if(!r.ok)throw Error(d.error||'호가 실패');if(token!==CP_TOKEN)return;CP_BOOK_SNAPSHOT=d;renderBook(d);renderMarketStrength();
    }catch(e){if(token===CP_TOKEN)$cp('#cpBook').innerHTML=`<div class="cp-empty">${escCp(e.message)}</div>`}
  }

  function flowVal(x){const n=nCp(x);return n==null?'-':eokCp(n)}
  async function loadFlow(token){
    try{
      const flowPromise=fetch(`/api/investor-flow?code=${encodeURIComponent(CP_CODE)}`,{cache:'no-store'})
        .then(async r=>{const d=await r.json();if(!r.ok)throw Error(d.error||'수급 실패');return d});
      const programPromise=fetch(`/api/program-flow-watch?codes=${encodeURIComponent(CP_CODE)}`,{cache:'no-store'})
        .then(async r=>{const d=await r.json();if(!r.ok)throw Error(d.error||'프로그램 수급 실패');return d})
        .catch(()=>null);

      const [d,pd]=await Promise.all([flowPromise,programPromise]);
      if(token!==CP_TOKEN)return;
      CP_FLOW_SNAPSHOT=d;

      const t=d.today||{},f=d.ten_day||d.five_day||{};
      const main=[['외국인',t.frgnr_invsr,f.frgnr_invsr],['기관계',t.orgn,f.orgn],['개인',t.ind_invsr,f.ind_invsr]];
      const inst=[['금융투자',t.fnnc_invt],['투신',t.invtrt],['연기금',t.penfnd_etc],['사모',t.samo_fund],['보험',t.insrnc]];

      let pg=null;
      if(pd){
        pg=pd?.rows?.[String(CP_CODE).replace(/\D/g,'')]||pd?.rows?.[CP_CODE]||null;
      }
      CP_PROGRAM_SNAPSHOT=pg;

      const programHtml=pg?`<div class="cp-flow-row"><span>프로그램</span><b class="${toneCp(pg.program_net_eok)}">${flowVal(pg.program_net_eok)}</b><b>${escCp(pg.market||'')}</b></div>`:'<div class="cp-flow-row"><span>프로그램</span><b>-</b><b>-</b></div>';
      $cp('#cpFlow').innerHTML=`<div class="cp-flow-grid">${main.map(([n,a,b])=>`<div class="cp-flow-box"><span>${n} · 오늘</span><b class="${toneCp(a)}">${flowVal(a)}</b><span>10일 ${flowVal(b)}</span></div>`).join('')}</div>${programHtml}${inst.map(([n,v])=>`<div class="cp-flow-row"><span>${n}</span><b class="${toneCp(v)}">${flowVal(v)}</b><b>${v==null?'-':'오늘'}</b></div>`).join('')}<div class="cp-flow-note">${escCp(d.source||'키움 투자자별 수급')} · 금액 기준</div>`;
      renderMarketStrength();
    }catch(e){
      if(token===CP_TOKEN)$cp('#cpFlow').innerHTML=`<div class="cp-empty">${escCp(e.message)}</div>`;
    }
  }

  function renderMarketStrength(){
    const host=$cp('#cpMarketStrength');if(!host)return;
    const q=quoteSnapshot(),book=CP_BOOK_SNAPSHOT||{},flow=CP_FLOW_SNAPSHOT||{},pg=CP_PROGRAM_SNAPSHOT||{};
    const today=flow.today||{};
    const ask=nCp(book.ask_total??book.total_ask_qty),bid=nCp(book.bid_total??book.total_bid_qty);
    const imbalance=(ask!=null&&bid!=null&&ask+bid>0)?(bid/(ask+bid))*100:null;
    const net=nCp(pg.program_net_eok),buy=nCp(pg.program_buy_eok),sell=nCp(pg.program_sell_eok),tradeRatio=nCp(pg.program_trade_ratio);
    const value=nCp(q.value_eok??q.trading_value_eok),programShare=(net!=null&&value&&value>0)?net/value*100:null;
    const cur=nCp(q.price??q.current_price??q.close),hi=nCp(q.high??q.high_price),lo=nCp(q.low??q.low_price);
    const dayPos=(cur!=null&&hi!=null&&lo!=null&&hi>lo)?((cur-lo)/(hi-lo))*100:null;
    const power=nCp(book.execution_strength??book.strength??q.power??q.execution_strength);
    let vwap=null;
    const one=CP_CHART_CACHE.get(`${CP_CODE}:1`)?.data, bars=(one?.bars||one?.rows||[]);
    if(bars.length){
      let pv=0,v=0;for(const b of bars.slice(-120)){const p=nCp(b.close),vol=nCp(b.volume);if(p!=null&&vol>0){pv+=p*vol;v+=vol}}
      if(v>0)vwap=pv/v;
    }
    const vwapGap=(cur!=null&&vwap)?(cur/vwap-1)*100:null;
    const main=[
      ['프로그램 순매수',net==null?'-':eokCp(net),net],
      ['프로그램 매수',buy==null?'-':eokCp(buy),buy],
      ['프로그램 매도',sell==null?'-':eokCp(sell),sell],
      ['외국인 오늘',flowVal(today.frgnr_invsr),nCp(today.frgnr_invsr)],
      ['기관 오늘',flowVal(today.orgn),nCp(today.orgn)],
      ['체결강도',power==null?'-':power.toFixed(1),power!=null?power-100:null]
    ];
    const detail=[
      ['프로그램 거래비중',tradeRatio==null?'-':pctCp(tradeRatio)],
      ['거래대금 대비 프로그램',programShare==null?'-':`<span class="${toneCp(programShare)}">${pctCp(programShare)}</span>`],
      ['매수잔량 비중',imbalance==null?'-':`${imbalance.toFixed(1)}%`],
      ['당일 고저 위치',dayPos==null?'-':`${dayPos.toFixed(1)}%`],
      ['1분봉 VWAP(근사)',vwap==null?'-':`${moneyCp(vwap)}원`],
      ['VWAP 대비',vwapGap==null?'-':pctCp(vwapGap)]
    ];
    host.innerHTML=`<div class="cp-market-main">${main.map(([a,b,v])=>`<div class="cp-market-box"><span>${a}</span><b class="${v!=null?toneCp(v):''}">${b}</b></div>`).join('')}</div><div class="cp-market-detail">${detail.map(([a,b])=>`<div class="cp-market-row"><span>${a}</span><b>${b}</b></div>`).join('')}</div>`;
    const st=$cp('#cpMarketStatus');if(st)st.textContent=`${pg.market||'-'} · 프로그램/호가/수급 종합`;
  }

  async function loadNews(token){
    try{
      const r=await fetch(`/api/news?code=${encodeURIComponent(CP_CODE)}&name=${encodeURIComponent(CP_NAME)}`,{cache:'no-store'}),d=await r.json();
      if(!r.ok)throw Error(d.error||'뉴스 실패');if(token!==CP_TOKEN)return;
      const rows=(d.rows||[]).slice(0,6);
      $cp('#cpNews').innerHTML=rows.map(x=>`<a href="${escCp(x.url||'#')}" target="_blank" rel="noopener noreferrer"><b>${escCp(x.title||'')}</b><small>${escCp(x.publisher||'')} · ${escCp(x.time||'')}</small></a>`).join('')||'<div class="cp-empty">관련 뉴스 없음</div>';
    }catch(e){if(token===CP_TOKEN)$cp('#cpNews').innerHTML=`<div class="cp-empty">${escCp(e.message)}</div>`}
  }

  
  function warmStartCockpit(){
    renderTop();
    try{
      const code=String(CP_CODE).replace(/\D/g,'');
      const q=quoteSnapshot();
      if(q && Object.keys(q).length) renderSignals(q);
      const key1=`${CP_CODE}:1`;
      const c=CP_CHART_CACHE.get(key1);
      if(c?.data && CP_TF==='1'){
        const d={...c.data,__clientCached:true};
        renderChartPayload('1',d);
      }
    }catch(_e){}
  }

async function refreshCockpitFast(){
    if(!CP_CODE)return;const token=CP_TOKEN;renderTop();await loadBook(token);if(token===CP_TOKEN)$cp('#cpUpdated').textContent=`FAST ${new Date().toLocaleTimeString('ko-KR')}`;
  }
  async function refreshCockpitSlow(force=false){
    if(!CP_CODE)return;const token=CP_TOKEN;
    await Promise.allSettled([loadChart(token),loadFlow(token),loadNews(token)]);
    if(token===CP_TOKEN)$cp('#cpUpdated').textContent=`갱신 ${new Date().toLocaleTimeString('ko-KR')} · 호가 3초 / 수급·뉴스 12초`;
  }
  async function refreshCockpitAll(force=false){renderTop();await Promise.allSettled([refreshCockpitFast(),refreshCockpitSlow(force)])}

  function stopTimers(){
    if(CP_FAST_TIMER){clearInterval(CP_FAST_TIMER);CP_FAST_TIMER=null}
    if(CP_SLOW_TIMER){clearInterval(CP_SLOW_TIMER);CP_SLOW_TIMER=null}
  }
  function closeTradingCockpit(){
    stopTimers();CP_TOKEN++;const m=document.getElementById('littoCockpitModal');if(m)m.classList.remove('open');
  }

  window.openTradingCockpit=async function(code,name){
    const m=ensureCockpit();stopTimers();CP_TOKEN++;CP_TF='1';CP_CHART_PAYLOAD=null;CP_AVG_PRICE=null;CP_BOOK_SNAPSHOT=null;CP_FLOW_SNAPSHOT=null;CP_PROGRAM_SNAPSHOT=null;CP_CODE=String(code||'').trim();CP_NAME=String(name||code||'').trim();m.querySelectorAll('[data-cp-tf]').forEach(x=>x.classList.toggle('active',x.dataset.cpTf==='1'));
    $cp('#cpName').childNodes[0].nodeValue=CP_NAME+' ';$cp('#cpCode').textContent=CP_CODE;m.classList.add('open');
    $cp('#cpBook').innerHTML='<div class="cp-empty">호가 조회 중</div>';$cp('#cpFlow').innerHTML='<div class="cp-empty">수급 조회 중</div>';$cp('#cpMarketStrength').innerHTML='<div class="cp-empty">시장강도 계산 중</div>';$cp('#cpNews').innerHTML='<div class="cp-empty">뉴스 조회 중</div>';
    warmStartCockpit();await refreshCockpitAll(true);prefetchCockpitCharts(CP_TOKEN);
    CP_FAST_TIMER=setInterval(()=>{if(m.classList.contains('open'))refreshCockpitFast()},3000);
    CP_SLOW_TIMER=setInterval(()=>{if(m.classList.contains('open'))refreshCockpitSlow(false)},12000);
  };

  // Add one more card to the existing stock-action popup without changing existing cards.
  const originalEnsure=window.ensureStockActionModal;
  if(typeof originalEnsure==='function'){
    window.ensureStockActionModal=function(){
      const m=originalEnsure.apply(this,arguments);
      const grid=m?.querySelector('.stock-action-buttons');
      if(grid&&!m.querySelector('#stockActionCockpit')){
        const b=document.createElement('button');b.id='stockActionCockpit';b.type='button';
        b.innerHTML='<b>🎛 매매 콕핏</b><span>차트 · 호가 · 수급 · 계좌 · 신호 · 뉴스를 한 화면에</span>';
        grid.insertBefore(b,grid.firstChild);
      }
      return m;
    };
  }

  const originalOpen=window.openStockAction;
  if(typeof originalOpen==='function'){
    window.openStockAction=function(code,name){
      originalOpen.apply(this,arguments);
      const m=document.getElementById('stockActionModal'),b=document.getElementById('stockActionCockpit');
      if(b)b.onclick=()=>{if(m)m.hidden=true;window.openTradingCockpit(code,name)};
    };
  }
})();
