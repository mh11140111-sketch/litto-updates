from __future__ import annotations

import os
import sys
import time
import socket
import subprocess
import urllib.request
from pathlib import Path

PORT = 8874
HOST = "127.0.0.1"
URL = f"http://{HOST}:{PORT}/"
BASE = Path(__file__).resolve().parent
LOG = BASE / "LITTO_DESKTOP.log"


def port_open(host: str, port: int) -> bool:
    try:
        with socket.create_connection((host, port), timeout=0.35):
            return True
    except OSError:
        return False


def http_ready(url: str) -> bool:
    try:
        with urllib.request.urlopen(url, timeout=0.8) as r:
            return 200 <= getattr(r, "status", 200) < 500
    except Exception:
        return False


def show_error(message: str) -> None:
    try:
        import tkinter as tk
        from tkinter import messagebox
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror("LITTO Trading System v1.24.0", message)
        root.destroy()
    except Exception:
        pass


def start_backend():
    app_py = BASE / "app.py"
    if not app_py.exists():
        raise FileNotFoundError(
            "같은 폴더에 app.py가 없습니다.\n\n"
            "LITTO_DESKTOP.pyw와 START_LITTO.cmd를 기존 LITTO 폴더 최상단에 넣어주세요."
        )

    # 기존 LITTO 서버가 이미 실행 중이면 그대로 사용한다.
    if http_ready(URL):
        return None, False

    if port_open(HOST, PORT):
        raise RuntimeError(f"{PORT} 포트를 다른 프로그램이 사용 중입니다.")

    flags = getattr(subprocess, "CREATE_NO_WINDOW", 0) if os.name == "nt" else 0
    log_fp = open(LOG, "a", encoding="utf-8", buffering=1)
    log_fp.write(f"\n[{time.strftime('%Y-%m-%d %H:%M:%S')}] LITTO desktop backend start\n")

    proc = subprocess.Popen(
        [sys.executable, str(app_py), "--port", str(PORT), "--no-browser"],
        cwd=str(BASE),
        stdout=log_fp,
        stderr=subprocess.STDOUT,
        creationflags=flags,
    )

    deadline = time.time() + 30
    while time.time() < deadline:
        if proc.poll() is not None:
            log_fp.flush()
            raise RuntimeError(
                "LITTO 서버가 시작 중 종료되었습니다.\n"
                "LITTO_DESKTOP.log 파일을 확인해주세요."
            )
        if http_ready(URL):
            return (proc, log_fp), True
        time.sleep(0.25)

    try:
        proc.terminate()
    except Exception:
        pass
    raise TimeoutError(
        "LITTO 서버 시작 시간이 초과되었습니다.\n"
        "LITTO_DESKTOP.log 파일을 확인해주세요."
    )


def stop_backend(handle) -> None:
    if not handle:
        return
    proc, log_fp = handle
    try:
        proc.terminate()
        proc.wait(timeout=5)
    except Exception:
        try:
            proc.kill()
        except Exception:
            pass
    try:
        log_fp.close()
    except Exception:
        pass


def main() -> int:
    try:
        import webview
    except Exception:
        show_error(
            "데스크톱 창 모듈(pywebview)이 설치되지 않았습니다.\n\n"
            "START_LITTO.cmd를 한 번 실행해주세요."
        )
        return 2

    backend = None
    started_by_us = False
    try:
        backend, started_by_us = start_backend()
        window = webview.create_window(
            "LITTO Trading System v1.24.0",
            URL,
            width=1600,
            height=960,
            min_size=(1100, 700),
            resizable=True,
            fullscreen=False,
            text_select=True,
            confirm_close=False,
        )
        # Windows 10/11의 Edge WebView2 엔진 사용
        def start_maximized():
            try:
                window.maximize()
            except Exception:
                pass

        webview.start(start_maximized, gui="edgechromium", debug=False, private_mode=False)
        return 0
    except Exception as e:
        show_error(str(e))
        return 1
    finally:
        if started_by_us:
            stop_backend(backend)


if __name__ == "__main__":
    raise SystemExit(main())
