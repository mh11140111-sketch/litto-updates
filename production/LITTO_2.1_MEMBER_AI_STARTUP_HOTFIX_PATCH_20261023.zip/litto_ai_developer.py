"""Constrained, opt-in source patch proposals for the local LITTO AI chat.

Never execute AI-provided commands, never modify the running application during
proposal, and never touch account/credential/database/trading-history files.
"""
import difflib
import hashlib
import json
import os
from pathlib import Path
import py_compile
import shutil
import subprocess
import tempfile
import threading
import time
import uuid

_LOCK = threading.RLock()
_ALLOWED = {"app.py", "web/app.js", "app.js", "web/style.css", "style.css", "web/index.html", "index.html", "search_panels.py", "ai_brain.py", "ai_evolve.py", "speed_runtime.py", "kiwoom.py", "engine.py", "pattern_engine.py", "screener_history.py"}
_BLOCKED_TOKENS = ("password", "secret", "token", "credential", "private_key", "apikey", "api_key")
_MAX_SOURCE = 1_500_000


def _root(root):
    return Path(root).resolve()


def _source(root, name):
    name = str(name).replace('\\', '/')
    if name not in _ALLOWED:
        raise ValueError('이 파일은 AI 개발 도구의 수정 허용 목록에 없어.')
    path = (_root(root) / name).resolve()
    if not path.is_file() or not path.is_relative_to(_root(root)) or path.is_symlink():
        raise ValueError('수정 가능한 원본 소스가 아니야.')
    if any(t in path.name.lower() for t in _BLOCKED_TOKENS):
        raise ValueError('민감 정보 파일 수정은 금지돼 있어.')
    if path.stat().st_size > _MAX_SOURCE:
        raise ValueError('파일 크기 제한을 초과했어.')
    return path


def _sha(data):
    return hashlib.sha256(data).hexdigest()


def _store(root):
    d = _root(root) / 'data' / 'ai_dev_proposals'
    d.mkdir(parents=True, exist_ok=True)
    return d


def inspect(root, filename, needle='', line=1):
    src = _source(root, filename)
    content = src.read_text('utf-8')
    lines = content.splitlines()
    if needle:
        hits = [i+1 for i,s in enumerate(lines) if str(needle).lower() in s.lower()][:25]
        if not hits:
            return {'file': filename, 'total_lines':len(lines), 'matches':[], 'message':'일치하는 내용을 찾지 못했어.'}
        line = hits[0]
    else:
        hits = []
    line = max(1, min(len(lines) or 1, int(line)))
    lo,hi=max(1,line-18),min(len(lines),line+50)
    return {'file':filename,'sha256':_sha(src.read_bytes()),'total_lines':len(lines), 'matches':hits, 'shown_lines':[f'{i}: {lines[i-1]}' for i in range(lo,hi+1)],'truncated':len(lines)>hi}


def _syntax(filename, data, dest):
    if filename.endswith('.py'):
        try:
            compile(data, str(dest), 'exec')
            return {'check':'python_compile','ok':True}
        except SyntaxError as e:
            return {'check':'python_compile','ok':False,'error':f'{e.msg} line {e.lineno}'}
    if filename.endswith('.js'):
        exe = shutil.which('node')
        if exe:
            with tempfile.TemporaryDirectory() as t:
                js = Path(t) / 'patch.js'
                js.write_text(data,'utf-8')
                p = subprocess.run([exe,'--check',str(js)],capture_output=True,text=True,timeout=15)
                return {'check':'node --check','ok':p.returncode==0,'error':(p.stderr or '')[:500]}
        return {'check':'javascript_syntax','ok':None,'note':'Node.js가 없어 검사하지 못했어.'}
    return {'check':'text_only','ok':None,'note':'형식상 검사만 가능해.'}


def propose(root, filename, find, replace, reason):
    if not isinstance(find,str) or not isinstance(replace,str) or not find or len(find)>12000 or len(replace)>12000:
        raise ValueError('수정 전후 문자열은 각각 12,000자 이하의 비어 있지 않은 값이어야 해.')
    path = _source(root, filename)
    with _LOCK:
        before = path.read_text('utf-8')
        if before.count(find) != 1:
            raise ValueError('수정 대상 문자열은 원본 소스에서 정확히 한 번만 일치해야 해. 주변 코드를 더 구체적으로 지정해.')
        after = before.replace(find, replace, 1)
        if after == before:
            raise ValueError('변경 내용이 없어.')
        checks = [_syntax(filename, after, path)]
        # Failed/unknown validation is reported honestly; only definite syntax failure prevents staging.
        if any(c['ok'] is False for c in checks):
            return {'ok':False,'staged':False,'checks':checks,'message':'문법 검사 실패로 수정안이 저장되지 않았어.'}
        pid = uuid.uuid4().hex[:12]
        diff = ''.join(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='before/'+filename,tofile='after/'+filename))
        info = {'id':pid,'file':filename,'reason':str(reason)[:500],'created_at':int(time.time()),'original_sha256':_sha(before.encode('utf-8')),'proposed_sha256':_sha(after.encode('utf-8')),'checks':checks,'diff':diff[:16000],'status':'pending'}
        store = _store(root) / pid
        store.mkdir(mode=0o700)
        (store/'proposal.json').write_text(json.dumps(info,ensure_ascii=False,indent=2),'utf-8')
        (store/'replacement.txt').write_bytes(after.encode('utf-8'))  # No Windows newline conversion
        return {'ok':True,'staged':True,'id':pid,'file':filename,'checks':checks,'diff':diff[:6000],'note':'원본은 변경하지 않았어. 명시적으로 승인해야 적용할 수 있어. 자동 실행/실거래 테스트는 수행하지 않았어.'}


def pending(root, pid):
    pid=str(pid)
    if len(pid)!=12 or any(c not in '0123456789abcdef' for c in pid):
        raise ValueError('잘못된 수정안 ID')
    meta=_store(root)/pid/'proposal.json'
    if not meta.is_file(): raise ValueError('수정안을 찾을 수 없어.')
    return json.loads(meta.read_text('utf-8'))


def recent(root, limit=8):
    """Metadata for proposals displayed in the local AI chat approval panel."""
    entries=[]
    for d in _store(root).iterdir():
        if not d.is_dir():continue
        try:
            info=pending(root,d.name)
            entries.append({k:info.get(k) for k in ('id','file','reason','created_at','status','checks','diff')})
        except (ValueError,OSError,KeyError,json.JSONDecodeError):continue
    entries.sort(key=lambda x:x.get('created_at') or 0,reverse=True)
    return {'items':entries[:max(1,min(20,int(limit)))]}



def discard(root, pid):
    """Delete only an unapplied proposal. Never touch application source or backups."""
    with _LOCK:
        info = pending(root, pid)  # validates 12-character hex ID and metadata
        if info.get('status') != 'pending':
            raise ValueError('대기 중인 수정안만 삭제할 수 있어.')
        directory = _store(root) / pid
        if directory.is_symlink() or not directory.is_dir():
            raise ValueError('안전하지 않은 수정안 폴더야.')
        for item in directory.iterdir():
            if item.is_symlink() or not item.is_file() or item.name not in ('proposal.json', 'replacement.txt'):
                raise ValueError('예상하지 못한 파일이 있어 삭제를 중단했어.')
        # No source file is opened for writing; only proposal artifacts are discarded.
        for name in ('replacement.txt', 'proposal.json'):
            f = directory / name
            if f.exists(): f.unlink()
        directory.rmdir()
        return {'ok': True, 'discarded': pid, 'note': '대기 수정안만 삭제했어. 원본 소스와 적용 기록은 변경하지 않았어.'}


def _checked_replacement(root, pid, expected_hash):
    """Verify staged bytes; accept only legacy Windows CRLF translation when hash agrees."""
    raw = (_store(root) / pid / 'replacement.txt').read_bytes()
    if _sha(raw) == expected_hash:
        return raw
    if b'\r\n' in raw:
        normalized = raw.replace(b'\r\n', b'\n')
        if _sha(normalized) == expected_hash:
            return normalized
    raise ValueError('수정안 무결성 검증 실패: 수정안 파일 해시가 일치하지 않아.')


def schedule_apply(root, pid):
    """Stage a checked source update for the next backend startup; never mutate running code."""
    with _LOCK:
        info = pending(root, pid)
        if info.get('status') != 'pending':
            raise ValueError('승인 대기 상태가 아니야.')
        source = _source(root, info['file'])
        if _sha(source.read_bytes()) != info['original_sha256']:
            raise ValueError('원본이 변경됐어. 수정안을 다시 생성해야 해.')
        replacement = _checked_replacement(root, pid, info['proposed_sha256'])
        check = _syntax(info['file'], replacement.decode('utf-8'), source)
        if check.get('ok') is not True:
            raise ValueError('문법 검사 미통과: 예약할 수 없어.')
        queue = _store(root) / 'approved_next_start.json'
        if queue.exists():
            raise ValueError('이미 다음 실행 적용 예약이 있어. 먼저 해당 예약을 처리해.')
        payload = {'id': pid, 'file': info['file'], 'sha256': info['original_sha256'], 'created_at': int(time.time())}
        with tempfile.NamedTemporaryFile(mode='w',dir=queue.parent,prefix='.approval_',delete=False,encoding='utf-8') as f:
            json.dump(payload,f,ensure_ascii=False); temp=Path(f.name)
        os.replace(temp,queue)
        info['status']='scheduled'
        (_store(root)/pid/'proposal.json').write_text(json.dumps(info,ensure_ascii=False,indent=2),'utf-8')
        return {'ok':True,'scheduled':True,'id':pid,'restart_required':True,'note':'승인 예약 완료. 다음 라이또 실행 시 서버 시작 전에 자동 적용해.'}


def apply_scheduled_at_startup(root):
    """Use at process startup only. Report failures without starting trading code with unknown edits."""
    queue = _store(root) / 'approved_next_start.json'
    if not queue.is_file():return {'ok':True,'scheduled':False}
    with _LOCK:
        payload=json.loads(queue.read_text('utf-8'))
        pid=payload['id'];info=pending(root,pid)
        if info.get('status')!='scheduled' or info['file']!=payload['file'] or info['original_sha256']!=payload['sha256']:
            raise ValueError('예약 내용이 수정안과 일치하지 않아. 자동 적용 중단.')
        info['status']='pending'
        (_store(root)/pid/'proposal.json').write_text(json.dumps(info,ensure_ascii=False,indent=2),'utf-8')
        try:
            result=apply(root,pid)
        except Exception:
            info['status']='scheduled'
            (_store(root)/pid/'proposal.json').write_text(json.dumps(info,ensure_ascii=False,indent=2),'utf-8')
            raise
        queue.unlink()
        return result


def apply(root, pid):
    """Explicitly approved apply only. The caller must enforce human confirmation."""
    with _LOCK:
        info=pending(root,pid)
        if info['status']!='pending':raise ValueError('승인 대기 중인 수정안이 아니야.')
        path=_source(root,info['file'])
        original=path.read_bytes()
        if _sha(original)!=info['original_sha256']:
            raise ValueError('원본 파일이 수정안 작성 뒤 변경됐어. 안전을 위해 적용을 중단했어.')
        replacement=_checked_replacement(root,pid,info['proposed_sha256'])
        check=_syntax(info['file'],replacement.decode('utf-8'),path)
        if check['ok'] is False:raise ValueError('적용 직전 문법 검사 실패')
        backups=_root(root)/'data'/'ai_dev_backups'
        backups.mkdir(parents=True,exist_ok=True)
        backup=backups/(pid+'_'+path.name+'.bak')
        backup.write_bytes(original)
        try:
            with tempfile.NamedTemporaryFile(mode='wb',dir=path.parent,prefix='.litto_dev_',delete=False) as f:
                f.write(replacement)
                tmp=Path(f.name)
            os.replace(tmp,path)
        except Exception:
            if 'tmp' in locals() and tmp.exists():tmp.unlink()
            raise
        info['status']='applied';info['backup']=str(backup.relative_to(_root(root)));info['applied_at']=int(time.time())
        (_store(root)/pid/'proposal.json').write_text(json.dumps(info,ensure_ascii=False,indent=2),'utf-8')
        return {'ok':True,'applied':info['file'],'backup':info['backup'],'restart_required':True,'note':'파일 교체가 완료됐어. 실행 중인 Python 모듈에는 재시작 후 반영돼. Windows 실전 테스트는 아직 필요해.'}


def rollback(root,pid):
    with _LOCK:
        info=pending(root,pid)
        if info['status']!='applied' or not info.get('backup'):raise ValueError('복원 가능한 적용 기록이 없어.')
        src=_source(root,info['file']);backup=(_root(root)/info['backup']).resolve()
        if not backup.is_relative_to(_root(root)/'data'/'ai_dev_backups') or not backup.is_file(): raise ValueError('백업이 없어.')
        if _sha(src.read_bytes())!=info['proposed_sha256']:
            raise ValueError('적용 뒤 소스가 달라졌어. 자동 복원을 중단했어.')
        os.replace(backup,src)
        info['status']='rolled_back';(_store(root)/pid/'proposal.json').write_text(json.dumps(info,ensure_ascii=False,indent=2),'utf-8')
        return {'ok':True,'rolled_back':info['file'],'restart_required':True}


def is_hot_safe(root,pid,operation):
    import litto_ai_live_patch
    try:
        info=pending(root,pid)
        if info.get('file') != 'app.py': return False
        if operation=='apply':
            if info.get('status')!='pending': return False
            before=_source(root,'app.py').read_bytes()
            after=(_store(root)/pid/'replacement.txt').read_bytes()
            return _sha(before)==info['original_sha256'] and litto_ai_live_patch.eligible('app.py', before,after)
        if operation=='rollback':
            if info.get('status')!='applied':return False
            old=(_root(root)/info['backup']).read_bytes()
            new=_source(root,'app.py').read_bytes()
            return litto_ai_live_patch.eligible('app.py',new,old)
    except Exception:return False
    return False


def current_hot_source(root,pid,operation):
    info=pending(root,pid)
    return _source(root, info['file']).read_bytes()


def reapply_after_failed_rollback(root,pid):
    # Restore the just-rolled-back file to its pre-rollback version.
    with _LOCK:
        info=pending(root,pid)
        if info.get('status')!='rolled_back': raise ValueError('복원 상태 불일치')
        file=_source(root,info['file'])
        replacement=(_store(root)/pid/'replacement.txt').read_bytes()
        if _sha(replacement)!=info['proposed_sha256']:raise ValueError('패치 불일치')
        with tempfile.NamedTemporaryFile(mode='wb',dir=file.parent,prefix='.litto_dev_',delete=False) as f:
            f.write(replacement)
            tmp=Path(f.name)
        os.replace(tmp,file)
        info['status']='applied'
        (_store(root)/pid/'proposal.json').write_text(json.dumps(info,ensure_ascii=False,indent=2),'utf-8')
