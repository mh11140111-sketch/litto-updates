"""Local, user-managed PDF reference library; never used from market data loops."""
import base64, hashlib, io, json, re, threading, time, uuid, os, shutil
from pathlib import Path

# PDF-only on-demand dependency setup. Does not run in quotation, scanner or chart loops.
_SETUP_LOCK = threading.Lock()
_SETUP_FAILURES = {}

def _pdf_dependency(import_name, pip_name):
    import importlib, subprocess, sys
    try:
        return importlib.import_module(import_name)
    except ImportError:
        pass
    with _SETUP_LOCK:
        try:
            return importlib.import_module(import_name)
        except ImportError:
            pass
        if pip_name in _SETUP_FAILURES:
            raise RuntimeError(_SETUP_FAILURES[pip_name])
        try:
            completed = subprocess.run(
                [sys.executable, '-m', 'pip', 'install', '--disable-pip-version-check',
                 '--only-binary=:all:', pip_name],
                stdout=subprocess.PIPE, stderr=subprocess.STDOUT,
                timeout=120, check=False, text=True, encoding='utf-8', errors='replace',
                creationflags=getattr(subprocess, 'CREATE_NO_WINDOW', 0),
            )
            if completed.returncode:
                raise RuntimeError((completed.stdout or '').strip()[-350:])
            importlib.invalidate_caches()
            return importlib.import_module(import_name)
        except Exception as exc:
            message = (
                f'PDF 지원 모듈({pip_name}) 자동 설치 실패: {str(exc)[:350]}. '
                '인터넷 연결과 라이또 실행 Python의 설치 권한을 확인해 줘.'
            )
            _SETUP_FAILURES[pip_name] = message
            raise RuntimeError(message) from exc

LOCK = threading.RLock()
ROOT = None
DRIVE_FOLDER = None
CONFIG_FILE = None
_SYNC = {"running":False,"done":0,"total":0,"error":"","note":""}

def init(root):
    global ROOT
    global DRIVE_FOLDER, CONFIG_FILE
    CONFIG_FILE = Path(os.environ.get('LOCALAPPDATA') or (Path.home()/'.litto'))/'LITTO'/'ai_drive_folder.txt'
    ROOT = Path(root) / 'data' / 'ai_pdf_library'
    ROOT.mkdir(parents=True, exist_ok=True)
    if CONFIG_FILE.exists():
        try:
            _activate_drive(CONFIG_FILE.read_text(encoding='utf-8').strip())
        except Exception as e:
            _SYNC['error'] = '구글 드라이브 경로를 찾지 못했어: '+str(e)[:120]


def _manifest():
    try:
        data=json.loads((ROOT/'index.json').read_text(encoding='utf-8'))
        return data if isinstance(data,list) else []
    except (OSError,ValueError):return []

def _save(rows):
    tmp=ROOT/'index.json.tmp'
    tmp.write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
    tmp.replace(ROOT/'index.json')

def listing():
    with LOCK:
        return {'ok':True,'items':_manifest(), 'drive_folder':str(DRIVE_FOLDER or ''), 'sync':dict(_SYNC)}

def add(name,content_b64):
    name=Path(str(name or '')).name[:120]
    if not name.lower().endswith('.pdf'):raise ValueError('PDF 파일만 등록할 수 있어.')
    if not isinstance(content_b64,str) or len(content_b64)>21_000_000:raise ValueError('PDF는 15MB 이하만 등록할 수 있어.')
    try:raw=base64.b64decode(content_b64,validate=True)
    except Exception:raise ValueError('파일 데이터 형식이 올바르지 않아.')
    if not raw.startswith(b'%PDF-') or len(raw)>15_000_000:raise ValueError('유효한 15MB 이하 PDF가 필요해.')
    try:
        PdfReader = _pdf_dependency('pypdf', 'pypdf').PdfReader
        reader=PdfReader(io.BytesIO(raw),strict=False)
        if reader.is_encrypted:raise ValueError('암호화된 PDF는 먼저 암호를 해제해야 해.')
        if len(reader.pages)>500:raise ValueError('500쪽 이하 PDF만 지원해.')
        pages=[]
        for i,page in enumerate(reader.pages):
            text=page.extract_text() or ''
            text=re.sub(r'\s+',' ',text).strip()
            if text:pages.append({'page':i+1,'text':text[:25000]})
    except ValueError:raise
    except Exception as exc:raise ValueError('PDF 글자를 읽지 못했어: '+str(exc)[:500])
    # Image-only pages are stored as original PDF and visualized on AI request.
    # Do not reject scans just because extract_text() returns nothing.

    docid=uuid.uuid4().hex
    item={'id':docid,'name':name,'pages':len(reader.pages),'text_pages':len(pages),'image_pages':len(reader.pages)-len(pages),'added_at':time.strftime('%Y-%m-%d %H:%M:%S'),'sha256':hashlib.sha256(raw).hexdigest()}
    with LOCK:
        rows=_manifest()
        if any(x.get('sha256')==item['sha256'] for x in rows):raise ValueError('이미 등록된 동일한 PDF야.')
        pdf_path=ROOT/(docid+'.pdf');text_path=ROOT/(docid+'.json')
        pdf_path.write_bytes(raw)
        try:
            text_path.write_text(json.dumps(pages,ensure_ascii=False),encoding='utf-8')
            rows.append(item);_save(rows)
        except Exception:
            pdf_path.unlink(missing_ok=True);text_path.unlink(missing_ok=True)
            raise
    return {'ok':True,'item':item}

def remove(docid):
    if not re.fullmatch('[0-9a-f]{32}',str(docid or '')):raise ValueError('자료 번호 오류')
    with LOCK:
        rows=_manifest()
        if not any(x.get('id')==docid for x in rows):raise ValueError('등록된 자료가 아니야.')
        _save([x for x in rows if x.get('id')!=docid])
        item=next((x for x in rows if x.get('id')==docid),{})
        if item.get('source')!='drive':
            (ROOT/(docid+'.pdf')).unlink(missing_ok=True)
        (ROOT/(docid+'.json')).unlink(missing_ok=True)
    return {'ok':True}

def audit():
    """Local metadata and extracted text availability. Does not parse PDFs or fetch from providers."""
    with LOCK:
        rows=_manifest()
        root=ROOT
    items=[]
    for row in rows:
        try:
            raw=json.loads((root/(str(row['id'])+'.json')).read_text(encoding='utf-8'))
            extracted=sum(1 for p in raw if str(p.get('text') or '').strip())
            state='ready' if extracted else 'image_only'
        except Exception:
            extracted=0;state='index_missing'
        items.append({'name':row.get('name',''), 'pages':int(row.get('pages') or 0),
                      'extracted_pages':extracted, 'state':state})
    return {'ok':True,'count':len(items),'items':items,
            'note':'ready means searchable text, not complete semantic understanding; image_only requires visual inspection.'}


def ai_documents():
    """List searchable documents without exposing local paths or raw indexes."""
    with LOCK:
        rows=list(_manifest()); root=ROOT
    docs=[]; seen=set()
    for row in rows:
        name=str(row.get('name') or '')
        signature=str(row.get('sha256') or '') or name
        if signature in seen:continue
        seen.add(signature)
        try:
            pages=json.loads((root/(str(row['id'])+'.json')).read_text(encoding='utf-8'))
            searchable=sum(bool(str(x.get('text') or '').strip()) for x in pages)
        except (OSError,ValueError,TypeError):searchable=0
        docs.append({'name':name,'pages':int(row.get('pages') or 0),
                     'searchable_pages':searchable,'status':'searchable' if searchable else 'unavailable_or_image_only'})
    return {'ok':True,'count':len(docs),'documents':docs,
            'note':'List/index readiness does not mean the AI read every page.'}

def ai_search(query,document='',limit=12):
    """Return page-grounded, capped excerpts across documents. Local disk reads only."""
    query=str(query or '').strip()[:400]
    document=str(document or '').strip()[:180]
    limit=max(1,min(24,int(limit or 12)))
    if not query: return {'ok':False,'error':'검색어를 입력해야 해.'}
    with LOCK:
        rows=list(_manifest());root=ROOT
    words=list(dict.fromkeys(re.findall(r'[가-힣A-Za-z0-9]{2,}',query.lower())))[:24]
    if not words:return {'ok':False,'error':'검색 가능한 단어가 없어.'}
    candidates=[];matched_docs=set();searched=[];seen=set()
    for item in rows:
        name=str(item.get('name') or '')
        if document and document.lower() not in name.lower():continue
        signature=str(item.get('sha256') or '') or name
        if signature in seen:continue
        seen.add(signature)
        try:pages=json.loads((root/(str(item['id'])+'.json')).read_text(encoding='utf-8'))
        except (OSError,ValueError,TypeError):continue
        searched.append(name)
        for page in pages:
            raw=str(page.get('text') or '')
            if not raw:continue
            for start in range(0,min(len(raw),100000),700):
                part=raw[start:start+900];low=part.lower()
                score=sum(min(low.count(w),5)*(2 if len(w)>3 else 1) for w in words)
                if score:
                    candidates.append((score,name,int(page.get('page') or 0),start,part[:900]))
                    matched_docs.add(name)
    candidates.sort(key=lambda v:(-v[0],v[1],v[2],v[3]))
    # Round-robin over docs prevents one 362-page book from monopolizing results.
    selected=[];used=set()
    for score,name,page,start,part in candidates:
        if len(selected)>=limit:break
        if name in used:continue
        selected.append({'name':name,'page':page,'excerpt':part,'score':score});used.add(name)
    for score,name,page,start,part in candidates:
        if len(selected)>=limit:break
        key=(name,page,start)
        if any(r['name']==name and r['page']==page and r['excerpt']==part for r in selected):continue
        selected.append({'name':name,'page':page,'excerpt':part,'score':score})
    return {'ok':True,'query':query,'document_filter':document,'searched_documents':searched,
            'matching_documents':sorted(matched_docs),'results':selected,'total_matching_chunks':len(candidates),
            'truncated':len(candidates)>len(selected),
            'note':'Excerpts are text-search evidence, not proof of complete semantic review. Pages without extracted text may require visual inspection.'}

def retrieve(query,max_chars=11000):
    """Local-only keyword scoring, bounded context. Never starts REST, websocket or scanner calls."""
    with LOCK:rows=_manifest()
    if not rows:return ''
    words=list(dict.fromkeys(re.findall(r'[가-힣A-Za-z0-9]{2,}',str(query).lower())))[:20]
    chunks=[]
    for item in rows:
        try:pages=json.loads((ROOT/(item['id']+'.json')).read_text(encoding='utf-8'))
        except (OSError,ValueError):continue
        for p in pages:
            s=str(p.get('text',''))
            if not s:continue
            # 850-char overlapping spans keep page provenance and prompt bounded.
            for start in range(0,min(len(s),100000),720):
                part=s[start:start+1000]
                lower=part.lower()
                hits=sum(min(lower.count(w),4)*(2 if len(w)>3 else 1) for w in words)
                if hits:chunks.append((hits,item['name'],p['page'],part))
    chunks.sort(key=lambda x:x[0],reverse=True)
    output=[];length=0
    for score,name,page,part in chunks[:18]:
        line=f'[자료: {name} · {page}쪽]\n{part}\n'
        if length+len(line)>max_chars:break
        output.append(line);length+=len(line)
    return '\n'.join(output)


def visual_pages(query,max_pages=2):
    """Return selected PDF pages as JPEG data URLs for AI vision only.

    No render, OCR, cloud call or image processing on market-data threads.
    Requires PyMuPDF on the local interpreter; returns a clear error if missing.
    """
    with LOCK:rows=_manifest()
    if not rows:return {'pages':[],'error':''}
    try:
        fitz = _pdf_dependency('fitz', 'PyMuPDF')
    except Exception as exc:
        return {'pages':[],'error':str(exc)}
    words=list(dict.fromkeys(re.findall(r'[가-힣A-Za-z0-9]{2,}',str(query).lower())))[:20]
    options=[]
    for item in rows:
        try:page_text=json.loads((ROOT/(item['id']+'.json')).read_text(encoding='utf-8'))
        except (OSError,ValueError):page_text=[]
        texts={p['page']:str(p.get('text','')).lower() for p in page_text}
        # Choose visually informative pages first; scanned PDFs have no extracted text.
        for i in range(min(int(item.get('pages') or 0),120)):
            t=texts.get(i+1,'')
            score=sum(min(t.count(w),4) for w in words)
            is_scan=not bool(t)
            if is_scan:score+=2
            if any(w in str(query).lower() for w in ('차트','그림','이미지','사진','캔들','매수','매도')):score+=1
            options.append((score,item['name'],int(i+1),item['id']))
    options.sort(key=lambda x:(-x[0],x[2]))
    results=[]
    for score,name,page_no,docid in options[:max_pages*3]:
        if len(results)>=max_pages:break
        try:
            with fitz.open(_pdf_path(next(i for i in rows if i['id']==docid))) as doc:
                page=doc[page_no-1]
                scale=min(1.5,1300/max(page.rect.width, page.rect.height))
                pix=page.get_pixmap(matrix=fitz.Matrix(scale,scale),alpha=False)
                data=pix.tobytes('jpeg',jpg_quality=65)
                if len(data)>700000:continue
                results.append({'name':name,'page':page_no,'image_url':'data:image/jpeg;base64,'+base64.b64encode(data).decode('ascii')})
        except Exception:continue
    return {'pages':results,'error':'' if results else 'PDF 이미지를 변환하지 못했어.'}


def _pdf_path(item):
    if item.get('source')=='drive':
        # Only filenames from direct Drive directory listing; never arbitrary request paths.
        return DRIVE_FOLDER/Path(item['source_name']).name
    return ROOT/(item['id']+'.pdf')

def _same_pdf_file(a, b):
    """Compare bytes, not names; never remove a user's source PDF."""
    try:
        a,b=Path(a),Path(b)
        if not a.is_file() or not b.is_file() or a.stat().st_size!=b.stat().st_size:
            return False
        def digest(path):
            h=hashlib.sha256()
            with path.open('rb') as f:
                for part in iter(lambda:f.read(1024*1024), b''):
                    h.update(part)
            return h.digest()
        return digest(a)==digest(b)
    except (OSError, ValueError):
        return False


def _drop_redundant_index_entries(folder, store):
    """Only drop duplicate *index references* where source PDF bytes agree.

    Prefer a folder-synced entry so subsequent syncs remain idempotent.
    Do not delete archived PDFs, text extracts or user data.
    """
    path=store/'index.json'
    try:
        rows=json.loads(path.read_text(encoding='utf-8'))
        if not isinstance(rows,list):return 0
    except (OSError, ValueError):return 0
    kept=[]; removed=0
    for row in rows:
        name=Path(str(row.get('name') or '')).name
        pdf=folder/name
        local=store/(str(row.get('id') or '')+'.pdf')
        if row.get('source')=='drive' and row.get('source_name')==name:
            src=pdf
        else:
            src=local
        duplicate=next((r for r in kept if r.get('name')==name and
            _same_pdf_file(src,
               (pdf if r.get('source')=='drive' and r.get('source_name')==name
                else store/(str(r.get('id') or '')+'.pdf')))),None)
        if duplicate is not None:
            # Keep the folder-linked record in preference to a migrated local copy.
            if row.get('source')=='drive' and duplicate.get('source')!='drive':
                kept.remove(duplicate);kept.append(row)
            removed+=1
        else:kept.append(row)
    if removed:
        tmp=store/'index.json.tmp'
        tmp.write_text(json.dumps(kept,ensure_ascii=False,indent=2),encoding='utf-8')
        tmp.replace(path)
    return removed


def _activate_drive(folder):
    """Connect any existing local/Drive folder without losing indexed PDFs.

    The index and extracted text live inside a hidden .litto_library directory.
    The folder is not required to be named LITTO_AI_MEMORY.
    """
    global ROOT, DRIVE_FOLDER
    path=Path(str(folder).strip().strip('"')).expanduser()
    if not path.is_dir():
        raise ValueError('존재하는 Windows 폴더의 전체 경로를 입력해 줘.')
    path=path.resolve()
    store=path/'.litto_library'
    if ROOT is not None and store.resolve()==ROOT.resolve():
        DRIVE_FOLDER=path
        return
    store.mkdir(parents=True,exist_ok=True)

    # Preserve manually registered PDFs and indexed items when changing folders.
    # Copy only; never delete from the previous folder. Do not overwrite files.
    previous_root=ROOT
    previous_folder=DRIVE_FOLDER
    if previous_root is not None and previous_root.exists():
        old_rows=_manifest()
        try:
            existing=json.loads((store/'index.json').read_text(encoding='utf-8'))
            if not isinstance(existing,list):existing=[]
        except (OSError,ValueError):existing=[]
        merged=list(existing)
        ids={x.get('id') for x in merged}
        changed=False
        for item in old_rows:
            docid=item.get('id')
            if not isinstance(docid,str) or not re.fullmatch('[0-9a-f]{32}',docid) or docid in ids:
                continue
            old_text=previous_root/(docid+'.json')
            old_pdf=(previous_folder/Path(item.get('source_name','')).name if item.get('source')=='drive' and previous_folder else previous_root/(docid+'.pdf'))
            if not old_text.is_file() or not old_pdf.is_file():
                continue
            # Startup replays migration from the legacy library; don't recreate
            # already synchronized copies under fresh UUIDs on every launch.
            folder_source=path/Path(str(item.get('name') or '')).name
            if _same_pdf_file(old_pdf,folder_source):
                continue
            if any(x.get('name')==item.get('name') and _same_pdf_file(
                old_pdf, (path/Path(str(x.get('source_name') or '')).name)
                if x.get('source')=='drive' else store/(str(x.get('id') or '')+'.pdf'))
                for x in merged):
                continue
            new_text=store/(docid+'.json')
            new_pdf=store/(docid+'.pdf')
            if new_text.exists() or new_pdf.exists():
                continue
            shutil.copy2(old_text,new_text)
            try:shutil.copy2(old_pdf,new_pdf)
            except Exception:
                new_text.unlink(missing_ok=True)
                raise
            converted=dict(item)
            converted.pop('source',None)
            converted.pop('source_name',None)
            converted.pop('source_size',None)
            converted.pop('source_mtime_ns',None)
            merged.append(converted)
            ids.add(docid)
            changed=True
        if changed:
            tmp=store/'index.json.tmp'
            tmp.write_text(json.dumps(merged,ensure_ascii=False,indent=2),encoding='utf-8')
            tmp.replace(store/'index.json')
    DRIVE_FOLDER=path
    ROOT=store
    _drop_redundant_index_entries(path,store)

def connect_drive(folder):
    with LOCK:
        if _SYNC['running']:
            raise ValueError('PDF 동기화가 끝난 다음 폴더를 변경해 줘.')
        _activate_drive(folder)
        CONFIG_FILE.parent.mkdir(parents=True,exist_ok=True)
        CONFIG_FILE.write_text(str(DRIVE_FOLDER),encoding='utf-8')
    start_drive_sync()
    return listing()

def start_drive_sync():
    if DRIVE_FOLDER is None:raise ValueError('먼저 PDF 폴더 경로를 연결해 줘.')
    with LOCK:
        if _SYNC['running']:return listing()
        _SYNC.update(running=True,done=0,total=0,error='',note='폴더 PDF 목록 확인 중')
    threading.Thread(target=_drive_worker,name='LITTO_PDF_DRIVE_IMPORT',daemon=True).start()
    return listing()

def _drive_worker():
    try:
        from pypdf import PdfReader
        pdfs=sorted(p for p in DRIVE_FOLDER.glob('*.pdf') if p.is_file())[:500]
        with LOCK:_SYNC['total']=len(pdfs)
        for pdf in pdfs:
            try:
                stat=pdf.stat()
                with LOCK:
                    rows=_manifest()
                    existing=next((x for x in rows if x.get('source')=='drive' and x.get('source_name')==pdf.name),None)
                if existing and existing.get('source_size')==stat.st_size and existing.get('source_mtime_ns')==stat.st_mtime_ns:
                    pass
                else:
                    # Parse a single file outside of market/API locks, without copying its entire bytes.
                    reader=PdfReader(str(pdf),strict=False)
                    if reader.is_encrypted:raise ValueError('암호화 PDF')
                    if len(reader.pages)>1500:raise ValueError('1500페이지 초과')
                    pages=[]
                    for i,page in enumerate(reader.pages):
                        t=re.sub(r'\s+',' ',page.extract_text() or '').strip()
                        if t:pages.append({'page':i+1,'text':t[:25000]})
                    docid=existing['id'] if existing else uuid.uuid4().hex
                    item={'id':docid,'name':pdf.name,'pages':len(reader.pages),'text_pages':len(pages),
                          'image_pages':len(reader.pages)-len(pages), 'added_at':time.strftime('%Y-%m-%d %H:%M:%S'),
                          'source':'drive','source_name':pdf.name,'source_size':stat.st_size,'source_mtime_ns':stat.st_mtime_ns}
                    with LOCK:
                        (ROOT/(docid+'.json')).write_text(json.dumps(pages,ensure_ascii=False),encoding='utf-8')
                        rows=_manifest()
                        rows=[r for r in rows if not (r.get('source')=='drive' and r.get('source_name')==pdf.name)]
                        rows.append(item)
                        _save(rows)
                        _drop_redundant_index_entries(DRIVE_FOLDER,ROOT)
            except Exception as e:
                with LOCK:_SYNC['error']+=f'[{pdf.name[:32]}] {str(e)[:100]}\n'
            finally:
                with LOCK:_SYNC['done']+=1
        with LOCK:_SYNC['note']='동기화 완료'
    except Exception as e:
        with LOCK:_SYNC['error']+='동기화 실패: '+str(e)[:250]
    finally:
        with LOCK:_SYNC['running']=False
