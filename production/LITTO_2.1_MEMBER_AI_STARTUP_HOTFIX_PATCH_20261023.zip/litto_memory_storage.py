"""Stable, per-Windows-user LITTO AI memory directory (independent of releases)."""
from pathlib import Path
import os
import sqlite3
import shutil
import datetime
import uuid


def storage_dir():
    base = os.environ.get('LOCALAPPDATA')
    if not base:
        base = str(Path.home() / 'AppData' / 'Local') if os.name == 'nt' else str(Path.home() / '.local' / 'share')
    return Path(base) / 'LITTO' / 'AI_MEMORY'


def db_path():
    return storage_dir() / 'litto_ai_brain.sqlite3'


def _snapshot(source, dest):
    src = sqlite3.connect(str(source), timeout=20)
    try:
        dst = sqlite3.connect(str(dest), timeout=20)
        try:
            src.backup(dst)
        finally:
            dst.close()
    finally:
        src.close()


def prepare_db(litto_root):
    """Migrate legacy memory once; never overwrite already-migrated memories."""
    target = db_path()
    target.parent.mkdir(parents=True, exist_ok=True)
    legacy = Path(litto_root) / 'data' / 'litto_ai_brain.sqlite3'
    if not target.exists() and legacy.is_file():
        stamp = datetime.datetime.now().strftime('%Y%m%d_%H%M%S')
        backup = target.parent / ('legacy_before_migration_' + stamp + '.sqlite3')
        _snapshot(legacy, backup)
        try:
            _snapshot(backup, target)
        except BaseException:
            target.unlink(missing_ok=True)
            raise
    return target


def device_id():
    """Stable for a PC/user across LITTO version replacements."""
    folder = storage_dir()
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / 'device_id.txt'
    if path.is_file():
        value = path.read_text(encoding='utf-8').strip()
        if len(value) == 32 and all(c in '0123456789abcdef' for c in value):
            return value[:12]
    value = uuid.uuid4().hex
    with path.open('x', encoding='utf-8') as f:
        f.write(value + '\n')
    return value[:12]
