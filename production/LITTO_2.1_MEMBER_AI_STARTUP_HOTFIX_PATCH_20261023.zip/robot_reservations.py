"""Persistent live robot reservations. Orders only follow explicit user approvals."""
import hashlib
import json
import os
import re
import tempfile
import threading
import uuid
from datetime import datetime, timezone, timedelta
import time
from pathlib import Path

_LOCK = threading.RLock()
_KST = timezone(timedelta(hours=9))
_PATH = Path(__file__).resolve().parent / 'data' / 'robot_reservations.json'

def _now():
    return datetime.now(_KST)

def _read():
    try:
        data = json.loads(_PATH.read_text(encoding='utf-8'))
        return data if isinstance(data, list) else []
    except (FileNotFoundError, json.JSONDecodeError, OSError):
        return []

def _write(rows):
    _PATH.parent.mkdir(parents=True, exist_ok=True)
    fd, temp = tempfile.mkstemp(prefix='.robot-',suffix='.tmp',dir=str(_PATH.parent))
    try:
        with os.fdopen(fd,'w',encoding='utf-8') as stream:
            json.dump(rows,stream,ensure_ascii=False,indent=2)
            stream.flush(); os.fsync(stream.fileno())
        os.replace(temp,_PATH)
    finally:
        try: os.unlink(temp)
        except FileNotFoundError: pass

# UI cleanup never erases broker/order audit records or live reservations.
_ARCHIVABLE = frozenset(('submitted', 'completed', 'cancelled', 'expired'))

def _archive_day(row):
    stamp = row.get('finished_at') or row.get('attempted_at') or row.get('created_at') or ''
    try:
        dt = datetime.fromisoformat(stamp)
        return (dt.replace(tzinfo=_KST) if dt.tzinfo is None else dt.astimezone(_KST)).date()
    except (ValueError, TypeError):
        return None

def _auto_archive(rows):
    today = _now().date()
    changed = False
    for row in rows:
        if row.get('status') in _ARCHIVABLE and not row.get('hidden_from_robot_list'):
            d = _archive_day(row)
            if d and d < today:
                row['hidden_from_robot_list'] = True
                row['hidden_at'] = _now().isoformat(timespec='seconds')
                changed = True
    return changed

def list_orders():
    with _LOCK:
        rows = _read()
        if _auto_archive(rows):
            _write(rows)
        return {'mode':'LIVE_ROBOT','live_order_enabled':os.getenv('LITTO_ROBOT_LIVE_ENABLED','0')=='1',
                'rows':list(reversed([x for x in rows if not x.get('hidden_from_robot_list')]))}

def hide_selected(data):
    ids = (data or {}).get('ids')
    if not isinstance(ids, list) or not ids or len(ids) > 100:
        raise ValueError('삭제할 종료 예약을 선택하세요 (최대 100건).')
    wanted = set(str(x) for x in ids)
    with _LOCK:
        rows = _read()
        found = [x for x in rows if x.get('id') in wanted and not x.get('hidden_from_robot_list')]
        if len(found) != len(wanted):
            raise ValueError('선택한 예약 중 찾을 수 없는 항목이 있습니다.')
        if any(x.get('status') not in _ARCHIVABLE for x in found):
            raise ValueError('대기·전송 중·확인 필요 예약은 삭제할 수 없습니다. 취소 또는 주문상태 확인이 필요합니다.')
        for row in found:
            row['hidden_from_robot_list'] = True
            row['hidden_at'] = _now().isoformat(timespec='seconds')
        _write(rows)
        return {'ok':True, 'hidden_count':len(found)}

def _dedupe(rows, data):
    """One natural-language instruction cannot create duplicate live orders within 90 sec."""
    command=str(data.get('source_command_text') or '').strip()
    if not command:return None
    digest=hashlib.sha256(command.encode('utf-8')).hexdigest()
    now=_now()
    for row in reversed(rows):
        if row.get('source_command_hash') != digest:continue
        try:age=(now-datetime.fromisoformat(row.get('created_at',''))).total_seconds()
        except Exception:continue
        if 0<=age<=90:return row
    return None

def create_order(data):
    if not isinstance(data,dict):raise ValueError('예약 데이터 형식 오류')
    if data.get('approved') is not True:raise ValueError('실전 자동 주문 사전 승인이 필요합니다.')
    code=str(data.get('code') or '').strip()
    if not re.fullmatch(r'[0-9]{6}',code):raise ValueError('종목코드 6자리를 확인하세요.')
    side=str(data.get('side') or '')
    if side not in ('buy','sell'):raise ValueError('매수/매도를 선택하세요.')
    unit=str(data.get('unit') or '')
    if unit not in ('amount','shares'):raise ValueError('금액/주식 수를 선택하세요.')
    val=data.get('value')
    if isinstance(val,bool) or not str(val).isdigit() or not 1<=int(val)<=10**12:raise ValueError('주문 금액/수량은 양의 정수여야 합니다.')
    dt=str(data.get('when') or '')
    try:
        scheduled=datetime.fromisoformat(dt)
        if scheduled.tzinfo is None:scheduled=scheduled.replace(tzinfo=_KST)
        scheduled=scheduled.astimezone(_KST)
    except (ValueError,TypeError):raise ValueError('예약 날짜와 시간을 확인하세요.')
    if not _now()<scheduled<=_now().replace(year=_now().year+1):raise ValueError('예약은 미래 1년 이내로 설정하세요.')
    price=data.get('price_limit')
    if isinstance(price,bool) or not str(price).isdigit() or int(price)<=0:raise ValueError('최대 매수가/최저 매도가를 입력해야 합니다.')
    name=str(data.get('name') or code).strip()[:60]
    item={'id':uuid.uuid4().hex,'code':code,'name':name,'side':side,
          'unit':unit,'value':int(val),'when':scheduled.isoformat(timespec='seconds'),
          'price_limit':int(price),'price_side':'ask1' if side=='buy' else 'bid1',
          'status':'pending','approved_live':True,'created_at':_now().isoformat(timespec='seconds'),
          'note':'실전 예약 승인 완료. 유효한 호가 확보 시 1회 주문 전송'}
    with _LOCK:
        rows=_read()
        old=_dedupe(rows,data)
        if old:return {'ok':True,'item':old,'live_order_enabled':os.getenv('LITTO_ROBOT_LIVE_ENABLED','0')=='1','already_exists':True}
        if len([x for x in rows if x.get('status')=='pending'])>=100:raise ValueError('대기 예약은 최대 100건입니다.')
        if data.get('source_command_text'):
            item['source_command_hash']=hashlib.sha256(str(data['source_command_text']).strip().encode()).hexdigest()
        if data.get('source_command_text'):
            item['source_command_hash']=hashlib.sha256(str(data['source_command_text']).strip().encode()).hexdigest()
        rows.append(item);_write(rows)
    return {'ok':True,'item':item,'live_order_enabled':True}

def create_cost_trigger(data):
    """Durable one-shot condition, pinned to an authenticated broker's cost basis."""
    if data.get('approved') is not True:raise ValueError('주문 승인이 필요합니다.')
    code=str(data.get('code') or '')
    if not re.fullmatch(r'\d{6}',code):raise ValueError('종목코드 오류')
    side=data.get('side');unit=data.get('unit')
    if side not in ('buy','sell') or unit not in ('shares','amount','holding_percent'):raise ValueError('조건 주문 단위 오류')
    if unit=='holding_percent' and side!='sell':raise ValueError('보유비율 매도만 가능')
    value=data.get('value');baseline=data.get('baseline_avg');pct=data.get('trigger_pct')
    if isinstance(value,bool) or not str(value).isdigit() or not 1<=int(value)<=10**10:raise ValueError('주문 수량 오류')
    if not isinstance(baseline,(int,float)) or isinstance(baseline,bool) or baseline<=0:raise ValueError('계좌 평단 정보가 확인되지 않았습니다.')
    if not isinstance(pct,(float,int)) or not -50<=pct<=50 or abs(pct)<0.1:raise ValueError('조건 수익률 오류')
    if (side=='buy' and pct>=0) or (side=='sell' and pct<=0):raise ValueError('익절/추매 수익률 방향 오류')
    now=_now();command=str(data.get('source_command_text') or '').strip()
    item={'id':uuid.uuid4().hex,'kind':'cost_trigger','code':code,'name':str(data.get('name') or code)[:60],
        'side':side,'unit':unit,'value':int(value),'trigger_pct':float(pct),
        'baseline_avg':float(baseline),'target_price':float(baseline)*(1+float(pct)/100),
        'status':'pending','approved_live':True,'created_at':now.isoformat(timespec='seconds'),
        'note':'계좌 평단 고정 기준 1회 조건 주문. 체결 확인 필요'}
    with _LOCK:
        rows=_read();old=_dedupe(rows,data)
        if old:return {'ok':True,'item':old,'already_exists':True}
        if sum(x.get('status')=='pending' for x in rows)>=100:raise ValueError('대기 예약 100건 초과')
        if command:item['source_command_hash']=hashlib.sha256(command.encode()).hexdigest()
        rows.append(item);_write(rows)
    return {'ok':True,'item':item,'already_exists':False}

def create_price_trigger(data):
    """Durable one-shot target limit. Never auto-raise buy price or lower sell price."""
    if data.get('approved') is not True:raise ValueError('주문 승인이 필요합니다.')
    code=str(data.get('code') or '').strip()
    if not re.fullmatch(r'\d{6}',code):raise ValueError('종목코드 오류')
    side=data.get('side');unit=data.get('unit')
    if side not in ('buy','sell') or unit!='shares':raise ValueError('가격 도달형 주문은 매수/매도 주수만 지원합니다.')
    val=data.get('value');target=data.get('target_price')
    if isinstance(val,bool) or not str(val).isdigit() or not 1<=int(val)<=1000000:raise ValueError('주문 주수 오류')
    if isinstance(target,bool) or not str(target).isdigit() or not 1<=int(target)<=10**9:raise ValueError('목표가격 오류')
    now=_now();command=str(data.get('source_command_text') or '').strip()
    item={'id':uuid.uuid4().hex,'kind':'price_trigger','code':code,'name':str(data.get('name') or code)[:60],
          'side':side,'unit':'shares','value':int(val),'target_price':int(target),
          'status':'pending','approved_live':True,'created_at':now.isoformat(timespec='seconds'),
          'note':'목표가격 조건부 1회 예약. 매수는 매도1호가 이하, 매도는 매수1호가 이상 시 주문 요청'}
    with _LOCK:
        rows=_read();old=_dedupe(rows,data)
        if old:return {'ok':True,'item':old,'already_exists':True}
        if sum(x.get('status')=='pending' for x in rows)>=100:raise ValueError('대기 예약 100건 초과')
        if command:item['source_command_hash']=hashlib.sha256(command.encode('utf-8')).hexdigest()
        rows.append(item);_write(rows)
    return {'ok':True,'item':item,'already_exists':False}

def create_timed_batch(data):
    """Validate all legs and atomically persist the batch. No broker submission here."""
    orders=(data or {}).get('orders')
    if not isinstance(orders,list) or not (2<=len(orders)<=10):
        raise ValueError('시간별 분할 예약은 2~10개가 필요해.')
    now=_now();prepared=[]
    for leg in orders:
        if leg.get('approved') is not True:raise ValueError('주문 승인 정보가 없어.')
        code=str(leg.get('code') or '')
        if not re.fullmatch(r'\d{6}',code):raise ValueError('종목코드 오류')
        side=leg.get('side');unit=leg.get('unit')
        if side not in ('buy','sell') or unit not in ('shares','amount'):raise ValueError('주문 방향/단위 오류')
        val=leg.get('value');price=leg.get('price_limit')
        if isinstance(val,bool) or not str(val).isdigit() or not 1<=int(val)<=10**12:raise ValueError('주문 수량 오류')
        if isinstance(price,bool) or not str(price).isdigit() or int(price)<=0:raise ValueError('허용 가격 오류')
        try:when=datetime.fromisoformat(str(leg.get('when'))).astimezone(_KST)
        except (TypeError,ValueError):raise ValueError('예약 시각 오류')
        if not now<when<=now+timedelta(days=365):raise ValueError('예약은 미래 1년 이내여야 해.')
        prepared.append({'id':uuid.uuid4().hex,'code':code,'name':str(leg.get('name') or code)[:60],
            'side':side,'unit':unit,'value':int(val),'when':when.isoformat(timespec='seconds'),
            'price_limit':int(price),'price_side':'ask1' if side=='buy' else 'bid1',
            'status':'pending','approved_live':True,'created_at':now.isoformat(timespec='seconds'),
            'note':'시간별 분할 예약 승인 완료'})
    if len(set(x['when'] for x in prepared))!=len(prepared):raise ValueError('예약 시간이 중복돼.')
    command=str(data.get('source_command_text') or '').strip()
    hashval=hashlib.sha256(command.encode()).hexdigest() if command else None
    with _LOCK:
        rows=_read()
        if hashval:
            duplicates=[x for x in rows if x.get('source_command_hash')==hashval and x.get('source_batch_id')]
            if duplicates:
                try:age=(now-datetime.fromisoformat(duplicates[0]['created_at'])).total_seconds()
                except (TypeError,ValueError):age=999
                if 0<=age<=90:
                    return {'ok':True,'items':duplicates,'already_exists':True}
        if sum(x.get('status')=='pending' for x in rows)+len(prepared)>100:
            raise ValueError('대기 예약 100건 한도 초과')
        batch_id=uuid.uuid4().hex
        for x in prepared:
            x['source_batch_id']=batch_id
            if hashval:x['source_command_hash']=hashval
        rows.extend(prepared);_write(rows)
    return {'ok':True,'items':prepared,'already_exists':False}

def cancel_order(data):
    ident=str((data or {}).get('id') or '')
    with _LOCK:
        rows=_read()
        for item in rows:
            if item['id']==ident:
                if item['status'] not in ('pending','simulation_only'):raise ValueError('이미 종료된 예약은 취소할 수 없습니다.')
                item['status']='cancelled';item['note']='사용자가 예약 취소함';_write(rows)
                return {'ok':True,'id':ident}
    raise ValueError('예약을 찾을 수 없습니다.')

def cancel_all(_data=None):
    with _LOCK:
        rows=_read();count=0
        for item in rows:
            if item['status'] in ('pending','simulation_only'):item['status']='cancelled';item['note']='사용자가 전체 취소함';count+=1
        if count:_write(rows)
        return {'ok':True,'cancelled_count':count}

def preview_quantity(data):
    """Pure simulation, never submits orders. Reference quote must be supplied explicitly."""
    unit=str(data.get('unit') or '')
    value=int(data.get('value') or 0)
    quote=int(data.get('reference_quote') or 0)
    side=str(data.get('side') or '')
    limit=int(data.get('price_limit') or 0)
    if quote<=0 or value<=0 or limit<=0 or side not in ('buy','sell') or unit not in ('amount','shares'):
        raise ValueError('금액, 호가 및 허용가격을 확인하세요.')
    if (side=='buy' and quote>limit) or (side=='sell' and quote<limit):
        return {'order_allowed':False,'reason':'허용 가격 범위 초과','shares':0,'estimated_amount':0,'is_simulation':True}
    shares=value//quote if unit=='amount' else value
    return {'order_allowed':shares>0,'shares':shares,'estimated_amount':shares*quote,
            'reason':'1주 미만' if shares<=0 else '계산 결과: 실제 주문 아님', 'is_simulation':True}


def _parse_split(data):
    if not isinstance(data,dict):raise ValueError('예약 데이터 형식 오류')
    code=str(data.get('code') or '').strip()
    if not re.fullmatch(r'[0-9]{6}',code):raise ValueError('종목코드를 확인하세요.')
    side=str(data.get('side') or '')
    if side not in ('buy','sell'):raise ValueError('매수/매도를 선택하세요.')
    raw=data.get('steps')
    if not isinstance(raw,list) or not (2<=len(raw)<=10):raise ValueError('분할 단계는 2~10개로 입력하세요.')
    steps=[]
    for i,step in enumerate(raw):
        if not isinstance(step,dict):raise ValueError(f'{i+1}단계 형식 오류')
        price=step.get('price');pct=step.get('percent')
        if isinstance(price,bool) or isinstance(pct,bool):raise ValueError('가격과 비율은 숫자여야 합니다.')
        if not str(price).isdigit() or not str(pct).isdigit():raise ValueError('가격과 비율은 양의 정수여야 합니다.')
        price=int(price);pct=int(pct)
        if not (1<=price<=10**9) or not (1<=pct<=100):raise ValueError('가격 또는 비율 범위 오류')
        steps.append({'price':price,'percent':pct,'index':i+1,'status':'waiting'})
    if sum(x['percent'] for x in steps)!=100:raise ValueError('분할 비율 합계는 정확히 100%여야 합니다.')
    prices=[x['price'] for x in steps]
    if len(prices)!=len(set(prices)):raise ValueError('동일한 목표 가격을 여러 단계에 사용할 수 없습니다.')
    if prices != sorted(prices, reverse=(side=='buy')):raise ValueError('매수는 높은 가격에서 낮은 가격, 매도는 낮은 가격에서 높은 가격 순서로 입력하세요.')
    shares=data.get('base_shares')
    if isinstance(shares,bool) or not str(shares).isdigit() or not (1<=int(shares)<=10**9):raise ValueError('전체 기준 수량을 양의 정수로 입력하세요.')
    return code,side,steps,int(shares)

def preview_split(data):
    code,side,steps,shares=_parse_split(data)
    allocated=0
    result=[]
    for i,step in enumerate(steps):
        count=shares-allocated if i==len(steps)-1 else shares*step['percent']//100
        allocated+=count
        result.append({**step,'shares':count,'estimated_amount':count*step['price']})
    return {'is_simulation':True,'live_order_enabled':False,'code':code,'side':side,'base_shares':shares,'steps':result,
            'warning':'미리보기 수량은 실전 실행 시 계좌/호가 조건에 따라 제한될 수 있습니다.'}

def create_split(data):
    if data.get('approved') is not True:raise ValueError('분할 실전 주문 사전 승인이 필요합니다.')
    preview=preview_split(data)
    name=str(data.get('name') or preview['code']).strip()[:60]
    item={'id':uuid.uuid4().hex,'kind':'split','code':preview['code'],'name':name,'side':preview['side'],
          'base_shares':preview['base_shares'],'steps':preview['steps'],
          'status':'pending','approved_live':True,'created_at':_now().isoformat(timespec='seconds'),
          'note':'분할 조건 감시 예약 승인 완료'}
    with _LOCK:
        rows=_read()
        old=_dedupe(rows,data)
        if old:return {'ok':True,'item':old,'live_order_enabled':os.getenv('LITTO_ROBOT_LIVE_ENABLED','0')=='1','already_exists':True}
        if len([x for x in rows if x.get('status') in ('pending','simulation_only')])>=100:raise ValueError('대기 예약은 최대 100건입니다.')
        rows.append(item);_write(rows)
    return {'ok':True,'item':item,'live_order_enabled':True}


# A reservation is durably claimed BEFORE transmitting to prevent double sends
# after a process restart or an uncertain broker response. Never retry an
# ambiguous transmission without manual inspection of broker order history.
def claim(task_id, step_index=None):
    with _LOCK:
        rows=_read()
        for row in rows:
            if row['id'] != task_id or (row.get('status')!='pending' or row.get('approved_live') is not True): continue
            if step_index is None:
                if row.get('kind')=='split':return None
                row['status']='submitting'; row['attempted_at']=_now().isoformat()
            else:
                if row.get('kind')!='split':return None
                step=row['steps'][step_index]
                if step['status']!='waiting':return None
                step['status']='submitting';step['attempted_at']=_now().isoformat()
            _write(rows)
            return dict(row)
    return None

def settle(task_id, result, step_index=None, success=False, note=''):
    with _LOCK:
        rows=_read()
        for row in rows:
            if row['id']!=task_id:continue
            item=row if step_index is None else row['steps'][step_index]
            if item.get('status')!='submitting':return
            item['status']='submitted' if success else 'review_required'
            item['result']=result if isinstance(result,dict) else {'info':str(result)[:500]}
            item['note']=note or ('키움 주문 요청 완료' if success else '주문 결과 불명확: 계좌 주문내역 확인 필요')
            item['finished_at']=_now().isoformat()
            if step_index is not None and all(x['status'] in ('submitted','review_required','skipped') for x in row['steps']):
                row['status']='completed' if all(x['status']=='submitted' for x in row['steps']) else 'review_required'
            _write(rows)
            return

def expire(task_id, note):
    with _LOCK:
        rows=_read()
        for row in rows:
            if row['id']==task_id and row.get('status')=='pending':
                row['status']='expired';row['note']=note;_write(rows);return

def eligible(now=None):
    now=now or _now()
    with _LOCK:rows=_read()
    return [x for x in rows if x.get('status')=='pending' and x.get('approved_live') is True]
