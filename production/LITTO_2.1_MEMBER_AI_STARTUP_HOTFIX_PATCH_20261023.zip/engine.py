"""Newheart screening rules. No orders. All money in KRW; all times KST.

Rules are a reviewable translation of supplied notes, not the original indicator.
See RULES.md for provenance and explicit operational assumptions.
"""
from datetime import datetime, timedelta, timezone
from statistics import mean
import math
import re
from yaksang import REVIEW_FIELDS, excluded_product

KST = timezone(timedelta(hours=9))
DEFAULTS = {}

def number(v):
    if v is None or v == '':
        return None
    if isinstance(v, bool):
        raise ValueError('숫자 자리에 참/거짓을 사용할 수 없습니다.')
    try:
        f = float(str(v).replace(',', '').strip())
    except (ValueError, TypeError):
        raise ValueError(f'숫자 형식 오류: {str(v)[:40]}')
    if not math.isfinite(f):
        raise ValueError('NaN/Infinity는 사용할 수 없습니다.')
    return f

def timeparse(v):
    t = datetime.fromisoformat(str(v).replace('Z', '+00:00'))
    return (t.replace(tzinfo=KST) if t.tzinfo is None else t.astimezone(KST))

def code(v):
    s = str(v).strip()
    if s.endswith('.0') and s[:-2].isdigit():
        s = s[:-2]
    s = s.zfill(6)
    if not re.fullmatch('[0-9A-Z]{6}', s):
        raise ValueError('종목코드는 숫자/영문 대문자 6자리여야 합니다.')
    return s

def config(values=None):
    if values:
        raise ValueError('임의 수치 설정은 제거되었습니다. 강의 확인 항목을 사용하세요.')
    return {}

def normalize_stock(stock, asof):
    s = dict(stock)
    s['code'] = code(s.get('code', ''))
    s['name'] = str(s.get('name') or s['code'])[:80]
    s['sector'] = str(s.get('sector') or '미분류')[:80]
    s['review'] = s.get('review') or {}
    if not isinstance(s['review'], dict):
        raise ValueError('review는 객체여야 합니다.')
    for k in REVIEW_FIELDS:
        if s['review'].get(k) is not None and type(s['review'].get(k)) is not bool:
            raise ValueError('수동 확인값은 true/false/null입니다.')
    for field, tkey in (('daily', 'date'), ('m15', 'time'), ('m3', 'time')):
        bars = []
        dates = set()
        for raw in s.get(field, []):
            b = dict(raw)
            if field == 'daily':
                d = datetime.strptime(str(b[tkey]), '%Y-%m-%d').date()
                if d > asof.date():
                    raise ValueError('조회 시각보다 미래인 일봉이 있습니다.')
            else:
                t = timeparse(b[tkey])
                if t > asof:
                    raise ValueError('조회 시각보다 미래인 분봉이 있습니다.')
                b[tkey] = t.isoformat()
            if b[tkey] in dates:
                raise ValueError('중복 봉: ' + b[tkey])
            dates.add(b[tkey])
            for k in ('open','high','low','close','volume','value'):
                b[k] = number(b.get(k))
                if b[k] is not None and b[k] < 0:
                    raise ValueError('가격·거래량·거래대금은 음수가 될 수 없습니다.')
            if any(b[k] is None or b[k] <= 0 for k in ('open','high','low','close')):
                raise ValueError('OHLC 가격이 누락되었거나 0입니다.')
            if b['low'] > min(b['open'],b['close']) or b['high'] < max(b['open'],b['close']) or b['low'] > b['high']:
                raise ValueError('고가/저가/OHLC 관계가 맞지 않습니다.')
            if field in ('m15','m3'):
                minutes=15 if field=='m15' else 3
                b['complete'] = b.get('complete', True) is True and timeparse(b[tkey])+timedelta(minutes=minutes)<=asof
            bars.append(b)
        s[field] = sorted(bars, key=lambda b:b[tkey])
    if len(s['daily']) < 2:
        raise ValueError('일봉이 최소 2개 필요합니다.')
    return s

def check(label, result, detail, source='프로그램 해석'):
    return {'label':label, 'state':'pass' if result is True else 'fail' if result is False else 'unknown',
            'detail':str(detail), 'source':source}

def pct(a, b):
    return (a / b - 1) * 100 if a is not None and b else None

def fmt(n, digits=1):
    return '자료 없음' if n is None else f'{n:,.{digits}f}'

def ma(bars, n):
    return mean(b['close'] for b in bars[-n:]) if len(bars) >= n else None

def outcome(checks):
    if any(x['state']=='fail' for x in checks):return '미충족'
    if any(x['state']=='unknown' for x in checks):return '자료 부족'
    return '충족'

def scan_stock(raw,asof,cfg,mode='import',market='unknown'):
    from strict_rules import lecture_patterns
    s=normalize_stock(raw,asof);d=s['daily'];t=d[-1];prev=d[-2]
    patterns=lecture_patterns(s,asof)
    return {'code':s['code'],'name':s['name'],'sector':s['sector'],
            'sector_source':s.get('sector_source','입력 자료 · 출처 미기재'),
            'price':t['close'],'change':pct(t['close'],prev['close']),
            'value_eok':t['value']/1e8 if t['value'] is not None else None,
            'date':t['date'],'asof':asof.isoformat(),'base':None,'patterns':patterns,
            'daily':d[-140:],'m15':s['m15'][-140:],'m3':s.get('m3',[])[-700:],'review':s['review']}

def scan_dataset(data, settings=None, market='unknown'):
    if not isinstance(data,dict) or not isinstance(data.get('stocks'),list):
        raise ValueError('stocks 배열이 포함된 JSON이 필요합니다.')
    if len(data['stocks'])>4000:
        raise ValueError('한 번에 4,000종목까지 지원합니다.')
    asof=timeparse(data['asof']); mode=data.get('mode','import')
    if mode not in ('demo','import','live'):mode='import'
    cfg=config(settings); results=[];errors=[];seen=set();excluded=[]
    for s in data['stocks']:
        try:
            c=code(s.get('code',''))
            if c in seen:raise ValueError('중복 종목코드')
            seen.add(c)
            reason=excluded_product(s)
            if reason:
                excluded.append({'code':c,'name':s.get('name',c),'reason':reason});continue
            results.append(scan_stock(s,asof,cfg,mode,market))
        except (ValueError,KeyError,TypeError) as e:
            errors.append({'code':str(s.get('code','?')),'error':str(e)})
    results.sort(key=lambda r:(-sum(p['technical']=='충족' and p['status']!='제외' for p in r['patterns']),-(r['value_eok'] or 0),r['code']))
    return {'mode':mode,'asof':asof.isoformat(),'results':results,'errors':errors,'excluded_products':excluded,
            'settings':cfg,'market':market,'input_count':len(data['stocks']),
            'scope':data.get('scope','가져온 시세 파일'),'generated_at':datetime.now(KST).isoformat()}
