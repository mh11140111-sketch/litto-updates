"""One-time automatic industry mapper for LITTO.

Uses Naver Finance public stock pages only to obtain the displayed industry name.
User-assigned sectors are never overwritten by the caller.
"""
from concurrent.futures import ThreadPoolExecutor, as_completed
from urllib.request import Request, urlopen
from urllib.error import URLError, HTTPError
from html import unescape
import re,time

UA='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/152 Safari/537.36'
_PATTERNS=[
    re.compile(r'sise_group_detail\.naver\?type=upjong&amp;no=\d+[^>]*>([^<]+)</a>',re.I),
    re.compile(r'sise_group_detail\.naver\?type=upjong&no=\d+[^>]*>([^<]+)</a>',re.I),
]

def fetch_sector(code, timeout=8):
    url=f'https://finance.naver.com/item/main.naver?code={code}'
    req=Request(url,headers={'User-Agent':UA,'Referer':'https://finance.naver.com/'})
    try:
        raw=urlopen(req,timeout=timeout).read()
    except (URLError,HTTPError,TimeoutError,OSError):
        return None
    # Naver legacy finance pages are normally euc-kr/cp949.
    text=None
    for enc in ('euc-kr','cp949','utf-8'):
        try:
            text=raw.decode(enc);break
        except UnicodeDecodeError:pass
    if not text:return None
    for p in _PATTERNS:
        m=p.search(text)
        if m:
            name=unescape(re.sub(r'\s+',' ',m.group(1))).strip()
            if name:return name
    return None

def sync(universe, existing=None, workers=8, progress=None):
    existing=existing or {}
    # Never overwrite explicit user sectors. Also skip already sourced automatic rows.
    targets=[]
    for item in universe:
        c=str(item.get('code','')).zfill(6)
        old=existing.get(c) or {}
        if str(old.get('source','')).startswith('사용자 직접 지정'):continue
        if old.get('sector') and old.get('sector')!='미분류':continue
        targets.append((c,item.get('name') or c))
    out={};done=0;total=len(targets)
    if progress:progress(done,total,'전 종목 섹터 동기화 시작')
    def one(pair):
        c,n=pair
        return c,n,fetch_sector(c)
    with ThreadPoolExecutor(max_workers=max(1,min(int(workers),12))) as ex:
        futs=[ex.submit(one,x) for x in targets]
        for f in as_completed(futs):
            c,n,sector=f.result();done+=1
            if sector:
                out[c]={'sector':sector,'source':'네이버 증권 업종 자동동기화','asof':time.strftime('%Y-%m-%d')}
            if progress and (done==total or done%25==0):
                progress(done,total,f'섹터 동기화 {done:,}/{total:,} · 매칭 {len(out):,}')
    return out,{'requested':total,'matched':len(out),'unmatched':total-len(out)}
