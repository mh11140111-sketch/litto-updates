"""LITTO on-demand reference-candle event matcher (R8).

Purpose
- For short-term trading, do not search the whole market for a vaguely similar chart.
- Detect the latest *strong bullish reference candle* in the selected stock.
- Compare it only with the same stock's historical strong-candle events.
- Rank by reference-candle strength/shape first, then by the five sessions leading
  into the candle and the 20-day background regime.
- Evaluate the following five sessions for +4% / -3% behavior.

Performance contract
- standard library only;
- no background work, timers or polling;
- one stock's already-fetched daily history only;
- deterministic / explainable scoring.
"""
from __future__ import annotations

import math
import statistics

LOOKBACK_ANCHOR = 3          # latest 3 sessions may contain the active reference candle
PRE_PATTERN_BARS = 5        # five sessions leading into the reference candle
CONTEXT_BARS = 20
MAX_HORIZON = 5
MAX_MATCHES = 30
MIN_CORE_SAMPLE = 8


def _f(v, default=0.0):
    try:
        x = float(v)
        return x if math.isfinite(x) else default
    except (TypeError, ValueError):
        return default


def _clean_bars(rows):
    out, seen = [], set()
    for r in rows or []:
        if not isinstance(r, dict):
            continue
        date = str(r.get('date') or r.get('dt') or '').strip()
        if not date or date in seen:
            continue
        close = abs(_f(r.get('close')))
        if close <= 0:
            continue
        seen.add(date)
        op = abs(_f(r.get('open'), close)) or close
        hi = abs(_f(r.get('high'), close)) or close
        lo = abs(_f(r.get('low'), close)) or close
        if hi < lo:
            hi, lo = lo, hi
        vol = max(0.0, _f(r.get('volume')))
        val = max(0.0, _f(r.get('value')))
        out.append({'date': date, 'open': op, 'high': hi, 'low': lo,
                    'close': close, 'volume': vol, 'value': val})
    out.sort(key=lambda x: x['date'])
    return out


def _median_positive(values, fallback=1.0):
    vals = [float(x) for x in values if _f(x) > 0]
    return statistics.median(vals) if vals else fallback


def _safe_ratio(a, b, default=0.0):
    return a / b if b and math.isfinite(a) and math.isfinite(b) else default


def _rmse(a, b):
    n = min(len(a), len(b))
    if n <= 0:
        return 9.0
    return math.sqrt(sum((a[i]-b[i])**2 for i in range(n))/n)


def _similarity(distance, decay=0.70):
    return max(0.0, min(100.0, 100.0 * math.exp(-decay * max(0.0, distance))))


def _event_feature(bars, end):
    """Return explainable metrics for one candidate reference candle."""
    if end < 60 or end >= len(bars):
        return None
    x = bars[end]
    prev = bars[end-1]
    prior20 = bars[end-20:end]
    prior60 = bars[end-60:end]
    if len(prior20) < 20 or len(prior60) < 60:
        return None

    close, op, hi, lo = x['close'], x['open'], x['high'], x['low']
    if min(close, op) <= 0:
        return None
    rng = max(hi-lo, close*1e-9)
    body_pct = (close/op - 1.0) * 100.0
    day_ret = (close/prev['close'] - 1.0) * 100.0 if prev['close'] else 0.0
    gap_pct = (op/prev['close'] - 1.0) * 100.0 if prev['close'] else 0.0
    close_pos = (close-lo)/rng
    upper_wick = max(0.0, hi-max(op, close))/rng
    lower_wick = max(0.0, min(op, close)-lo)/rng

    vol_base = _median_positive([b['volume'] for b in prior20], 1.0)
    vol_ratio = x['volume']/vol_base if vol_base else 0.0
    prior_values = [b['value'] for b in prior20 if b.get('value', 0) > 0]
    if x.get('value', 0) > 0 and prior_values:
        value_ratio = x['value']/_median_positive(prior_values, 1.0)
    else:
        value_ratio = 0.0

    ma5 = statistics.fmean(b['close'] for b in bars[end-4:end+1])
    ma20 = statistics.fmean(b['close'] for b in bars[end-19:end+1])
    ma60 = statistics.fmean(b['close'] for b in bars[end-59:end+1])
    old20 = bars[end-24:end-4]
    old_ma20 = statistics.fmean(b['close'] for b in old20) if len(old20) == 20 else ma20
    ma20_slope5 = ma20/old_ma20 - 1.0 if old_ma20 else 0.0

    hi20_prior = max(b['high'] for b in prior20)
    lo20_prior = min(b['low'] for b in prior20)
    pos20 = (close-lo20_prior)/(hi20_prior-lo20_prior) if hi20_prior > lo20_prior else 0.5
    ma20_dist = close/ma20 - 1.0 if ma20 else 0.0
    ma60_dist = close/ma60 - 1.0 if ma60 else 0.0

    pre = bars[end-PRE_PATTERN_BARS:end]
    pre_base = pre[0]['close'] if pre else prev['close']
    pre_shape = [b['close']/pre_base - 1.0 for b in pre] if pre_base else [0.0]*len(pre)
    pre5_ret = (prev['close']/pre[0]['close'] - 1.0) * 100.0 if pre and pre[0]['close'] else 0.0
    pre_rets = [(pre[i]['close']/pre[i-1]['close']-1.0) for i in range(1,len(pre)) if pre[i-1]['close']]
    pre_volatility = statistics.fmean(abs(v) for v in pre_rets) if pre_rets else 0.0

    # Baseline event definition: deliberately broad enough to produce useful
    # self-history samples while still representing a genuinely strong bullish bar.
    qualifies = (
        close > op and
        body_pct >= 2.0 and
        day_ret >= 2.0 and
        vol_ratio >= 1.50 and
        close_pos >= 0.60
    )

    # Reference-candle type. Types are used as a preference/bonus, not as a hard
    # exclusion, so sample size does not collapse.
    if close > hi20_prior:
        event_type = '전고점 돌파형'
    elif prev['close'] <= ma20 and close > ma20:
        event_type = '20일선 돌파형'
    elif pre5_ret <= 1.0 and close > ma20 and day_ret >= 3.0:
        event_type = '눌림 후 재돌파형'
    elif pre5_ret >= 8.0 or ma20_dist >= 0.12:
        event_type = '급등 연장형'
    else:
        event_type = '거래량 장대양봉형'

    strength = (
        min(30.0, max(0.0, body_pct)*4.0) +
        min(25.0, max(0.0, day_ret)*3.0) +
        min(25.0, max(0.0, vol_ratio-1.0)*12.5) +
        min(20.0, max(0.0, close_pos-0.5)*40.0)
    )

    # 5-day lead-in plus the anchor close, only for visualization / shape matching.
    shape_bars = bars[end-PRE_PATTERN_BARS:end+1]
    sb = shape_bars[0]['close'] if shape_bars else close
    display_shape = [b['close']/sb*100.0 for b in shape_bars] if sb else [100.0]

    return {
        'qualifies': qualifies,
        'event_type': event_type,
        'strength': strength,
        'body_pct': body_pct,
        'day_ret': day_ret,
        'gap_pct': gap_pct,
        'vol_ratio': vol_ratio,
        'value_ratio': value_ratio,
        'close_pos': close_pos,
        'upper_wick': upper_wick,
        'lower_wick': lower_wick,
        'ma20_dist': ma20_dist,
        'ma60_dist': ma60_dist,
        'ma20_slope5': ma20_slope5,
        'pos20': pos20,
        'pre5_ret': pre5_ret,
        'pre_volatility': pre_volatility,
        'pre_shape': pre_shape,
        'display_shape': display_shape,
    }


def _find_current_anchor(bars):
    """Use the latest qualifying strong bullish candle within three sessions."""
    latest = len(bars)-1
    for end in range(latest, max(59, latest-LOOKBACK_ANCHOR), -1):
        f = _event_feature(bars, end)
        if f and f['qualifies']:
            return end, f
    return None, None


def _event_distance(a, b):
    # Reference candle itself carries most of the meaning.
    body = min(3.0, abs(a['body_pct']-b['body_pct'])/4.0)
    ret = min(3.0, abs(a['day_ret']-b['day_ret'])/4.5)
    vol = min(3.0, abs(math.log1p(a['vol_ratio'])-math.log1p(b['vol_ratio']))/0.48)
    cpos = min(3.0, abs(a['close_pos']-b['close_pos'])/0.22)
    wick = min(3.0, abs(a['upper_wick']-b['upper_wick'])/0.22)
    gap = min(3.0, abs(a['gap_pct']-b['gap_pct'])/3.5)
    value = 0.0
    if a['value_ratio'] > 0 and b['value_ratio'] > 0:
        value = min(3.0, abs(math.log1p(a['value_ratio'])-math.log1p(b['value_ratio']))/0.55)
    return 0.22*body + 0.18*ret + 0.22*vol + 0.13*cpos + 0.10*wick + 0.08*gap + 0.07*value


def _setup_distance(a, b):
    # What happened during the five sessions before the reference candle.
    shape = min(3.0, _rmse(a['pre_shape'], b['pre_shape'])/0.045)
    ret = min(3.0, abs(a['pre5_ret']-b['pre5_ret'])/8.0)
    vol = min(3.0, abs(a['pre_volatility']-b['pre_volatility'])/0.025)
    return 0.60*shape + 0.25*ret + 0.15*vol


def _context_distance(a, b):
    ma20 = min(3.0, abs(a['ma20_dist']-b['ma20_dist'])/0.09)
    ma60 = min(3.0, abs(a['ma60_dist']-b['ma60_dist'])/0.14)
    slope = min(3.0, abs(a['ma20_slope5']-b['ma20_slope5'])/0.04)
    pos = min(3.0, abs(a['pos20']-b['pos20'])/0.30)
    return 0.34*ma20 + 0.22*ma60 + 0.22*slope + 0.22*pos


def _score_pair(current, past):
    ed = _event_distance(current, past)
    sd = _setup_distance(current, past)
    cd = _context_distance(current, past)
    event_sim = _similarity(ed, 0.62)
    setup_sim = _similarity(sd, 0.62)
    context_sim = _similarity(cd, 0.58)
    overall = 0.60*event_sim + 0.25*setup_sim + 0.15*context_sim
    if current['event_type'] == past['event_type']:
        overall = min(100.0, overall + 3.0)
    return event_sim, setup_sim, context_sim, overall


def _first_hit(future, base, up_pct, down_pct):
    up_px, dn_px = base*(1+up_pct), base*(1-down_pct)
    for day, x in enumerate(future, 1):
        up, dn = x['high'] >= up_px, x['low'] <= dn_px
        if up and dn:
            return {'result':'same_day','day':day}
        if up:
            return {'result':'up','day':day}
        if dn:
            return {'result':'down','day':day}
    return {'result':'neither','day':None}


def _outcome(bars, end):
    if end + MAX_HORIZON >= len(bars):
        return None
    base = bars[end]['close']
    future = bars[end+1:end+MAX_HORIZON+1]
    if base <= 0 or len(future) < MAX_HORIZON:
        return None
    def cr(n):
        return (future[n-1]['close']/base - 1.0)*100.0
    max_up = (max(x['high'] for x in future)/base - 1.0)*100.0
    max_dn = (min(x['low'] for x in future)/base - 1.0)*100.0
    future_shape = [100.0] + [x['close']/base*100.0 for x in future]
    return {
        'r1':cr(1),'r3':cr(3),'r5':cr(5),
        'max_up5':max_up,'max_down5':max_dn,
        'hit_up4':any(x['high'] >= base*1.04 for x in future),
        'hit_dn3':any(x['low'] <= base*0.97 for x in future),
        'first_4_3':_first_hit(future,base,0.04,0.03),
        'future_shape':future_shape,
    }


def _avg(rows, key):
    vals=[x['outcome'][key] for x in rows if x.get('outcome') and key in x['outcome']]
    return statistics.fmean(vals) if vals else None


def _pct_pos(rows, key):
    vals=[x['outcome'][key] for x in rows if x.get('outcome') and key in x['outcome']]
    return sum(1 for v in vals if v>0)/len(vals)*100.0 if vals else None


def _first_hit_stats(rows):
    counts={'up':0,'down':0,'same_day':0,'neither':0}
    up_days,down_days=[],[]
    for row in rows:
        info=(row.get('outcome') or {}).get('first_4_3') or {}
        result=info.get('result')
        if result not in counts:
            result='neither'
        counts[result]+=1
        day=info.get('day')
        if isinstance(day,(int,float)):
            if result=='up': up_days.append(float(day))
            elif result=='down': down_days.append(float(day))
    n=max(1,sum(counts.values()))
    return {
        'up_pct':counts['up']/n*100.0,
        'down_pct':counts['down']/n*100.0,
        'same_day_pct':counts['same_day']/n*100.0,
        'neither_pct':counts['neither']/n*100.0,
        'up_avg_day':statistics.fmean(up_days) if up_days else None,
        'down_avg_day':statistics.fmean(down_days) if down_days else None,
    }


def _interpret(stats, first, similarity, n):
    up, down, same = first['up_pct'], first['down_pct'], first['same_day_pct']
    max_up = stats.get('avg_max_up_5d') or 0.0
    max_dn = abs(stats.get('avg_max_down_5d') or 0.0)
    if same >= 18.0 or (max_up >= 7 and max_dn >= 6 and abs(up-down)<18):
        label='고변동'
        detail='기준봉 이후 상·하방 흔들림이 모두 큰 과거 사례가 많았습니다.'
    elif up-down >= 15:
        label='상승 우세'
        detail='+4%가 -3%보다 먼저 나온 기준봉 사례가 뚜렷하게 많았습니다.'
    elif down-up >= 15:
        label='하방 위험'
        detail='-3%가 +4%보다 먼저 나온 기준봉 사례가 뚜렷하게 많았습니다.'
    else:
        label='중립'
        detail='기준봉 이후 선도달 우위가 뚜렷하지 않습니다.'
    if similarity >= 82 and n >= 12:
        quality='높음'
    elif similarity >= 74 and n >= 8:
        quality='보통'
    elif similarity >= 65 and n >= 6:
        quality='낮음'
    else:
        quality='매우 낮음'
    if n < 8:
        detail += ' 자기 종목의 과거 기준봉 표본이 적어 통계 신뢰도는 낮게 보세요.'
    return {'label':label,'detail':detail,'match_quality':quality}


def analyze(target_code, target_name, target_sector, target_bars, loaded_stocks=None, cache_file=None, max_matches=60):
    bars=_clean_bars(target_bars)
    if len(bars) < 100:
        raise ValueError('기준봉 이벤트 분석에 필요한 자기 종목 일봉 데이터가 부족합니다.')

    anchor_end, current = _find_current_anchor(bars)
    if current is None:
        raise ValueError('최근 3거래일 안에 강한 거래량·양봉 기준봉이 없습니다. 기준: 양봉 몸통 2%+, 전일 대비 2%+, 거래량 20일 중앙값의 1.5배+, 종가가 당일 범위 상단 40% 이내입니다.')

    current_date=bars[-1]['date']
    anchor_date=bars[anchor_end]['date']
    anchor_age=len(bars)-1-anchor_end

    candidates=[]
    # Leave enough room before the active area and enough future bars for outcome.
    for end in range(60, len(bars)-MAX_HORIZON):
        if end >= anchor_end-7:
            continue
        f=_event_feature(bars,end)
        if not f or not f['qualifies']:
            continue
        out=_outcome(bars,end)
        if not out:
            continue
        event_sim,setup_sim,context_sim,overall=_score_pair(current,f)
        candidates.append({
            'end':end,'date':bars[end]['date'],'feature':f,'outcome':out,
            'event_similarity':event_sim,'setup_similarity':setup_sim,
            'context_similarity':context_sim,'similarity':overall,
            'shape':f['display_shape'],
        })
    candidates.sort(key=lambda x:(-x['similarity'],x['date']))

    # De-cluster repeated events from the same swing.
    dedup=[]; picked=[]
    for row in candidates:
        if any(abs(row['end']-e)<7 for e in picked):
            continue
        picked.append(row['end']); dedup.append(row)

    same_type=[x for x in dedup if x['feature']['event_type']==current['event_type'] and x['similarity']>=58 and x['event_similarity']>=60]
    broad=[x for x in dedup if x['similarity']>=60 and x['event_similarity']>=60]
    relaxed=[x for x in dedup if x['similarity']>=55 and x['event_similarity']>=55]
    limit=min(MAX_MATCHES,int(max_matches or MAX_MATCHES),30)

    if len(same_type)>=MIN_CORE_SAMPLE:
        selected=same_type[:limit]; mode=f'동일 유형 우선 · {current["event_type"]}'
        threshold=58.0
    elif len(broad)>=MIN_CORE_SAMPLE:
        selected=broad[:limit]; mode='강한 기준봉 유사도 60%+'
        threshold=60.0
    else:
        selected=relaxed[:limit]; mode='표본 보강 · 강한 기준봉 유사도 55%+'
        threshold=55.0

    if not selected:
        raise ValueError('이 종목의 과거에서 현재 기준봉과 비교할 수 있는 강한 양봉·거래량 이벤트를 찾지 못했습니다.')

    n=len(selected)
    stats={
        'count':n,
        'positive_1d':_pct_pos(selected,'r1'),
        'positive_3d':_pct_pos(selected,'r3'),
        'positive_5d':_pct_pos(selected,'r5'),
        'avg_return_1d':_avg(selected,'r1'),
        'avg_return_3d':_avg(selected,'r3'),
        'avg_return_5d':_avg(selected,'r5'),
        'hit_plus4_5d':sum(1 for x in selected if x['outcome']['hit_up4'])/n*100.0,
        'hit_minus3_5d':sum(1 for x in selected if x['outcome']['hit_dn3'])/n*100.0,
        'avg_max_up_5d':_avg(selected,'max_up5'),
        'avg_max_down_5d':_avg(selected,'max_down5'),
    }
    first=_first_hit_stats(selected)
    core=selected[:min(10,n)]
    core_similarity=statistics.fmean(x['similarity'] for x in core)
    core_event_similarity=statistics.fmean(x['event_similarity'] for x in core)
    core_setup_similarity=statistics.fmean(x['setup_similarity'] for x in core)
    core_context_similarity=statistics.fmean(x['context_similarity'] for x in core)
    interpretation=_interpret(stats,first,core_similarity,n)

    top=[]
    for x in selected[:5]:
        f=x['feature']; o=x['outcome']
        top.append({
            'code':target_code,'name':target_name or target_code,'date':x['date'],
            'event_type':f['event_type'],
            'similarity':round(x['similarity'],1),
            'event_similarity':round(x['event_similarity'],1),
            'setup_similarity':round(x['setup_similarity'],1),
            'context_similarity':round(x['context_similarity'],1),
            'body_pct':round(f['body_pct'],2),'day_ret':round(f['day_ret'],2),
            'volume_ratio':round(f['vol_ratio'],2),'close_pos':round(f['close_pos']*100,1),
            'return_1d':round(o['r1'],2),'return_3d':round(o['r3'],2),'return_5d':round(o['r5'],2),
            'max_up_5d':round(o['max_up5'],2),'max_down_5d':round(o['max_down5'],2),
            'first_4_3':o['first_4_3'],
            'shape':[round(v,3) for v in x['shape']],
            'future_shape':[round(v,3) for v in o['future_shape']],
        })

    return {
        'version':8,
        'comparison_scope':'self_reference_candle',
        'code':target_code,'name':target_name or target_code,'sector':target_sector or '',
        'asof':current_date,'anchor_date':anchor_date,'anchor_age':anchor_age,
        'anchor_type':current['event_type'],
        'anchor_metrics':{
            'body_pct':round(current['body_pct'],2),
            'day_ret':round(current['day_ret'],2),
            'volume_ratio':round(current['vol_ratio'],2),
            'value_ratio':round(current['value_ratio'],2),
            'close_pos':round(current['close_pos']*100,1),
            'gap_pct':round(current['gap_pct'],2),
            'ma20_dist_pct':round(current['ma20_dist']*100,2),
            'pre5_ret':round(current['pre5_ret'],2),
        },
        'pattern_days':PRE_PATTERN_BARS+1,
        'context_days':CONTEXT_BARS,
        'history_bars':len(bars),
        'candidate_events':len(candidates),'dedup_events':len(dedup),
        'same_type_count':len(same_type),'broad_count':len(broad),'relaxed_count':len(relaxed),
        'similarity_threshold':threshold,'selection_mode':mode,
        'stats':{k:(None if v is None else round(v,2)) for k,v in stats.items()},
        'first_hit_4_3':{k:(None if v is None else round(v,2)) for k,v in first.items()},
        'core_similarity':round(core_similarity,2),
        'core_event_similarity':round(core_event_similarity,2),
        'core_setup_similarity':round(core_setup_similarity,2),
        'core_context_similarity':round(core_context_similarity,2),
        'interpretation':interpretation,
        'current_shape':[round(v,3) for v in current['display_shape']],
        'top_matches':top,
        'limited':n<MIN_CORE_SAMPLE,
        'scope_note':f'{target_name or target_code} 자기 종목의 과거 강한 기준봉만 비교합니다. 현재 기준봉은 {anchor_date} {current["event_type"]}이며, 기준봉 자체 60% + 직전 5일 흐름 25% + 20일 환경 15%로 유사도를 계산합니다.',
        'performance_note':'버튼을 눌렀을 때 해당 종목 일봉 1개만 분석합니다. 실시간 호가·체결·검색기·웹소켓 루프에는 추가 작업이 없습니다.',
    }
