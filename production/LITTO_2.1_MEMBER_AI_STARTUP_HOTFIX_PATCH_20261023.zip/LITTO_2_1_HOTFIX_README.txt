LITTO 2.1 MEMBER HOTFIX - 2026-10-23

Root-cause: original v2.1 patch included app.py but omitted litto_bounded_http.py and other AI/runtime modules.
This hotfix includes all critical root Python runtime modules from the 2.1 member full candidate plus chart/UI changes.
DOES NOT include: member account, DB, personal preferences, LITTO.exe or updater.
IMPORTANT: LITTO.exe is still the pre-existing binary; runtime feature compatibility needs a Windows member-PC test.
Deployment: back up original member install, stop LITTO completely; upload this ZIP to repo and update production/manifest.json with new URL & SHA256.
Do not add to an already-running process.
