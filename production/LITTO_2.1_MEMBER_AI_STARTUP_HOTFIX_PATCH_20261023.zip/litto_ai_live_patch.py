"""Strict hot reload for ONLY the local AI developer-intent classifier.

Reject any other source change. Do not import/reload the full app, order engine,
or anything else.  Call only after a user's explicit approval.
"""
import ast
from pathlib import Path

TARGET = '_ai_dev_requested'


def _extract_changed_function(before: bytes, after: bytes):
    prior = ast.parse(before.decode('utf-8'), filename='app.py')
    fresh = ast.parse(after.decode('utf-8'), filename='app.py')
    old_funcs = [node for node in prior.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == TARGET]
    new_funcs = [node for node in fresh.body if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == TARGET]
    if len(old_funcs) != 1 or len(new_funcs) != 1 or not isinstance(new_funcs[0], ast.FunctionDef):
        raise ValueError('AI 명령 인식 함수 구조가 달라졌어. 재시작 적용만 가능해.')
    if new_funcs[0].decorator_list:
        raise ValueError('데코레이터 변경은 실시간 반영 불가')
    old_copy = ast.parse(before.decode('utf-8'))
    new_copy = ast.parse(after.decode('utf-8'))
    for tree in (old_copy, new_copy):
        tree.body = [item for item in tree.body if not (isinstance(item, (ast.FunctionDef, ast.AsyncFunctionDef)) and item.name == TARGET)]
    if ast.dump(old_copy, include_attributes=False) != ast.dump(new_copy, include_attributes=False):
        raise ValueError('app.py의 AI 명령 인식 함수 외 코드가 변경돼 실시간 적용을 거부했어.')
    return new_funcs[0]


def eligible(filename, before, after):
    if filename != 'app.py':
        return False
    try:
        _extract_changed_function(before, after)
        return True
    except (ValueError, SyntaxError, UnicodeDecodeError):
        return False


def install(app_globals: dict, new_bytes: bytes, validation="forward"):
    tree = ast.parse(new_bytes.decode('utf-8'), filename='app.py')
    nodes = [n for n in tree.body if isinstance(n, ast.FunctionDef) and n.name == TARGET]
    if len(nodes) != 1 or nodes[0].decorator_list:
        raise ValueError('핫 리로드 대상이 올바르지 않아.')
    node = nodes[0]
    mod = ast.Module(body=[node], type_ignores=[])
    ast.fix_missing_locations(mod)
    scope = {'__builtins__': __builtins__, 're': __import__('re')}
    exec(compile(mod, '<litto-ai-hot-reload>', 'exec'), scope)
    new_fn = scope[TARGET]
    # Test both positive and negative prompts before modifying current session.
    # Some valid classifiers may have different target conditions; use actual real target.
    if new_fn('라이또 프로그램 오류 고쳐줘') is not True:
        raise ValueError('개발 명령 정상 인식 테스트 실패')
    if validation == 'forward' and new_fn('라이또 오류 수정하지 마') is not False:
        raise ValueError('수정 금지 명령 차단 테스트 실패')
    if new_fn('오늘 종목 분석해줘') is not False:
        raise ValueError('일반 대화 명령 격리 테스트 실패')
    app_globals[TARGET] = new_fn
    return {'hot_reloaded': True, 'target': TARGET, 'checks': ['positive_command', 'negated_command', 'ordinary_chat']}
