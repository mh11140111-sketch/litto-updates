"""Kiwoom domestic real-time stock trade feed (0B).

Read-only WebSocket overlay for LITTO.  The REST scanner remains authoritative for
rank/universe selection; this module only keeps live trade fields warm between rank
refreshes.
"""
from __future__ import annotations
import json, socket, threading, time
from datetime import datetime, timezone
from us_realtime import _WebSocket


def _num(v):
    try:
        if v is None or v == '': return None
        return float(str(v).replace(',', '').replace('+', '').strip())
    except Exception:
        return None


def _base_code(v):
    s=str(v or '').strip().upper()
    for suf in ('_AL','_NX'):
        if s.endswith(suf): s=s[:-len(suf)]
    digits=''.join(ch for ch in s if ch.isdigit())
    return digits[-6:] if len(digits)>=6 else s[-6:]


def _kr_market_window():
    # KST without requiring an additional timezone database dependency.
    now=datetime.utcfromtimestamp(time.time()+9*3600)
    if now.weekday()>=5:return False
    hm=now.hour*60+now.minute
    return 480 <= hm < 1210  # 08:00~20:10, NXT premarket through NXT after-hours


def _kst_date():
    return datetime.utcfromtimestamp(time.time()+9*3600).strftime('%Y%m%d')

def _trade_feed_stall_watch_window(kst_now):
    """Only inspect missing trade ticks during active, liquid trading windows.

    The premarket starts at 08:00. Do not assume a tick stream is continuously
    active during the NXT/KRX handover or on weekends. This does not initiate
    polling or perform any network request.
    """
    if kst_now.weekday() >= 5:
        return False
    minutes = kst_now.hour * 60 + kst_now.minute
    return (480 <= minutes < 530) or (545 <= minutes < 920)




class DomesticRealtimeFeed:
    """Background Kiwoom 0B(주식체결) subscriber for selected domestic symbols."""
    URL='wss://api.kiwoom.com:10000/api/dostk/websocket'

    def __init__(self, kiwoom):
        self.kiwoom=kiwoom
        self.lock=threading.RLock(); self.desired=[]; self.version=0
        # Multiple LITTO screens share one Kiwoom 0B socket.  Keep each caller's
        # desired set separately and subscribe to their union, otherwise Page-1,
        # watchlist and account refreshes can repeatedly replace one another's REG.
        self.owners={}
        self.quotes={}; self.thread=None; self.stop_event=threading.Event()
        self.state='대기'; self.error=''; self.connected=False
        self.last_message=0.0; self.last_frame=0.0; self.raw_sample=None; self.reconnects=0; self.started_at=time.time(); self.session_date=_kst_date()

    def ensure(self, symbols, owner='default'):
        today=_kst_date()
        with self.lock:
            if today!=self.session_date:
                self.session_date=today; self.quotes={}; self.last_message=0.0
        clean=[]; seen=set()
        for x in symbols or []:
            c=_base_code(x)
            if c and c not in seen:
                seen.add(c); clean.append(c)
        key=str(owner or 'default')[:40]
        with self.lock:
            self.owners[key]=clean[:160]
            # Stable priority keeps foreground watch/account symbols warm first,
            # then Page-1/leader candidates.  Total remains below the existing
            # 160-symbol safety cap used by this feed.
            priority=('watch','account','page1','leader','default')
            ordered=[]; merged=set()
            for k in priority:
                for c in self.owners.get(k,[]):
                    if c not in merged:
                        merged.add(c); ordered.append(c)
            for k,vals in self.owners.items():
                if k in priority: continue
                for c in vals:
                    if c not in merged:
                        merged.add(c); ordered.append(c)
            wanted=ordered[:160]
            if wanted != self.desired:
                self.desired=wanted; self.version+=1
                keep=set(self.desired); self.quotes={k:v for k,v in self.quotes.items() if k in keep}
            if not self.thread or not self.thread.is_alive():
                self.stop_event.clear()
                self.thread=threading.Thread(target=self._run,daemon=True,name='LITTO-KR-0B')
                self.thread.start()

    def stop(self): self.stop_event.set()

    def snapshot(self):
        now=time.time()
        with self.lock:
            q=dict(self.quotes); desired=list(self.desired)
            stale=sum(1 for c in desired if c not in q or now-float((q.get(c) or {}).get('received_at') or 0)>15)
            fresh=sum(1 for c in desired if c in q and now-float((q.get(c) or {}).get('received_at') or 0)<=15)
            return q, {
                'connected':self.connected,'state':self.state,'error':self.error,
                'subscribed':len(desired),'live_count':len(q),'fresh_count':fresh,'stale_count':stale,
                'last_message':datetime.fromtimestamp(self.last_message,timezone.utc).isoformat() if self.last_message else None,
                'last_message_age':(now-self.last_message) if self.last_message else None,
                'last_frame_age':(now-self.last_frame) if self.last_frame else None,
                'last_quote_age':(now-self.last_message) if self.last_message else None,
                'reconnects':self.reconnects,
                'transport':'Kiwoom WebSocket 0B · SOR(_AL) 주식체결'
            }

    def _set_state(self,state,error='',connected=None):
        with self.lock:
            self.state=state; self.error=str(error or '')[:300]
            if connected is not None:self.connected=bool(connected)

    def _register(self,ws,symbols):
        if not symbols:return
        # 0B is Kiwoom's official domestic stock execution realtime type.
        # In live mode subscribe with the provider's integrated SOR code (_AL),
        # so the same stream can follow KRX + NXT (pre/main/after) executions.
        # Mock only supports KRX, so keep plain six-digit codes there.
        use_mock=bool(getattr(self.kiwoom,'mock',False))
        items=[c if use_mock else f'{c}_AL' for c in symbols]
        # refresh=0 replaces this group's old registrations; this prevents stale
        # symbols accumulating whenever the Page-1/watchlist universe changes.
        ws.send_json({'trnm':'REG','grp_no':'7','refresh':'0','data':[{'item':items,'type':['0B']}]})

    def _handle(self,msg):
        if not isinstance(msg,dict) or msg.get('trnm')!='REAL': return
        rows=msg.get('data') or []
        if not isinstance(rows,list): return
        with self.lock: known=set(self.desired)
        for row in rows:
            if not isinstance(row,dict) or str(row.get('type') or '').upper()!='0B': continue
            vals=row.get('values') or {}
            if not isinstance(vals,dict): continue
            c=_base_code(row.get('item') or vals.get('9001') or vals.get('stk_cd'))
            if c not in known: continue
            # Official common realtime FIDs: 10 price, 12 rate, 13 accumulated volume,
            # 14 accumulated trading value, 15 tick volume, 20 execution time.
            price=_num(vals.get('10') if '10' in vals else vals.get('cur_prc'))
            rate=_num(vals.get('12') if '12' in vals else vals.get('flu_rt'))
            acc_vol=_num(vals.get('13') if '13' in vals else vals.get('acc_trde_qty'))
            acc_value=_num(vals.get('14') if '14' in vals else vals.get('acc_trde_prica'))
            tick_vol=_num(vals.get('15') if '15' in vals else vals.get('cntr_trde_qty'))
            # 0B also carries today's open/high/low.  Keeping these fields in the
            # live overlay lets 하트존/피뢰침/끼도주 recalculate locally without
            # re-running the heavy REST scanner for every tick.
            open_p=_num(vals.get('16') if '16' in vals else vals.get('open_pric'))
            high_p=_num(vals.get('17') if '17' in vals else vals.get('high_pric'))
            low_p=_num(vals.get('18') if '18' in vals else vals.get('low_pric'))
            tm=str(vals.get('20') or vals.get('cntr_tm') or '')
            if price is not None: price=abs(price)
            if open_p is not None: open_p=abs(open_p)
            if high_p is not None: high_p=abs(high_p)
            if low_p is not None: low_p=abs(low_p)
            raw_item=str(row.get('item') or vals.get('9001') or vals.get('stk_cd') or '')
            venue='SOR' if raw_item.upper().endswith('_AL') else ('NXT' if raw_item.upper().endswith('_NX') else 'KRX')
            q={'code':c,'price':price,'change_rate':rate,'acc_volume':acc_vol,
               'acc_value':acc_value,'tick_volume':tick_vol,'time':tm,
               'open':open_p,'high':high_p,'low':low_p,
               'market_item':raw_item,'venue':venue,'session_date':_kst_date(),
               'source':'websocket_0B','received_at':time.time()}
            with self.lock:
                self.quotes[c]=q; self.last_message=time.time()
                self.raw_sample={'item':row.get('item'),'keys':sorted(vals.keys())[:80],'type':row.get('type')}

    def _run(self):
        backoff=1.0
        while not self.stop_event.is_set():
            ws=None
            try:
                self.kiwoom.auth(); token=self.kiwoom.token
                self._set_state('연결 중',connected=False)
                ws=_WebSocket(self.URL,5.0); ws.connect()
                ws.send_json({'trnm':'LOGIN','token':token})
                logged=False; deadline=time.time()+8
                while time.time()<deadline and not self.stop_event.is_set():
                    try:text=ws.recv_text()
                    except socket.timeout:continue
                    msg=json.loads(text)
                    with self.lock:self.last_frame=time.time()
                    if msg.get('trnm')=='PING': ws.send_json(msg); continue
                    if msg.get('trnm')=='LOGIN':
                        if str(msg.get('return_code','0'))!='0': raise OSError('Kiwoom domestic WebSocket LOGIN rejected')
                        logged=True; break
                if not logged: raise OSError('Kiwoom domestic WebSocket LOGIN timeout')
                with self.lock: symbols=list(self.desired); reg_version=self.version
                self._register(ws,symbols)
                self._set_state('실시간 연결',connected=True); backoff=1.0
                connected_since=time.time()
                while not self.stop_event.is_set():
                    with self.lock:
                        changed=self.version!=reg_version; symbols=list(self.desired); cur_ver=self.version
                    if changed:
                        self._register(ws,symbols); reg_version=cur_ver
                    try:text=ws.recv_text()
                    except socket.timeout:
                        with self.lock:
                            silent=(time.time()-self.last_frame) if self.last_frame else (time.time()-self.started_at)
                            wanted=bool(self.desired)
                        if wanted and _kr_market_window() and silent>45:
                            raise OSError('Kiwoom WebSocket frame stale >45s')
                        # PING frames alone can keep the socket alive even when
                        # execution quotes have stopped. Avoid churn for one
                        # quiet symbol; require at least 3 subscribed symbols
                        # and a full 120 s observation window during the
                        # liquid part of the regular session only.
                        with self.lock:
                            quote_age=time.time()-max(self.last_message,connected_since)
                            monitored=len(self.desired)
                        kst_now=datetime.utcfromtimestamp(time.time()+9*3600)
                        trade_active=_trade_feed_stall_watch_window(kst_now)
                        if monitored>=10 and trade_active and quote_age>120:
                            raise OSError('Kiwoom WebSocket 0B quotes stale >120s (PING-only)')
                        continue
                    msg=json.loads(text)
                    with self.lock:self.last_frame=time.time()
                    if msg.get('trnm')=='PING': ws.send_json(msg); continue
                    if msg.get('trnm')=='REG' and str(msg.get('return_code','0'))!='0':
                        raise OSError('Kiwoom 0B REG rejected: '+str(msg.get('return_msg') or ''))
                    self._handle(msg)
            except Exception as e:
                with self.lock:self.reconnects+=1
                self._set_state('재연결 대기',str(e),False)
                if self.stop_event.wait(backoff): break
                backoff=min(backoff*2,15.0)
            finally:
                if ws: ws.close()
        self._set_state('중지',connected=False)
