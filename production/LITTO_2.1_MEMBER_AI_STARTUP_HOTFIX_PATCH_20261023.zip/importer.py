import csv,io,json
from datetime import datetime
from engine import KST,code

def parse_file(text,kind,asof=None):
    if kind=='json':
        data=json.loads(text)
        if not isinstance(data,dict):raise ValueError('JSON 최상위는 객체여야 합니다.')
        data['mode']='import' # uploaded data cannot impersonate live or demo
        return data
    if kind!='csv':raise ValueError('JSON 또는 CSV 파일을 사용하세요.')
    rows=csv.DictReader(io.StringIO(text.lstrip('\ufeff')))
    required={'code','name','timeframe','time','open','high','low','close','volume','value'}
    if not required.issubset(rows.fieldnames or []):raise ValueError('CSV 열 필요: '+', '.join(sorted(required)))
    stocks={};latest=None
    for r in rows:
        c=code(r['code']);s=stocks.setdefault(c,{'code':c,'name':r['name'],'sector':r.get('sector') or '미분류','daily':[],'m15':[]})
        if (r.get('product_type') or '').upper()=='ETF':s['etf']=True
        tf=r['timeframe'].strip()
        b={k:r[k] for k in ('open','high','low','close','volume','value')}
        if r.get('limit_up_price'):b['limit_up_price']=r['limit_up_price']
        if tf=='D':
            b['date']=r['time'][:10];s['daily'].append(b)
        elif tf=='15':
            b['time']=r['time'];b['complete']=r.get('complete','true').lower() not in ('false','0','n');s['m15'].append(b)
        else:raise ValueError('timeframe은 D 또는 15입니다.')
        latest=max(latest or '',r['time'][:10])
    if not stocks:raise ValueError('빈 파일입니다.')
    # Explicitly describe imported historical end-of-day assumption; UI shows the time.
    return {'mode':'import','asof':asof or latest+'T15:30:00+09:00','scope':'CSV 업로드 · 조회시각 미입력 시 마지막 날짜 15:30 가정','stocks':list(stocks.values())}
