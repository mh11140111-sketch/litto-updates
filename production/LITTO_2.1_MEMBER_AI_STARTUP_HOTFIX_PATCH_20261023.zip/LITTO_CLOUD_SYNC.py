"""Optional, out-of-process Google Drive sync for LITTO R58.13.
Requires rclone executable and an already configured Drive remote.
Never modifies LITTO source code or trades/market data.
"""
import argparse
from contextlib import closing
import hashlib
import json
import os
import shutil
import socket
import sqlite3
import subprocess
import sys
import tempfile
import time
from pathlib import Path
from litto_memory_storage import prepare_db, device_id

SCHEMA_MEMORY = '''CREATE TABLE IF NOT EXISTS memory(id INTEGER PRIMARY KEY AUTOINCREMENT,mkey TEXT NOT NULL,value TEXT NOT NULL,kind TEXT NOT NULL DEFAULT 'preference',confidence REAL NOT NULL DEFAULT 1.0,created_at REAL NOT NULL,updated_at REAL NOT NULL,UNIQUE(mkey,kind))'''
SCHEMA_EPISODE = '''CREATE TABLE IF NOT EXISTS episode(id INTEGER PRIMARY KEY AUTOINCREMENT,ts REAL NOT NULL,user_msg TEXT NOT NULL,assistant_msg TEXT NOT NULL,model TEXT,tools_json TEXT,actions_json TEXT,context_json TEXT)'''

def run_rclone(args):
    executable=shutil.which('rclone') or str(Path(__file__).resolve().parent / ('rclone.exe' if os.name == 'nt' else 'rclone'))
    if not Path(executable).is_file() and not shutil.which(executable):
        executable=None
    if not executable:
        raise RuntimeError('rclone 프로그램이 없습니다. https://rclone.org/downloads/ 설치 후 rclone config에서 Google Drive remote를 구성하세요.')
    cmd=[executable,*args]
    p=subprocess.run(cmd,capture_output=True,text=True,encoding='utf-8',errors='replace')
    if p.returncode:
        raise RuntimeError(f'rclone 실패 ({p.returncode}): {(p.stderr or p.stdout)[-900:]}')
    return p.stdout

def snapshot(db_path,dest):
    if not db_path.is_file():
        raise RuntimeError(f'라이또 AI 기억 DB 없음: {db_path}')
    src=sqlite3.connect(str(db_path),timeout=10)
    try:
        with closing(sqlite3.connect(str(dest),timeout=10)) as dst:
            src.backup(dst)
    finally: src.close()

def merge_db(target, remote_files):
    count_mem=count_eps=0
    with closing(sqlite3.connect(str(target),timeout=15)) as out, out:
        out.execute(SCHEMA_MEMORY);out.execute(SCHEMA_EPISODE)
        # Explicit user memory: newest timestamp wins. Never remove memory omitted by another PC.
        for db in remote_files:
            with closing(sqlite3.connect(str(db),timeout=10)) as src:
                try: memories=src.execute('SELECT mkey,value,kind,confidence,created_at,updated_at FROM memory').fetchall()
                except sqlite3.OperationalError: memories=[]
                for m in memories:
                    cur=out.execute('''INSERT INTO memory(mkey,value,kind,confidence,created_at,updated_at)
                        VALUES(?,?,?,?,?,?) ON CONFLICT(mkey,kind) DO UPDATE SET
                        value=excluded.value,confidence=excluded.confidence,updated_at=excluded.updated_at
                        WHERE excluded.updated_at > memory.updated_at''',m)
                    count_mem+=cur.rowcount
                try: episodes=src.execute('SELECT ts,user_msg,assistant_msg,model,tools_json,actions_json,context_json FROM episode').fetchall()
                except sqlite3.OperationalError: episodes=[]
                # Deduplicate by content (source DB autoincrement IDs are PC-local).
                known={hashlib.sha256(json.dumps(r,ensure_ascii=False,default=str).encode()).hexdigest()
                       for r in out.execute('SELECT ts,user_msg,assistant_msg,model,tools_json,actions_json,context_json FROM episode')}
                for e in episodes:
                    key=hashlib.sha256(json.dumps(e,ensure_ascii=False,default=str).encode()).hexdigest()
                    if key not in known:
                        out.execute('INSERT INTO episode(ts,user_msg,assistant_msg,model,tools_json,actions_json,context_json) VALUES(?,?,?,?,?,?,?)',e)
                        known.add(key);count_eps+=1
        out.execute('DELETE FROM episode WHERE id NOT IN (SELECT id FROM episode ORDER BY ts DESC,id DESC LIMIT 1500)')
    return count_mem,count_eps

def sync(args):
    root=Path(args.litto).resolve()
    db=prepare_db(root)
    if not (root/'litto_pdf_knowledge.py').is_file():
        raise RuntimeError('지정 폴더가 라이또 R58.13 소스 폴더가 아닙니다.')
    remote=args.remote.rstrip('/')
    if ':' not in remote or remote.startswith(':'):
        raise RuntimeError('remote는 gdrive:LITTO_AI_MEMORY 형식으로 지정하세요.')
    local=Path(args.local).expanduser().resolve()
    local.mkdir(parents=True,exist_ok=True)
    # Never use sync/delete: preserve all remote and local PDFs.
    print('1/5 구글 드라이브 PDF 및 색인 내려받기...')
    run_rclone(['copy', remote, str(local),'--include','*.pdf','--include','.litto_library/**',
                '--exclude','**','--ignore-existing','--transfers','2','--checkers','2'])
    print('2/5 로컬 PDF 및 색인 업로드...')
    run_rclone(['copy', str(local), remote,'--include','*.pdf','--include','.litto_library/**',
                '--exclude','**','--ignore-existing','--transfers','2','--checkers','2'])
    # Memory snapshots are immutable per PC per invocation; keep last N using rclone separately.
    device=device_id()
    with tempfile.TemporaryDirectory(prefix='litto_cloud_') as td:
        work=Path(td)
        snapshot_file=work/(device+'.sqlite3')
        print('3/5 로컬 AI 기억 안전 백업...')
        snapshot(db,snapshot_file)
        print('4/5 다른 PC의 AI 기억 다운로드 및 병합...')
        snaps=work/'remote';snaps.mkdir()
        run_rclone(['mkdir', remote+'/_litto_ai_sync/devices'])
        run_rclone(['copy',remote+'/_litto_ai_sync/devices',str(snaps),'--include','*.sqlite3','--transfers','2','--checkers','2'])
        files=list(snaps.glob('*.sqlite3'))
        if files:
            m,e=merge_db(db,files)
            print(f'    기억 반영 {m}건, 대화 병합 {e}건')
        snapshot(db,snapshot_file)
        print('5/5 병합된 기억 업로드...')
        run_rclone(['copyto',str(snapshot_file),remote+'/_litto_ai_sync/devices/'+device+'.sqlite3'])
    # App reads a locally accessible folder; configured on this PC only.
    cfg=Path(os.environ.get('LOCALAPPDATA') or (Path.home()/'.litto'))/'LITTO'/'ai_drive_folder.txt'
    if args.set_path:
        if local.name.lower()!='litto_ai_memory':
            raise RuntimeError('로컬 폴더 이름은 LITTO_AI_MEMORY 여야 합니다.')
        cfg.parent.mkdir(parents=True,exist_ok=True)
        cfg.write_text(str(local),encoding='utf-8')
    print('완료. 라이또를 실행하고 PDF 동기화를 눌러 최신 자료를 색인하세요.')
    print('주의: 다른 PC에서 삭제한 기억은 자동 전파하지 않습니다. 동시에 여러 PC에서 수정할 경우 재동기화가 필요합니다.')

def main():
    p=argparse.ArgumentParser(description='LITTO R58.13 독립형 Google Drive 동기화')
    p.add_argument('--litto',default='.',help='라이또 R58.13 폴더')
    p.add_argument('--remote',default='gdrive:LITTO_AI_MEMORY',help='rclone remote 경로')
    p.add_argument('--local',default=str(Path.home()/'LITTO_AI_MEMORY'),help='이 PC의 PDF 로컬 저장 경로')
    p.add_argument('--set-path',action='store_true',help='라이또 PDF 경로 설정 파일을 이 로컬 폴더로 변경')
    args=p.parse_args()
    try:sync(args)
    except Exception as e:
        print('동기화 중단:',e,file=sys.stderr);sys.exit(1)
if __name__=='__main__':main()
