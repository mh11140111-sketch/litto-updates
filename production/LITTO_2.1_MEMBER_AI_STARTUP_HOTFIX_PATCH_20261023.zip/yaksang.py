"""약상 후보 분류: 종합 PDF 33,60~61쪽. 주문·SF/F 가격 계산 없음."""
import re,unicodedata
from strict_rules import FIELDS
REVIEW_FIELDS=('leader','news_clear','liquidity_ok','common_stock','sector_strong','interest_ok','money_ok','not_single_price','limit_today','limit_prev','strong_limit_today','strong_limit_prev','external_weakness','previous_session')
REVIEW_FIELDS=tuple(dict.fromkeys(REVIEW_FIELDS+tuple(FIELDS)))

def excluded_product(s):
    n=unicodedata.normalize('NFKC',str(s.get('name',''))).upper().strip()
    if s.get('etf') is True or str(s.get('product_type','')).upper()=='ETF':return 'ETF'
    if s.get('etn') is True or str(s.get('product_type','')).upper()=='ETN' or re.search(r'(?<![A-Z0-9])ETN(?![A-Z0-9])',n):return 'ETN'
    if s.get('leveraged') is True or s.get('inverse') is True:return '레버리지·인버스'
    if any(t in n for t in ('레버리지','인버스','LEVERAGE','INVERSE')):return '레버리지·인버스'
    if re.search(r'(?<![A-Z0-9])(?:ETF|[23]\s*[X×]|[X×]\s*[23])(?![A-Z0-9])',n):return 'ETF·배수형 상품'
    if re.match(r'^(KODEX|TIGER|ACE|RISE|PLUS|SOL|HANARO|KIWOOM|KOSEF|KBSTAR|KINDEX|ARIRANG|TIMEFOLIO|KOACT|WON|WOORI|FOCUS|HK|파워|마이다스)(?=$|[^A-Z])',n):return 'ETF 브랜드'
    return None

def patterns(s,asof):
    from engine import check,outcome,number
    d=s['daily'];today=d[-1];prev=d[-2];r=s['review']
    current=today['date']==asof.date().isoformat()
    reviewed=r.get('date')==today['date']
    def flag(k):return r.get(k) if reviewed else None
    common=[check(label,flag(key),'해당 거래일에 직접 확인; 미확인은 후보 확정 불가','종합 PDF 33,60~61쪽') for key,label in (
        ('common_stock','일반 주식 확인 (ETF 등 제외)'),('leader','주도섹터 대장·끼도주'),('sector_strong','주도섹터 동반 강세'),('interest_ok','시장 관심 유지'),('money_ok','충분한 거래대금'),('liquidity_ok','충분한 호가 유동성'),('news_clear','종목 자체 악재 없음'),('not_single_price','30분 단일가 아님'))]
    common.append(check('분석 날짜 일치',current,'자료 마지막 일봉 날짜와 분석 기준일 일치','구현 데이터 검증'))
    result=[]
    for future,b,suffix in [(True,today,'today'),(False,prev,'prev')]:
        limit=number(b.get('limit_up_price'))
        atlimit=(b['close']==limit) if limit is not None and limit>0 else flag('limit_'+suffix)
        cs=[check('상한가 종가 확인',atlimit,'공식 상한가 가격과 종가 비교 또는 직접 확인; +29.5% 근사 판정 안 함','종합 PDF 33쪽'),
            check('강한 상한가·유지력',flag('strong_limit_'+suffix),'상한가 잠김·유지 과정 직접 확인','종합 PDF 60~61쪽')]
        if future:
            cs.append(check('정규장 마감 확인',flag('market_closed'),'시장별 실제 마감 직접 확인; 미완성 봉을 후보 확정에 사용하지 않음','구현 시간 제한'))
        else:
            cs.extend([check('직전 거래일 자료 확인',flag('previous_session'),'직전 일봉이 실제 전 거래일인지 확인; 휴장·누락 자동 추정 안 함','구현 데이터 검증'),
                check('약한 출발 확인',flag('opening_weakness'),f"전일 종가 {prev['close']:g} / 시가 {today['open']:g}",'종합 PDF 33쪽; 갭하락으로 임의 제한하지 않음'),
                check('외부 시장 악재에 의한 약세',flag('external_weakness'),'개별 악재와 구별해 직접 확인','종합 PDF 33쪽'),
                check('강의 진입 시간 확인',flag('entry_time'),'기법과 시장에 맞는 시간인지 직접 확인','종합 PDF 65쪽')])
        allchecks=cs+common;tech=outcome(allchecks)
        result.append({'name':'약상 관찰' if future else '약상 당일','technical':tech,'status':'관찰 후보' if tech=='충족' and future else '조건 후보' if tech=='충족' else '제외' if tech=='미충족' else '확인 필요','checks':cs,'quality':common,'levels':{},'reference':'종합 PDF 33쪽, 60~61쪽, 65쪽','notes':['주도주·악재·호가 등 확인 전에는 확정 목록에 표시하지 않습니다.','매수 신호가 아닙니다. SF존/F존 원식과 보유 여부별 분할 계획은 별도 확인합니다.']})
    return result
