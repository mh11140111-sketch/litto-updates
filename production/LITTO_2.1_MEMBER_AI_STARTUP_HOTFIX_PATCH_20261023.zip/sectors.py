"""Source-labelled sector mapping; never infer sector from company name."""
import csv,io,json,os,shutil,copy,threading
from pathlib import Path

# 배포본에 포함되는 기본 섹터 파일
BUNDLED_FILE=Path(__file__).parent/'data/sectors.json'

# 사용자별 영구 저장 위치
# 예: C:\\Users\\사용자\\AppData\\Local\\LITTO\\sectors.json
def _user_data_dir():
 base=os.environ.get('LOCALAPPDATA')
 if base:
  return Path(base)/'LITTO'
 return Path.home()/'AppData'/'Local'/'LITTO'

DATA_DIR=_user_data_dir()
FILE=DATA_DIR/'sectors.json'

def _ensure_user_sector_file():
 DATA_DIR.mkdir(parents=True,exist_ok=True)
 if FILE.exists():
  return
 # 첫 실행에만 배포본의 기본 섹터를 사용자 저장소로 복사한다.
 if BUNDLED_FILE.exists():
  shutil.copy2(BUNDLED_FILE,FILE)
 else:
  FILE.write_text('{}',encoding='utf-8')

_CACHE_LOCK=threading.RLock()
_CACHE_SIGNATURE=None
_CACHE_MAPPING=None
_CACHE_FLAT=True

def load():
 global _CACHE_SIGNATURE,_CACHE_MAPPING,_CACHE_FLAT
 with _CACHE_LOCK:
  _ensure_user_sector_file()
  stat=FILE.stat()
  signature=(str(FILE),stat.st_mtime_ns,stat.st_size)
  if _CACHE_MAPPING is None or signature!=_CACHE_SIGNATURE:
   mapping=json.loads(FILE.read_text(encoding='utf-8'))
   _CACHE_MAPPING=mapping
   _CACHE_FLAT=all(isinstance(v,dict) and all(not isinstance(x,(dict,list)) for x in v.values()) for v in mapping.values())
   _CACHE_SIGNATURE=signature
  # Return isolated rows so caller edits cannot mutate the cache.
  return {k:dict(v) for k,v in _CACHE_MAPPING.items()} if _CACHE_FLAT else copy.deepcopy(_CACHE_MAPPING)
def parse(text):
 from engine import code
 rows=csv.DictReader(io.StringIO(text.lstrip('\ufeff')))
 if not {'code','sector','source'}.issubset(rows.fieldnames or []):raise ValueError('섹터 CSV 필수 열: code,sector,source')
 result={}
 for r in rows:
  c=code(r['code']);sector=r['sector'].strip();source=r['source'].strip()
  if not sector or not source:raise ValueError(c+': 섹터와 출처를 모두 입력하세요.')
  if c in result:raise ValueError('중복 코드: '+c)
  result[c]={'sector':sector[:100],'source':source[:500],'asof':r.get('asof','').strip()[:30]}
 if not result:raise ValueError('빈 섹터 자료입니다.')
 return result
def save(mapping):
 global _CACHE_SIGNATURE,_CACHE_MAPPING
 with _CACHE_LOCK:
  _ensure_user_sector_file()
  temp=FILE.with_suffix('.tmp')
  temp.write_text(json.dumps(mapping,ensure_ascii=False,indent=2),encoding='utf-8')
  os.replace(temp,FILE)
  _CACHE_SIGNATURE=None
  _CACHE_MAPPING=None
def apply(data,mapping):
 for s in data['stocks']:
  info=mapping.get(str(s.get('code','')).zfill(6))
  if info:s['sector']=info['sector'];s['sector_source']=info['source']+' '+info.get('asof','')
 return data


def stats(universe, mapping=None):
 mapping=mapping if mapping is not None else load()
 total=len(universe); mapped=0; manual=0; missing=[]
 for x in universe:
  c=str(x.get('code','')).zfill(6);v=mapping.get(c)
  if v and v.get('sector') and v.get('sector')!='미분류':
   mapped+=1
   if str(v.get('source','')).startswith('사용자 직접 지정'): manual+=1
  else: missing.append({'code':c,'name':x.get('name') or c})
 return {'total':total,'mapped':mapped,'manual':manual,'missing_count':len(missing),'missing':missing[:200]}
