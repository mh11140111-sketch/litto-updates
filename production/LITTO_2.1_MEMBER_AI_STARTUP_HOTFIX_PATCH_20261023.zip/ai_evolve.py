"""Approval-gated self-improvement controller for LITTO BOT.

The module never edits source code and never promotes a challenger automatically.
It learns from resolved LITTO BOT outcomes, proposes bounded scoring-weight changes,
runs them in shadow mode, and exposes promotion/rollback only through explicit user action.
"""
from pathlib import Path
import json, math, threading, time

_LOCK=threading.RLock()
_FILE=None
BASE_WEIGHTS={"liquidity":25.0,"close_quality":25.0,"momentum":20.0,"breakout":15.0,"risk":15.0}
CAPS=dict(BASE_WEIGHTS)
DEFAULT_PROFILE={"version":1,"weights":dict(BASE_WEIGHTS),"threshold":74.0,"label":"R52 baseline"}
MIN_PROPOSE_SAMPLES=30
MIN_SHADOW_SAMPLES=30


def init(root):
    global _FILE
    _FILE=Path(root)/"data"/"littobot_evolve.json"
    _FILE.parent.mkdir(parents=True,exist_ok=True)
    with _LOCK:
        if not _FILE.exists(): _save(_blank())
        else: _save(_normalize(_load()))


def _blank():
    return {"version":1,"approved":dict(DEFAULT_PROFILE),"challenger":None,"history":[],"last_proposal_resolved":0,"updated_at":time.time()}


def _load():
    if _FILE is None: raise RuntimeError("ai_evolve.init() required")
    try:
        raw=json.loads(_FILE.read_text(encoding="utf-8"))
        return raw if isinstance(raw,dict) else _blank()
    except Exception:
        return _blank()


def _save(data):
    if _FILE is None: raise RuntimeError("ai_evolve.init() required")
    data["updated_at"]=time.time()
    tmp=_FILE.with_suffix(".tmp")
    tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding="utf-8")
    tmp.replace(_FILE)


def _profile(p):
    p=p if isinstance(p,dict) else {}
    w=p.get("weights") if isinstance(p.get("weights"),dict) else {}
    vals={k:max(5.0,min(40.0,float(w.get(k,BASE_WEIGHTS[k])))) for k in BASE_WEIGHTS}
    total=sum(vals.values()) or 100.0
    vals={k:round(v*100.0/total,4) for k,v in vals.items()}
    return {"version":int(p.get("version") or 1),"weights":vals,"threshold":max(65.0,min(85.0,float(p.get("threshold") or 74))),"label":str(p.get("label") or "LITTO BOT")[:80]}


def _normalize(d):
    if not isinstance(d,dict): d=_blank()
    d.setdefault("version",1); d["approved"]=_profile(d.get("approved"))
    if isinstance(d.get("challenger"),dict):
        c=d["challenger"]; c["profile"]=_profile(c.get("profile")); c.setdefault("created_at",time.time()); c.setdefault("status","shadow")
    else:d["challenger"]=None
    if not isinstance(d.get("history"),list):d["history"]=[]
    d["history"]=d["history"][-10:]
    d["last_proposal_resolved"]=int(d.get("last_proposal_resolved") or 0)
    return d


def current_profile():
    with _LOCK:return _normalize(_load())["approved"]


def _resolved(perf):
    out=[]
    for d in (perf.get("days") or []):
        row=d.get("row") if isinstance(d,dict) else None
        if isinstance(row,dict) and isinstance(row.get("result"),dict) and row["result"].get("next_date"):out.append(row)
    return out


def _paired(perf):
    out=[]
    for d in (perf.get("days") or []):
        if not isinstance(d,dict):continue
        m=d.get("row") if isinstance(d.get("row"),dict) else None
        c=d.get("challenger") if isinstance(d.get("challenger"),dict) else None
        if m and c and isinstance(m.get("result"),dict) and isinstance(c.get("result"),dict) and m["result"].get("next_date") and c["result"].get("next_date"):
            out.append((m,c))
    return out


def _num(v,default=0.0):
    try:return float(v)
    except Exception:return default


def _metrics(rows):
    if not rows:return {"n":0}
    maxr=[_num((r.get("result") or {}).get("max_return_pct")) for r in rows]
    close=[_num((r.get("result") or {}).get("close_return_pct")) for r in rows]
    mins=[_num((r.get("result") or {}).get("min_return_pct")) for r in rows]
    hit2=sum(1 for r in rows if (r.get("result") or {}).get("hit2"))/len(rows)*100
    hit4=sum(1 for r in rows if (r.get("result") or {}).get("hit4"))/len(rows)*100
    pos=sum(1 for r in rows if (r.get("result") or {}).get("close_positive"))/len(rows)*100
    expectancy=sum(0.6*max(-12,min(15,a))+0.4*max(-12,min(12,b)) for a,b in zip(maxr,close))/len(rows)
    return {"n":len(rows),"hit2_rate":round(hit2,2),"hit4_rate":round(hit4,2),"close_positive_rate":round(pos,2),"avg_max_return_pct":round(sum(maxr)/len(rows),3),"avg_close_return_pct":round(sum(close)/len(rows),3),"avg_min_return_pct":round(sum(mins)/len(rows),3),"expectancy_score":round(expectancy,3)}


def _correlation(xs,ys):
    if len(xs)<3:return 0.0
    mx=sum(xs)/len(xs); my=sum(ys)/len(ys)
    a=sum((x-mx)*(y-my) for x,y in zip(xs,ys)); b=sum((x-mx)**2 for x in xs); c=sum((y-my)**2 for y in ys)
    if b<=1e-12 or c<=1e-12:return 0.0
    return max(-1.0,min(1.0,a/math.sqrt(b*c)))


def _derive_profile(rows,approved,next_version):
    # Use only features captured at decision time and next-session outcomes.
    targets=[]; feats={k:[] for k in BASE_WEIGHTS}
    for r in rows:
        parts=r.get("parts") if isinstance(r.get("parts"),dict) else {}
        res=r.get("result") or {}
        targets.append(0.6*max(-12,min(15,_num(res.get("max_return_pct"))))+0.4*max(-12,min(12,_num(res.get("close_return_pct")))))
        for k in feats: feats[k].append(max(0,min(1,_num(parts.get(k))/CAPS[k])))
    cor={k:_correlation(v,targets) for k,v in feats.items()}
    old=approved["weights"]
    # Bounded evolution: one generation can move each dimension by at most 12%.
    raw={k:old[k]*(1.0+0.12*cor[k]) for k in old}
    total=sum(raw.values()) or 100.0
    w={k:raw[k]*100.0/total for k in raw}
    # Re-apply per-generation bounds and normalize.
    bounded={k:max(old[k]*0.88,min(old[k]*1.12,w[k])) for k in w}
    total=sum(bounded.values()) or 100.0
    bounded={k:round(v*100.0/total,4) for k,v in bounded.items()}
    return {"version":next_version,"weights":bounded,"threshold":approved.get("threshold",74.0),"label":f"AUTO EVOLVE challenger v{next_version}"},cor


def maybe_propose(perf):
    with _LOCK:
        d=_normalize(_load()); rows=_resolved(perf); n=len(rows)
        if d.get("challenger") or n<MIN_PROPOSE_SAMPLES:return d
        # Require a fresh block of evidence after the previous proposal/promotion.
        if n-d.get("last_proposal_resolved",0)<MIN_PROPOSE_SAMPLES:return d
        version=int(d["approved"].get("version") or 1)+1
        p,cor=_derive_profile(rows,d["approved"],version)
        d["challenger"]={"profile":p,"status":"shadow","created_at":time.time(),"based_on_samples":n,"correlations":{k:round(v,4) for k,v in cor.items()}}
        d["last_proposal_resolved"]=n
        _save(d); return d


def status(perf=None,auto_propose=True):
    with _LOCK:
        d=_normalize(_load())
        if perf is not None and auto_propose:
            d=maybe_propose(perf)
        paired=_paired(perf or {})
        mm=_metrics([m for m,_ in paired]); cm=_metrics([c for _,c in paired])
        eligible=False; reason="챌린저 생성 대기"
        if d.get("challenger"):
            if mm.get("n",0)<MIN_SHADOW_SAMPLES: reason=f"그림자 비교 {mm.get('n',0)}/{MIN_SHADOW_SAMPLES}"
            else:
                exp_gain=cm.get("expectancy_score",0)-mm.get("expectancy_score",0)
                close_guard=cm.get("avg_close_return_pct",0)>=mm.get("avg_close_return_pct",0)-0.25
                risk_guard=cm.get("avg_min_return_pct",0)>=mm.get("avg_min_return_pct",0)-0.35
                eligible=exp_gain>=0.20 and close_guard and risk_guard
                reason="승격 검토 가능" if eligible else "기존 모델 우세/위험 기준 미통과"
        return {"ok":True,"mode":"approval_gated","approved":d["approved"],"challenger":d.get("challenger"),"paired_samples":mm.get("n",0),"minimum_shadow_samples":MIN_SHADOW_SAMPLES,"main_metrics":mm,"challenger_metrics":cm,"promotion_eligible":eligible,"promotion_reason":reason,"history_count":len(d.get("history") or []),"self_modifying_code":False,"automatic_promotion":False}


def approve(perf):
    with _LOCK:
        st=status(perf,auto_propose=False)
        if not st.get("challenger"):return {"ok":False,"error":"승격할 챌린저가 없습니다."}
        if not st.get("promotion_eligible"):return {"ok":False,"error":"아직 승격 기준을 충족하지 못했습니다.","status":st}
        d=_normalize(_load())
        d["history"].append({"profile":d["approved"],"retired_at":time.time(),"metrics":st.get("main_metrics")})
        d["approved"]=_profile(d["challenger"]["profile"]); d["approved"]["label"]="승인된 AUTO EVOLVE"
        d["challenger"]=None
        _save(d)
        return {"ok":True,"message":"챌린저를 메인 라이또봇으로 승격했습니다.","status":status(perf,auto_propose=False)}


def reject():
    with _LOCK:
        d=_normalize(_load())
        if not d.get("challenger"):return {"ok":False,"error":"거절할 챌린저가 없습니다."}
        d["challenger"]=None; _save(d)
        return {"ok":True,"message":"챌린저를 폐기했습니다."}


def rollback():
    with _LOCK:
        d=_normalize(_load()); hist=d.get("history") or []
        if not hist:return {"ok":False,"error":"롤백할 이전 승인 모델이 없습니다."}
        prev=hist.pop(); d["challenger"]=None; d["approved"]=_profile(prev.get("profile")); d["history"]=hist; _save(d)
        return {"ok":True,"message":"직전 승인 모델로 롤백했습니다.","approved":d["approved"]}
