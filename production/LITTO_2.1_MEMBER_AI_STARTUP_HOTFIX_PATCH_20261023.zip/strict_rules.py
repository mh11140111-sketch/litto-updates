"""Only source-backed checklist conditions; no invented numeric pattern proxies."""
FIELDS={
 'base_confirmed':('상한가·강한 기준봉 확인','종합 PDF 31~32쪽'),
 'day_after_base':('기준봉 D+1·D+2 위치 확인','종합 PDF 31쪽'),
 'new_high':('신고가 기준봉 확인','종합 PDF 26쪽'),
 'expansion':('기준봉 이후 충분한 시세발산','종합 PDF 31쪽'),
 'large_drop':('시세발산 뒤 큰 낙폭·반등 구조','종합 PDF 31쪽'),
 'money_increased':('피뢰침봉 거래대금이 기준봉보다 증가','종합 PDF 31쪽'),
 'money_dried':('기준봉 이후 거래대금 급감','종합 PDF 32쪽'),
 'rest_without_expansion':('시세발산 없이 하루 조정','종합 PDF 32쪽'),
 'first_support':('3·5일선 및 첫 지지 구조 확인','종합 PDF 26,32쪽'),
 'minute_support':('15분봉 60·120선 지지 맥락 확인','종합 PDF 32쪽'),
 'day_zero':('당일 주도주 D-day','종합 PDF 19쪽'),
 'not_limit':('상한가 미도달 상태 확인','종합 PDF 19~20쪽'),
 'strength_to_close':('15시까지 주도력·일봉 유지','종합 PDF 19~21쪽'),
 'inflow_hold':('돈 유입 후 횡보·버팀','종합 PDF 20쪽'),
 'entry_time':('해당 기법의 강의상 진입 시간 확인','종합 PDF 20,31,65쪽'),
 'opening_weakness':('다음 날 약한 출발 확인','종합 PDF 33쪽'),
 'market_closed':('해당 거래일 마감 확인','관찰목록 데이터 확정 확인'),
}
def lecture_patterns(s,asof):
 from engine import check,outcome
 r=s['review'];valid=r.get('date')==s['daily'][-1]['date']
 def flag(k):return r.get(k) if valid else None
 q=[check(label,flag(key),'강의 정성 조건 직접 확인; 미확인 자동 통과 금지',ref) for key,label,ref in [
 ('leader','주도주·대장 확인','종합 PDF 7~12쪽'),('news_clear','종목 고유 악재 확인','종합 PDF 31쪽'),('liquidity_ok','호가 유동성 확인','종합 PDF 23쪽')]]
 groups=[('어종',['day_zero','not_limit','strength_to_close','inflow_hold','entry_time'],'종합 PDF 19~21쪽'),
 ('피뢰침',['base_confirmed','day_after_base','expansion','large_drop','money_increased','entry_time'],'종합 PDF 31,34쪽'),
 ('하트존',['base_confirmed','new_high','day_after_base','money_dried','rest_without_expansion','first_support','minute_support','entry_time'],'종합 PDF 26,32,34쪽')]
 result=[]
 for name,keys,ref in groups:
  cs=[check(FIELDS[k][0],flag(k),'강의 조건 직접 확인',FIELDS[k][1]) for k in keys]
  # Exact algorithms are not established from the reviewed source; no automatic pass.
  cs.append(check('원문 기반 자동 판정 검증',None,'미확정 정의·원식 검증 전 자동 후보 확정 보류','개발 검증 상태'))
  tech=outcome(cs+q)
  result.append({'name':name,'technical':tech,'status':'제외' if tech=='미충족' else '원문 확인 대기','checks':cs,'quality':q,'levels':{},'reference':ref,'notes':['임의 상승률·대금 배수·이평선 허용오차를 제거했습니다.','확인 기록용이며 원본 지표 자동 구현 완료판이 아닙니다.']})
 return result
