# coding: utf-8
"""Read-only historical closing TOP5 cohort analysis. No API/network/background tasks."""
from collections import defaultdict

def _f(v):
    try:return float(str(v).replace(',',''))
    except (ValueError,TypeError):return None

def analyze_top5(data,min_sample=10):
    min_sample=max(3,min(100,int(min_sample)))
    days=data.get('days',[]) if isinstance(data,dict) else []
    rows=[]; pending=0
    for day in days:
        if not isinstance(day,dict):continue
        for pick in day.get('rows',[]):
            if not isinstance(pick,dict):continue
            result=pick.get('result')
            if not isinstance(result,dict) or not result.get('next_date'):
                pending+=1;continue
            rows.append((str(day.get('date','')),pick,result))
    def aggregate(items):
        def mean(key):
            vals=[_f(r.get(key)) for _,_,r in items]
            vals=[v for v in vals if v is not None]
            return round(sum(vals)/len(vals),3) if vals else None
        def rate(key):
            vals=[r.get(key) for _,_,r in items if isinstance(r.get(key),bool)]
            return round(100*sum(vals)/len(vals),2) if vals else None
        return {'count':len(items),'distinct_days':len(set(d for d,_,_ in items)),
                'average_gap_pct':mean('open_gap_pct'),'average_high_pct':mean('max_return_pct'),
                'average_low_pct':mean('min_return_pct'),'average_close_pct':mean('close_return_pct'),
                'high_reached_2pct_rate':rate('hit2'),'high_reached_4pct_rate':rate('hit4')}
    groups=defaultdict(list)
    for item in rows:
        _,pick,_=item
        for k,v in [('rank',str(pick.get('rank') or '')),('grade',str(pick.get('grade') or '')),('sector',str(pick.get('sector') or ''))]:
            if v:groups[(k,v)].append(item)
        for k in ('tags','reasons'):
            vals=pick.get(k)
            if isinstance(vals,list):
                for v in set(str(x).strip()[:90] for x in vals if x):
                    if v:groups[(k[:-1] if k=='tags' else 'reason',v)].append(item)
    output=[]
    for (kind,name),items in sorted(groups.items()):
        stats=aggregate(items)
        output.append({'type':kind,'name':name,**stats,
                       'insufficient_sample':stats['count']<min_sample or stats['distinct_days']<min_sample})
    return {'status':'ok' if rows else 'no_resolved_records','saved_days':len(days),
            'resolved_picks':len(rows),'pending_picks':pending,'overall':aggregate(rows),
            'cohorts':sorted(output,key=lambda x:(-x['count'],x['type'],x['name']))[:100],
            'source':'Local closing_top5_performance.json; no live market updates',
            'cautions':['TOP5 selection bias: does not cover rejected candidates',
                'Next-day high-touch percentages are not realized P/L',
                'Small samples and repeated market regimes can distort comparisons',
                'Associations by tag or reason do not prove causality',
                'No scanner formula, trade orders, or thresholds are modified',
                'Past results cannot guarantee future performance']}
