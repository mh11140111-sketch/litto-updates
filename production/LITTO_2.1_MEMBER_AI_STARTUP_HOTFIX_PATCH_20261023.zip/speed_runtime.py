"""Coalesce concurrent read-only work. No result cache or order retries."""
from concurrent.futures import Future
from threading import Lock

class SingleFlight:
    def __init__(self):
        self._lock=Lock()
        self._pending={}

    def run(self,key,loader):
        with self._lock:
            future=self._pending.get(key)
            owner=future is None
            if owner:
                future=self._pending[key]=Future()
        if not owner:
            return future.result()
        try:
            result=loader()
        except BaseException as exc:
            future.set_exception(exc)
            raise
        else:
            future.set_result(result)
            return result
        finally:
            with self._lock:
                if self._pending.get(key) is future:
                    del self._pending[key]
