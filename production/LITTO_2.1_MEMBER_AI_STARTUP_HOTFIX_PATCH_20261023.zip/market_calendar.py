"""Official-source market calendar collectors for the LITTO local dashboard.

No third-party package is required.  Each source is isolated so one failed site does not
break the whole calendar.  All timed events are normalized to Asia/Seoul.
"""
from __future__ import annotations

import html
import re
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import datetime, timedelta, date
from html.parser import HTMLParser
from urllib.request import Request, urlopen
from zoneinfo import ZoneInfo

KST = ZoneInfo("Asia/Seoul")
NY = ZoneInfo("America/New_York")
FRANKFURT = ZoneInfo("Europe/Berlin")
TOKYO = ZoneInfo("Asia/Tokyo")
SHANGHAI = ZoneInfo("Asia/Shanghai")

UA = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 LITTO-MarketCalendar/1.0"
TIMEOUT = 7

URLS = {
    "kind": "https://kind.krx.co.kr/external/dst/main/main_contents.htm",
    "bls": "https://www.bls.gov/schedule/news_release/bls.ics",
    "bea": "https://www.bea.gov/news/schedule",
    "fed": "https://www.federalreserve.gov/monetarypolicy/fomccalendars.htm",
    "ecb": "https://www.ecb.europa.eu/press/calendars/mgcgc/html/index.en.html",
    "boj": "https://www.boj.or.jp/en/mopo/mpmsche_minu/index.htm",
    "nbs": "https://www.stats.gov.cn/english/PressRelease/ReleaseCalendar/202512/t20251226_1962154.html",
    "coex": "https://www.coex.co.kr/event/exhibitions-calendar/",
    "setec": "https://www.setec.or.kr/front/schedule/list.do",
    "kes": "https://www.kes.org/kor/intro/info.asp",
    "semicon_korea": "https://www.semiconkorea.org/ko/about/overview",
    "semicon_europa": "https://www.semiconeuropa.org/about/overview",
    "gtc": "https://www.nvidia.com/gtc/faq/",
    "mwc": "https://www.mwcbarcelona.com/about",
}

_CACHE = {"at": 0.0, "payload": None}
CACHE_TTL = 300

MONTHS = {
    "january": 1, "jan": 1, "february": 2, "feb": 2, "march": 3, "mar": 3,
    "april": 4, "apr": 4, "may": 5, "june": 6, "jun": 6, "july": 7, "jul": 7,
    "august": 8, "aug": 8, "september": 9, "sept": 9, "sep": 9, "october": 10,
    "oct": 10, "november": 11, "nov": 11, "december": 12, "dec": 12,
}


def _fetch(url: str, accept: str = "text/html,*/*") -> str:
    req = Request(url, headers={
        "User-Agent": UA,
        "Accept": accept,
        "Accept-Language": "ko-KR,ko;q=0.9,en-US;q=0.8,en;q=0.7",
        "Cache-Control": "no-cache",
    })
    with urlopen(req, timeout=TIMEOUT) as r:
        raw = r.read()
        enc = r.headers.get_content_charset() or "utf-8"
    for codec in (enc, "utf-8", "euc-kr", "cp949"):
        try:
            return raw.decode(codec)
        except Exception:
            pass
    return raw.decode("utf-8", "replace")


def _clean_text(s: str) -> str:
    s = html.unescape(re.sub(r"<[^>]+>", " ", s or ""))
    return re.sub(r"\s+", " ", s).strip()


def _event(dt: datetime | None, *, date_only: date | None = None, country: str,
           category: str, title: str, importance: str, source: str, url: str,
           note: str = "", raw_time: str = "", end_date: date | None = None,
           venue: str = "", sector_tags: list[str] | None = None, event_type: str = "macro") -> dict:
    if dt is not None:
        if dt.tzinfo is None:
            dt = dt.replace(tzinfo=KST)
        k = dt.astimezone(KST)
        day = k.date().isoformat()
        time_kst = k.strftime("%H:%M")
        iso = k.isoformat(timespec="minutes")
    else:
        d = date_only or datetime.now(KST).date()
        day = d.isoformat()
        time_kst = raw_time or "시간 미정"
        iso = None
    return {
        "id": f"{source}:{day}:{title}:{time_kst}",
        "date_kst": day,
        "time_kst": time_kst,
        "datetime_kst": iso,
        "country": country,
        "category": category,
        "title": title,
        "importance": importance,
        "source": source,
        "url": url,
        "note": note,
        "end_date_kst": end_date.isoformat() if end_date else None,
        "venue": venue,
        "sector_tags": list(sector_tags or []),
        "event_type": event_type,
    }



# Market-relevant exhibition / industry-event tagging.  The dashboard intentionally
# filters out general consumer fairs so the list stays useful for trading preparation.
_SECTOR_RULES = [
    ("반도체", ("반도체", "semicon", "semiconductor", "chip", "첨단소재", "전자부품", "power semiconductor")),
    ("AI", ("ai ", " ai", "인공지능", "artificial intelligence", "ax(", "digital dna", "디지털 dna", "에듀테크", "smart work")),
    ("로봇", ("로봇", "robot", "humanoid", "휴머노이드", "자율제조")),
    ("2차전지", ("배터리", "battery", "interbattery", "이차전지", "2차전지")),
    ("바이오", ("바이오", "bio", "life science", "lifescience", "라이프사이언스", "medical", "medtech", "헬스케어")),
    ("전력·에너지", ("에너지", "energy", "전력", "smart grid", "hydrogen", "수소", "renewable")),
    ("방산", ("방산", "defense", "defence", "aerospace", "우주", "항공")),
    ("모빌리티", ("모빌리티", "mobility", "ev ", "전기차", "자율주행", "automotive")),
    ("IT·전자", ("전자전", "electronics", "ict", "quantum", "양자", "cloud", "클라우드", "이커머스", "e-commerce")),
    ("금융", ("ipo", "나스닥", "투자", "재테크", "finance", "fintech")),
]

def _sector_tags(title: str) -> list[str]:
    low=(title or "").lower()
    out=[]
    for tag, words in _SECTOR_RULES:
        if any(w in low for w in words): out.append(tag)
    return out[:4]

def _relevant_exhibition(title: str) -> bool:
    return bool(_sector_tags(title))

def _industry_event(d: date, title: str, *, end: date | None = None, country="KR", source="산업행사",
                    url="", venue="", importance="high", note="") -> dict:
    tags=_sector_tags(title)
    if end and end != d:
        span=f"{d.strftime('%m/%d')}~{end.strftime('%m/%d')}"
        note=(note+" · " if note else "")+span
    return _event(None,date_only=d,country=country,category="전시·산업행사",title=title,
                  importance=importance,source=source,url=url,note=note,raw_time="종일",
                  end_date=end,venue=venue,sector_tags=tags,event_type="industry")

def _month_shift(y:int,m:int,delta:int):
    n=(y*12+(m-1)+delta); return n//12,n%12+1

def collect_coex() -> list[dict]:
    """COEX official calendar.  Parse the visible month grid and collapse multi-day repeats."""
    raw=_fetch(URLS["coex"]); lines=_html_to_lines(raw)
    ym=None
    for line in lines:
        m=re.fullmatch(r"(20\d{2})\.(\d{1,2})",line)
        if m: ym=(int(m.group(1)),int(m.group(2))); break
    if not ym: raise ValueError("COEX calendar month not found")
    y,m=ym; day=None; phase=0; title_days={}
    # phase -1: previous month, 0: target month, 1: next month
    prev_day=None
    for line in lines:
        mm=re.match(r"^(\d{1,2})(?:\s+)?(.*)$",line)
        if mm and 1<=int(mm.group(1))<=31:
            nd=int(mm.group(1)); rest=mm.group(2).strip()
            if prev_day is not None and prev_day>=25 and nd<=7: phase += 1
            if prev_day is None and nd>=25: phase=-1
            prev_day=nd; day=nd
            if rest and len(rest)>2:
                title_days.setdefault(rest,[]).append((phase,day))
            continue
        if day is not None and len(line)>=4 and not line.startswith(("Sun","Mon","Tue","Wed","Thu","Fri","Sat","Previous","Next","검색")):
            # Calendar event titles are short anchor texts. Ignore navigation/footer noise.
            if len(line)<=100 and _relevant_exhibition(line): title_days.setdefault(line,[]).append((phase,day))
    events=[]
    for title, vals in title_days.items():
        if not _relevant_exhibition(title): continue
        dates=[]
        for ph,dd in vals:
            yy,mo=_month_shift(y,m,ph)
            try: dates.append(date(yy,mo,dd))
            except ValueError: pass
        dates=sorted(set(dates))
        if not dates: continue
        # One row per event, spanning first..last visible day.
        events.append(_industry_event(dates[0],title,end=dates[-1],source="COEX",url=URLS["coex"],venue="COEX"))
    if not events: raise ValueError("COEX market-relevant events not parsed")
    return events

def collect_setec() -> list[dict]:
    lines=_html_to_lines(_fetch(URLS["setec"])); events=[]
    pat=re.compile(r"(?:^|\s)(.+?)\s*기간\s*:\s*(20\d{2}-\d{2}-\d{2})\s*~\s*(20\d{2}-\d{2}-\d{2})")
    for line in lines:
        m=pat.search(line)
        if not m: continue
        title=re.sub(r"^\d+\s+","",m.group(1)).strip()
        if not _relevant_exhibition(title): continue
        try: d1=date.fromisoformat(m.group(2)); d2=date.fromisoformat(m.group(3))
        except ValueError: continue
        events.append(_industry_event(d1,title,end=d2,source="SETEC",url=URLS["setec"],venue="SETEC",importance="medium"))
    if not events: raise ValueError("SETEC market-relevant events not parsed")
    return events

def collect_flagship_industry() -> list[dict]:
    """Major official industry events whose organizers publish stable event dates."""
    specs=[
      ("KES 2026 한국전자전",date(2026,10,13),date(2026,10,16),"KR","KES",URLS["kes"],"COEX A·B홀","critical"),
      ("SEMICON Europa 2026",date(2026,11,10),date(2026,11,13),"EU","SEMI",URLS["semicon_europa"],"Messe München","critical"),
      ("SEMICON Korea 2027",date(2027,2,17),date(2027,2,19),"KR","SEMI",URLS["semicon_korea"],"COEX","critical"),
      ("NVIDIA GTC 2027",date(2027,3,14),date(2027,3,18),"US","NVIDIA",URLS["gtc"],"San Jose","critical"),
      ("MWC Barcelona 2027",date(2027,3,1),date(2027,3,4),"EU","GSMA",URLS["mwc"],"Fira Gran Via","high"),
    ]
    events=[]
    for title,d1,d2,country,src,url,venue,imp in specs:
        events.append(_industry_event(d1,title,end=d2,country=country,source=src,url=url,venue=venue,importance=imp,
                                      note="주최기관 공식 발표 일정"))
    return events


def _unfold_ics(text: str) -> list[str]:
    out = []
    for line in text.replace("\r\n", "\n").split("\n"):
        if line.startswith((" ", "\t")) and out:
            out[-1] += line[1:]
        else:
            out.append(line)
    return out


def _ics_unescape(s: str) -> str:
    return (s or "").replace("\\,", ",").replace("\\;", ";").replace("\\n", " ").replace("\\N", " ").replace("\\\\", "\\")


_BLS_RULES = [
    ("Consumer Price Index", "미국 CPI", "critical", "물가"),
    ("Employment Situation", "미국 고용보고서", "critical", "고용"),
    ("Producer Price Index", "미국 PPI", "high", "물가"),
    ("Job Openings and Labor Turnover Survey", "미국 JOLTS", "high", "고용"),
    ("Employment Cost Index", "미국 고용비용지수 ECI", "high", "고용"),
    ("U.S. Import and Export Price Indexes", "미국 수출입물가지수", "medium", "물가"),
    ("Productivity and Costs", "미국 생산성·단위노동비용", "medium", "고용"),
]


def collect_bls() -> list[dict]:
    text = _fetch(URLS["bls"], "text/calendar,*/*")
    events, cur = [], None
    for line in _unfold_ics(text):
        if line == "BEGIN:VEVENT":
            cur = {}
        elif line == "END:VEVENT":
            if cur:
                summary = _ics_unescape(cur.get("SUMMARY", ""))
                rule = next((x for x in _BLS_RULES if x[0].lower() in summary.lower()), None)
                if rule and cur.get("DTSTART"):
                    value, params = cur["DTSTART"]
                    dt = _parse_ics_dt(value, params)
                    if dt:
                        events.append(_event(dt, country="US", category=rule[3], title=rule[1],
                                             importance=rule[2], source="BLS", url=URLS["bls"],
                                             note="미 노동통계국 공식 발표 일정"))
            cur = None
        elif cur is not None and ":" in line:
            left, value = line.split(":", 1)
            name = left.split(";", 1)[0]
            params = left[len(name):]
            if name == "DTSTART":
                cur[name] = (value.strip(), params)
            elif name in ("SUMMARY", "DESCRIPTION", "URL"):
                cur[name] = value.strip()
    return events


def _parse_ics_dt(value: str, params: str) -> datetime | None:
    try:
        if len(value) == 8 and value.isdigit():
            return datetime.strptime(value, "%Y%m%d").replace(tzinfo=NY)
        fmt = "%Y%m%dT%H%M%S" if len(value.rstrip("Z")) >= 15 else "%Y%m%dT%H%M"
        v = value.rstrip("Z")
        dt = datetime.strptime(v[:15] if fmt.endswith("%S") else v[:13], fmt)
        if value.endswith("Z"):
            return dt.replace(tzinfo=ZoneInfo("UTC"))
        tz = NY
        m = re.search(r"TZID=([^;:]+)", params or "")
        if m:
            try:
                tz = ZoneInfo(m.group(1))
            except Exception:
                tz = NY
        return dt.replace(tzinfo=tz)
    except Exception:
        return None


class _TableParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.rows, self.row, self.cell = [], None, None
    def handle_starttag(self, tag, attrs):
        t = tag.lower()
        if t == "tr": self.row = []
        elif t in ("td", "th") and self.row is not None: self.cell = []
        elif t == "br" and self.cell is not None: self.cell.append(" ")
    def handle_data(self, data):
        if self.cell is not None: self.cell.append(data)
    def handle_endtag(self, tag):
        t = tag.lower()
        if t in ("td", "th") and self.row is not None and self.cell is not None:
            self.row.append(re.sub(r"\s+", " ", "".join(self.cell)).strip()); self.cell = None
        elif t == "tr" and self.row is not None:
            if self.row: self.rows.append(self.row)
            self.row = None; self.cell = None


def _parse_month_day_time(s: str, year: int, tz=NY) -> datetime | None:
    m = re.search(r"([A-Za-z]+)\s+(\d{1,2})\s+(\d{1,2}):(\d{2})\s*(AM|PM)", s or "", re.I)
    if not m: return None
    mon = MONTHS.get(m.group(1).lower().rstrip("."))
    if not mon: return None
    hh = int(m.group(3)); mm = int(m.group(4)); ap = m.group(5).upper()
    if ap == "PM" and hh != 12: hh += 12
    if ap == "AM" and hh == 12: hh = 0
    try: return datetime(year, mon, int(m.group(2)), hh, mm, tzinfo=tz)
    except ValueError: return None


_BEA_RULES = [
    ("Personal Income and Outlays", "미국 PCE·개인소득/지출", "critical", "물가"),
    ("GDP (Advance Estimate)", "미국 GDP 속보치", "critical", "성장"),
    ("GDP (Second Estimate)", "미국 GDP 2차", "high", "성장"),
    ("GDP (Third Estimate)", "미국 GDP 확정치", "high", "성장"),
    ("International Trade in Goods and Services", "미국 무역수지", "high", "무역"),
]


def collect_bea() -> list[dict]:
    text = _fetch(URLS["bea"])
    p = _TableParser(); p.feed(text)
    year = datetime.now(KST).year
    events = []
    for row in p.rows:
        if len(row) < 2: continue
        joined = " | ".join(row)
        dt = _parse_month_day_time(row[0], year, NY)
        if not dt: continue
        rule = next((x for x in _BEA_RULES if x[0].lower() in joined.lower()), None)
        if not rule: continue
        events.append(_event(dt, country="US", category=rule[3], title=rule[1],
                             importance=rule[2], source="BEA", url=URLS["bea"],
                             note="미 상무부 경제분석국 공식 발표 일정"))
    return events


def _html_to_lines(text: str) -> list[str]:
    text = re.sub(r"(?i)</?(?:p|div|li|tr|td|th|h1|h2|h3|h4|br)[^>]*>", "\n", text or "")
    text = html.unescape(re.sub(r"<[^>]+>", " ", text))
    return [re.sub(r"\s+", " ", x).strip() for x in text.splitlines() if re.sub(r"\s+", " ", x).strip()]


def collect_fed() -> list[dict]:
    text = _clean_text(_fetch(URLS["fed"]))
    year = datetime.now(KST).year
    # Keep only the current-year meeting section. Requiring a day range avoids matching minutes-release dates.
    marker = re.search(rf"{year}\s+FOMC\s+Meetings", text, re.I)
    if marker:
        chunk = text[marker.end():]
        nxt = re.search(rf"{year+1}\s+FOMC\s+Meetings", chunk, re.I)
        if nxt: chunk = chunk[:nxt.start()]
    else:
        chunk = text
    pat = re.compile(r"\b(January|February|March|April|May|June|July|August|September|October|November|December)\s+(\d{1,2})\s*[-–]\s*(\d{1,2})\*?", re.I)
    events=[]
    for m in pat.finditer(chunk):
        mon=MONTHS[m.group(1).lower()]; final_day=int(m.group(3))
        try: dt=datetime(year,mon,final_day,14,0,tzinfo=NY)
        except ValueError: continue
        events.append(_event(dt,country="US",category="중앙은행",title="FOMC 금리결정·성명",
                             importance="critical",source="Federal Reserve",url=URLS["fed"],
                             note="회의 종료일 14:00 ET 기준 · 기자회견은 통상 30분 뒤"))
    return events


def collect_ecb() -> list[dict]:
    lines = _html_to_lines(_fetch(URLS["ecb"]))
    events=[]
    for i,line in enumerate(lines):
        m=re.fullmatch(r"(\d{2})/(\d{2})/(\d{4})",line)
        if not m: continue
        desc=lines[i+1] if i+1<len(lines) else ""
        if "monetary policy meeting" not in desc.lower() or "day 2" not in desc.lower(): continue
        d=date(int(m.group(3)),int(m.group(2)),int(m.group(1)))
        events.append(_event(None,date_only=d,country="EU",category="중앙은행",title="ECB 통화정책회의·기자회견",
                             importance="critical",source="ECB",url=URLS["ecb"],
                             note="공식 회의일 · 발표시각은 ECB 당일 공지 확인",raw_time="시간 별도"))
    return events


def _month_num(name: str) -> int | None:
    return MONTHS.get((name or "").lower().rstrip("."))



def collect_nbs() -> list[dict]:
    """China NBS official 2026 release calendar, published as an annual schedule.

    NBS publishes the whole year's dates at once; keeping the market-moving rows locally
    avoids fragile parsing of a very wide HTML table while preserving the official dates.
    """
    year=datetime.now(KST).year
    if year != 2026:
        return []
    rows=[]
    def cn(month,day,hour,minute,title,importance,category):
        dt=datetime(2026,month,day,hour,minute,tzinfo=SHANGHAI)
        rows.append(_event(dt,country="CN",category=category,title=title,importance=importance,
                           source="China NBS",url=URLS["nbs"],note="중국 국가통계국 2026 공식 발표일정"))
    # PMI
    for m,d in [(9,30),(10,31),(11,30),(12,31)]: cn(m,d,9,30,"중국 제조업 PMI","high","경기")
    # CPI / producer prices
    for m,d in [(10,14),(11,9),(12,9)]:
        cn(m,d,9,30,"중국 CPI","high","물가");cn(m,d,9,30,"중국 PPI","medium","물가")
    # Monthly/quarterly national economic performance. October includes Q3 GDP.
    for m,d in [(10,19),(11,16),(12,15)]:
        title="중국 GDP·국민경제지표" if m==10 else "중국 산업생산·소매판매 등"
        cn(m,d,10,0,title,"critical" if m==10 else "high","성장")
    return rows

def collect_boj() -> list[dict]:
    text=_clean_text(_fetch(URLS["boj"]))
    year=datetime.now(KST).year
    marker=re.search(rf"\b{year}\b",text)
    if marker: text=text[marker.start():]
    # Match two-day MPM dates, using the second day as the policy-decision day.
    pat=re.compile(r"\b(Jan\.|Feb\.|Mar\.|Apr\.|May|June|July|Aug\.|Sept\.|Oct\.|Nov\.|Dec\.)\s+(\d{1,2})\s*\([^)]*\)\s*,\s*(\d{1,2})\s*\([^)]*\)",re.I)
    events=[]; seen=set()
    for m in pat.finditer(text):
        mon=_month_num(m.group(1)); final=int(m.group(3))
        if not mon: continue
        try: d=date(year,mon,final)
        except ValueError: continue
        if d in seen: continue
        seen.add(d)
        events.append(_event(None,date_only=d,country="JP",category="중앙은행",title="BOJ 금융정책결정회의",
                             importance="critical",source="BOJ",url=URLS["boj"],
                             note="회의 종료일 · 정책결정 발표시각은 고정되지 않음",raw_time="시간 미정"))
    return events


def collect_kind() -> list[dict]:
    text = _fetch(URLS["kind"])
    lines = _html_to_lines(text)
    events=[]
    section=None
    pending=None
    for line in lines:
        if line == "공모기업": section="ipo"; pending=None; continue
        if line == "신규상장기업": section="listing"; pending=None; continue
        if section and line in ("코넥스신청기업","채권정보","전체"):
            section=None; pending=None; continue
        if section:
            dm=re.fullmatch(r"(20\d{2})-(\d{2})-(\d{2})",line)
            if dm and pending:
                d=date(int(dm.group(1)),int(dm.group(2)),int(dm.group(3)))
                if section=="ipo":
                    title=f"{pending} · KIND 공모기업"
                    cat="공모"
                    imp="medium"
                else:
                    title=f"{pending} · 신규상장"
                    cat="상장"
                    imp="high"
                events.append(_event(None,date_only=d,country="KR",category=cat,title=title,importance=imp,
                                     source="KIND",url=URLS["kind"],note="KRX KIND 공식 기업공시채널",raw_time="장중/일정",
                                     event_type="corporate"))
                pending=None
            elif not re.search(r"제조업|서비스업|소프트웨어|금융|연구개발|소매업|도매업|공급업|기타|더보기",line):
                # The main page lists company name, industry, then date. Keep only plausible company-name lines.
                if len(line)<=40 and not line.startswith(("http","Image")):
                    pending=line
    return events




def _fallback_2026(source: str) -> list[dict]:
    """Small bundled cache of already-published 2026 official dates.

    Used only when the live official page cannot be reached. It is deliberately limited
    to market-moving releases and is visibly marked as cached in the UI.
    """
    if datetime.now(KST).year != 2026:
        return []
    rows=[]
    def us(month, day, hour, minute, title, importance, category, src, url):
        dt=datetime(2026,month,day,hour,minute,tzinfo=NY)
        rows.append(_event(dt,country="US",category=category,title=title,importance=importance,
                           source=src,url=url,note="공식 일정 내장 캐시 · 실시간 수집 실패"))
    if source == "BLS":
        for m,d,h,mi,title,imp,cat in [
            (9,16,8,30,"미국 수출입물가지수","medium","물가"),
            (9,29,10,0,"미국 JOLTS","high","고용"),(10,2,8,30,"미국 고용보고서","critical","고용"),
            (10,14,8,30,"미국 CPI","critical","물가"),(10,15,8,30,"미국 PPI","high","물가"),
            (10,16,8,30,"미국 수출입물가지수","medium","물가"),(10,30,8,30,"미국 고용비용지수 ECI","high","고용"),
            (11,3,10,0,"미국 JOLTS","high","고용"),(11,5,8,30,"미국 생산성·단위노동비용","medium","고용"),
            (11,6,8,30,"미국 고용보고서","critical","고용"),(11,10,8,30,"미국 CPI","critical","물가"),
            (11,13,8,30,"미국 PPI","high","물가"),(11,17,8,30,"미국 수출입물가지수","medium","물가"),
            (12,1,10,0,"미국 JOLTS","high","고용"),(12,4,8,30,"미국 고용보고서","critical","고용"),
            (12,8,8,30,"미국 생산성·단위노동비용","medium","고용"),(12,10,8,30,"미국 CPI","critical","물가"),
            (12,15,8,30,"미국 PPI","high","물가"),(12,17,8,30,"미국 수출입물가지수","medium","물가")]:
            us(m,d,h,mi,title,imp,cat,"BLS",URLS["bls"])
    elif source == "BEA":
        for m,d,title,imp,cat in [
            (9,30,"미국 GDP 확정치","high","성장"),(9,30,"미국 PCE·개인소득/지출","critical","물가"),
            (10,6,"미국 무역수지","high","무역"),(10,29,"미국 GDP 속보치","critical","성장"),
            (10,29,"미국 PCE·개인소득/지출","critical","물가"),(11,4,"미국 무역수지","high","무역"),
            (11,25,"미국 GDP 2차","high","성장"),(11,25,"미국 PCE·개인소득/지출","critical","물가"),
            (12,8,"미국 무역수지","high","무역"),(12,23,"미국 GDP 확정치","high","성장"),
            (12,23,"미국 PCE·개인소득/지출","critical","물가")]:
            us(m,d,8,30,title,imp,cat,"BEA",URLS["bea"])
    elif source == "Federal Reserve":
        for m,d in [(9,16),(10,28),(12,9)]:
            us(m,d,14,0,"FOMC 금리결정·성명","critical","중앙은행","Federal Reserve",URLS["fed"])
    elif source == "ECB":
        for m,d in [(10,29),(12,17)]:
            rows.append(_event(None,date_only=date(2026,m,d),country="EU",category="중앙은행",
                               title="ECB 통화정책회의·기자회견",importance="critical",source="ECB",url=URLS["ecb"],
                               note="공식 일정 내장 캐시 · 발표시각 당일 확인",raw_time="시간 별도"))
    elif source == "BOJ":
        for m,d in [(9,18),(10,30),(12,18)]:
            rows.append(_event(None,date_only=date(2026,m,d),country="JP",category="중앙은행",
                               title="BOJ 금융정책결정회의",importance="critical",source="BOJ",url=URLS["boj"],
                               note="공식 일정 내장 캐시 · 발표시각 고정되지 않음",raw_time="시간 미정"))
    elif source == "COEX":
        for title,m,d1,d2,imp in [
            ("2026 에듀테크 페어",9,17,19,"medium"),
            ("2026 투자 인사이트 포럼",9,19,19,"high"),
            ("코리아 라이프사이언스 위크 2026",9,21,22,"high"),
            ("GoIPO 나스닥 세미나 2026",9,21,22,"high"),
            ("2026 배터리코리아",9,21,21,"high"),
            ("2026 휴머노이드 서밋 서울",9,22,23,"critical"),
            ("제14회 국제첨단소재 기술대전",9,30,2,"high"),
        ]:
            d1v=date(2026,m,d1); d2v=date(2026,10,d2) if m==9 and d2<d1 else date(2026,m,d2)
            rows.append(_industry_event(d1v,title,end=d2v,source="COEX",url=URLS["coex"],venue="COEX",importance=imp,note="COEX 공식 일정 내장 캐시"))
    elif source == "SETEC":
        for title,d1,d2,imp in [
            ("2026 코리아 이커머스 페어",date(2026,9,17),date(2026,9,19),"medium"),
            ("강남 디지털 DNA 페스티벌",date(2026,9,30),date(2026,9,30),"medium"),
        ]:
            rows.append(_industry_event(d1,title,end=d2,source="SETEC",url=URLS["setec"],venue="SETEC",importance=imp,note="SETEC 공식 일정 내장 캐시"))
    return rows

COLLECTORS = [
    ("KIND", collect_kind),
    ("BLS", collect_bls),
    ("BEA", collect_bea),
    ("Federal Reserve", collect_fed),
    ("ECB", collect_ecb),
    ("BOJ", collect_boj),
    ("China NBS", collect_nbs),
    ("COEX", collect_coex),
    ("SETEC", collect_setec),
    ("Industry", collect_flagship_industry),
]


def _dedupe(events: list[dict]) -> list[dict]:
    out=[]; seen=set()
    for e in events:
        key=(e.get("date_kst"),e.get("time_kst"),e.get("country"),e.get("title"))
        if key in seen: continue
        seen.add(key); out.append(e)
    def sort_key(e):
        t=e.get("time_kst") or "99:99"
        if not re.fullmatch(r"\d{2}:\d{2}",t): t="99:99"
        rank={"critical":0,"high":1,"medium":2,"low":3}.get(e.get("importance"),9)
        return (e.get("date_kst") or "9999",t,rank,e.get("title") or "")
    return sorted(out,key=sort_key)


def snapshot(force: bool=False, days_back: int=1, days_forward: int=200) -> dict:
    now=time.time()
    if not force and _CACHE.get("payload") and now-_CACHE.get("at",0)<CACHE_TTL:
        return _CACHE["payload"]
    events=[]; sources=[]; errors=[]
    results={}
    with ThreadPoolExecutor(max_workers=len(COLLECTORS)) as pool:
        future_map={pool.submit(fn):name for name,fn in COLLECTORS}
        for fut in as_completed(future_map):
            name=future_map[fut]
            try:
                rows=fut.result(); results[name]=(rows,{"name":name,"ok":True,"count":len(rows)},None)
            except Exception as exc:
                msg=f"{type(exc).__name__}: {exc}"
                fallback=_fallback_2026(name)
                results[name]=(fallback,{"name":name,"ok":False,"fallback":bool(fallback),"count":len(fallback),"error":msg},f"{name}: {msg}")
    for name,_fn in COLLECTORS:
        rows,status,err=results.get(name,([],{"name":name,"ok":False,"count":0,"error":"collector missing"},f"{name}: collector missing"))
        events.extend(rows); sources.append(status)
        if err: errors.append(err)
    today=datetime.now(KST).date(); start=today-timedelta(days=days_back); end=today+timedelta(days=days_forward)
    filtered=[]
    for e in _dedupe(events):
        try: d=date.fromisoformat(e["date_kst"])
        except Exception: continue
        if start<=d<=end: filtered.append(e)
    payload={
        "updated_at":datetime.now(KST).isoformat(timespec="seconds"),
        "timezone":"Asia/Seoul",
        "window":{"start":start.isoformat(),"end":end.isoformat()},
        "events":filtered,
        "sources":sources,
        "errors":errors,
        "source_note":"공식 일정 우선 · 발표/상장 일정은 기관 사정에 따라 변경될 수 있음",
    }
    _CACHE.update(at=now,payload=payload)
    return payload
