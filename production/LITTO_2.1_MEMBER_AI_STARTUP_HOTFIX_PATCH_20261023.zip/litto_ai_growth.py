"""AI-only evidence and reflection. No Kiwoom calls or auto-trading actions."""
import json, sqlite3, threading, time, re, hashlib, queue
from pathlib import Path

_DB = None
_LOCK = threading.RLock()
_QUEUE=queue.Queue(maxsize=96)
_WORKER=False

def init(root):
    global _DB
    _DB = Path(root) / 'data' / 'litto_ai_reflections.sqlite3'
    _DB.parent.mkdir(parents=True,exist_ok=True)
    with _connect() as con:
        con.execute('''CREATE TABLE IF NOT EXISTS reflections (
          id INTEGER PRIMARY KEY AUTOINCREMENT, created_at REAL NOT NULL,
          symbol TEXT NOT NULL, thesis TEXT NOT NULL, evidence TEXT NOT NULL,
          invalidation TEXT NOT NULL, status TEXT NOT NULL DEFAULT 'pending',
          result_note TEXT NOT NULL DEFAULT '', reviewed_at REAL)''')
        con.execute('CREATE INDEX IF NOT EXISTS reflections_recent ON reflections(created_at DESC)')
        con.execute("CREATE TABLE IF NOT EXISTS ai_auto_index (id INTEGER PRIMARY KEY, code TEXT, candle_time TEXT, price REAL, fingerprint TEXT, created REAL)")
        con.execute("CREATE INDEX IF NOT EXISTS ai_auto_code ON ai_auto_index(code,created)")
        con.execute("CREATE TABLE IF NOT EXISTS ai_auto_observations (id INTEGER PRIMARY KEY, reflection_id INTEGER, candle_time TEXT, price REAL, observed REAL, UNIQUE(reflection_id,candle_time,price))")
    _start_autoworker()

def _connect():
    if _DB is None: raise RuntimeError('growth.init required')
    con = sqlite3.connect(str(_DB), timeout=3)
    con.row_factory = sqlite3.Row
    return con

def add_reflection(symbol, thesis, evidence='', invalidation=''):
    symbol=str(symbol or '').strip()[:40]
    thesis=str(thesis or '').strip()[:1200]
    if not symbol or not thesis: raise ValueError('종목과 분석 내용이 필요해.')
    with _LOCK, _connect() as con:
        cur=con.execute('INSERT INTO reflections(created_at,symbol,thesis,evidence,invalidation) VALUES(?,?,?,?,?)',
            (time.time(), symbol, thesis, str(evidence or '')[:2000], str(invalidation or '')[:700]))
        return {'ok':True, 'id':cur.lastrowid, 'status':'pending'}

def review_reflection(item_id, result_note, status='reviewed'):
    status=str(status or '')
    if status not in ('reviewed','invalidated'): raise ValueError('지원하지 않는 상태')
    result_note=str(result_note or '').strip()[:1400]
    if not result_note: raise ValueError('검증한 결과를 입력해.')
    with _LOCK, _connect() as con:
        cur=con.execute("UPDATE reflections SET status=?, result_note=?, reviewed_at=? WHERE id=? AND status='pending'",
            (status,result_note,time.time(),int(item_id)))
        return {'ok': bool(cur.rowcount), 'updated':cur.rowcount}

def recent(query='',limit=5):
    limit=max(1,min(int(limit),12))
    with _LOCK, _connect() as con:
        records=[dict(row) for row in con.execute('SELECT id,created_at,symbol,thesis,evidence,invalidation,status,result_note,reviewed_at FROM reflections ORDER BY id DESC LIMIT 150')]
    tokens=re.findall(r'[가-힣A-Za-z0-9]{2,}',str(query).lower())[:15]
    matches=[r for r in records if not tokens or any(t in (r['symbol']+' '+r['thesis']+' '+r['evidence']).lower() for t in tokens)]
    return matches[:limit]

def status():
    with _LOCK, _connect() as con:
        rows=con.execute('SELECT status,COUNT(*) FROM reflections GROUP BY status').fetchall()
    return {'ok':True,'counts':{r[0]:r[1] for r in rows}, 'auto_orders':False}

# Passive asynchronous journal: no broker requests and no order placement.
def _start_autoworker():
    global _WORKER
    with _LOCK:
        if not _WORKER:
            threading.Thread(target=_auto_worker, name='litto-ai-auto-journal', daemon=True).start()
            _WORKER=True

def _auto_worker():
    while True:
        item=_QUEUE.get()
        try:_write_auto(*item)
        except Exception as exc:print('[LITTO AI AUTO] '+str(exc)[:150],flush=True)
        finally:_QUEUE.task_done()

def enqueue_analysis(code,symbol,thesis,evidence,observed_at,price):
    code=str(code or '').strip()
    if not re.fullmatch(r'\d{6}',code) or not str(thesis or '').strip() or not str(observed_at or '').strip():return False
    try:
        price=float(price)
        if not 0<price<1e9:return False
        _QUEUE.put_nowait((code,str(symbol or code)[:40],str(thesis or '')[:1200],str(evidence or '')[:2000],str(observed_at)[:48],price))
        return True
    except (ValueError,TypeError,queue.Full):return False

def _write_auto(code,symbol,thesis,evidence,observed_at,price):
    now=time.time()
    fingerprint=hashlib.sha256((code+'|'+observed_at+'|'+thesis).encode()).hexdigest()
    with _LOCK,_connect() as con:
        prev=con.execute('SELECT id,created,fingerprint FROM ai_auto_index WHERE code=? ORDER BY id DESC LIMIT 1',(code,)).fetchone()
        if not prev or (prev['fingerprint']!=fingerprint and now-prev['created']>=1800):
            rec=con.execute('INSERT INTO reflections(created_at,symbol,thesis,evidence,invalidation) VALUES(?,?,?,?,?)',(now,symbol,thesis,evidence,'미확인 — 사후 검증 대기'))
            con.execute('INSERT INTO ai_auto_index(id,code,candle_time,price,fingerprint,created) VALUES(?,?,?,?,?,?)',(rec.lastrowid,code,observed_at,price,fingerprint,now))
        # Observe only strictly later DATE, never label it a correct/incorrect prediction.
        prior=con.execute('SELECT id,candle_time FROM ai_auto_index WHERE code=? ORDER BY id DESC LIMIT 12',(code,)).fetchall()
        for row in prior:
            if observed_at[:10]>str(row['candle_time'])[:10]:
                con.execute('INSERT OR IGNORE INTO ai_auto_observations(reflection_id,candle_time,price,observed) VALUES(?,?,?,?)',(row['id'],observed_at,price,now))

def auto_status(limit=10):
    limit=max(1,min(int(limit),20))
    with _LOCK,_connect() as con:
        records=[dict(r) for r in con.execute('SELECT a.id,a.code,a.candle_time,a.price,r.status,r.thesis,(SELECT COUNT(*) FROM ai_auto_observations o WHERE o.reflection_id=a.id) AS followup_count FROM ai_auto_index a JOIN reflections r ON a.id=r.id ORDER BY a.id DESC LIMIT ?',(limit,))]
    return {'ok':True,'items':records,'queue_size':_QUEUE.qsize(),'note':'Follow-up price observations do not establish trading accuracy; pending remains pending.'}
