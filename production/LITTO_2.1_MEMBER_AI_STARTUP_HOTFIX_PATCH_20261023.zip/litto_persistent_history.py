"""User-scoped durable TOP5 and candidate/sector history, independent of release folder.

Migration copies/merges legacy release-local JSON into %LOCALAPPDATA%/LITTO/history,
without deleting the originals. No background worker or network calls.
"""
import copy
import json
import os
import threading
from datetime import datetime
from pathlib import Path

_LOCK = threading.RLock()
_ALLOWED = {'closing_top5_performance.json', 'candidate_history.json'}
_DONE = set()

def storage_dir():
    home = os.getenv('LOCALAPPDATA')
    return (Path(home) if home else Path.home() / 'AppData' / 'Local') / 'LITTO' / 'history'

def _read(path, filename):
    try:
        value = json.loads(path.read_text(encoding='utf-8'))
        if filename == 'candidate_history.json':
            if not isinstance(value, dict): return None
            return value
        if not isinstance(value, dict) or not isinstance(value.get('days'), list): return None
        return value
    except (OSError, ValueError, TypeError):
        return None

def _merge(filename, current, legacy):
    if filename == 'candidate_history.json':
        merged = copy.deepcopy(current)
        for day, row in legacy.items():
            if day not in merged:
                merged[day] = copy.deepcopy(row)
            elif isinstance(row,dict) and isinstance(merged.get(day),dict):
                # Keep the current date record authoritative; add only missing codes.
                newer=merged[day]
                old_stocks=row.get('stocks')
                if isinstance(old_stocks,dict) and isinstance(newer.get('stocks'),dict):
                    for code,stock in old_stocks.items():
                        if code not in newer['stocks']:newer['stocks'][code]=copy.deepcopy(stock)
        return merged
    merged=copy.deepcopy(current)
    days=merged['days']
    have={str(d.get('date')):d for d in days if isinstance(d,dict) and d.get('date')}
    for day in legacy['days']:
        if not isinstance(day,dict):continue
        key=str(day.get('date') or '')
        if not key:continue
        if key not in have:
            days.append(copy.deepcopy(day));have[key]=days[-1]
        else:
            existing=have[key]
            # Only restore completed next-day results if current same-day rows lack them.
            old_rows={str(r.get('code')):r for r in (day.get('rows') or []) if isinstance(r,dict)}
            for r in existing.get('rows') or []:
                if not isinstance(r,dict):continue
                previous=old_rows.get(str(r.get('code')))
                if previous and not r.get('result') and isinstance(previous.get('result'),dict):
                    r['result']=copy.deepcopy(previous['result'])
            if day.get('snapshot_final') and not existing.get('snapshot_final'):
                # Never overwrite candidate selection; preserve the finalized flag only.
                existing['snapshot_final']=True
    days.sort(key=lambda x:str(x.get('date') or '') if isinstance(x,dict) else '')
    return merged

def _write(path, data):
    path.parent.mkdir(parents=True,exist_ok=True)
    tmp=path.with_name(path.name+'.migration.tmp')
    try:
        with tmp.open('w',encoding='utf-8') as f:
            json.dump(data,f,ensure_ascii=False,indent=2)
            f.flush();os.fsync(f.fileno())
        os.replace(tmp,path)
    finally:
        try:tmp.unlink(missing_ok=True)
        except OSError:pass

def file_path(release_root, filename):
    if filename not in _ALLOWED:raise ValueError('Unsupported history filename')
    dest=storage_dir()/filename
    key=(str(Path(release_root).resolve()),filename)
    with _LOCK:
        if key not in _DONE:
            old=Path(release_root)/'data'/filename
            # Keep source unchanged. Prefer the durable target on conflicting dates.
            old_data=_read(old,filename) if old.is_file() else None
            target_data=_read(dest,filename) if dest.is_file() else None
            if old_data is not None and (not dest.exists() or target_data is not None):
                merged=old_data if target_data is None else _merge(filename,target_data,old_data)
                if target_data != merged:
                    # Preserve existing external data before changes, too.
                    if target_data is not None:
                        backup=dest.with_name(dest.name+'.pre_migration.bak')
                        if not backup.exists():
                            import shutil
                            shutil.copy2(dest,backup)
                    _write(dest,merged)
            # An invalid existing target is never overwritten automatically.
            _DONE.add(key)
    return dest
