"""Deterministic synthetic fixtures. No real names or market prices."""
from datetime import datetime,timedelta
from engine import KST

def dataset():
    end=datetime(2026,9,14,15,20,tzinfo=KST)
    days=[];day=end.date()
    while len(days)<70:
        if day.weekday()<5:days.append(day.isoformat())
        day-=timedelta(days=1)
    days.reverse()
    def daily(o,h,l,c,v,date):return {'date':date,'open':o,'high':h,'low':l,'close':c,'volume':round(v/c),'value':v}
    def make(kind,idx):
        bars=[daily(10000,10100,9900,10000,20e9,date) for date in days]
        if kind=='어종':bars[-1]=daily(10100,11300,10000,11100,250e9,days[-1])
        elif kind=='피뢰침':
            bars[-2]=daily(10000,13000,9950,12950,150e9,days[-2])
            bars[-1]=daily(13000,14500,11950,12000,240e9,days[-1])
        elif kind=='하트존':
            bars[-2]=daily(10000,11150,9950,11100,180e9,days[-2])
            bars[-1]=daily(11000,11100,10650,10700,65e9,days[-1])
        elif kind=='F존':
            bars[-2]=daily(10000,13000,9950,12950,180e9,days[-2])
            bars[-1]=daily(13600,14500,13000,13100,170e9,days[-1])
        else:bars[-1]=daily(10000,10100,9300,9400,9e9,days[-1])
        ms=[]
        for date in days[-7:]:
            dt=datetime.fromisoformat(date+'T09:00:00').replace(tzinfo=KST)
            for j in range(26):
                tm=dt+timedelta(minutes=j*15)
                if tm>end:break
                price=10700 if kind=='하트존' else 10000
                if date==days[-1]:
                    if kind=='어종':price=10100+j*40
                    elif kind=='피뢰침':price=13000+(j*140 if j<10 else 1400-(j-10)*160)
                    elif kind=='F존':price=13600+j*80 if j<11 else 14400-(j-10)*88
                op=price-10;lo=price-30;hi=price+30
                ms.append({'time':tm.isoformat(),'open':op,'high':hi,'low':lo,'close':price,'volume':10000,'value':None,'complete':tm+timedelta(minutes=15)<=end})
        if kind=='F존':
            # Controlled monotonic retreat following expansion, no 4% rebound.
            pass
        return {'code':f'99000{idx}','name':kind+' 예시','sector':'가상 섹터 A' if idx<3 else '가상 섹터 B',
                'daily':bars,'m15':ms,'review':{}}
    return {'mode':'demo','asof':end.isoformat(),'scope':'가상 예시 5종목 · 실제 시세 아님',
            'stocks':[make(k,i) for i,k in enumerate(['어종','피뢰침','하트존','F존','제외'],1)]}
