"""SQLite-backed trading journal for LITTO/NewHeart.

User data is stored outside the program folder on Windows so replacing the
application does not erase reviews. On non-Windows/dev environments it falls
back to ./data.
"""
from __future__ import annotations

import json
import os
import sqlite3
from datetime import datetime
from pathlib import Path
from typing import Any, Iterable


def _default_data_dir(root: Path) -> Path:
    local = os.getenv("LOCALAPPDATA")
    if os.name == "nt" and local:
        p = Path(local) / "LITTO" / "NewHeart" / "user_data"
    else:
        p = root / "data"
    p.mkdir(parents=True, exist_ok=True)
    return p


def _storage_config_path(root: Path) -> Path:
    # Keep the pointer outside the selectable journal folder so moving the DB
    # does not lose the selected location.
    local = os.getenv("LOCALAPPDATA")
    if os.name == "nt" and local:
        p = Path(local) / "LITTO" / "NewHeart" / "journal_storage.json"
    else:
        p = root / "data" / "journal_storage.json"
    p.parent.mkdir(parents=True, exist_ok=True)
    return p


def _configured_data_dir(root: Path) -> Path | None:
    cfg = _storage_config_path(root)
    if not cfg.exists():
        return None
    try:
        raw = json.loads(cfg.read_text(encoding="utf-8"))
        value = str(raw.get("directory") or "").strip()
        if not value:
            return None
        return Path(value).expanduser()
    except Exception:
        return None


def _data_dir(root: Path) -> Path:
    p = _configured_data_dir(root) or _default_data_dir(root)
    p.mkdir(parents=True, exist_ok=True)
    return p


def db_path(root: Path) -> Path:
    return _data_dir(root) / "trading_journal.db"


def storage_info(root: Path) -> dict[str, Any]:
    directory = _data_dir(root)
    default = _default_data_dir(root)
    cfg = _storage_config_path(root)
    return {
        "directory": str(directory),
        "db_path": str(directory / "trading_journal.db"),
        "is_default": directory.resolve() == default.resolve(),
        "default_directory": str(default),
        "configured": cfg.exists(),
    }


def set_storage_dir(root: Path, directory: str, migrate: bool = True) -> dict[str, Any]:
    value = str(directory or "").strip().strip('"')
    if not value:
        raise ValueError("저장할 폴더 경로를 입력하세요.")
    target_dir = Path(value).expanduser()
    if not target_dir.is_absolute():
        raise ValueError("저장 위치는 D:\\LITTO_DATA 같은 전체 경로로 입력하세요.")
    target_dir.mkdir(parents=True, exist_ok=True)
    # Verify that the selected folder is writable before changing the pointer.
    probe = target_dir / ".litto_write_test"
    try:
        probe.write_text("ok", encoding="utf-8")
        probe.unlink(missing_ok=True)
    except Exception as exc:
        raise ValueError(f"선택한 폴더에 저장할 수 없습니다: {exc}") from exc

    old_db = db_path(root)
    new_db = target_dir / "trading_journal.db"
    try:
        same = old_db.resolve() == new_db.resolve()
    except Exception:
        same = str(old_db) == str(new_db)
    if same:
        return storage_info(root)

    if new_db.exists():
        raise ValueError("선택한 폴더에 trading_journal.db가 이미 있습니다. 데이터 보호를 위해 빈 폴더를 선택하세요.")

    if migrate and old_db.exists():
        # SQLite backup includes committed WAL contents and produces one clean DB.
        with sqlite3.connect(old_db, timeout=10) as source, sqlite3.connect(new_db, timeout=10) as dest:
            source.backup(dest)
            dest.commit()

    cfg = _storage_config_path(root)
    cfg.write_text(json.dumps({"directory": str(target_dir)}, ensure_ascii=False, indent=2), encoding="utf-8")
    init(root)
    return storage_info(root)


def reset_storage_dir(root: Path, migrate: bool = True) -> dict[str, Any]:
    current_db = db_path(root)
    target_dir = _default_data_dir(root)
    target_db = target_dir / "trading_journal.db"
    try:
        same = current_db.resolve() == target_db.resolve()
    except Exception:
        same = str(current_db) == str(target_db)
    if not same and target_db.exists():
        raise ValueError("기본 저장 위치에 기존 trading_journal.db가 있어 자동으로 덮어쓰지 않았습니다.")
    if not same and migrate and current_db.exists():
        with sqlite3.connect(current_db, timeout=10) as source, sqlite3.connect(target_db, timeout=10) as dest:
            source.backup(dest)
            dest.commit()
    cfg = _storage_config_path(root)
    cfg.write_text(json.dumps({"directory": str(target_dir), "confirmed": True}, ensure_ascii=False, indent=2), encoding="utf-8")
    init(root)
    return storage_info(root)



def confirm_default_storage(root: Path) -> dict[str, Any]:
    """Mark the default journal directory as an intentional user choice."""
    target_dir = _default_data_dir(root)
    cfg = _storage_config_path(root)
    cfg.write_text(json.dumps({"directory": str(target_dir), "confirmed": True}, ensure_ascii=False, indent=2), encoding="utf-8")
    init(root)
    return storage_info(root)

def _conn(root: Path) -> sqlite3.Connection:
    c = sqlite3.connect(db_path(root), timeout=10)
    c.row_factory = sqlite3.Row
    c.execute("PRAGMA journal_mode=WAL")
    c.execute("PRAGMA foreign_keys=ON")
    return c


def init(root: Path) -> None:
    with _conn(root) as c:
        c.executescript(
            """
            CREATE TABLE IF NOT EXISTS trades (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              trade_date TEXT NOT NULL,
              stock_code TEXT NOT NULL DEFAULT '',
              stock_name TEXT NOT NULL DEFAULT '',
              buy_qty REAL NOT NULL DEFAULT 0,
              buy_avg REAL,
              sell_qty REAL NOT NULL DEFAULT 0,
              sell_avg REAL,
              pnl REAL,
              return_rate REAL,
              fees REAL,
              tax REAL,
              settlement REAL,
              source TEXT NOT NULL DEFAULT 'manual',
              source_key TEXT NOT NULL UNIQUE,
              imported_at TEXT NOT NULL,
              strategy TEXT NOT NULL DEFAULT '',
              entry_reason TEXT NOT NULL DEFAULT '',
              exit_reason TEXT NOT NULL DEFAULT '',
              good TEXT NOT NULL DEFAULT '',
              bad TEXT NOT NULL DEFAULT '',
              next_action TEXT NOT NULL DEFAULT '',
              rule_followed INTEGER,
              chasing INTEGER,
              averaging_down INTEGER,
              sector_strong INTEGER,
              leader_stock INTEGER,
              fzone INTEGER,
              heartzone INTEGER,
              lightning INTEGER,
              tags TEXT NOT NULL DEFAULT '',
              stock_class TEXT NOT NULL DEFAULT '',
              sector_name TEXT NOT NULL DEFAULT '',
              theme_name TEXT NOT NULL DEFAULT '',
              checklist_json TEXT NOT NULL DEFAULT '{}',
              review_updated_at TEXT
            );
            CREATE INDEX IF NOT EXISTS idx_trades_date ON trades(trade_date DESC);
            CREATE INDEX IF NOT EXISTS idx_trades_code ON trades(stock_code, trade_date DESC);

            CREATE TABLE IF NOT EXISTS imports (
              id INTEGER PRIMARY KEY AUTOINCREMENT,
              trade_date TEXT NOT NULL,
              source TEXT NOT NULL,
              imported_at TEXT NOT NULL,
              row_count INTEGER NOT NULL DEFAULT 0,
              message TEXT NOT NULL DEFAULT ''
            );

            CREATE TABLE IF NOT EXISTS bs_fills (
              source_key TEXT PRIMARY KEY,
              trade_date TEXT NOT NULL,
              trade_time TEXT NOT NULL DEFAULT '',
              stock_code TEXT NOT NULL,
              stock_name TEXT NOT NULL DEFAULT '',
              side TEXT NOT NULL,
              qty REAL NOT NULL DEFAULT 0,
              price REAL,
              order_no TEXT NOT NULL DEFAULT '',
              exact_time INTEGER NOT NULL DEFAULT 1,
              source TEXT NOT NULL DEFAULT 'ka10076',
              imported_at TEXT NOT NULL
            );
            CREATE INDEX IF NOT EXISTS idx_bs_fills_code_date ON bs_fills(stock_code, trade_date, trade_time);
            """
        )
        # Schema migration for existing users: keep all prior journal rows and
        # append checklist fields only when they are missing.
        cols={r[1] for r in c.execute("PRAGMA table_info(trades)").fetchall()}
        migrations=[
            ("stock_class", "TEXT NOT NULL DEFAULT ''"),
            ("sector_name", "TEXT NOT NULL DEFAULT ''"),
            ("theme_name", "TEXT NOT NULL DEFAULT ''"),
            ("checklist_json", "TEXT NOT NULL DEFAULT '{}'"),
        ]
        for name,ddl in migrations:
            if name not in cols:
                c.execute(f"ALTER TABLE trades ADD COLUMN {name} {ddl}")


def _num(v: Any) -> float | None:
    if v in (None, ""):
        return None
    try:
        return float(str(v).replace(",", "").replace("+", "").strip())
    except (ValueError, TypeError):
        return None


def _first(row: dict[str, Any], *keys: str, default: Any = None) -> Any:
    for k in keys:
        if row.get(k) not in (None, ""):
            return row.get(k)
    return default


def normalize_ka10170(row: dict[str, Any], date: str) -> dict[str, Any]:
    code = str(_first(row, "stk_cd", "code", default="")).strip()
    name = str(_first(row, "stk_nm", "name", default=code)).strip()
    buy_qty = _num(_first(row, "buy_qty", "buy_cntr_qty", "buy_trde_qty")) or 0
    sell_qty = _num(_first(row, "sell_qty", "sel_qty", "sell_cntr_qty", "sel_cntr_qty")) or 0
    buy_avg = _num(_first(row, "buy_avg_pric", "buy_avg", "buy_uv", "avg_buy_pric"))
    sell_avg = _num(_first(row, "sel_avg_pric", "sell_avg_pric", "sell_avg", "cntr_pric", "avg_sell_pric"))
    pnl = _num(_first(row, "pl_amt", "tdy_sel_pl", "rlzt_pl", "profit_loss"))
    rr = _num(_first(row, "prft_rt", "pl_rt", "profit_rate"))
    fees = _num(_first(row, "cmsn", "tdy_trde_cmsn", "tot_cmsn"))
    tax = _num(_first(row, "tax", "tdy_trde_tax", "tot_tax"))
    settlement = _num(_first(row, "exct_amt", "settlement", "tot_exct_amt"))
    source_key = "ka10170:" + ":".join(
        [date, code, str(buy_qty), str(sell_qty), str(buy_avg or ""), str(sell_avg or ""), str(pnl or "")]
    )
    return dict(trade_date=date, stock_code=code, stock_name=name, buy_qty=buy_qty,
                buy_avg=buy_avg, sell_qty=sell_qty, sell_avg=sell_avg, pnl=pnl,
                return_rate=rr, fees=fees, tax=tax, settlement=settlement,
                source="키움 ka10170", source_key=source_key)


def normalize_ka10073(row: dict[str, Any], date: str) -> dict[str, Any]:
    code = str(_first(row, "stk_cd", default="")).strip()
    name = str(_first(row, "stk_nm", default=code)).strip()
    qty = _num(_first(row, "cntr_qty")) or 0
    buy_avg = _num(_first(row, "buy_uv"))
    sell_avg = _num(_first(row, "cntr_pric"))
    pnl = _num(_first(row, "tdy_sel_pl"))
    rr = _num(_first(row, "pl_rt"))
    fees = _num(_first(row, "tdy_trde_cmsn"))
    tax = _num(_first(row, "tdy_trde_tax"))
    row_date = str(_first(row, "dt", default=date)).strip()
    if len(row_date) == 8 and row_date.isdigit():
        row_date = f"{row_date[:4]}-{row_date[4:6]}-{row_date[6:]}"
    source_key = "ka10073:" + ":".join(
        [row_date, code, str(qty), str(buy_avg or ""), str(sell_avg or ""), str(pnl or "")]
    )
    return dict(trade_date=row_date or date, stock_code=code, stock_name=name,
                buy_qty=qty, buy_avg=buy_avg, sell_qty=qty, sell_avg=sell_avg,
                pnl=pnl, return_rate=rr, fees=fees, tax=tax, settlement=None,
                source="키움 ka10073", source_key=source_key)


def upsert_import(root: Path, rows: Iterable[dict[str, Any]]) -> tuple[int, int]:
    init(root)
    inserted = updated = 0
    now = datetime.now().isoformat(timespec="seconds")
    with _conn(root) as c:
        for r in rows:
            if not r.get("stock_code") and not r.get("stock_name"):
                continue
            old = c.execute("SELECT id FROM trades WHERE source_key=?", (r["source_key"],)).fetchone()
            if old:
                c.execute(
                    """UPDATE trades SET stock_code=?,stock_name=?,buy_qty=?,buy_avg=?,sell_qty=?,sell_avg=?,
                       pnl=?,return_rate=?,fees=?,tax=?,settlement=?,source=?,imported_at=? WHERE id=?""",
                    (r.get("stock_code",""), r.get("stock_name",""), r.get("buy_qty",0), r.get("buy_avg"),
                     r.get("sell_qty",0), r.get("sell_avg"), r.get("pnl"), r.get("return_rate"),
                     r.get("fees"), r.get("tax"), r.get("settlement"), r.get("source",""), now, old["id"]),
                )
                updated += 1
            else:
                c.execute(
                    """INSERT INTO trades
                       (trade_date,stock_code,stock_name,buy_qty,buy_avg,sell_qty,sell_avg,pnl,return_rate,
                        fees,tax,settlement,source,source_key,imported_at)
                       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
                    (r.get("trade_date",""),r.get("stock_code",""),r.get("stock_name",""),r.get("buy_qty",0),
                     r.get("buy_avg"),r.get("sell_qty",0),r.get("sell_avg"),r.get("pnl"),r.get("return_rate"),
                     r.get("fees"),r.get("tax"),r.get("settlement"),r.get("source",""),r["source_key"],now),
                )
                inserted += 1
    return inserted, updated


def log_import(root: Path, date: str, source: str, row_count: int, message: str = "") -> None:
    init(root)
    with _conn(root) as c:
        c.execute("INSERT INTO imports(trade_date,source,imported_at,row_count,message) VALUES(?,?,?,?,?)",
                  (date, source, datetime.now().isoformat(timespec="seconds"), int(row_count), str(message or "")[:1000]))


REVIEW_FIELDS = {
    "strategy", "entry_reason", "exit_reason", "good", "bad", "next_action", "tags",
    "rule_followed", "chasing", "averaging_down", "sector_strong", "leader_stock",
    "fzone", "heartzone", "lightning",
    "stock_class", "sector_name", "theme_name", "checklist_json"
}
BOOL_FIELDS = {"rule_followed", "chasing", "averaging_down", "sector_strong", "leader_stock", "fzone", "heartzone", "lightning"}


def update_review(root: Path, trade_id: int, review: dict[str, Any]) -> dict[str, Any]:
    init(root)
    clean: dict[str, Any] = {}
    for k in REVIEW_FIELDS:
        if k not in review:
            continue
        v = review[k]
        if k in BOOL_FIELDS:
            clean[k] = None if v is None else (1 if bool(v) else 0)
        elif k == "checklist_json":
            # Accept a dict from the browser but store portable JSON in SQLite.
            if isinstance(v, dict):
                clean[k] = json.dumps({str(a): bool(b) for a,b in v.items()}, ensure_ascii=False)
            else:
                try:
                    obj=json.loads(str(v or "{}"))
                    clean[k]=json.dumps(obj if isinstance(obj,dict) else {}, ensure_ascii=False)
                except Exception:
                    clean[k]="{}"
        else:
            clean[k] = str(v or "")[:5000]
    if not clean:
        raise ValueError("저장할 복기 내용이 없습니다.")
    clean["review_updated_at"] = datetime.now().isoformat(timespec="seconds")
    parts = ",".join(f"{k}=?" for k in clean)
    vals = list(clean.values()) + [int(trade_id)]
    with _conn(root) as c:
        cur = c.execute(f"UPDATE trades SET {parts} WHERE id=?", vals)
        if cur.rowcount < 1:
            raise ValueError("매매일지 항목을 찾을 수 없습니다.")
    return get_trade(root, trade_id)


def add_manual(root: Path, row: dict[str, Any]) -> dict[str, Any]:
    init(root)
    date = str(row.get("trade_date") or datetime.now().date().isoformat())[:10]
    code = str(row.get("stock_code") or "").strip()[:20]
    name = str(row.get("stock_name") or code).strip()[:100]
    now = datetime.now().isoformat(timespec="seconds")
    key = f"manual:{now}:{code}:{os.getpid()}"
    with _conn(root) as c:
        cur = c.execute(
            """INSERT INTO trades(trade_date,stock_code,stock_name,buy_qty,buy_avg,sell_qty,sell_avg,pnl,return_rate,
                   fees,tax,settlement,source,source_key,imported_at,strategy,entry_reason,exit_reason,good,bad,next_action,tags)
               VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)""",
            (date,code,name,_num(row.get("buy_qty")) or 0,_num(row.get("buy_avg")),_num(row.get("sell_qty")) or 0,
             _num(row.get("sell_avg")),_num(row.get("pnl")),_num(row.get("return_rate")),_num(row.get("fees")),
             _num(row.get("tax")),_num(row.get("settlement")),"수동입력",key,now,
             str(row.get("strategy") or "")[:100],str(row.get("entry_reason") or "")[:5000],
             str(row.get("exit_reason") or "")[:5000],str(row.get("good") or "")[:5000],
             str(row.get("bad") or "")[:5000],str(row.get("next_action") or "")[:5000],str(row.get("tags") or "")[:1000])
        )
        tid = cur.lastrowid
    return get_trade(root, int(tid))


def delete_trade(root: Path, trade_id: int) -> None:
    init(root)
    with _conn(root) as c:
        c.execute("DELETE FROM trades WHERE id=?", (int(trade_id),))


def _rowdict(r: sqlite3.Row) -> dict[str, Any]:
    d = dict(r)
    for k in BOOL_FIELDS:
        if d.get(k) is not None:
            d[k] = bool(d[k])
    raw=d.get("checklist_json")
    if isinstance(raw,str):
        try:d["checklist"] = json.loads(raw or "{}")
        except Exception:d["checklist"] = {}
    elif isinstance(raw,dict):
        d["checklist"] = raw
    else:
        d["checklist"] = {}
    return d


def get_trade(root: Path, trade_id: int) -> dict[str, Any]:
    init(root)
    with _conn(root) as c:
        r = c.execute("SELECT * FROM trades WHERE id=?", (int(trade_id),)).fetchone()
    if not r:
        raise ValueError("매매일지 항목을 찾을 수 없습니다.")
    return _rowdict(r)


def list_trades(root: Path, start: str | None = None, end: str | None = None, limit: int = 500) -> list[dict[str, Any]]:
    """Return sell-side journal rows grouped by day + stock.

    The review screen is intended to answer "how much did I realize when I sold?".
    Multiple partial sells of the same stock on the same day are therefore
    combined into one row. Buy-only rows are intentionally hidden.
    """
    init(root)
    where=["sell_qty>0"];args=[]
    if start:
        where.append("trade_date>=?");args.append(start[:10])
    if end:
        where.append("trade_date<=?");args.append(end[:10])
    sql="SELECT * FROM trades WHERE "+" AND ".join(where)+" ORDER BY trade_date DESC,id DESC LIMIT ?"
    args.append(max(1,min(int(limit)*10,10000)))
    with _conn(root) as c:
        raw=[_rowdict(r) for r in c.execute(sql,args).fetchall()]

    grouped: dict[tuple[str,str],dict[str,Any]]={}
    review_keys=list(REVIEW_FIELDS)+["review_updated_at"]
    for r in raw:
        code=str(r.get("stock_code") or r.get("stock_name") or "").strip()
        key=(str(r.get("trade_date") or ""),code)
        qty=float(r.get("sell_qty") or 0)
        if qty<=0:
            continue
        g=grouped.get(key)
        if g is None:
            g=dict(r)
            g["sell_qty"]=0.0
            g["sell_avg"]=None
            g["sell_amount"]=0.0
            g["pnl"]=0.0
            g["fees"]=0.0
            g["tax"]=0.0
            g["settlement"]=0.0
            g["_sell_value"]=0.0
            g["_rate_num"]=0.0
            g["_rate_den"]=0.0
            g["source"]="키움 실현손익 합산" if str(r.get("source") or "").startswith("키움") else str(r.get("source") or "")
            grouped[key]=g
        price=float(r.get("sell_avg") or 0)
        g["sell_qty"]+=qty
        g["_sell_value"]+=qty*price
        g["sell_amount"]+=qty*price
        for f in ("pnl","fees","tax","settlement"):
            if r.get(f) is not None:
                g[f]=float(g.get(f) or 0)+float(r.get(f) or 0)
        if r.get("return_rate") is not None:
            g["_rate_num"]+=float(r.get("return_rate") or 0)*qty
            g["_rate_den"]+=qty
        # Prefer the row that actually contains review text/settings, otherwise
        # keep the newest row id already selected by the query ordering.
        has_review=bool(r.get("review_updated_at") or r.get("strategy") or r.get("entry_reason") or r.get("good") or r.get("bad") or r.get("next_action"))
        current_review=bool(g.get("review_updated_at") or g.get("strategy") or g.get("entry_reason") or g.get("good") or g.get("bad") or g.get("next_action"))
        if has_review and not current_review:
            g["id"]=r.get("id")
            for f in review_keys:
                g[f]=r.get(f)
    out=[]
    for g in grouped.values():
        q=float(g.get("sell_qty") or 0)
        g["sell_avg"]=round(float(g.get("_sell_value") or 0)/q,4) if q else None
        if float(g.get("_rate_den") or 0)>0:
            g["return_rate"]=round(float(g.get("_rate_num") or 0)/float(g.get("_rate_den") or 1),4)
        g.pop("_sell_value",None);g.pop("_rate_num",None);g.pop("_rate_den",None)
        out.append(g)
    out.sort(key=lambda x:(str(x.get("trade_date") or ""),int(x.get("id") or 0)),reverse=True)
    return out[:max(1,min(int(limit),2000))]


def stats(root: Path, start: str | None = None, end: str | None = None) -> dict[str, Any]:
    rows=list_trades(root,start,end,2000)
    finished=[r for r in rows if r.get("pnl") is not None or r.get("return_rate") is not None]
    pnls=[float(r["pnl"] or 0) for r in finished if r.get("pnl") is not None]
    rates=[float(r["return_rate"] or 0) for r in finished if r.get("return_rate") is not None]
    wins=[r for r in finished if float(r.get("pnl") or 0)>0 or (r.get("pnl") is None and float(r.get("return_rate") or 0)>0)]
    losses=[r for r in finished if float(r.get("pnl") or 0)<0 or (r.get("pnl") is None and float(r.get("return_rate") or 0)<0)]
    gross_profit=sum(max(0,x) for x in pnls); gross_loss=abs(sum(min(0,x) for x in pnls))
    by_strategy: dict[str,dict[str,Any]]={}
    for r in finished:
        s=(r.get("strategy") or "미분류").strip() or "미분류"
        b=by_strategy.setdefault(s,{"strategy":s,"count":0,"wins":0,"pnl":0.0,"rates":[]})
        b["count"]+=1;b["pnl"]+=float(r.get("pnl") or 0)
        if r in wins:b["wins"]+=1
        if r.get("return_rate") is not None:b["rates"].append(float(r["return_rate"]))
    strategies=[]
    for b in by_strategy.values():
        strategies.append({"strategy":b["strategy"],"count":b["count"],"win_rate":round(100*b["wins"]/b["count"],1) if b["count"] else 0,
                           "pnl":round(b["pnl"],0),"avg_return":round(sum(b["rates"])/len(b["rates"]),2) if b["rates"] else None})
    strategies.sort(key=lambda x:(-x["count"],-x["pnl"]))
    return {
        "count":len(finished),"wins":len(wins),"losses":len(losses),
        "win_rate":round(100*len(wins)/len(finished),1) if finished else 0,
        "pnl":round(sum(pnls),0),"avg_return":round(sum(rates)/len(rates),2) if rates else None,
        "avg_win":round(sum(float(r.get("return_rate") or 0) for r in wins)/len(wins),2) if wins else None,
        "avg_loss":round(sum(float(r.get("return_rate") or 0) for r in losses)/len(losses),2) if losses else None,
        "profit_factor":round(gross_profit/gross_loss,2) if gross_loss else (None if not gross_profit else 999.0),
        "strategies":strategies,
    }


def snapshot(root: Path, start: str | None = None, end: str | None = None, limit: int = 500) -> dict[str, Any]:
    init(root)
    rows=list_trades(root,start,end,limit)
    with _conn(root) as c:
        imp=c.execute("SELECT * FROM imports ORDER BY id DESC LIMIT 10").fetchall()
    info=storage_info(root)
    return {"db_path":info["db_path"],"storage_dir":info["directory"],"storage_is_default":info["is_default"],"storage_configured":info.get("configured",False),"rows":rows,"stats":stats(root,start,end),"imports":[dict(x) for x in imp]}


def upsert_bs_fills(root: Path, rows: list[dict[str, Any]]) -> int:
    if not rows:
        return 0
    now=datetime.now().isoformat(timespec="seconds")
    data=[]
    for r in rows:
        key=str(r.get("source_key") or "").strip()
        code=str(r.get("stock_code") or "").strip()
        side=str(r.get("side") or "").strip().lower()
        date=str(r.get("trade_date") or "").strip()
        if not key or not code or side not in {"buy","sell"} or not date:
            continue
        data.append((key,date,str(r.get("trade_time") or ""),code,str(r.get("stock_name") or ""),side,float(r.get("qty") or 0),_num(r.get("price")),str(r.get("order_no") or ""),1 if r.get("exact_time",True) else 0,str(r.get("source") or "ka10076"),now))
    if not data:
        return 0
    with _conn(root) as c:
        c.executemany("""INSERT INTO bs_fills(source_key,trade_date,trade_time,stock_code,stock_name,side,qty,price,order_no,exact_time,source,imported_at) VALUES(?,?,?,?,?,?,?,?,?,?,?,?) ON CONFLICT(source_key) DO UPDATE SET trade_time=excluded.trade_time,stock_name=excluded.stock_name,qty=excluded.qty,price=excluded.price,order_no=excluded.order_no,exact_time=excluded.exact_time,source=excluded.source,imported_at=excluded.imported_at""",data)
    return len(data)

def delete_bs_fills(root: Path, stock_code: str, trade_date: str = "", source: str = "") -> int:
    code=str(stock_code or "").strip()
    if not code:
        return 0
    q="DELETE FROM bs_fills WHERE stock_code=?"
    args=[code]
    if trade_date:
        q+=" AND trade_date=?"; args.append(str(trade_date))
    if source:
        q+=" AND source=?"; args.append(str(source))
    with _conn(root) as c:
        cur=c.execute(q,args)
        return int(cur.rowcount or 0)

def list_bs_fills(root: Path, stock_code: str, start_date: str = "", end_date: str = "") -> list[dict[str, Any]]:
    code=str(stock_code or "").strip()
    if not code:
        return []
    q="SELECT trade_date,trade_time,stock_code,stock_name,side,qty,price,order_no,exact_time,source FROM bs_fills WHERE stock_code=?"
    args=[code]
    if start_date:
        q+=" AND trade_date>=?";args.append(start_date)
    if end_date:
        q+=" AND trade_date<=?";args.append(end_date)
    q+=" ORDER BY trade_date,trade_time,side"
    with _conn(root) as c:
        return [dict(r) for r in c.execute(q,args).fetchall()]

def journal_bs_daily_rows(root: Path, stock_code: str, start_date: str = "") -> list[dict[str, Any]]:
    code=str(stock_code or "").strip()
    if not code:
        return []
    q="SELECT trade_date,stock_code,stock_name,buy_qty,buy_avg,sell_qty,sell_avg,source FROM trades WHERE stock_code=?"
    args=[code]
    if start_date:
        q+=" AND trade_date>=?";args.append(start_date)
    q+=" ORDER BY trade_date"
    out=[]
    with _conn(root) as c:
        for r in c.execute(q,args).fetchall():
            d=dict(r)
            buy_qty=float(d.get("buy_qty") or 0)
            sell_qty=float(d.get("sell_qty") or 0)
            # Realized-P/L journal rows are dated by SELL date even though they also
            # carry buy_qty/buy_avg.  Never invent a historical B on the sell date.
            # Only true buy-only/manual rows may supply a daily B fallback.
            if buy_qty>0 and sell_qty<=0:
                out.append({"trade_date":d["trade_date"],"trade_time":"","stock_code":code,"stock_name":d.get("stock_name") or "","side":"buy","qty":buy_qty,"price":d.get("buy_avg"),"order_no":"","exact_time":0,"source":"journal"})
            if sell_qty>0:
                out.append({"trade_date":d["trade_date"],"trade_time":"","stock_code":code,"stock_name":d.get("stock_name") or "","side":"sell","qty":d.get("sell_qty") or 0,"price":d.get("sell_avg"),"order_no":"","exact_time":0,"source":"journal"})
    return out
