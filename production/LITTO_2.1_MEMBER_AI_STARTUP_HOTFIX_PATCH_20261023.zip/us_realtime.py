"""Minimal Kiwoom U.S. real-time WebSocket client (stdlib only).

Used only for read-only FE (미국체결) market data.  REST remains the initial/fallback
source; this module overlays live trades when Kiwoom emits them.
"""
from __future__ import annotations
import base64, hashlib, json, os, socket, ssl, struct, threading, time
from datetime import datetime, timezone
from urllib.parse import urlparse


def _num(v):
    try:
        if v is None or v == '': return None
        return float(str(v).replace(',', '').replace('+', '').strip())
    except Exception:
        return None


class _WebSocket:
    def __init__(self, url, timeout=5.0, frame_timeout=None):
        self.url=url; self.timeout=timeout; self.sock=None
        # Bound an incomplete message without changing the normal idle timeout.
        self.frame_timeout=float(frame_timeout) if frame_timeout is not None else max(8.0,float(timeout)*3.0)
        self._frame_deadline=None

    def connect(self):
        u=urlparse(self.url)
        if u.scheme != 'wss': raise OSError('wss only')
        host=u.hostname; port=u.port or 443; path=u.path or '/'
        raw=socket.create_connection((host,port), timeout=self.timeout)
        ctx=ssl.create_default_context()
        s=ctx.wrap_socket(raw, server_hostname=host); s.settimeout(self.timeout)
        key=base64.b64encode(os.urandom(16)).decode('ascii')
        req=(f"GET {path} HTTP/1.1\r\nHost: {host}:{port}\r\nUpgrade: websocket\r\n"
             f"Connection: Upgrade\r\nSec-WebSocket-Key: {key}\r\nSec-WebSocket-Version: 13\r\n\r\n")
        s.sendall(req.encode('ascii'))
        buf=b''
        while b'\r\n\r\n' not in buf and len(buf)<65536:
            part=s.recv(4096)
            if not part: raise OSError('websocket handshake closed')
            buf+=part
        head=buf.split(b'\r\n\r\n',1)[0].decode('latin1','replace')
        if ' 101 ' not in head.split('\r\n',1)[0]: raise OSError('websocket handshake failed')
        accept=None
        for line in head.split('\r\n')[1:]:
            if ':' in line:
                k,v=line.split(':',1)
                if k.strip().lower()=='sec-websocket-accept': accept=v.strip()
        expected=base64.b64encode(hashlib.sha1((key+'258EAFA5-E914-47DA-95CA-C5AB0DC85B11').encode()).digest()).decode()
        if accept != expected: raise OSError('websocket accept mismatch')
        self.sock=s

    def close(self):
        s=self.sock; self.sock=None
        if s:
            try:self._send_frame(b'',0x8,s)
            except Exception:pass
            try:s.close()
            except Exception:pass

    def _send_frame(self,payload,opcode=0x1,sock=None):
        s=sock or self.sock
        if not s: raise OSError('websocket not connected')
        if isinstance(payload,str): payload=payload.encode('utf-8')
        n=len(payload); mask=os.urandom(4); first=0x80|(opcode&0x0f)
        if n<126: header=bytes([first,0x80|n])
        elif n<65536: header=bytes([first,0x80|126])+struct.pack('!H',n)
        else: header=bytes([first,0x80|127])+struct.pack('!Q',n)
        masked=bytes(b ^ mask[i%4] for i,b in enumerate(payload))
        s.sendall(header+mask+masked)

    def send_json(self,obj): self._send_frame(json.dumps(obj,ensure_ascii=False,separators=(',',':')))

    def _exact(self,n):
        # A timeout after consuming even a single frame byte cannot be treated
        # as an idle timeout: the next recv would otherwise lose frame alignment.
        out=bytearray()
        while len(out)<n:
            try:
                b=self.sock.recv(n-len(out))
            except socket.timeout:
                if self._frame_deadline is None and not out:
                    raise  # Safe idle timeout: no frame bytes consumed yet.
                if self._frame_deadline is None:
                    self._frame_deadline=time.monotonic()+self.frame_timeout
                if time.monotonic()<self._frame_deadline:
                    continue
                raise OSError('websocket incomplete frame deadline exceeded')
            if not b:raise OSError('websocket closed')
            if self._frame_deadline is None:
                self._frame_deadline=time.monotonic()+self.frame_timeout
            out.extend(b)
            if time.monotonic()>self._frame_deadline:
                raise OSError('websocket incomplete frame deadline exceeded')
        return bytes(out)

    def recv_text(self):
        fragments=[];started=False
        self._frame_deadline=None
        try:
            while True:
                h=self._exact(2);b1,b2=h[0],h[1];fin=bool(b1&0x80);op=b1&0x0f;masked=bool(b2&0x80);n=b2&0x7f
                if n==126:n=struct.unpack('!H',self._exact(2))[0]
                elif n==127:n=struct.unpack('!Q',self._exact(8))[0]
                mask=self._exact(4) if masked else None;payload=self._exact(n) if n else b''
                if mask:payload=bytes(b ^ mask[i%4] for i,b in enumerate(payload))
                if op==0x8:raise OSError('websocket close frame')
                if op==0x9:
                    self._send_frame(payload,0xA)
                    self._frame_deadline=None
                    continue
                if op==0xA:
                    self._frame_deadline=None
                    continue
                if op==0x1:
                    fragments=[payload];started=True
                    if fin:return b''.join(fragments).decode('utf-8','replace')
                elif op==0x0 and started:
                    fragments.append(payload)
                    if fin:return b''.join(fragments).decode('utf-8','replace')
                elif op==0x2:
                    return ''  # Ignore unexpected binary frame without busy-spin.
                # Each continuation is part of the same logical message deadline.
        finally:
            self._frame_deadline=None


class UsRealtimeFeed:
    """Background FE (미국체결) subscriber shared by one Kiwoom client."""
    URL='wss://api.kiwoom.com:10000/api/us/websocket'
    def __init__(self, kiwoom):
        self.kiwoom=kiwoom
        self.lock=threading.RLock(); self.desired=[]; self.version=0
        self.quotes={}; self.thread=None; self.stop_event=threading.Event()
        self.state='대기'; self.error=''; self.connected=False; self.last_message=0.0; self.last_reg=0.0
        self.raw_sample=None

    def ensure(self, symbols):
        clean=[];seen=set()
        for x in symbols:
            s=str(x or '').strip().upper()
            if s and s not in seen:seen.add(s);clean.append(s)
        with self.lock:
            if clean != self.desired:
                self.desired=clean; self.version+=1
            if not self.thread or not self.thread.is_alive():
                self.stop_event.clear(); self.thread=threading.Thread(target=self._run,daemon=True,name='LITTO-US-FE'); self.thread.start()

    def stop(self): self.stop_event.set()

    def snapshot(self):
        with self.lock:
            return dict(self.quotes),{
                'connected':self.connected,'state':self.state,'error':self.error,
                'subscribed':len(self.desired),'live_count':len(self.quotes),
                'last_message':datetime.fromtimestamp(self.last_message,timezone.utc).isoformat() if self.last_message else None,
                'transport':'Kiwoom WebSocket FE (미국체결)'
            }

    def _set_state(self,state,error='',connected=None):
        with self.lock:
            self.state=state; self.error=str(error or '')[:240]
            if connected is not None:self.connected=bool(connected)

    def _register(self,ws,symbols):
        # Official REG shape; FE is the U.S. trade stream.
        ws.send_json({'trnm':'REG','grp_no':'1','refresh':'0','data':[{'item':symbols,'type':['FE']}]})
        self.last_reg=time.time()

    def _symbol(self,item,vals,known):
        # Never use startswith/endswith matching here.  Short U.S. tickers
        # (O, F, T, etc.) can otherwise steal another symbol's real-time frame.
        # Accept only an exact ticker or an exact token inside a qualified code.
        import re
        candidates=[vals.get('9001'), vals.get('stk_cd'), item]
        for c in candidates:
            raw=str(c or '').strip().upper()
            if not raw:
                continue
            if raw in known:
                return raw
            tokens=[t for t in re.split(r'[^A-Z0-9]+', raw) if t]
            exact=[t for t in tokens if t in known]
            if len(exact)==1:
                return exact[0]
        return ''

    def _handle(self,msg):
        if not isinstance(msg,dict) or msg.get('trnm')!='REAL':return
        rows=msg.get('data') or []
        if not isinstance(rows,list):return
        with self.lock: known=set(self.desired)
        for row in rows:
            if not isinstance(row,dict) or str(row.get('type') or '').upper()!='FE':continue
            vals=row.get('values') or {}
            if not isinstance(vals,dict):continue
            sym=self._symbol(row.get('item'),vals,known)
            if not sym:continue
            # FE uses the standard Kiwoom realtime market FIDs for price/change/rate/time.
            price=_num(vals.get('10') if '10' in vals else vals.get('cur_prc'))
            change=_num(vals.get('11') if '11' in vals else vals.get('pred_pre'))
            rate=_num(vals.get('12') if '12' in vals else vals.get('flu_rt'))
            tm=str(vals.get('20') or vals.get('51020') or vals.get('cntr_tm') or '')
            if price is not None: price=abs(price)
            if price is None and rate is None:continue
            q={'code':sym,'price':price,'change':change,'change_rate':rate,'time':tm,
               'source':'websocket_FE','received_at':time.time()}
            with self.lock:
                self.quotes[sym]=q; self.last_message=time.time(); self.raw_sample={'item':row.get('item'),'keys':sorted(vals.keys())[:80]}

    def _run(self):
        backoff=1.0
        while not self.stop_event.is_set():
            ws=None
            try:
                self.kiwoom.auth(); token=self.kiwoom.token
                self._set_state('연결 중',connected=False)
                ws=_WebSocket(self.URL,5.0); ws.connect()
                ws.send_json({'trnm':'LOGIN','token':token})
                logged=False; deadline=time.time()+8
                while time.time()<deadline and not self.stop_event.is_set():
                    try:text=ws.recv_text()
                    except socket.timeout:continue
                    msg=json.loads(text)
                    if msg.get('trnm')=='PING':ws.send_json(msg);continue
                    if msg.get('trnm')=='LOGIN':
                        if str(msg.get('return_code','0'))!='0':raise OSError('Kiwoom WebSocket LOGIN rejected')
                        logged=True;break
                if not logged:raise OSError('Kiwoom WebSocket LOGIN timeout')
                with self.lock:symbols=list(self.desired); reg_version=self.version
                if symbols:self._register(ws,symbols)
                self._set_state('실시간 연결',connected=True); backoff=1.0
                while not self.stop_event.is_set():
                    with self.lock: changed=(self.version!=reg_version); symbols=list(self.desired); current_version=self.version
                    if changed:
                        self._register(ws,symbols); reg_version=current_version
                    try:text=ws.recv_text()
                    except socket.timeout:continue
                    msg=json.loads(text)
                    if msg.get('trnm')=='PING':ws.send_json(msg);continue
                    if msg.get('trnm')=='REG' and str(msg.get('return_code','0'))!='0':
                        raise OSError('Kiwoom FE REG rejected')
                    self._handle(msg)
            except Exception as e:
                self._set_state('재연결 대기',str(e),False)
                if self.stop_event.wait(backoff):break
                backoff=min(backoff*2,15.0)
            finally:
                if ws:ws.close()
        self._set_state('중지',connected=False)
