"""On-demand Kiwoom domestic 0D orderbook realtime feed.

Separate from the frozen Page-1 0B trade engine. Only one user-selected stock is
subscribed at a time, so opening the orderbook does not add load to the scanner.
"""
from __future__ import annotations
import json, socket, threading, time
from datetime import datetime, timezone
from domestic_realtime import _kr_market_window
from us_realtime import _WebSocket


def _num(v):
    try:
        if v is None or v == '': return None
        return float(str(v).replace(',', '').replace('+', '').strip())
    except Exception:
        return None


def _base_code(v):
    s=str(v or '').strip().upper()
    for suf in ('_AL','_NX'):
        if s.endswith(suf): s=s[:-len(suf)]
    digits=''.join(ch for ch in s if ch.isdigit())
    return digits[-6:] if len(digits)>=6 else s[-6:]


class DomesticOrderbookFeed:
    URL='wss://api.kiwoom.com:10000/api/dostk/websocket'
    def __init__(self,kiwoom):
        self.kiwoom=kiwoom; self.lock=threading.RLock(); self.desired=''; self.version=0
        self.book={}; self.thread=None; self.stop_event=threading.Event(); self.connected=False
        self.state='대기'; self.error=''; self.last_message=0.0; self.reconnects=0
        self.seq=0; self.recent_trades=[]; self.cond=threading.Condition(self.lock)
        self.use_sor=not bool(getattr(kiwoom,'mock',False)); self.provider_code='' ; self.last_register_at=0.0
        self.last_book_message=0.0; self.watchdog_refreshes=0
        self.recv_slow_count=0; self.recv_max_ms=0.0; self.recv_last_slow_ms=0.0; self.recv_last_slow_at=0.0; self.last_trade_message=0.0
        # Diagnostic-only receive intervals; no timers, Kiwoom requests, or reconnects.
        self.book_gap_max_ms=0.0; self.book_gap_count=0; self.book_gap_recent=[]; self.trade_gap_max_ms=0.0; self.trade_gap_count=0

    def ensure(self,symbol):
        c=_base_code(symbol)
        if not c:return
        with self.lock:
            if c!=self.desired:
                self.desired=c; self.version+=1; self.book={}; self.recent_trades=[]; self.last_message=0.0; self.seq+=1
                self.use_sor=not bool(getattr(self.kiwoom,'mock',False)); self.provider_code=''; self.last_book_message=0.0
                self.book_gap_max_ms=0.0; self.book_gap_count=0; self.book_gap_recent=[]; self.trade_gap_max_ms=0.0; self.trade_gap_count=0; self.last_trade_message=0.0
            if not self.thread or not self.thread.is_alive():
                self.stop_event.clear(); self.thread=threading.Thread(target=self._run,daemon=True,name='LITTO-KR-0D'); self.thread.start()

    def stop(self): self.stop_event.set()

    def snapshot(self,symbol=None):
        c=_base_code(symbol or self.desired)
        with self.lock:
            b=dict(self.book) if c==self.desired else {}
            age=(time.time()-self.last_message) if self.last_message else None
            venue='SOR' if self.provider_code.endswith('_AL') else 'KRX'
            return {**b,'code':c,'connected':self.connected,'state':self.state,'error':self.error,
                    'last_message_age':age,'orderbook_age':(time.time()-self.last_book_message) if self.last_book_message else None,
                    'watchdog_refreshes':self.watchdog_refreshes,'reconnects':self.reconnects,'seq':self.seq,
                    'recv_slow_count':self.recv_slow_count,'recv_max_ms':round(self.recv_max_ms,1),
                    'recv_last_slow_ms':round(self.recv_last_slow_ms,1),'recv_last_slow_at':self.recv_last_slow_at,
                    'trade_age':(time.time()-self.last_trade_message) if self.last_trade_message else None,
                    'recent_trades':list(self.recent_trades[-30:]),'venue':venue,
                    'provider_code':self.provider_code or c,
                    'source':('키움 WebSocket 0D/0B · 통합(SOR)' if venue=='SOR' else '키움 WebSocket 0D/0B · KRX')}

    def diagnostics(self):
        with self.lock:
            now=time.time()
            return {'symbol':self.desired,'state':self.state,'connected':self.connected,
                    'seq':self.seq,'provider_code':self.provider_code,
                    'last_book_at':self.last_book_message,'book_age_s':round(now-self.last_book_message,3) if self.last_book_message else None,
                    'last_trade_at':self.last_trade_message,'trade_age_s':round(now-self.last_trade_message,3) if self.last_trade_message else None,
                    'book_gap_max_ms':round(self.book_gap_max_ms,1),'book_gap_count_ge_1500ms':self.book_gap_count,
                    'book_gap_recent':list(self.book_gap_recent),'trade_gap_max_ms':round(self.trade_gap_max_ms,1),
                    'trade_gap_count_ge_1500ms':self.trade_gap_count,'reconnects':self.reconnects,
                    'recv_slow_count':self.recv_slow_count,'recv_max_ms':round(self.recv_max_ms,1),
                    'watchdog_refreshes':self.watchdog_refreshes,
                    'note':'Gaps are intervals between received provider messages; quiet symbols can naturally show gaps.'}

    def wait_snapshot(self,symbol,last_seq=0,timeout=0.75):
        c=_base_code(symbol or self.desired)
        end=time.time()+max(0.05,min(float(timeout or 0.75),1.2))
        with self.cond:
            while c==self.desired and int(self.seq)==int(last_seq or 0):
                remain=end-time.time()
                if remain<=0: break
                self.cond.wait(remain)
            b=dict(self.book) if c==self.desired else {}
            age=(time.time()-self.last_message) if self.last_message else None
            venue='SOR' if self.provider_code.endswith('_AL') else 'KRX'
            return {**b,'code':c,'connected':self.connected,'state':self.state,'error':self.error,
                    'last_message_age':age,'orderbook_age':(time.time()-self.last_book_message) if self.last_book_message else None,
                    'watchdog_refreshes':self.watchdog_refreshes,'reconnects':self.reconnects,'seq':self.seq,
                    'recv_slow_count':self.recv_slow_count,'recv_max_ms':round(self.recv_max_ms,1),
                    'recv_last_slow_ms':round(self.recv_last_slow_ms,1),'recv_last_slow_at':self.recv_last_slow_at,
                    'trade_age':(time.time()-self.last_trade_message) if self.last_trade_message else None,
                    'recent_trades':list(self.recent_trades[-30:]),'venue':venue,
                    'provider_code':self.provider_code or c,
                    'source':('키움 WebSocket 0D/0B · 통합(SOR)' if venue=='SOR' else '키움 WebSocket 0D/0B · KRX')}

    def _set_state(self,state,error='',connected=None):
        with self.lock:
            self.state=state; self.error=str(error or '')[:300]
            if connected is not None:self.connected=bool(connected)

    def _register(self,ws,c,force_krx=False):
        if not c:return
        provider=c if (force_krx or bool(getattr(self.kiwoom,'mock',False))) else c+'_AL'
        with self.lock:
            self.provider_code=provider; self.use_sor=provider.endswith('_AL'); self.last_register_at=time.time()
        # _AL is Kiwoom's integrated KRX+NXT symbol. If an account/environment
        # rejects it, _run immediately falls back to the plain KRX symbol.
        ws.send_json({'trnm':'REG','grp_no':'8','refresh':'0','data':[{'item':[provider],'type':['0D','0B']}]})

    def _handle(self,msg):
        if not isinstance(msg,dict) or msg.get('trnm')!='REAL':return
        rows=msg.get('data') or []
        if not isinstance(rows,list):return
        for row in rows:
            if not isinstance(row,dict):continue
            typ=str(row.get('type') or '').upper()
            vals=row.get('values') or {}; c=_base_code(row.get('item'))
            with self.lock: desired=self.desired
            if not isinstance(vals,dict) or c!=desired:continue
            now=time.time()
            if typ=='0D':
                asks=[]; bids=[]
                for i in range(10):
                    ap=_num(vals.get(str(41+i))); aq=_num(vals.get(str(61+i)))
                    bp=_num(vals.get(str(51+i))); bq=_num(vals.get(str(71+i)))
                    if ap is not None:ap=abs(ap)
                    if bp is not None:bp=abs(bp)
                    asks.append({'level':i+1,'price':ap,'qty':abs(aq) if aq is not None else None})
                    bids.append({'level':i+1,'price':bp,'qty':abs(bq) if bq is not None else None})
                patch={'time':str(vals.get('21') or ''),'asks':asks,'bids':bids,
                       'ask_total':abs(_num(vals.get('121')) or 0),'bid_total':abs(_num(vals.get('125')) or 0),
                       'expected_price':abs(_num(vals.get('23')) or 0),'expected_qty':abs(_num(vals.get('24')) or 0),
                       'buy_ratio':_num(vals.get('129')),'sell_ratio':_num(vals.get('139')),
                       'orderbook_received_at':now}
                with self.cond:
                    if self.last_book_message:
                        gap_ms=(now-self.last_book_message)*1000.0
                        self.book_gap_max_ms=max(self.book_gap_max_ms,gap_ms)
                        if gap_ms>=1500:
                            self.book_gap_count+=1
                            self.book_gap_recent.append({'at':round(now,3),'gap_ms':round(gap_ms,1),'symbol':c})
                            if len(self.book_gap_recent)>30:self.book_gap_recent=self.book_gap_recent[-30:]
                    cur=dict(self.book);cur.update(patch);self.book=cur;self.last_message=now;self.last_book_message=now;self.seq+=1
                    self.cond.notify_all()
            elif typ=='0B':
                price=_num(vals.get('10') if '10' in vals else vals.get('cur_prc'))
                rate=_num(vals.get('12') if '12' in vals else vals.get('flu_rt'))
                acc_vol=_num(vals.get('13') if '13' in vals else vals.get('acc_trde_qty'))
                acc_value=_num(vals.get('14') if '14' in vals else vals.get('acc_trde_prica'))
                tick_vol=_num(vals.get('15') if '15' in vals else vals.get('cntr_trde_qty'))
                open_p=_num(vals.get('16') if '16' in vals else vals.get('open_pric'))
                high_p=_num(vals.get('17') if '17' in vals else vals.get('high_pric'))
                low_p=_num(vals.get('18') if '18' in vals else vals.get('low_pric'))
                if price is not None:price=abs(price)
                if open_p is not None:open_p=abs(open_p)
                if high_p is not None:high_p=abs(high_p)
                if low_p is not None:low_p=abs(low_p)
                # Kiwoom 0B field 14 is million KRW. 100 million KRW = 100 units.
                value_eok=(abs(acc_value)/100.0) if acc_value is not None else None
                patch={'current_price':price,'change_rate':rate,'acc_volume':abs(acc_vol) if acc_vol is not None else None,
                       'acc_value_million':abs(acc_value) if acc_value is not None else None,'acc_value_eok':value_eok,
                       'open':open_p,'high':high_p,'low':low_p,'trade_time':str(vals.get('20') or ''),
                       'trade_received_at':now}
                with self.cond:
                    if self.last_trade_message:
                        gap_ms=(now-self.last_trade_message)*1000.0
                        self.trade_gap_max_ms=max(self.trade_gap_max_ms,gap_ms)
                        if gap_ms>=1500:self.trade_gap_count+=1
                    prev=float(self.book.get('current_price') or 0)
                    cur=dict(self.book);cur.update({k:v for k,v in patch.items() if v is not None});self.book=cur;self.last_message=now;self.last_trade_message=now;self.seq+=1
                    if price is not None:
                        direction='up' if prev and price>prev else ('down' if prev and price<prev else 'flat')
                        self.recent_trades.append({'time':str(vals.get('20') or ''),'price':price,
                                                   'qty':abs(tick_vol) if tick_vol is not None else None,
                                                   'direction':direction,'received_at':now})
                        if len(self.recent_trades)>40:self.recent_trades=self.recent_trades[-40:]
                    self.cond.notify_all()
    def _run(self):
        backoff=0.2
        while not self.stop_event.is_set():
            ws=None
            try:
                self.kiwoom.auth(); token=self.kiwoom.token; self._set_state('연결 중',connected=False)
                ws=_WebSocket(self.URL,1.0,frame_timeout=2.0); ws.connect(); ws.send_json({'trnm':'LOGIN','token':token})
                logged=False; deadline=time.time()+8
                while time.time()<deadline and not self.stop_event.is_set():
                    recv_start=time.monotonic()
                    try:
                        text=ws.recv_text()
                        recv_ms=(time.monotonic()-recv_start)*1000
                        # A blocking receive may legitimately wait for market traffic.
                        # Do not classify an idle socket as broken solely from elapsed time.
                        # Count only delayed deliveries; capture when the message arrives.
                        if recv_ms>=1500:
                            with self.lock:
                                self.recv_slow_count+=1
                                self.recv_max_ms=max(self.recv_max_ms,recv_ms)
                                self.recv_last_slow_ms=recv_ms
                                self.recv_last_slow_at=time.time()
                    except socket.timeout:continue
                    msg=json.loads(text)
                    if msg.get('trnm')=='PING':ws.send_json(msg);continue
                    if msg.get('trnm')=='LOGIN':
                        if str(msg.get('return_code','0'))!='0':raise OSError('Kiwoom 0D LOGIN rejected')
                        logged=True;break
                if not logged:raise OSError('Kiwoom 0D LOGIN timeout')
                with self.lock:c=self.desired; reg_ver=self.version
                self._register(ws,c); self._set_state('실시간 연결',connected=True); backoff=0.2
                watchdog_for_version=reg_ver
                watchdog_refreshed=False
                watchdog_refresh_at=0.0
                was_market_window=_kr_market_window()
                while not self.stop_event.is_set():
                    with self.lock:
                        changed=self.version!=reg_ver; c=self.desired; cur=self.version
                    if changed:
                        self._register(ws,c); reg_ver=cur
                        watchdog_for_version=reg_ver; watchdog_refreshed=False; watchdog_refresh_at=0.0
                    # When the connection was established before 08:00, a premarket
                    # subscription may remain quiet after the session opens. Refresh
                    # once at the market-window transition, only if no fresh 0D
                    # orderbook has arrived. No extra HTTP polling or reconnect.
                    market_window=_kr_market_window()
                    if market_window and not was_market_window:
                        with self.lock:
                            book_age=(time.time()-self.last_book_message) if self.last_book_message else None
                            current_symbol=self.desired
                        if current_symbol and (book_age is None or book_age>3):
                            self._register(ws,current_symbol)
                            with self.lock:self.watchdog_refreshes+=1
                    was_market_window=market_window
                    # Only monitor the subscribed 0D orderbook during KR trading hours.
                    # PING/0B traffic alone does not establish that 0D is still updating.
                    # Use a generous grace period for quiet symbols and after-hours gaps.
                    with self.lock:
                        started=self.last_register_at
                        last_book=self.last_book_message
                        is_subscribed=bool(self.desired)
                    silent=time.time()-max(started,last_book)
                    if is_subscribed and _kr_market_window() and silent>90:
                        if not watchdog_refreshed:
                            self._register(ws,c,force_krx=not self.use_sor)
                            with self.lock:self.watchdog_refreshes+=1
                            watchdog_refreshed=True; watchdog_refresh_at=time.time()
                            self._set_state('호가 재구독',connected=True)
                        elif time.time()-watchdog_refresh_at>90:
                            raise OSError('Kiwoom 0D orderbook stale >180s after refresh')
                    if last_book and silent<30 and watchdog_refreshed:
                        watchdog_refreshed=False; watchdog_refresh_at=0.0
                        self._set_state('실시간 연결',connected=True)
                    try:text=ws.recv_text()
                    except socket.timeout:
                        with self.lock:
                            sor_wait=self.use_sor and not self.last_book_message and (time.time()-self.last_register_at)>3.0
                            c=self.desired
                        if sor_wait:
                            self._register(ws,c,force_krx=True)
                        continue
                    msg=json.loads(text)
                    if msg.get('trnm')=='PING':ws.send_json(msg);continue
                    if msg.get('trnm')=='REG' and str(msg.get('return_code','0'))!='0':
                        with self.lock: was_sor=self.use_sor; c=self.desired
                        if was_sor:
                            self._register(ws,c,force_krx=True); continue
                        raise OSError('Kiwoom 0D REG rejected: '+str(msg.get('return_msg') or ''))
                    self._handle(msg)
            except Exception as e:
                with self.lock:self.reconnects+=1
                self._set_state('재연결 대기',str(e),False)
                if self.stop_event.wait(backoff):break
                backoff=min(backoff*2,2.0)
            finally:
                if ws:ws.close()
        self._set_state('중지',connected=False)
