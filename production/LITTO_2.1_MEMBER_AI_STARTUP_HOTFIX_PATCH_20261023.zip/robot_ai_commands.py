"""Strict, deterministic Korean natural-language order intake.

Only fully specified commands qualify. Ambiguous commands never reach the broker.
The sender's explicit imperative is treated as the authorization; no popup.
"""
import re
from datetime import datetime, timedelta, time as dtime, timezone

KST=timezone(timedelta(hours=9))
_NUM=r'(?:\d[\d,]*\s*(?:억|천만|백만|만|천)?|\d[\d,]*)'


def money(text):
    s=str(text).replace(',','').replace(' ','')
    m=re.fullmatch(r'(\d+)(억|천만|백만|만|천)?(?:원|주)?',s)
    if not m:raise ValueError('금액/수량을 인식할 수 없어 예약하지 않았어.')
    return int(m[1])*{'억':100000000,'천만':10000000,'백만':1000000,'만':10000,'천':1000,None:1}[m[2]]


def _compact_name(value):
    """Normalize harmless spaces in exact security names, never fuzzy-match orders."""
    return re.sub(r"\s+", "", str(value or "")).casefold()


def _stock(msg, context, universe):
    raw=str(msg or "")
    compact=_compact_name(raw)
    matches={}
    for x in universe:
        nm=str(x.get('name') or '').strip()
        cd=str(x.get('code') or '').strip().upper()
        if cd.startswith('A') and len(cd)==7:cd=cd[1:]
        if not re.fullmatch(r'\d{6}',cd) or not nm:continue
        key=_compact_name(nm)
        if (key and key in compact) or re.search(r'(?<!\d)'+re.escape(cd)+r'(?!\d)',raw):
            matches[cd]=nm
    context_stock=(context or {}).get('current_stock') or {}
    cd=str(context_stock.get('code') or '').strip().upper().removeprefix('A')
    nm=str(context_stock.get('name') or '').strip()
    if re.fullmatch(r'\d{6}',cd) and nm and (_compact_name(nm) in compact or re.search(r'(?<!\d)'+re.escape(cd)+r'(?!\d)',raw)):
        matches[cd]=nm
    if not matches:
        raise ValueError('종목명을 확인할 수 없어 주문을 등록하지 않았어. 종목명 또는 6자리 코드를 입력해 줘.')
    # A short security name can be part of a longer, different security name.
    # Accept the uniquely most specific exact name; reject ambiguous ties.
    ranked=sorted(((len(_compact_name(nm)),cd,nm) for cd,nm in matches.items()),reverse=True)
    top=ranked[0]
    if any(size==top[0] and code!=top[1] for size,code,_ in ranked[1:]):
        raise ValueError('여러 종목이 일치해 주문을 등록하지 않았어. 6자리 종목코드를 입력해 줘.')
    return top[1],top[2]


def _when(msg,now):
    day=re.search(r'(오늘|내일|모레|\d{4}[-./]\d{1,2}[-./]\d{1,2})',msg)
    clock=re.search(r'(?:(오전|오후)\s*)?(\d{1,2})\s*(?:시(?:\s*(\d{1,2})\s*분)?|:(\d{1,2}))',msg)
    if not clock:raise ValueError('실행 시간을 명확히 지정해 줘. 예: 오후 7시 47분.')
    d=day.group(1) if day else None
    if d in ('오늘','내일','모레'):
        dt=now.date()+timedelta(days={'오늘':0,'내일':1,'모레':2}[d])
    elif d:
        dt=datetime.strptime(d.replace('.','-').replace('/','-'),'%Y-%m-%d').date()
    else:
        dt=now.date()
    hh=int(clock.group(2)); mm=int(clock.group(3) or clock.group(4) or 0)
    if mm>59 or hh>23:raise ValueError('예약 시각이 잘못됐어.')
    if clock.group(1):
        if not 1<=hh<=12:raise ValueError('오전/오후 시각이 잘못됐어.')
        hh=hh%12+(12 if clock.group(1)=='오후' else 0)
    if not day and not clock.group(1) and 1<=hh<=7 and 12<=now.hour<20:
        hh+=12  # During the NXT afternoon session, '7시' means 19:00.
    scheduled=datetime.combine(dt,dtime(hh,mm),tzinfo=KST)
    if not day and scheduled<=now:
        scheduled+=timedelta(days=1)
    return scheduled


def parse(message,context,universe,now=None,holding_lookup=None):
    msg=str(message or '').strip(); now=now or datetime.now(KST)
    # Restrict typo correction to a signed percentage near the account cost phrase.
    msg=re.sub(r'(?:내\s*)?평판(?=\s*(?:보다|대비|에서)?\s*[+-]?\s*\d{1,2}(?:\.\d+)?\s*(?:%|프로|퍼센트|이하|이상))', '평단', msg)
    msg=re.sub(r'내\s*평단', '평단', msg)
    msg=re.sub(r'추가로\s*(?:사줘|사|매수해|매수|사달라)', '추매', msg)
    msg=re.sub(r'(?:좀\s*)?팔아(?:줘|주세요|달라)', '팔아줘', msg)
    msg=re.sub(r'(?:좀\s*)?사(?:줘|주세요|달라)', '사줘', msg)
    msg=re.sub(r'추가\s*매수', '추매', msg)
    if not re.search(r'(예약|매수|매도|사줘|팔아줘|주문|추매|익절|매도해|매수해)',msg):return None
    buy=bool(re.search(r'(매수|사줘|추매)',msg));sell=bool(re.search(r'(매도|팔아줘|익절)',msg))
    if buy==sell:raise ValueError('매수 또는 매도 방향 하나만 명확히 지정해 줘.')
    side='buy' if buy else 'sell'
    code,name=_stock(msg,context,universe)
    # Account-cost trigger: freeze the broker cost basis when the instruction is registered.
    # This is not a timed order and never substitutes daily stock change % for account return.
    if re.search(r'(?:평단|평균\s*매입가|매입\s*평균)',msg):
        trigger=re.search(r'(?:평단|평균\s*매입가|매입\s*평균)(?:\s*(?:대비|에서|보다))?\s*([+-]?)\s*(\d{1,2}(?:\.\d{1,2})?)\s*(?:%|프로|퍼센트)',msg)
        # '평단 -13이하' / '평단 +4이상': percent sign may be omitted ONLY
        # when an explicit +/- sign and a matching lower/upper comparator exist.
        if not trigger:
            short = re.search(r'(?:평단|평균\s*매입가|매입\s*평균)(?:\s*(?:대비|에서|보다))?\s*([+-])\s*(\d{1,2}(?:\.\d{1,2})?)\s*(이하|이상)', msg)
            if short and ((short.group(1)=='-' and short.group(3)=='이하') or (short.group(1)=='+' and short.group(3)=='이상')):
                trigger = short
            else:
                raise ValueError('평단 조건은 -13% 이하 또는 +4% 이상처럼 지정해 줘.')
        # Explicit direction words are required if the user omitted +/-.
        after=msg[trigger.end():]
        down=(len(trigger.groups())>=3 and trigger.group(3)=='이하') or bool(re.search(r'(?:내려|내리|떨어|하락|빠지|손실|낮아|낮은|낮게|낮을|밑으로|이하|하회|떨어지|빠졌|내렸)',after))
        up=(len(trigger.groups())>=3 and trigger.group(3)=='이상') or bool(re.search(r'(?:올라|오르|상승|높아|높은|높게|높을|이상|넘으|상회|올랐)',after))
        if not trigger.group(1) and down==up:
            raise ValueError('상승/하락 방향이 불명확해. 평단 -13% 또는 평단보다 13% 내려가면처럼 입력해 줘.')
        if trigger.group(1) and ((trigger.group(1)=='+' and down) or (trigger.group(1)=='-' and up)):
            raise ValueError('수익률 부호와 상승/하락 표현이 충돌해 예약하지 않았어.')
        sign=trigger.group(1) or ('-' if down else '+')
        pct=float(trigger.group(2)) * (-1 if sign=='-' else 1)
        if not (-50<=pct<=50) or abs(pct)<0.1:raise ValueError('조건 수익률은 -50%~+50% 사이에서 지정해 줘.')
        if side=='buy' and pct>=0:raise ValueError('추가매수는 평단보다 낮은 -% 조건으로 지정해 줘.')
        if side=='sell' and pct<=0:raise ValueError('익절 매도는 평단보다 높은 +% 조건으로 지정해 줘.')
        # Everything following the trigger must clearly encode one size.
        qty_match=re.search(r'(\d[\d,]*)\s*주\s*(?:추매|추가매수|매수|매도|익절|팔아줘|사줘)?',msg[trigger.end():])
        cash_match=re.search(r'(\d[\d,]*\s*(?:억|천만|백만|만|천)?)\s*원\s*(?:어치|만큼)?\s*(?:추매|추가매수|매수)?',msg[trigger.end():])
        ratio_match=re.search(r'(\d{1,3})\s*(?:%|프로|퍼센트)\s*(?:만큼|를|을)?\s*(?:매도|익절)',msg[trigger.end():])
        types=sum(bool(v) for v in (qty_match,cash_match,ratio_match))
        if types!=1:raise ValueError('조건 주문 수량을 하나만 지정해 줘. 예: 평단 +4%면 5주 익절.')
        if ratio_match:
            if side!='sell':raise ValueError('추매는 비율 대신 금액이나 주수를 입력해 줘.')
            unit='holding_percent';value=int(ratio_match.group(1))
            if not 1<=value<=100:raise ValueError('매도 비율은 1~100%여야 해.')
        elif qty_match:unit='shares';value=int(qty_match.group(1).replace(',',''))
        else:unit='amount';value=money(cash_match.group(1))
        if not 1<=value<=10**10:raise ValueError('수량/금액이 허용 범위를 벗어났어.')
        return 'cost_trigger',{'code':code,'name':name,'side':side,'unit':unit,
            'value':value,'trigger_pct':pct,'approved':True}
    # Fixed-price one-shot trigger. Explicit price + explicit share count only.
    # Never treat 23만원 as an order-size amount or 7시 as a price.
    price_tokens=list(re.finditer(r'(?<![\d.])([\d,]+\s*(?:억|천만|백만|만|천)?)\s*원\s*(?:에|에서|까지|이하|이상|되면|도달(?:하면|시)?|찍으면)',msg))
    share_tokens=list(re.finditer(r'(?<!\d)([\d,]+)\s*주\s*(?:를|을)?\s*(?:매수|매도|추매|사줘|팔아줘)?',msg))
    if price_tokens:
        if len(price_tokens)!=1 or len(share_tokens)!=1:
            raise ValueError('목표가격 하나와 주문 주수를 하나씩 지정해 줘. 예: 삼성전자 23만원에 3주 매수.')
        if re.search(r'(?:(?:오전|오후)\s*)?\d{1,2}\s*시',msg):
            raise ValueError('가격 조건과 실행 시각을 한 명령에 혼합하지 말아 줘.')
        price=money(price_tokens[0].group(1)); qty=int(share_tokens[0].group(1).replace(',',''))
        if not (1<=price<=10**9 and 1<=qty<=1000000):raise ValueError('목표가격 또는 주수가 범위를 벗어났어.')
        if side=='buy' and re.search(r'가격.*(?:이상|오르면)|\d+\s*원\s*이상',msg):
            raise ValueError('매수는 목표가격 이하 도달 조건만 지원해.')
        if side=='sell' and re.search(r'가격.*(?:이하|내리면)|\d+\s*원\s*이하',msg):
            raise ValueError('매도는 목표가격 이상 도달 조건만 지원해.')
        return 'price_trigger',{'code':code,'name':name,'side':side,'unit':'shares','value':qty,
            'target_price':price,'approved':True}
    # Time-sliced orders: "삼성전자 6시16분 1주 매수 6시17분 1주 매수".
    # Keep price-trigger splits independent. Never silently discard a second leg.
    time_legs=list(re.finditer(
        r'(?:(?:오늘|내일|모레)\s*)?(?:(?:오전|오후)\s*)?\d{1,2}\s*(?:시|:)\s*(?:\d{1,2}\s*분)?\s*에?\s*'
        r'\d[\d,]*\s*(?:억|천만|백만|만|천)?\s*(?:원|주)\s*(?:어치|만큼)?\s*(?:매수|매도|사줘|팔아줘)',msg))
    if len(time_legs)>=2:
        covered=msg
        orders=[]
        for match in time_legs:
            fragment=match.group(0)
            leg_side='buy' if re.search(r'(매수|사줘)',fragment) else 'sell'
            if leg_side!=side:raise ValueError('매수와 매도를 한 명령에 섞지 말아 줘.')
            tm=re.search(r'(?:(?:오늘|내일|모레)\s*)?(?:(?:오전|오후)\s*)?\d{1,2}\s*(?:시|:)\s*(?:\d{1,2}\s*분)?\s*에?',fragment)
            qty=re.search(r'(\d[\d,]*\s*(?:억|천만|백만|만|천)?)\s*(원|주)',fragment[tm.end():])
            if not qty:raise ValueError('각 예약의 수량을 확인해 줘.')
            orders.append({'code':code,'name':name,'side':side,
                'unit':'amount' if qty.group(2)=='원' else 'shares','value':money(qty.group(1)),
                'when':_when(tm.group(0),now).isoformat(timespec='seconds'),
                'price_limit':0,'approved':True})
        if len(orders)>10:raise ValueError('한 번에 최대 10개 예약까지 가능해.')
        if len(set(x['when'] for x in orders))!=len(orders):raise ValueError('분할 예약 시각이 중복돼.')
        return 'timed_batch',{'orders':orders}
    if len(time_legs)==1 and len(re.findall(r'(?:매수|매도|사줘|팔아줘)',msg))>1:
        raise ValueError('분할 명령에 해석할 수 없는 주문이 있어. 각 시간과 수량을 명확하게 입력해 줘.')
    # Split: 100주 중 15만원에 50%, 16만원에 50% 매도
    splits=re.findall(r'([\d,]+\s*(?:억|천만|백만|만|천)?\s*원?)\s*(?:에|에서|도달(?:하면)?)\s*(\d{1,3})\s*(?:%|프로|퍼센트)',msg)
    if splits:
        qty=re.search(r'(?:전체|보유|기준|총)?\s*([\d,]+)\s*주\s*(?:중|기준|를|을)?',msg)
        if qty:
            shares=int(qty[1].replace(',',''))
        elif side=='sell' and holding_lookup is not None:
            shares=int(holding_lookup(code))
            if shares<=0:raise ValueError('매도 가능 보유 수량이 확인되지 않아 예약하지 않았어.')
        else:
            raise ValueError('분할매수 또는 보유수량 조회가 안 되는 경우에는 전체 기준 주식 수를 함께 말해 줘.')
        steps=[{'price':money(p),'percent':int(pc)} for p,pc in splits]
        return 'split',{'code':code,'name':name,'side':side,'base_shares':shares,'steps':steps,'approved':True}
    when=_when(msg,now)
    # Require a bounded price. Never infer an unlimited market order.
    limit=re.search(r'(?:최대\s*매수가|최대\s*가격|매수\s*상한|매수\s*한도|최저\s*매도가|최저\s*가격|매도\s*하한|매도\s*한도|허용\s*가격)\s*[:：]?\s*('+_NUM+r')\s*원?',msg)
    # A missing limit is filled only after a fresh actual broker quote is checked by app.py.
    # Never allow a free-floating unbounded live order. 
    val=re.search(r'('+_NUM+r')\s*(원|주)\s*(?:어치|만큼|분량)?',msg)
    candidates=[]
    if val:
        # identify all quantity strings; avoid mistaking limit for amount
        for m in re.finditer(r'('+_NUM+r')\s*(원|주)\s*(?:어치|만큼|분량)?',msg):
            start=m.start()
            if '가격' in msg[max(0,start-8):start] or '매수가' in msg[max(0,start-8):start] or '매도가' in msg[max(0,start-8):start] or '한도' in msg[max(0,start-8):start] or '상한' in msg[max(0,start-8):start] or '하한' in msg[max(0,start-8):start]:continue
            candidates.append((money(m[1]),m[2]))
    if len(candidates)!=1:raise ValueError('주문할 금액/주식 수를 명확하게 한 번만 지정해 줘. 예: 100만원어치.')
    amount,unit=candidates[0]
    return 'once',{'code':code,'name':name,'side':side,'unit':'amount' if unit=='원' else 'shares','value':amount,'when':when.isoformat(timespec='seconds'),'price_limit':money(limit[1]) if limit else 0,'approved':True}
