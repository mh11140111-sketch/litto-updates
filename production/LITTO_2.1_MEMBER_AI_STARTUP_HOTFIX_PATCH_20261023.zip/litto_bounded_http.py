"""Bounded request-thread server for LITTO's localhost UI.

Only rejects *new* connections when all slots are occupied; never terminates
an in-flight order request. Uses no polling threads or extra Kiwoom API calls.
"""
import threading
from http.server import ThreadingHTTPServer


class LittoBoundedHTTPServer(ThreadingHTTPServer):
    daemon_threads = True
    block_on_close = False

    def __init__(self, server_address, RequestHandlerClass, max_requests=128):
        if not isinstance(max_requests, int) or max_requests < 1:
            raise ValueError('max_requests must be a positive integer')
        self._request_slots = threading.BoundedSemaphore(max_requests)
        self._metrics_lock = threading.Lock()
        self.active_requests = 0
        self.peak_requests = 0
        self.rejected_requests = 0
        super().__init__(server_address, RequestHandlerClass)

    def process_request(self, request, client_address):
        if not self._request_slots.acquire(blocking=False):
            with self._metrics_lock:
                self.rejected_requests += 1
            try:
                request.settimeout(0.2)
                request.sendall(b'HTTP/1.1 503 Service Unavailable\r\nConnection: close\r\nContent-Length: 0\r\nRetry-After: 1\r\n\r\n')
            except OSError:
                pass
            finally:
                self.shutdown_request(request)
            return
        with self._metrics_lock:
            self.active_requests += 1
            self.peak_requests = max(self.peak_requests, self.active_requests)
        try:
            super().process_request(request, client_address)
        except BaseException:
            self._release_request_slot()
            raise

    def process_request_thread(self, request, client_address):
        try:
            super().process_request_thread(request, client_address)
        finally:
            self._release_request_slot()

    def _release_request_slot(self):
        with self._metrics_lock:
            self.active_requests -= 1
        self._request_slots.release()

    def request_metrics(self):
        with self._metrics_lock:
            return {'active_requests': self.active_requests,
                    'peak_requests': self.peak_requests,
                    'rejected_requests': self.rejected_requests}
