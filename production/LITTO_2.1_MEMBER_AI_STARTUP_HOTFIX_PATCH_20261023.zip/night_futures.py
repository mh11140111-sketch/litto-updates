from __future__ import annotations

import json
import re
import threading
import time
from collections import deque
from datetime import datetime, timezone, timedelta
from http.cookiejar import CookieJar
from urllib.parse import urlencode
from urllib.request import build_opener, HTTPCookieProcessor, Request

KST = timezone(timedelta(hours=9))
PAGE_URL = 'https://esignal.co.kr/kospi200-futures-night/'
SOCKET_BASE = 'https://esignal.co.kr/proxy/8899/socket.io/'
CACHE_URL = 'https://esignal.co.kr/data/cache/kospif_ngt_est.js'
OPENING_TS_URL = 'https://esignal.co.kr/data/timestamps/kospif_ngt_opening.txt'
CACHE_MTIME_URL = 'https://esignal.co.kr/data/cache/kospif_ngt_est_cache_mtime.txt'
CLOSING_TS_URL = 'https://esignal.co.kr/data/timestamps/kospif_ngt_closing.txt'
UA = ('Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
      'AppleWebKit/537.36 (KHTML, like Gecko) Chrome/153.0.0.0 Safari/537.36')


def _now_iso():
    return datetime.now(KST).isoformat()


class NightFuturesFeed:
    """Public-page Socket.IO polling client for eSignal's KOSPI200 night futures page.

    It intentionally fetches a fresh page-issued ticket on every reconnect instead of
    storing/reusing tickets. Engine.IO polling is used so LITTO does not need an extra
    websocket/socket.io Python package.
    """

    def __init__(self):
        self._lock = threading.RLock()
        self._thread = None
        self._stop = threading.Event()
        self._running = False
        self._state = {
            'connected': False,
            'streaming': False,
            'cache_loaded': False,
            'opening_ts': None,
            'closing_ts': None,
            'price': None,
            'base_price': None,
            'change': None,
            'change_rate': None,
            'session_open_price': None,
            'price_2000': None,
            'session_close_price': None,
            'official_open_price': None,
            'official_close_price': None,
            'reference_source': '',
            'rate_open_to_close': None,
            'rate_2000_to_close': None,
            'price_1800': None,
            'rate_1800_vs_prevclose': None,
            'rate_2000_vs_prevclose': None,
            'time_text': '',
            'unix_timestamp': None,
            'updated_at': None,
            'last_error': None,
            'source': 'eSignal 공개 야간선물 페이지 · Socket.IO populate',
            'transport': 'Engine.IO v4 polling + page-issued ticket',
            'live_event': 'populate',
            'points': [],
        }
        self._points = deque(maxlen=5000)
        self._last_final_refresh_session = None
        self._last_final_refresh_attempt = 0.0
        self._last_opening_ts = None

    def start(self):
        with self._lock:
            if self._thread and self._thread.is_alive():
                return
            self._stop.clear()
            self._thread = threading.Thread(target=self._run, name='LITTO-NightFutures', daemon=True)
            self._thread.start()

    def stop(self):
        self._stop.set()

    def snapshot(self):
        self.start()
        with self._lock:
            out = dict(self._state)
            out['points'] = list(self._points)
            out['running'] = bool(self._thread and self._thread.is_alive())
            # Socket.IO transport can remain connected long after the last market tick.
            recent = False
            updated = self._state.get('updated_at')
            if updated:
                try:
                    recent = (datetime.now(KST) - datetime.fromisoformat(updated)).total_seconds() <= 120
                except (TypeError, ValueError):
                    pass
            closing = self._state.get('closing_ts')
            market_closed = bool(closing and time.time() >= int(closing))
            out['streaming'] = bool(out.get('streaming') and recent and not market_closed)
            out['market_closed'] = market_closed
            return out

    def _headers(self, extra=None):
        h = {
            'User-Agent': UA,
            'Accept': '*/*',
            'Referer': PAGE_URL,
            'Origin': 'https://esignal.co.kr',
            'Cache-Control': 'no-cache',
            'Pragma': 'no-cache',
        }
        if extra:
            h.update(extra)
        return h

    def _open_text(self, opener, url, method='GET', data=None, timeout=12):
        raw = None if data is None else data.encode('utf-8')
        req = Request(url, data=raw, method=method, headers=self._headers(
            {'Content-Type': 'text/plain;charset=UTF-8'} if method == 'POST' else None
        ))
        with opener.open(req, timeout=timeout) as r:
            body = r.read()
            enc = r.headers.get_content_charset() or 'utf-8'
            return body.decode(enc, errors='replace')

    def _fresh_session(self):
        jar = CookieJar()
        opener = build_opener(HTTPCookieProcessor(jar))
        html = self._open_text(opener, PAGE_URL, timeout=15)
        m = re.search(r'window\._socketTicket\s*=\s*["\']([^"\']+)["\']', html)
        if not m:
            raise RuntimeError('eSignal 페이지에서 Socket.IO ticket을 찾지 못했습니다.')
        ticket = m.group(1).strip()
        if not ticket:
            raise RuntimeError('eSignal Socket.IO ticket이 비어 있습니다.')
        return opener, ticket

    @staticmethod
    def _to_epoch_seconds(value):
        try:
            x = int(float(value))
        except Exception:
            return None
        if x > 10_000_000_000:
            x //= 1000
        return x if x > 0 else None

    @staticmethod
    def _extract_price_field(obj, kind):
        # Prefer explicit eSignal quote metadata over reconstructing open/close from the chart series.
        # This recursively checks likely field names while excluding timestamps/dates.
        if not isinstance(obj, dict):
            return None, None
        open_keys = {
            'open','openprice','opening','openingprice','priceopen','valueopen',
            'startprice','valuestart','marketopen','siga','sigaprice'
        }
        close_keys = {
            'close','closeprice','closing','closingprice','priceclose','valueclose',
            'endprice','valueend','marketclose','jongga','jonggaprice'
        }
        wanted = open_keys if kind == 'open' else close_keys

        def norm(k):
            return re.sub(r'[^a-z0-9가-힣]+', '', str(k).lower())

        def walk(x, path=''):
            if isinstance(x, dict):
                # exact/normalized field-name match first
                for k, v in x.items():
                    nk = norm(k)
                    if any(bad in nk for bad in ('timestamp','unixtime','datetime','date','mtime','opents','closets')):
                        continue
                    if nk in wanted:
                        try:
                            n = float(v)
                            if 100.0 <= n <= 100000.0:
                                return n, f'{path}{k}'
                        except Exception:
                            pass
                for k, v in x.items():
                    if isinstance(v, dict):
                        got = walk(v, f'{path}{k}.')
                        if got[0] is not None:
                            return got
            return None, None

        return walk(obj)

    @staticmethod
    def _interpolated_price(points, target_ts):
        # Return the source-series price at target_ts using surrounding received ticks.
        if not points or not target_ts:
            return None
        pts = sorted(
            [(int(x.get('t')), float(x.get('p'))) for x in points
             if isinstance(x, dict) and x.get('t') and x.get('p')],
            key=lambda x: x[0]
        )
        if not pts:
            return None
        before = after = None
        for ts, price in pts:
            if ts <= target_ts:
                before = (ts, price)
            if ts >= target_ts:
                after = (ts, price)
                break
        if before and after:
            if after[0] == before[0]:
                return before[1]
            ratio = (target_ts - before[0]) / float(after[0] - before[0])
            return before[1] + (after[1] - before[1]) * ratio
        if before:
            return before[1]
        if after:
            return after[1]
        return None

    def _update_reference_metrics_locked(self):
        # 기준 구조
        # - 시작 기준값(base_price) = eSignal 전일 종가(value_day)
        # - 18시 기준 퍼센트 = 오늘 종가(06:00) 대비 18:00에서 얼마나 올랐나/내렸나
        # - 20시 기준 퍼센트 = 오늘 종가(06:00) 대비 20:00에서 얼마나 올랐나/내렸나
        points = list(self._points)
        if not points:
            return

        opening = self._state.get('opening_ts')
        closing = self._state.get('closing_ts')
        prev_close = self._state.get('base_price')

        price_1800 = None
        price_2000 = None

        if opening:
            price_1800 = self._interpolated_price(points, int(opening))
            odt = datetime.fromtimestamp(int(opening), KST)
            t20 = odt.replace(hour=20, minute=0, second=0, microsecond=0)
            price_2000 = self._interpolated_price(points, int(t20.timestamp()))

        # 오늘 야간장 종가(06:00). 장중에는 가장 최근 수신값을 사용.
        close_price = self._state.get('official_close_price')
        if not close_price:
            valid = []
            if closing:
                valid = [x for x in points if int(x.get('t') or 0) <= int(closing)]
            if valid:
                close_price = float(valid[-1]['p'])
            elif points:
                close_price = float(points[-1]['p'])

        rate18 = rate20 = None
        if close_price is not None:
            cp = float(close_price)
            if price_1800 not in (None, 0):
                rate18 = (cp - float(price_1800)) / float(price_1800) * 100.0
            if price_2000 not in (None, 0):
                rate20 = (cp - float(price_2000)) / float(price_2000) * 100.0

        self._state.update({
            'price_1800': price_1800,
            'price_2000': price_2000,
            'session_open_price': prev_close,  # 시작 기준값은 전일 종가
            'session_close_price': close_price,
            'rate_1800_vs_prevclose': rate18,   # legacy key; meaning now 18시→오늘종가
            'rate_2000_vs_prevclose': rate20,   # legacy key; meaning now 20시→오늘종가
            'rate_open_to_close': rate18,
            'rate_2000_to_close': rate20,
            'reference_source': '시작기준=eSignal 전일종가 / 18·20시 퍼센트=오늘종가 대비',
        })

    def _load_cache(self, opener):
        """Mirror the page's startup cache: value_day + existing chart series."""
        try:
            opening_raw = self._open_text(opener, OPENING_TS_URL + '?_=' + str(int(time.time()*1000)), timeout=8).strip()
            closing_raw = self._open_text(opener, CLOSING_TS_URL + '?_=' + str(int(time.time()*1000)), timeout=8).strip()
            cache_mtime_raw = self._open_text(opener, CACHE_MTIME_URL + '?_=' + str(int(time.time()*1000)), timeout=8).strip()
            opening = self._to_epoch_seconds(opening_raw) or 0
            closing = self._to_epoch_seconds(closing_raw) or 0
            cache_mtime = self._to_epoch_seconds(cache_mtime_raw) or 0
            with self._lock:
                prior_opening = self._state.get('opening_ts')
                # The provider may publish tomorrow's opening timestamp before 18:00.
                # Keep the previous finished night intact until that opening actually arrives.
                if opening and prior_opening and opening > prior_opening and opening > time.time():
                    return
                if opening and prior_opening and opening != prior_opening:
                    # New session: never blend old-night ticks with a new session.
                    self._points.clear()
                    self._state.update({'price': None, 'base_price': None,
                                        'change': None, 'change_rate': None,
                                        'official_close_price': None, 'official_open_price': None,
                                        'session_close_price': None, 'price_1800': None,
                                        'price_2000': None, 'updated_at': None, 'streaming': False})
                self._state['opening_ts'] = opening or self._state.get('opening_ts')
                self._state['closing_ts'] = closing or self._state.get('closing_ts')
            # History freshness is only used to decide whether old chart points should be seeded.
            # IMPORTANT: even on weekends/after close we still read value_day from the cache,
            # because eSignal's displayed official change / change-rate is based on that value.
            cache_history_fresh = not (opening > 0 and cache_mtime > 0 and cache_mtime <= opening)
        except Exception:
            # Timestamps are advisory. The JSON itself is still useful if available.
            cache_history_fresh = True

        try:
            raw = self._open_text(opener, CACHE_URL + '?_=' + str(int(time.time()*1000)), timeout=10).strip()
            data = json.loads(raw)
        except Exception:
            return
        if not isinstance(data, dict):
            return

        official_open, official_open_key = self._extract_price_field(data, 'open')
        official_close, official_close_key = self._extract_price_field(data, 'close')
        with self._lock:
            if official_open:
                self._state['official_open_price'] = official_open
            if official_close:
                self._state['official_close_price'] = official_close
            if official_open or official_close:
                self._state['reference_source'] = 'eSignal cache metadata'

        base = None
        try:
            x = float(data.get('value_day'))
            if x > 0:
                base = x
        except Exception:
            pass

        seeded_map = {}
        rows = data.get('data')
        if isinstance(rows, list):
            for row in rows:
                if not isinstance(row, (list, tuple)) or len(row) < 2:
                    continue
                ts = self._to_epoch_seconds(row[0])
                try:
                    price = float(row[1])
                except Exception:
                    continue
                if not ts or price <= 0:
                    continue
                # The source Highcharts chart pins xAxis to the night-session opening/closing timestamps.
                # Mirror that here instead of blindly taking the last N array elements.
                if opening and ts < opening:
                    continue
                if closing and ts > closing:
                    continue
                seeded_map[ts] = price
        seeded = [{'t': ts, 'p': seeded_map[ts]} for ts in sorted(seeded_map)]
        if not cache_history_fresh:
            seeded = []

        cache_price = seeded[-1]['p'] if seeded else None
        change = rate = None
        if cache_price and base:
            change = cache_price - base
            rate = change / base * 100.0
        with self._lock:
            if seeded:
                self._points.clear()
                self._points.extend(seeded)
            self._state.update({
                'cache_loaded': bool(seeded or base),
                'base_price': base or self._state.get('base_price'),
                'price': cache_price or self._state.get('price'),
                'change': change if change is not None else self._state.get('change'),
                'change_rate': rate if rate is not None else self._state.get('change_rate'),
            })
            self._update_reference_metrics_locked()

    def _refresh_session_cache_if_due(self, opener):
        """Refresh on first post-18:00 poll, then briefly retry until rollover.

        During ordinary hours the previous 5-minute closed-session throttle is kept.
        The pre-open snapshot stays unchanged until the source's new opening
        timestamp is reached; never synthesize a new market price at 18:00.
        """
        with self._lock:
            closing = self._state.get('closing_ts')
            opening = self._state.get('opening_ts')
        now = time.time()
        if not closing or now < int(closing) + 60:
            return False
        local_now = datetime.fromtimestamp(now, KST)
        boundary = local_now.replace(hour=18, minute=0, second=0, microsecond=0).timestamp()
        in_rollover_window = boundary <= now < boundary + 30 * 60
        # Recheck promptly once the new session is due. Once source timestamps
        # reflect an opening >= today's 18:00, return to the slow interval.
        awaiting_new_session = in_rollover_window and (not opening or int(opening) < boundary)
        interval = 15 if awaiting_new_session else 300
        if (self._last_final_refresh_session == (opening, closing)
                and now - self._last_final_refresh_attempt < interval):
            return False
        self._last_final_refresh_session = (opening, closing)
        self._last_final_refresh_attempt = now
        try:
            self._load_cache(opener)
            return True
        except Exception as exc:
            with self._lock:
                self._state['last_error'] = f'야간장 세션 캐시 확인 실패: {exc}'
            return False

    @staticmethod
    def _packets(body):
        # Engine.IO v4 polling concatenates packets with ASCII record separator.
        return [x for x in str(body or '').split('\x1e') if x]

    def _poll_url(self, sid=None):
        q = {'EIO': '4', 'transport': 'polling', 't': str(int(time.time() * 1000))}
        if sid:
            q['sid'] = sid
        return SOCKET_BASE + '?' + urlencode(q)

    def _post_packet(self, opener, sid, packet):
        return self._open_text(opener, self._poll_url(sid), method='POST', data=packet, timeout=12)

    def _parse_event(self, packet):
        if not packet.startswith('42'):
            return False
        try:
            arr = json.loads(packet[2:])
        except Exception:
            return False
        if not isinstance(arr, list) or len(arr) < 2 or arr[0] != 'populate':
            return False
        payload = arr[1]
        if isinstance(payload, str):
            try:
                payload = json.loads(payload)
            except Exception:
                return False
        if not isinstance(payload, dict):
            return False

        try:
            price = float(payload.get('approx'))
        except Exception:
            return False

        live_open, live_open_key = self._extract_price_field(payload, 'open')
        live_close, live_close_key = self._extract_price_field(payload, 'close')
        if not (price > 0):
            return False

        base = None
        for key in ('value_day', 'base_price', 'prev_close', 'yesterday_close'):
            try:
                x = float(payload.get(key))
                if x > 0:
                    base = x
                    break
            except Exception:
                pass

        ts = payload.get('unix_timestamp')
        try:
            ts = int(float(ts))
            # Some feeds use milliseconds.
            if ts > 10_000_000_000:
                ts //= 1000
        except Exception:
            ts = int(time.time())

        time_text = str(payload.get('time_format') or payload.get('time') or '')
        point = {'t': ts, 'p': price}
        with self._lock:
            effective_base = base or self._state.get('base_price')
            change = None
            rate = None
            if effective_base:
                change = price - float(effective_base)
                rate = (change / float(effective_base)) * 100.0
            opening = self._state.get('opening_ts')
            closing = self._state.get('closing_ts')
            # Outside the source chart's pinned session window, keep the quote but do not distort the chart.
            if (not opening or ts >= opening) and (not closing or ts <= closing):
                if self._points and self._points[-1].get('t') == ts:
                    self._points[-1] = point
                else:
                    self._points.append(point)
            if live_open:
                self._state['official_open_price'] = live_open
                self._state['reference_source'] = 'eSignal live metadata'
            if live_close:
                self._state['official_close_price'] = live_close
                self._state['reference_source'] = 'eSignal live metadata'
            self._state.update({
                'connected': True,
                'streaming': True,
                'price': price,
                'base_price': effective_base,
                'change': change if change is not None else self._state.get('change'),
                'change_rate': rate if rate is not None else self._state.get('change_rate'),
                'time_text': time_text,
                'unix_timestamp': ts,
                'updated_at': _now_iso(),
                'last_error': None,
            })
            self._update_reference_metrics_locked()
        return True

    def _connect_once(self):
        opener, ticket = self._fresh_session()
        self._load_cache(opener)
        body = self._open_text(opener, self._poll_url(), timeout=15)
        open_packet = next((p for p in self._packets(body) if p.startswith('0')), None)
        if not open_packet:
            raise RuntimeError('Engine.IO 연결 응답을 받지 못했습니다.')
        try:
            hello = json.loads(open_packet[1:])
            sid = str(hello['sid'])
            ping_interval = max(5.0, float(hello.get('pingInterval', 25000)) / 1000.0)
            ping_timeout = max(5.0, float(hello.get('pingTimeout', 20000)) / 1000.0)
        except Exception as e:
            raise RuntimeError('Engine.IO handshake 해석 실패') from e

        self._post_packet(opener, sid, '40' + json.dumps({'ticket': ticket}, separators=(',', ':')))
        last_rx = time.monotonic()
        with self._lock:
            self._state['connected'] = True
            self._state['streaming'] = False
            self._state['last_error'] = None

        while not self._stop.is_set():
            try:
                body = self._open_text(opener, self._poll_url(sid), timeout=max(15, int(ping_interval + ping_timeout)))
            except Exception as e:
                raise RuntimeError(f'야간선물 polling 중단: {e}') from e
            last_rx = time.monotonic()
            self._refresh_session_cache_if_due(opener)
            for packet in self._packets(body):
                if packet == '2':
                    self._post_packet(opener, sid, '3')
                elif packet.startswith('42'):
                    self._parse_event(packet)
                elif packet.startswith('1'):
                    raise RuntimeError('eSignal Engine.IO 연결이 종료되었습니다.')
                elif packet.startswith('44'):
                    raise RuntimeError('eSignal Socket.IO 인증이 거부되었습니다.')
            if time.monotonic() - last_rx > (ping_interval + ping_timeout + 10):
                raise RuntimeError('eSignal 야간선물 응답 시간 초과')

    def _run(self):
        self._running = True
        backoff = 3
        while not self._stop.is_set():
            try:
                self._connect_once()
                backoff = 3
            except Exception as e:
                with self._lock:
                    self._state['connected'] = False
                    self._state['streaming'] = False
                    self._state['last_error'] = str(e)
                    self._state['updated_at'] = self._state.get('updated_at') or _now_iso()
                if self._stop.wait(backoff):
                    break
                backoff = min(30, backoff + 3)
        self._running = False


FEED = NightFuturesFeed()


def snapshot():
    return FEED.snapshot()
