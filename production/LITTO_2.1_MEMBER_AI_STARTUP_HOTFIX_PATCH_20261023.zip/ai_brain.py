"""Persistent local brain for LITTO AI.

Stores compact user-approved/durable memories and interaction episodes locally.
No cloud database, no embeddings, and no self-modifying code.
"""
from pathlib import Path
import sqlite3, json, re, time, threading
from litto_memory_storage import prepare_db

_LOCK=threading.RLock()
_DB=None

def init(root):
    global _DB
    _DB=prepare_db(root)
    _DB.parent.mkdir(parents=True,exist_ok=True)
    with _conn() as c:
        c.execute('''CREATE TABLE IF NOT EXISTS memory(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            mkey TEXT NOT NULL,
            value TEXT NOT NULL,
            kind TEXT NOT NULL DEFAULT 'preference',
            confidence REAL NOT NULL DEFAULT 1.0,
            created_at REAL NOT NULL,
            updated_at REAL NOT NULL,
            UNIQUE(mkey,kind)
        )''')
        c.execute('''CREATE TABLE IF NOT EXISTS episode(
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            ts REAL NOT NULL,
            user_msg TEXT NOT NULL,
            assistant_msg TEXT NOT NULL,
            model TEXT,
            tools_json TEXT,
            actions_json TEXT,
            context_json TEXT
        )''')
        c.execute('CREATE INDEX IF NOT EXISTS idx_episode_ts ON episode(ts DESC)')
        c.execute('CREATE INDEX IF NOT EXISTS idx_memory_updated ON memory(updated_at DESC)')

def _conn():
    if _DB is None: raise RuntimeError('ai_brain.init() required')
    c=sqlite3.connect(str(_DB),timeout=10)
    c.row_factory=sqlite3.Row
    return c

def _clip(s,n):
    s=str(s or '')
    return s if len(s)<=n else s[:n]+'…'

def _tokens(s):
    return set(x.lower() for x in re.findall(r'[가-힣A-Za-z0-9_]{2,}',str(s or '')))

def _overlap_count(query_tokens, target_tokens):
    """Equivalent to original substring matching; short-circuit exact hits."""
    if not query_tokens or not target_tokens:
        return 0
    exact=query_tokens & target_tokens
    pending=query_tokens-exact
    return len(exact)+sum(1 for q in pending if any(q in t or t in q for t in target_tokens))

def remember(key,value,kind='preference',confidence=1.0):
    key=_clip(key.strip(),120); value=_clip(value.strip(),2000); kind=_clip(kind.strip() or 'preference',40)
    if not key or not value: raise ValueError('기억 key/value가 비어 있습니다.')
    now=time.time(); conf=max(0.0,min(1.0,float(confidence)))
    with _LOCK,_conn() as c:
        c.execute('''INSERT INTO memory(mkey,value,kind,confidence,created_at,updated_at)
          VALUES(?,?,?,?,?,?)
          ON CONFLICT(mkey,kind) DO UPDATE SET value=excluded.value,confidence=excluded.confidence,updated_at=excluded.updated_at''',
          (key,value,kind,conf,now,now))
    return {'ok':True,'key':key,'kind':kind,'value':value,'confidence':conf}

def forget(key,kind=''):
    key=str(key or '').strip(); kind=str(kind or '').strip()
    if not key:return {'ok':False,'deleted':0}
    with _LOCK,_conn() as c:
        if kind:r=c.execute('DELETE FROM memory WHERE mkey=? AND kind=?',(key,kind))
        else:r=c.execute('DELETE FROM memory WHERE mkey=?',(key,))
        n=r.rowcount
    return {'ok':True,'deleted':n}

def memories(limit=100):
    limit=max(1,min(500,int(limit)))
    with _LOCK,_conn() as c:
        rows=c.execute('SELECT mkey,value,kind,confidence,updated_at FROM memory ORDER BY updated_at DESC LIMIT ?',(limit,)).fetchall()
    return [dict(r) for r in rows]

def recall(query,limit=8):
    limit=max(1,min(30,int(limit))); qtok=_tokens(query)
    rows=memories(250)
    scored=[]
    for i,r in enumerate(rows):
        text=f"{r['mkey']} {r['value']} {r['kind']}"; tok=_tokens(text)
        overlap=_overlap_count(qtok,tok)
        recency=max(0,1-i/250)
        score=overlap*5 + float(r.get('confidence') or 0)*2 + recency
        if overlap or not qtok: scored.append((score,r))
    scored.sort(key=lambda x:x[0],reverse=True)
    return [r for _,r in scored[:limit]]

def log_episode(user_msg,assistant_msg,model='',tools=None,actions=None,context=None):
    with _LOCK,_conn() as c:
        c.execute('INSERT INTO episode(ts,user_msg,assistant_msg,model,tools_json,actions_json,context_json) VALUES(?,?,?,?,?,?,?)',(
            time.time(),_clip(user_msg,8000),_clip(assistant_msg,16000),_clip(model,120),
            json.dumps(tools or [],ensure_ascii=False,default=str)[:24000],
            json.dumps(actions or [],ensure_ascii=False,default=str)[:16000],
            json.dumps(context or {},ensure_ascii=False,default=str)[:24000]))
        # bounded local history
        c.execute('DELETE FROM episode WHERE id NOT IN (SELECT id FROM episode ORDER BY id DESC LIMIT 1500)')

def recent_episodes(limit=8):
    limit=max(1,min(50,int(limit)))
    with _LOCK,_conn() as c:
        rows=c.execute('SELECT ts,user_msg,assistant_msg,model FROM episode ORDER BY id DESC LIMIT ?',(limit,)).fetchall()
    return [dict(r) for r in rows]

def search_episodes(query,limit=6):
    limit=max(1,min(20,int(limit))); qtok=_tokens(query)
    with _LOCK,_conn() as c:
        rows=c.execute('SELECT ts,user_msg,assistant_msg,model FROM episode ORDER BY id DESC LIMIT 300').fetchall()
    scored=[]
    for i,row in enumerate(rows):
        r=dict(row); tok=_tokens(r['user_msg']+' '+r['assistant_msg']); overlap=_overlap_count(qtok,tok)
        if overlap:
            scored.append((overlap*5+max(0,1-i/300),r))
    scored.sort(key=lambda x:x[0],reverse=True)
    return [r for _,r in scored[:limit]]

def status():
    with _LOCK,_conn() as c:
        mc=c.execute('SELECT COUNT(*) FROM memory').fetchone()[0]
        ec=c.execute('SELECT COUNT(*) FROM episode').fetchone()[0]
        last=c.execute('SELECT MAX(ts) FROM episode').fetchone()[0]
    return {'memory_count':mc,'episode_count':ec,'last_episode_at':last,'local_only':True,'self_modifying':False}
