# LITTO screener history - per-user SQLite storage.
from pathlib import Path
from datetime import datetime
import json, os, sqlite3

_DB_PATH = None
EXCLUDED_PANELS = {'검색 진단'}

def _default_dir():
    base = os.environ.get('LOCALAPPDATA')
    if base:
        return Path(base) / 'LITTO'
    return Path.home() / 'AppData' / 'Local' / 'LITTO'

def init(root=None):
    global _DB_PATH
    folder = _default_dir()
    folder.mkdir(parents=True, exist_ok=True)
    _DB_PATH = folder / 'screener_history.db'
    with sqlite3.connect(_DB_PATH, timeout=10) as con:
        con.execute('PRAGMA journal_mode=WAL')
        con.execute('PRAGMA synchronous=NORMAL')
        con.execute(
            '''CREATE TABLE IF NOT EXISTS screener_hits(
                trade_date TEXT NOT NULL,
                panel_name TEXT NOT NULL,
                stock_code TEXT NOT NULL,
                stock_name TEXT,
                sector TEXT,
                price REAL,
                change_rate REAL,
                value_eok REAL,
                value_rank INTEGER,
                first_seen_at TEXT NOT NULL,
                last_seen_at TEXT NOT NULL,
                hit_count INTEGER NOT NULL DEFAULT 1,
                payload_json TEXT,
                PRIMARY KEY(trade_date, panel_name, stock_code)
            )'''
        )
        con.execute('CREATE INDEX IF NOT EXISTS idx_screener_hits_date ON screener_hits(trade_date DESC)')
        con.execute('CREATE INDEX IF NOT EXISTS idx_screener_hits_panel ON screener_hits(trade_date, panel_name)')
    return str(_DB_PATH)

def db_path():
    if _DB_PATH is None:
        init()
    return _DB_PATH

def _num(v):
    try:
        if v is None or v == '':
            return None
        return float(str(v).replace(',','').replace('%','').strip())
    except Exception:
        return None

def _int(v):
    n = _num(v)
    return int(n) if n is not None else None

def _change_by_code(panels):
    out = {}
    for panel_name, panel in (panels or {}).items():
        if panel_name == '강한 섹터':
            continue
        for row in ((panel or {}).get('rows') or []):
            if not isinstance(row, dict):
                continue
            code = str(row.get('code') or '').strip()
            if not code or code.startswith('SECTOR:'):
                continue
            ch = _num(row.get('change'))
            if ch is None:
                ch = _num(row.get('formula_change'))
            if ch is not None:
                out[code] = ch
    return out

def _row_change(row, panel_name, code_changes):
    ch = _num(row.get('change'))
    if ch is None:
        ch = _num(row.get('formula_change'))
    if panel_name == '강한 섹터' and ch is None:
        members = ((row.get('levels') or {}).get('members') or [])
        vals = []
        for m in members:
            code = str((m or {}).get('code') or '').strip()
            v = code_changes.get(code)
            if v is not None:
                vals.append(v)
        if vals:
            ch = sum(vals) / len(vals)
    return ch

def save_report(report, trade_date, saved_at=None):
    panels = (((report or {}).get('search_panels') or {}).get('panels') or {})
    if not panels:
        return {'saved':0, 'date':trade_date}
    saved_at = saved_at or datetime.now().isoformat()
    code_changes = _change_by_code(panels)
    records = []
    for panel_name, panel in panels.items():
        if panel_name in EXCLUDED_PANELS:
            continue
        rows = (panel or {}).get('rows') or []
        for row in rows:
            if not isinstance(row, dict):
                continue
            code = str(row.get('code') or '').strip()
            if not code:
                continue
            name = str(row.get('name') or code).strip()
            sector = str(row.get('sector') or '미분류').strip() or '미분류'
            price = _num(row.get('price'))
            change = _row_change(row, panel_name, code_changes)
            value_eok = _num(row.get('value_eok'))
            value_rank = _int(row.get('value_rank'))
            try:
                payload = json.dumps(row, ensure_ascii=False, separators=(',',':'))
            except Exception:
                payload = '{}'
            records.append((trade_date, panel_name, code, name, sector, price, change,
                            value_eok, value_rank, saved_at, saved_at, payload))
    if not records:
        return {'saved':0, 'date':trade_date}

    with sqlite3.connect(db_path(), timeout=10) as con:
        con.executemany(
            '''INSERT INTO screener_hits(
                trade_date,panel_name,stock_code,stock_name,sector,price,change_rate,
                value_eok,value_rank,first_seen_at,last_seen_at,payload_json
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
            ON CONFLICT(trade_date,panel_name,stock_code) DO UPDATE SET
                stock_name=excluded.stock_name,
                sector=excluded.sector,
                price=excluded.price,
                change_rate=excluded.change_rate,
                value_eok=excluded.value_eok,
                value_rank=excluded.value_rank,
                last_seen_at=excluded.last_seen_at,
                hit_count=screener_hits.hit_count+1,
                payload_json=excluded.payload_json''',
            records
        )
    return {'saved':len(records), 'date':trade_date}


def import_report_once(report, trade_date, saved_at=None):
    # Import restored last scanner snapshot without increasing hit_count on every restart.
    panels = (((report or {}).get('search_panels') or {}).get('panels') or {})
    if not panels or not trade_date:
        return {'saved':0, 'date':trade_date}
    saved_at = saved_at or datetime.now().isoformat()
    code_changes = _change_by_code(panels)
    records = []
    for panel_name, panel in panels.items():
        if panel_name in EXCLUDED_PANELS:
            continue
        for row in ((panel or {}).get('rows') or []):
            if not isinstance(row, dict):
                continue
            code = str(row.get('code') or '').strip()
            if not code:
                continue
            name = str(row.get('name') or code).strip()
            sector = str(row.get('sector') or '미분류').strip() or '미분류'
            price = _num(row.get('price'))
            change = _row_change(row, panel_name, code_changes)
            value_eok = _num(row.get('value_eok'))
            value_rank = _int(row.get('value_rank'))
            try:
                payload = json.dumps(row, ensure_ascii=False, separators=(',',':'))
            except Exception:
                payload = '{}'
            records.append((trade_date,panel_name,code,name,sector,price,change,
                            value_eok,value_rank,saved_at,saved_at,payload))
    if not records:
        return {'saved':0, 'date':trade_date}
    with sqlite3.connect(db_path(), timeout=10) as con:
        before = con.total_changes
        con.executemany(
            '''INSERT INTO screener_hits(
                trade_date,panel_name,stock_code,stock_name,sector,price,change_rate,
                value_eok,value_rank,first_seen_at,last_seen_at,payload_json
            ) VALUES(?,?,?,?,?,?,?,?,?,?,?,?)
            ON CONFLICT(trade_date,panel_name,stock_code) DO UPDATE SET
                stock_name=excluded.stock_name,
                sector=excluded.sector,
                price=excluded.price,
                change_rate=excluded.change_rate,
                value_eok=excluded.value_eok,
                value_rank=excluded.value_rank,
                payload_json=excluded.payload_json''',
            records
        )
        saved = con.total_changes - before
    return {'saved':int(saved), 'date':trade_date}

def snapshot(trade_date=None, panel=None, limit=1000):
    limit = max(1, min(int(limit or 1000), 5000))
    with sqlite3.connect(db_path(), timeout=10) as con:
        con.row_factory = sqlite3.Row
        dates = [r['trade_date'] for r in con.execute(
            'SELECT DISTINCT trade_date FROM screener_hits ORDER BY trade_date DESC LIMIT 260'
        ).fetchall()]
        selected = trade_date if trade_date in dates else (dates[0] if dates else trade_date)
        if not selected:
            return {'dates':[], 'date':None, 'panels':[], 'rows':[], 'count':0, 'db_path':str(db_path())}
        panel_counts = [dict(r) for r in con.execute(
            '''SELECT panel_name, COUNT(*) AS count
               FROM screener_hits WHERE trade_date=?
               GROUP BY panel_name ORDER BY MIN(first_seen_at), panel_name''',
            (selected,)
        ).fetchall()]
        args = [selected]
        where = 'trade_date=?'
        if panel and panel not in ('all','전체'):
            where += ' AND panel_name=?'
            args.append(panel)
        args.append(limit)
        rows = [dict(r) for r in con.execute(
            f'''SELECT trade_date,panel_name,stock_code,stock_name,sector,price,change_rate,
                       value_eok,value_rank,first_seen_at,last_seen_at,hit_count
                FROM screener_hits
                WHERE {where}
                ORDER BY panel_name,
                         CASE WHEN value_rank IS NULL THEN 999999 ELSE value_rank END,
                         CASE WHEN value_eok IS NULL THEN 0 ELSE value_eok END DESC,
                         stock_name
                LIMIT ?''',
            args
        ).fetchall()]
    return {'dates':dates,'date':selected,'panels':panel_counts,'rows':rows,'count':len(rows),'db_path':str(db_path())}
