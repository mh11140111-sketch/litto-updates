"""Isolated GPT/Gemini debate. Read-only: no orders, writes or UI actions."""
import re
READ_ONLY_EXACT={'litto_pdf_list','litto_pdf_search','litto_get_ai_capabilities'}
def is_readonly_tool(name):
    return name.startswith('litto_get_') or name in READ_ONLY_EXACT or name.startswith('litto_analysis_list')

def run(payload,gpt,gemini,definitions,dispatch):
    topic=str((payload or {}).get('topic') or '').strip()
    if not topic or len(topic)>1200:raise ValueError('토론 주제는 1~1,200자로 입력해줘.')
    turns=int((payload or {}).get('rounds') or 2)
    if turns not in (1,2,3):raise ValueError('토론은 1~3라운드로 진행할 수 있어.')
    context=(payload or {}).get('context') or {}
    if not isinstance(context,dict):context={}
    # Separate debate history per provider, no user conversation history or memory sharing.
    context={k:v for k,v in context.items() if k in ('asof','current_stock','chart_timeframe','chart_snapshot','market','fzone','top5','scanner_panel_counts','newheart_evidence')}
    readonly=[x for x in definitions if is_readonly_tool(x.get('name',''))]
    audit=context.get('newheart_evidence') if isinstance(context.get('newheart_evidence'),dict) else None
    if audit:
        audit={k:audit.get(k) for k in ('stock','mode','checked_at','criteria','missing','decision','source_policy')}
        context['newheart_evidence']=audit
    transcript=[]
    def ask(role,query):
        if role=='GPT':
            r=gpt({'message':query,'_debate_readonly':True,'history':[],'context':context,'quality':'fast','model':'auto'})
        else:
            r=gemini({'message':query,'history':[],'context':context},tool_definitions=readonly,tool_dispatch=dispatch)
        text=str(r.get('text') or '').strip()
        if not text:raise ValueError(role+' 답변이 비어 있어.')
        return {'speaker':role,'text':text[:5000],'model':str(r.get('model') or '')}
    # Debate is decision support only. No trade execution, reservations or settings changes.
    # Grounded in the user's Newheart course summary (not invented universal buy rules).
    # The source is a qualitative trading framework; it is NOT a guaranteed signal.
    newheart_rules=(
        '[뉴하트 원문 기준 - AI 임의 규칙보다 우선]\n'
        '공통 순서: 시황 → 주도섹터 → 종목 → 자리 → 비중 → 대응. 매매기법은 구별해서 판단한다.\n'
        '종배: 오늘 강한 주도섹터·주도주의 거래대금, 오전 자금유입, 오후 재유입 또는 저점 상승, '
        '종가권 힘 유지, 고점 대비 위치, 호가와 익일 대응을 함께 검토한다. '
        '3시 이후에는 강한 종목을 얼마나 유리하게 매수할지가 중요하다. '
        '특정 가격 신고가 돌파나 15분봉 2개 안착을 뉴하트의 필수 규칙으로 만들어내지 마라. '
        'NXT 막판 흐름을 확인할 수 있으나 19:40~50 시각 자체가 매수신호는 아니다.\n'
        '하트존: 기준봉 후 본격 시세발산 전 조정, 기준봉보다 거래대금 감소, 3/5일선과 '
        '15분봉 60/120선 근처 지지 여부를 검토. 다음날 첫 지지 이탈은 15분봉 마감으로 페이크 여부 확인. '
        '추매 금지, 다음날 10시까지 해결 선호.\n'
        '피뢰침: 기준봉 후 D+1/D+2 강한 분출 뒤 긴 윗꼬리/급락, 기술적 반등 자리 검토. '
        '하트존과 혼동 금지. 다음날 첫 저점 이탈시 정리, 추매 금지, 10시까지 정리 선호.\n'
        'F존: B1/B2/B3 및 실제 진입 위치와 반등 여부를 확인. 정석은 B3 훼손 대응, '
        '빠른 대응은 B1/B2 이후 B2 이탈·반등 실패 시 정리할 수 있다. '
        '기법 선택 및 비중 계획 없이 단순히 F존 표시만으로 매수 판정 금지.\n'
        '증거 구분: [원문 규칙], [실제 확인 데이터/시각], [AI 보조조건], [미확인]으로 분리. '
        '원문의 정성적 조건에 임의 점수나 가짜 승률을 부여하지 마라. '
        '최신 시세/호가/수급이 실제 조회되지 않았다면 조회한 척 하지 마라. '
        '뉴하트 원칙으로 검증 가능한 조건이 충족된 경우에는 매수 조건 충족을 허용하되 '
        '근거 없이 매수 또는 보류를 강요하지 마라.\n'
    )
    intro=(
        newheart_rules+
        'newheart_evidence가 있으면 동일한 증거표를 두 AI 모두 우선 확인하되 관찰은 매수 신호가 아니다. 실제 확인과 사후 관찰을 구분해. '
        '너는 라이또 종배 판단 토론의 독립적인 분석가야. 상대 AI의 의견을 무조건 반대하거나 따르지 마. '
        '실제 시장 데이터와 조회 시각에 근거해 독립적으로 판단해. 확인하지 못한 정보는 추측으로 채우지 마. '
        'TOP5 종배 추천 요청이면 제시된 후보를 모두 비교하고, 1순위와 차선 후보를 명시해. TOP5 점수 자체를 매수 신호로 사용하지 마. 후보별 실제 데이터를 조회할 수 없으면 부족한 데이터와 재확인 조건을 분명히 밝혀. '
        '후보 적합성과 지금 주문 가능한지를 반드시 별도로 평가해. ① 종배 적합/조건부 적합/부적합/검증 불가, ② 지금 매수 검토 가능/조건 충족 시 검토/오늘 매수 제외/장 종료(사후 평가) 중 각각 하나를 선택해. '
        '지금 즉시 매수하지 않아도 관찰 후보로 남길 수 있으나 조건 대기를 무기한 반복하지 마. '
        '진입 범위·무효화 기준은 검증된 데이터와 수치가 있을 때만 제시해. '
        '의견 차이만을 이유로 자동 보류하지 마. 반대로 무리해서 매수 결론을 만들지도 마. '
        '실제 주문·예약·설정 변경·파일 저장은 절대 하지 마. 최대 650자.\n주제: '+topic)
    try:
        for round_num in range(turns):
            for who in ('GPT','Gemini'):
                recent='\n'.join(x['speaker']+': '+x['text'] for x in transcript[-4:])
                query=intro+('\n이전 토론:\n'+recent+'\n상대의 가장 중요한 주장 하나를 검증하거나 반박하고 네 판단을 갱신해.' if recent else '\n먼저 독립적인 초기 의견을 제시해.')
                transcript.append(dict(ask(who,query),round=round_num+1))
    except Exception as exc:
        return {'ok':False,'error':str(exc)[:500],'turns':transcript,'topic':topic,'complete':False}
    summary='\n'.join(x['speaker']+'(라운드 '+str(x['round'])+'): '+x['text'] for x in transcript)
    final=ask('GPT',(
        newheart_rules+
        '다음 GPT/Gemini 토론 기록을 실제 데이터 중심으로 최종 판정해. '
        'AI가 서로 반대한다고 자동 보류하지 말고, 먼저 어느 뉴하트 기법을 적용했는지 명시한 뒤 해당 기법의 조건을 판정해. '
        '반드시 답변 시작에 다음 네 줄을 정확한 형식으로 작성해. 나머지 근거는 그 아래에 작성해.\n'
        '종배 1순위: 종목명 (후보가 없으면 없음)\n'
        '후보 적합성: 종배 적합 / 조건부 적합 / 부적합 / 검증 불가 중 하나\n'
        '오늘의 실행판단: 지금 매수 검토 가능 / 조건 충족 시 검토 / 오늘 매수 제외 / 장 종료(사후 평가) 중 하나\n'
        '마지막에 과거 방식의 최종판정: 조건 대기 같은 중복 결론을 작성하지 마. TOP5 비교 주제라면 후보별 우열과 1순위·차선 후보를 설명해. 후보 적합성과 실제 매수 실행판단을 절대로 한 상태로 합치지 마. 지금이 장 종료 후라면 실행판단은 장 종료(사후 평가)로 쓰고, 당시 종배 적합성은 당시 확인 가능한 데이터로 별도로 평가해. 장중이어도 충분한 근거가 있으면 종배 적합으로 분명히 답하고, 미확인 근거가 핵심이면 임의로 매수 확정하지 마. 적용 전략, 원문 기준, 확인 데이터의 시각, AI 보조 조건, 미확인 데이터, 진입 및 실패 기준을 각각 구분해 제시해. '
        '조건 충족 시 검토라면 필요한 조건과 기한을 명시하고, 미충족 시 오늘 매수 제외를 제시해. '
        '후보 제외 시 대체 후보를 검토하되 확인되지 않은 후보를 억지로 매수 추천하지 마. '
        '매수 조건 충족은 해당 뉴하트 전략의 핵심 판단 근거가 실제로 확인된 경우에만 사용해. AI가 임의로 추가한 돌파 가격을 필수 규칙으로 격상하지 마. '
        '보류를 무조건 실패로 간주하지 말고 익일 성과와 당시 매수 조건 충족 여부를 별도로 검증해야 한다고 밝혀. '
        '진입 가격이 확인되지 않으면 지어내지 마. 실제 주문 및 예약은 실행하지 마. '
        '주제: '+topic+'\n토론 기록:\n'+summary[:15000]))
    # Classification is explicit, auditable, and never triggers execution.
    final_text=str(final.get('text') or '')
    final_text=re.sub(r'(?m)^\s*\*{0,2}최종판정\s*[:：][^\n]*\n?', '', final_text)
    final['text']=final_text
    def header(key, allowed):
        m=re.search(r'^'+re.escape(key)+r'\s*[:：]\s*(.+)$',final_text,re.M)
        if not m:return '미확인'
        value=m.group(1).strip().strip('*').strip()
        return value if value in allowed else '미확인'
    candidate=header('후보 적합성',{'종배 적합','조건부 적합','부적합','검증 불가'})
    action=header('오늘의 실행판단',{'지금 매수 검토 가능','조건 충족 시 검토','오늘 매수 제외','장 종료(사후 평가)'})
    pick_match=re.search(r'^종배 1순위\s*[:：]\s*(.+)$',final_text,re.M)
    pick=pick_match.group(1).strip()[:90] if pick_match else '미확인'
    # One authoritative execution status; candidate quality remains independent.
    return {'ok':True,'topic':topic,'turns':transcript,'summary':final,'decision':action,'candidate_fit':candidate,'today_action':action,'first_pick':pick,'complete':True}
