"""Newheart closing-candidate read-only evidence check v1.
No provider/API calls, file writes, orders, reservations or AI model calls.
No success probabilities or arbitrary trading score.
"""
from datetime import datetime


def _num(x):
    try:
        if isinstance(x, bool) or x is None: return None
        a=float(str(x).replace(',',''))
        return a if 0 <= a < 1e16 else None
    except (ValueError, TypeError):return None


def _result(label, state, evidence):
    return {'criterion':label, 'state':state, 'evidence':evidence}


def evaluate(payload):
    """Use only submitted UI snapshot; unknown never means pass or fail."""
    if not isinstance(payload,dict):raise ValueError('검증 데이터가 올바르지 않습니다.')
    ctx=payload.get('context') if isinstance(payload.get('context'),dict) else payload
    selected=ctx.get('current_stock') if isinstance(ctx.get('current_stock'),dict) else {}
    chart=ctx.get('chart_snapshot') if isinstance(ctx.get('chart_snapshot'),dict) else {}
    code=str(chart.get('code') or selected.get('code') or '').strip()[:16]
    name=str(chart.get('name') or selected.get('name') or code).strip()[:80]
    top5=ctx.get('top5') if isinstance(ctx.get('top5'),list) else []
    top5=[x for x in top5[:5] if isinstance(x,dict)]
    ranks=[(i+1,x) for i,x in enumerate(top5) if str(x.get('code') or '').strip()==code]
    criteria=[]
    criteria.append(_result('시장 주도섹터 확인','미확인','현재 UI 맥락만으로 주도섹터의 시장 전체 지배력은 확인할 수 없음'))
    if ranks:
        rank,row=ranks[0]
        criteria.append(_result('종배 TOP5 후보 여부','확인',f'TOP5 {rank}위, 점수 {row.get("score","-")} (점수는 승률이 아님)'))
    else:
        criteria.append(_result('종배 TOP5 후보 여부','미확인','현재 선택종목이 전달된 TOP5에 없음; 후보 제외의 근거로 단정하지 않음'))
    criteria.append(_result('오전 거래대금 집중','미확인','시간대별 거래대금 자료가 전달되지 않음'))
    criteria.append(_result('오후 자금 재유입','미확인','오전·오후 자금 유입을 비교할 거래대금/체결 흐름 자료가 없음'))
    tf=str(chart.get('timeframe') or '')
    raw=chart.get('bars') if isinstance(chart.get('bars'),list) else []
    bars=[]
    for b in raw[-200:]:
        if not isinstance(b,dict):continue
        if b.get('complete') is False:continue
        o,h,l,c=(_num(b.get(k)) for k in ('open','high','low','close'))
        if None in (o,h,l,c) or not (0<l<=min(o,c)<=max(o,c)<=h):continue
        bars.append({'open':o,'high':h,'low':l,'close':c,'date':str(b.get('date') or ''),'time':str(b.get('time') or '')})
    if len(bars)>=2 and tf in ('m15','m3','m1','daily'):
        last=bars[-1]; prev=bars[-2]
        location=round(100*(last['close']-last['low'])/(last['high']-last['low']),1) if last['high']>last['low'] else None
        desc=f'{tf} 마지막 완성봉 종가 {last["close"]:,.0f}, 직전 완성봉 종가 {prev["close"]:,.0f}'
        if location is not None:desc+=f', 봉 내 종가 위치 {location}%'
        criteria.append(_result('종가권 가격 위치','관찰',desc+'; 당일 고가 대비 위치와 종배 강도까지 확정하지 않음'))
    else:
        criteria.append(_result('종가권 가격 위치','미확인','유효한 완성 분봉이 2개 이상 없어 산정 불가'))
    criteria.append(_result('유리한 매수 자리','미확인','호가·스프레드·구체적인 진입 가격 검증이 없으므로 자동 합격 판정하지 않음'))
    criteria.append(_result('익일 무효화/비중 계획','미확인','사용자 지정 진입·무효화·비중 정보 없음'))
    return {'ok':True,'engine':'newheart_jongba_v1','read_only':True,'strategy':'종가베팅',
            'stock':{'code':code,'name':name},'asof':str(ctx.get('asof') or '')[:40],
            'decision':'조건 검증 미완료', 'criteria':criteria,
            'notice':'뉴하트 원문 정성 기준의 증거 점검용. 미확인은 실패가 아니며, 매수 신호·실주문·예약을 생성하지 않습니다.',
            'missing':[x['criterion'] for x in criteria if x['state']=='미확인']}
