"""Separate Gemini memory and episodes. Never reads or edits GPT memory."""
from pathlib import Path
import sqlite3
from litto_memory_storage import storage_dir
import ai_brain as _shared_code

# Separate copy of the same library with its own module globals (_DB and _LOCK).
import importlib.util
_SPEC=importlib.util.spec_from_file_location("_litto_gemini_brain_engine", Path(__file__).with_name("ai_brain.py"))
_engine=importlib.util.module_from_spec(_SPEC)
_SPEC.loader.exec_module(_engine)

def init():
    path=storage_dir()/"litto_gemini_brain.sqlite3"
    path.parent.mkdir(parents=True,exist_ok=True)
    # The shared ai_brain.init() derives the GPT DB: initialize this instance explicitly.
    _engine._DB=path
    with _engine._conn() as db:
        db.execute("CREATE TABLE IF NOT EXISTS memory(id INTEGER PRIMARY KEY AUTOINCREMENT,mkey TEXT NOT NULL,value TEXT NOT NULL,kind TEXT NOT NULL DEFAULT 'preference',confidence REAL NOT NULL DEFAULT 1.0,created_at REAL NOT NULL,updated_at REAL NOT NULL,UNIQUE(mkey,kind))")
        db.execute('CREATE TABLE IF NOT EXISTS episode(id INTEGER PRIMARY KEY AUTOINCREMENT,ts REAL NOT NULL,user_msg TEXT NOT NULL,assistant_msg TEXT NOT NULL,model TEXT,tools_json TEXT,actions_json TEXT,context_json TEXT)')
        db.execute('CREATE INDEX IF NOT EXISTS idx_episode_ts ON episode(ts DESC)')
        db.execute('CREATE INDEX IF NOT EXISTS idx_memory_updated ON memory(updated_at DESC)')

init()
remember=_engine.remember
recall=_engine.recall
forget=_engine.forget
memories=_engine.memories
log_episode=_engine.log_episode
search_episodes=_engine.search_episodes
status=_engine.status
