"""Newheart closing-bet evidence audit v2. Read only. No orders or background polling.

Only supplied UI/TOP5 and timestamped completed bars count as evidence.
Unknown is not failure and a positive observation is not a buy instruction.
"""
from datetime import datetime, time
from zoneinfo import ZoneInfo
import math

KST=ZoneInfo('Asia/Seoul')

def num(x):
    try:
        if x is None or isinstance(x,bool): return None
        n=float(str(x).replace(',',''))
        return n if math.isfinite(n) and 0<=n<1e16 else None
    except (ValueError,TypeError):return None

def item(name,state,evidence,source=''):
    return {'criterion':name,'state':state,'evidence':evidence,'source':source}

def code_of(v):
    return str(v or '').strip().removeprefix('A').replace('_AL','').replace('_NX','').zfill(6)

def parse_bar(b):
    if not isinstance(b,dict) or b.get('complete') is False:return None
    o=num(b.get('open'));h=num(b.get('high'));l=num(b.get('low'));c=num(b.get('close'))
    if None in (o,h,l,c) or l<=0 or not (l<=o<=h and l<=c<=h):return None
    vol=num(b.get('volume'));value=num(b.get('value'))
    date=str(b.get('date') or '');tm=str(b.get('time') or '')
    stamp=(date+' '+tm).strip()
    # Normalize HH:mm for time filters; never infer a time from an unparseable value.
    import re
    match=re.search(r'(\d{1,2}):(\d{2})',tm)
    hhmm=f'{int(match.group(1)):02d}:{match.group(2)}' if match and int(match.group(1))<24 else ''
    return {'open':o,'high':h,'low':l,'close':c,'volume':vol,'value':value,'time':hhmm,'stamp':stamp,'date':date}

def evaluate(payload):
    if not isinstance(payload,dict):raise ValueError('검증 요청 형식이 올바르지 않습니다.')
    ctx=payload.get('context') if isinstance(payload.get('context'),dict) else payload
    chosen=ctx.get('audit_stock') if isinstance(ctx.get('audit_stock'),dict) else (ctx.get('current_stock') if isinstance(ctx.get('current_stock'),dict) else {})
    chart=ctx.get('audit_chart') if isinstance(ctx.get('audit_chart'),dict) else (ctx.get('chart_snapshot') if isinstance(ctx.get('chart_snapshot'),dict) else {})
    code=code_of(chosen.get('code') or chart.get('code'))
    if not code.strip('0'):raise ValueError('대상 종목이 확인되지 않았습니다. 토론 주제에 종목명을 입력하거나 차트를 선택해 주세요.')
    name=str(chosen.get('name') or chart.get('name') or code)[:90]
    # Keep a chart only if its code is unequivocally that of the selected stock.
    if code_of(chart.get('code'))!=code:chart={}
    day=ctx.get('audit_day') if isinstance(ctx.get('audit_day'),dict) else {}
    now=datetime.now(KST)
    mode='실시간 판단' if time(14,40)<=now.time()<time(20,0) and now.weekday()<5 else '사후 검증 / 장외 관찰'
    top5=ctx.get('top5') if isinstance(ctx.get('top5'),list) else []
    matches=[(i,x) for i,x in enumerate(top5[:5],1) if isinstance(x,dict) and code_of(x.get('code'))==code]
    criteria=[]
    sector=str(chosen.get('sector') or '')
    criteria.append(item('시장 주도섹터','미확인',f'종목 분류: {sector}. 시장 전체 섹터 간 주도성 비교 자료 없음' if sector else '섹터 비교 자료 없음','사용자 UI'))
    criteria.append(item('종배 TOP5 후보 여부','확인',f'현재 TOP5 {matches[0][0]}위 · {matches[0][1].get("score","-")}점. 현재 순위이며 과거 시점의 순위 증거는 아님' if matches else '현재 TOP5에 해당 종목이 없음. 당시 후보 제외를 증명하지는 않음','현재 TOP5' if matches else ''))
    raw=chart.get('bars') if isinstance(chart.get('bars'),list) else []
    bars=[v for v in (parse_bar(x) for x in raw[-400:]) if v]
    tf=str(chart.get('timeframe') or chart.get('tf') or '')
    # No time-bucket inference from daily candles.
    minute_bars=[b for b in bars if b['time'] and (tf in ('m15','15','m3','3','m1','1'))]
    morning=[b for b in minute_bars if '09:00'<=b['time']<'12:00']
    afternoon=[b for b in minute_bars if '13:00'<=b['time']<='15:30']
    if morning:
        qty=sum(b['volume'] or 0 for b in morning)
        criteria.append(item('오전 거래 집중','관찰',f'{len(morning)}개 완성 분봉 거래량 합계 {qty:,.0f}주. 당일 다른 종목 대비 거래대금 집중은 미확인','완성 분봉'))
    else:criteria.append(item('오전 거래 집중','미확인','시간이 명시된 오전 완성 분봉이 없음'))
    if len(afternoon)>=2:
        first,last=afternoon[0],afternoon[-1]
        low_first=min(b['low'] for b in afternoon[:max(1,len(afternoon)//2)])
        low_later=min(b['low'] for b in afternoon[max(1,len(afternoon)//2):]) if len(afternoon)>2 else afternoon[-1]['low']
        direction='상승' if low_later>low_first else ('하락' if low_later<low_first else '동일')
        criteria.append(item('오후 저점·자금 재유입','관찰',f'오후 완성 분봉 {len(afternoon)}개, 전반 저점 {low_first:,.0f}원 → 후반 저점 {low_later:,.0f}원 ({direction}). 자금 재유입은 거래대금·체결 자료 없으면 단정 불가','완성 분봉'))
    else:criteria.append(item('오후 저점·자금 재유입','미확인','오후 완성 분봉이 부족함'))
    # Day bar taken from existing UI stock state; no fabricated regular-session close.
    d=parse_bar(day)
    if d and d['high']>d['low']:
        pos=100*(d['close']-d['low'])/(d['high']-d['low'])
        criteria.append(item('당일 고가권 가격 위치','관찰',f'UI 일봉 종가 필드 {d["close"]:,.0f}원 · 당일 범위 상단 {pos:.1f}%. 데이터 세션/확정 여부는 별도 확인 필요','UI 일봉'))
    elif minute_bars:
        latest=minute_bars[-1]
        criteria.append(item('당일 고가권 가격 위치','관찰',f'최근 유효 분봉 종가 {latest["close"]:,.0f}원 ({latest["stamp"]}). 장 마감 확정 종가 아님','완성 분봉'))
    else:criteria.append(item('당일 고가권 가격 위치','미확인','선택 종목의 유효한 일봉/분봉 미전달'))
    criteria.append(item('유리한 매수 자리','미확인','스프레드·실제 호가·체결가격·사용자 지정 진입 조건이 없어 확정하지 않음'))
    criteria.append(item('익일 대응·비중 계획','미확인','손절 기준·비중·익일 시간 대응이 입력되지 않음'))
    missing=[x['criterion'] for x in criteria if x['state']=='미확인']
    return {'ok':True,'engine':'newheart_jongba_v2','read_only':True,'strategy':'주도주 종가베팅',
        'stock':{'code':code,'name':name},'checked_at':now.isoformat(), 'mode':mode,
        'decision':'조건 검증 미완료' if missing else '증거 검토 완료 · 매수 여부는 별도 판단',
        'criteria':criteria,'missing':missing,
        'source_policy':'현재 시각 데이터는 과거 시점 진입 근거로 소급할 수 없음',
        'notice':'확인/관찰/미확인 = 증거 상태이며 매수·매도 신호가 아닙니다. 주문·예약·데이터 저장은 수행하지 않습니다.'}
