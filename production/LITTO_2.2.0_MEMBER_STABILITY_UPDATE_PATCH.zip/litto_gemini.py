"""Gemini API: explicit opt-in, minimal context, per-user DPAPI protected key."""
import json,os,base64,re
from pathlib import Path
from urllib.request import Request,urlopen
from urllib.parse import urlencode
from urllib.error import HTTPError,URLError

SECRET=Path(__file__).resolve().parent/'data'/'gemini_api_key.dpapi'
PAID_SECRET=SECRET.with_name('gemini_paid_api_key.dpapi')
MODE_FILE=SECRET.with_name('gemini_tier_mode.json')
PAID_MODEL_PREFERENCES=('gemini-3.1-pro-preview','gemini-3-pro-preview','gemini-2.5-pro','gemini-3.1-flash','gemini-2.5-flash')
# Free-tier candidates only; user projects can have different model availability.
# Prefer currently offered fast models over legacy 2.5, access to which is limited for new projects.
FREE_MODEL_CANDIDATES=('gemini-3.5-flash-lite','gemini-3.8-flash','gemini-3.1-flash-lite','gemini-3.6-flash','gemini-2.5-flash-lite','gemini-2.5-flash')
MODEL=FREE_MODEL_CANDIDATES[0]

def _protect(text,unlock=False):
    if os.name!='nt':
        raise RuntimeError('Gemini 키 저장은 Windows DPAPI 환경에서만 지원해.')
    import ctypes
    from ctypes import wintypes
    class BLOB(ctypes.Structure):
        _fields_=[('cbData',wintypes.DWORD),('pbData',ctypes.POINTER(ctypes.c_byte))]
    raw=text if isinstance(text,bytes) else text.encode('utf-8')
    src=ctypes.create_string_buffer(raw); inp=BLOB(len(raw),ctypes.cast(src,ctypes.POINTER(ctypes.c_byte)));out=BLOB()
    fn=ctypes.windll.crypt32.CryptUnprotectData if unlock else ctypes.windll.crypt32.CryptProtectData
    if not fn(ctypes.byref(inp),None,None,None,None,0,ctypes.byref(out)):
        raise OSError('Windows 키 보안 처리 실패')
    try:return ctypes.string_at(out.pbData,out.cbData)
    finally:ctypes.windll.kernel32.LocalFree(out.pbData)
def get_mode():
    try:
        data=json.loads(MODE_FILE.read_text('utf-8'))
        return 'paid' if data.get('mode')=='paid' else 'free'
    except (OSError,ValueError,TypeError,AttributeError):return 'free'

def key_status():
    mode=get_mode()
    return {'configured':(PAID_SECRET if mode=='paid' else SECRET).is_file(),
            'free_configured':SECRET.is_file(),'paid_configured':PAID_SECRET.is_file(),
            'mode':mode,'model':MODEL if mode=='free' else '자동 선택 (유료 모델)'}

def set_mode(mode):
    if mode not in ('free','paid'):raise ValueError('모드는 free 또는 paid만 가능해.')
    if mode=='paid' and not PAID_SECRET.is_file():raise ValueError('유료 API 키를 먼저 저장해줘.')
    MODE_FILE.parent.mkdir(parents=True,exist_ok=True)
    temp=MODE_FILE.with_suffix('.tmp')
    try:
        temp.write_text(json.dumps({'mode':mode}),encoding='utf-8')
        temp.replace(MODE_FILE)
    finally:temp.unlink(missing_ok=True)
    return key_status()

def _normalize_api_key(raw):
    """Remove only paste artifacts; never alter valid API key characters."""
    key=str(raw or '').strip()
    # Google API keys never contain whitespace. Some copy actions insert
    # line wraps or nonbreaking spaces, including in the middle of the value.
    key=''.join(ch for ch in key if not ch.isspace() and ch not in
                ('\u200b', '\u200c', '\u200d', '\ufeff', '\u2060'))
    # Accept a quoted value pasted from a config/code block.
    for _ in range(2):
        if len(key)>=2 and key[0]==key[-1] and key[0] in ('"', "'", '`', '“', '”'):
            key=key[1:-1]
    return key

def _validate_api_key(key):
    """Check only obviously unsuitable input; Google's API is the authority.

    Google may change its key formats. An overly strict local allowlist blocks
    legitimate credentials before any network request. Never log or echo keys.
    """
    if not 15 <= len(key) <= 300:
        raise ValueError('입력값 길이를 확인해줘. Google AI Studio에서 API 키 자체를 복사해줘.')
    if any(ord(c) < 32 or ord(c) == 127 for c in key):
        raise ValueError('키에 제어 문자가 포함되어 있어. API 키만 복사해줘.')
    if any(c.isspace() for c in key):
        raise ValueError('키에 공백이 있어. Google AI Studio에서 API 키만 복사해줘.')
    # No AIza prefix or rigid character allowlist here: the provider validates
    # the exact credential at request time and returns a specific HTTP error.

def save_key(key, mode='free'):
    if mode not in ('free','paid'):raise ValueError('잘못된 API 모드야.')
    target=PAID_SECRET if mode=='paid' else SECRET
    key=_normalize_api_key(key)
    if not key:
        target.unlink(missing_ok=True)
        if get_mode()==mode and mode=='paid':set_mode('free')
        return key_status()
    _validate_api_key(key)
    encrypted=_protect(key)
    target.parent.mkdir(parents=True,exist_ok=True)
    temp=target.with_suffix('.tmp')
    try:
        temp.write_bytes(encrypted)
        try:temp.chmod(0o600)
        except OSError:pass
        temp.replace(target)
    finally:
        try:temp.unlink(missing_ok=True)
        except OSError:pass
    return key_status()
def _key(mode=None):
    mode=mode or get_mode()
    target=PAID_SECRET if mode=='paid' else SECRET
    if not target.is_file():raise ValueError(('유료' if mode=='paid' else '무료')+' Gemini API 키를 먼저 등록해줘.')
    return _protect(target.read_bytes(),True).decode('utf-8')
def _provider_detail(exc):
    """A short, sanitized provider error; never include the API key or URL."""
    try:
        data=json.loads(exc.read(8192).decode('utf-8','replace'))
        detail=str((data.get('error') or {}).get('message') or '')
        # Provider messages should not contain keys, but remove them defensively.
        detail=re.sub(r'AIza[0-9A-Za-z_-]{10,}', '[API KEY]', detail)
        return detail[:350]
    except Exception:return ''

def _available_models(api_key,mode='free'):
    """Discover accessible text+image generation models without sending user messages."""
    available=set()
    token=None
    for _ in range(4):
        query={'pageSize':1000}
        if token:query['pageToken']=token
        request=Request('https://generativelanguage.googleapis.com/v1beta/models?'+urlencode(query),headers={'x-goog-api-key':api_key},method='GET')
        with urlopen(request,timeout=20) as response:data=json.load(response)
        for obj in data.get('models',[]):
            if 'generateContent' in (obj.get('supportedGenerationMethods') or []):
                available.add(str(obj.get('name') or '').removeprefix('models/'))
        token=data.get('nextPageToken')
        if not token:break
    if mode=='free':return [name for name in FREE_MODEL_CANDIDATES if name in available]
    # Choose known text generation candidates only, not image/live/embedding models.
    preferred=[name for name in PAID_MODEL_PREFERENCES if name in available]
    candidates=sorted(name for name in available if re.fullmatch(r'gemini-[\w.-]+',name)
                      and not any(bad in name for bad in ('image','audio','tts','embedding','live','robotics')))
    return preferred+[name for name in candidates if name not in preferred]


def _generate(req_body,api_key,model):
    req=Request('https://generativelanguage.googleapis.com/v1beta/models/'+model+':generateContent',data=req_body,headers={'Content-Type':'application/json','x-goog-api-key':api_key},method='POST')
    with urlopen(req,timeout=100) as response:return json.load(response)


# The same tool definitions/dispatch as the paid GPT backend; no separate
# duplicated PDF/chart implementation. Gemini free-tier data disclosures apply.
TOOL_DENY={'litto_generate_image'}  # image generation uses a separately billed API
PRIVATE_TOOLS={'litto_get_account','litto_get_daily_pnl','litto_get_journal'}
WRITE_TOOLS={'litto_analysis_save','litto_analysis_review'}

def _explicit_private_request(message):
    return bool(re.search(r'계좌|잔고|보유|평단|손익|매매일지|거래내역|체결내역',message,re.I))

def _explicit_write_request(message):
    return bool(re.search(r'저장|기록|검토완료|무효화|수정해|변경해|등록해',message,re.I))

def _gemini_schema(schema):
    # Convert OpenAI tool JSON schema to Gemini function declaration schema.
    if not isinstance(schema,dict):return {'type':'STRING'}
    typ=schema.get('type','string')
    if isinstance(typ,list):typ=next((x for x in typ if x!='null'),'string')
    out={'type':str(typ).upper()}
    if schema.get('description'):out['description']=schema['description']
    # Gemini API rejects empty enum entries. OpenAI tools may use '' as an optional sentinel.
    if isinstance(schema.get('enum'), list):
        choices = [str(x) for x in schema['enum'] if x is not None and str(x).strip()]
        if choices:
            out['enum'] = list(dict.fromkeys(choices))
    if out['type']=='OBJECT':
        out['properties']={k:_gemini_schema(v) for k,v in schema.get('properties',{}).items()}
        if schema.get('required'):out['required']=schema['required']
    if out['type']=='ARRAY':out['items']=_gemini_schema(schema.get('items',{'type':'string'}))
    for k in ('minimum','maximum','minLength','maxLength'):
        if k in schema:out[k]=schema[k]
    return out

def _tool_specs(definitions,message):
    spec=[];allowed={}
    for item in definitions:
        name=item.get('name','')
        if item.get('type')!='function' or name in TOOL_DENY:continue
        if name in PRIVATE_TOOLS and not _explicit_private_request(message):continue
        if name in WRITE_TOOLS and not _explicit_write_request(message):continue
        if name=='litto_memory' and not _explicit_write_request(message):
            # memory searching okay; enforcement of write happens in dispatcher
            pass
        params=_gemini_schema(item.get('parameters',{'type':'object'}))
        spec.append({'name':name,'description':item.get('description',''),'parameters':params})
        allowed[name]=True
    return spec,allowed

def _call_tool(name,args,context,actions,message,dispatch):
    if name in TOOL_DENY:raise PermissionError('Gemini 무료 모드에서 유료 이미지 생성 도구는 호출할 수 없어.')
    if name in PRIVATE_TOOLS and not _explicit_private_request(message):
        raise PermissionError('계좌·거래내역은 명시적으로 요청했을 때만 조회할 수 있어.')
    if name in WRITE_TOOLS and not _explicit_write_request(message):
        raise PermissionError('기록 변경은 사용자가 명시적으로 요청해야 해.')
    if name=='litto_memory' and str(args.get('action') or '') in ('save','delete') and not _explicit_write_request(message):
        raise PermissionError('기억 변경은 사용자가 명시적으로 요청해야 해.')
    if name=='litto_control_ui' and str(args.get('action') or '')=='prepare_order' and not re.search(r'주문표|매수|매도|주문',message):
        raise PermissionError('주문표 준비는 명시적 주문 요청이 필요해.')
    return dispatch(name,args,context,actions)
def chat(payload, tool_definitions=None, tool_dispatch=None):
    msg=str(payload.get('message') or '').strip()[:8000]
    images=payload.get('images') or []
    if not msg and not images:raise ValueError('질문을 입력해줘.')
    if len(images)>4:raise ValueError('이미지는 최대 4장이야.')
    parts=[]
    for item in images:
        url=str((item or {}).get('data_url') or '')
        m=re.fullmatch(r'data:(image/(?:png|jpeg|webp));base64,([A-Za-z0-9+/=]+)',url)
        if not m:raise ValueError('PNG, JPG, WEBP 이미지만 지원해.')
        raw=base64.b64decode(m.group(2),validate=True)
        if len(raw)>3_000_000:raise ValueError('이미지 용량이 너무 커. 더 작게 첨부해줘.')
        parts.append({'inline_data':{'mime_type':m.group(1),'data':m.group(2)}})
    if msg:parts.insert(0,{'text':msg})
    contents=[]
    for h in (payload.get('history') or [])[-12:]:
        role=h.get('role') if isinstance(h,dict) else None
        txt=str(h.get('content') or '')[:3000] if isinstance(h,dict) else ''
        if role in ('user','assistant') and txt:
            contents.append({'role':'model' if role=='assistant' else 'user','parts':[{'text':txt}]})
    contents.append({'role':'user','parts':parts})
    mode=get_mode()
    api_key=_key(mode)
    tools,allowed=_tool_specs(tool_definitions or [],msg)
    prompt=('너는 Google Gemini 기반 LITTO AI 비서야. 너의 기반 모델은 Gemini이며 GPT라고 거짓말하지 마. '
      '라이또 도구 목록을 제공받은 경우, 사용자의 질문에 필요한 도구를 호출해 실제 데이터를 확인하고 답해. '
      'PDF 질문은 반드시 litto_pdf_list 또는 litto_pdf_search를 호출해서 원문을 확인해. '
      '주식 분석은 litto_get_chart 또는 litto_get_stock_full 등으로 근거를 확인해. '
      '시세에는 수신 시각과 지연 가능성을 명시해. '
      '계좌·거래내역은 사용자가 명시적으로 요청한 경우에만 조회해. '
      '주문은 최종 증권사 주문을 실행했다고 주장하지 말고 화면 준비만 가능해. '
      '사용자 질문, 필요한 결과 일부가 Google API로 전송되므로 비밀키, 계좌번호 등 비밀정보를 답변에 노출하지 마. '
      '없는 기능이나 직접 읽지 않은 PDF를 읽었다고 주장하지 마. 한국어 반말로 정확하고 간결하게 답해.')
    # Gemini's own memory (never GPT's memory). Debate requests do not supply it.
    persona_memory=payload.get('_persona_memory') or []
    if persona_memory:
        prompt+='\nGemini 전용 기억(해당 질문과 관련된 경우에만 사용): '+json.dumps(persona_memory,ensure_ascii=False)[:4000]
    req={'systemInstruction':{'parts':[{'text':prompt}]},'contents':contents,
         'generationConfig':{'temperature':0.5,'maxOutputTokens':4096}}
    if tools:req['tools']=[{'functionDeclarations':tools}]
    try:models=_available_models(api_key,mode)
    except HTTPError as exc:
        detail=_provider_detail(exc)
        raise ValueError('Gemini 모델 목록 조회 오류 (HTTP '+str(exc.code)+'): '+(detail or 'API 키와 프로젝트 권한을 확인해줘.'))
    except URLError:raise ValueError('Gemini 모델 목록을 불러오지 못했어. 인터넷 연결을 확인해줘.')
    if not models:raise ValueError('현재 API 키로 사용할 수 있는 '+('유료' if mode=='paid' else '무료')+' 모델을 찾지 못했어.')
    chosen=None;actions=[];trace=[];result=None;errors=[]
    context=payload.get('context') or {}
    if not isinstance(context,dict):context={}
    # Hard budget for tool recursion. Keep the same chosen model.
    for turn in range(6):
        body=json.dumps(req,ensure_ascii=False).encode('utf-8')
        if len(body)>18_000_000:raise ValueError('첨부 용량이 너무 커.')
        if chosen is None:
            for model in models:
                try:result=_generate(body,api_key,model);chosen=model;break
                except HTTPError as exc:
                    detail=_provider_detail(exc)
                    if exc.code==404:errors.append(model+': '+(detail or '404'));continue
                    if exc.code==429:raise ValueError('Gemini 호출 한도에 도달했어. 모델: '+model)
                    raise ValueError('Gemini 서버 오류 (HTTP '+str(exc.code)+'): '+(detail or '프로젝트 설정을 확인해줘.'))
        else:
            try:result=_generate(body,api_key,chosen)
            except HTTPError as exc:
                detail=_provider_detail(exc)
                if exc.code==429:raise ValueError('Gemini 호출 한도에 도달했어.')
                raise ValueError('Gemini 서버 오류 (HTTP '+str(exc.code)+'): '+(detail or '다시 시도해줘.'))
        if result is None:raise ValueError('Gemini 모델 호출이 모두 404로 실패했어. '+(' / '.join(errors)[:350]))
        candidate=(result.get('candidates') or [{}])[0]
        c=candidate.get('content') or {}
        response_parts=c.get('parts') or []
        calls=[p['functionCall'] for p in response_parts if isinstance(p,dict) and isinstance(p.get('functionCall'),dict)]
        if not calls:
            answer='\n'.join(p.get('text','') for p in response_parts if isinstance(p,dict) and p.get('text'))
            if not answer:raise ValueError('Gemini가 답변을 반환하지 않았어. 요청 내용을 바꿔봐.')
            return {'ok':True,'text':answer,'model':chosen,'actions':actions,'tools_used':trace,'web_used':False,'verified':False}
        # Preserve Gemini thoughtSignature on content parts for multi-turn function calling.
        req['contents'].append({'role':'model','parts':response_parts})
        output=[]
        for call in calls[:8]:
            name=str(call.get('name') or '');args=call.get('args') or {}
            if not isinstance(args,dict):args={}
            try:
                if not tool_dispatch or name not in allowed:raise PermissionError('허용되지 않은 도구 요청')
                value=_call_tool(name,args,context,actions,msg,tool_dispatch)
                ok=True
            except Exception as e:value={'ok':False,'error':str(e)};ok=False
            trace.append({'name':name,'ok':ok})
            # Bounded size controls cost and accidental private-data exposure.
            encoded=json.dumps(value,ensure_ascii=False,default=str)
            if len(encoded)>18000:value={'truncated':True,'excerpt':encoded[:17000]}
            output.append({'functionResponse':{'name':name,'response':{'result':value}}})
        req['contents'].append({'role':'user','parts':output})
    return {'ok':True,'text':'라이또 데이터 조회가 여러 단계 이어져 자동으로 중단했어. 요청 범위를 줄여서 다시 물어봐.',
            'model':chosen,'actions':actions,'tools_used':trace,'web_used':False,'verified':False}
