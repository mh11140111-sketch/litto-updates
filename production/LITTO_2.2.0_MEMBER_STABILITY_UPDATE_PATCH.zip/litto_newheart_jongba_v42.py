"""Read-only Newheart v4.2 audit: session separation and genuine snapshot linkage."""
from datetime import datetime
from zoneinfo import ZoneInfo
import re
import litto_newheart_jongba_v3 as v3
import litto_newheart_jongba_v4 as v4

KST=ZoneInfo('Asia/Seoul')

def evaluate(payload):
    result=v3.evaluate(payload)
    ctx=payload.get('context',payload)
    stock=result.get('stock') or {}
    code=str(stock.get('code') or (ctx.get('audit_stock') or {}).get('code') or '')
    trade_date=result.get('trade_date')
    records=v4.evidence_for(code,trade_date)
    chart=ctx.get('audit_chart') or {}
    bars=chart.get('bars') or []
    counts={'krx_time_window':0,'nxt_only_time_window':0,'overlap_venue_unknown':0,'explicit_krx':0,'explicit_nxt':0,'outside':0}
    for bar in bars:
        if not isinstance(bar,dict):continue
        date=(v3._date_key(bar.get('date')) or v3._date_key(bar.get('trade_date')) or
              v3._date_key(bar.get('dt')) or v3._date_key(bar.get('time')) or v3._date_key(bar.get('cntr_tm')))
        if date!=trade_date:continue
        clock=v3._clock_from_bar(bar)
        if not clock:continue
        venue=str(bar.get('venue') or bar.get('market') or bar.get('exchange') or '').upper()
        if venue in ('KRX','NXT'):
            counts['explicit_'+venue.lower()]+=1
        elif '09:00'<=clock<'15:30':counts['overlap_venue_unknown']+=1
        elif '08:00'<=clock<'09:00':counts['nxt_only_time_window']+=1
        elif '15:30'<=clock<'20:00':counts['outside']+=1
        else:counts['outside']+=1
    # Clock ranges are descriptive, not proof of venue; 15:40+ overlaps KRX and NXT.
    result['engine']='newheart_jongba_v4.2'
    result['session_evidence']={'counts':counts,'note':'거래소 식별자 없는 분봉은 KRX/NXT 확정 분류 불가. 시간대 구분은 거래소 확인과 다름.'}
    result['auto_snapshots']=records
    result['snapshot_status']='실제 15:20/15:29 저장 기록 '+str(len(records))+'건' if records else '해당 종목·거래일의 15:20/15:29 자동 저장 기록 없음 (소급 생성 금지)'
    result['decision']='증거 수집 중 · 매수 판정 아님'
    for c in result.get('criteria',[]):
        if c.get('criterion')=='종배 TOP5 후보 여부':
            if records:
                c['state']='기록 확인'
                c['evidence']='실제 저장 TOP5: '+', '.join(str(x['slot'])+' '+str(x['rank'])+'위 ('+str(x['score'])+'점)' for x in records)
            else:
                c['state']='관찰'
                c['evidence']='현재 TOP5는 과거 순위 증거가 아님. 실제 15:20·15:29 저장 기록 없음.'
    return result
