"""Evidence-only Newheart v3 audit and immutable local snapshot ledger.
No securities orders, no strategy execution, no market-background polling.
"""
import copy, json, os, tempfile, threading, re
from datetime import date as date_type
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo
import litto_newheart_jongba_v2 as v2

LOCK=threading.RLock()
KST=ZoneInfo('Asia/Seoul')
ROOT=Path(__file__).resolve().parent
FILE=ROOT/'data'/'newheart_jongba_evidence_v3.json'

def _date_key(value):
    """Accept explicit YYYY-MM-DD / YYYYMMDD and Kiwoom ISO/compact datetime.

    Date must be present in the source. Never infer a trade date from the
    requested day or current clock for an undated candle.
    """
    text=str(value or '').strip()
    match=re.match(r'^(\d{4})[-/.]?(\d{2})[-/.]?(\d{2})(?:$|[T\s\d:+-])',text)
    if not match:return ''
    y,m,d=map(int,match.groups())
    try:return date_type(y,m,d).isoformat()
    except ValueError:return ''

def _clock_from_bar(bar):
    """Normalize minute time for v2 without treating a time-only value as a date."""
    source=str(bar.get('time') or bar.get('cntr_tm') or '').strip()
    m=re.search(r'(?:T|\s)(\d{2}):(\d{2})(?::\d{2})?',source)
    if not m:
        m=re.match(r'^\d{8}(\d{2})(\d{2})(?:\d{2})?$',source)
    if not m:
        m=re.match(r'^(\d{2}):(\d{2})(?::\d{2})?|\d{2}(\d{2})(\d{2})(?:\d{2})?)$',source)
        if m:
            vals=m.groups(); hh,mm=(vals[0],vals[1]) if vals[0] is not None else (vals[2],vals[3])
            return f'{int(hh):02d}:{int(mm):02d}' if int(hh)<24 and int(mm)<60 else ''
        return ''
    hh,mm=map(int,m.groups())
    return f'{hh:02d}:{mm:02d}' if hh<24 and mm<60 else ''

def evaluate(payload):
    if not isinstance(payload,dict): raise ValueError('검증 데이터 형식 오류')
    raw=payload.get('context',payload)
    if not isinstance(raw,dict):raise ValueError('검증 context 오류')
    ctx=copy.deepcopy(raw)
    chart=ctx.get('audit_chart')
    now=datetime.now(KST)
    target=_date_key(ctx.get('audit_trade_date')) or now.date().isoformat()
    if isinstance(chart,dict) and isinstance(chart.get('bars'),list):
        orig=chart['bars'];valid=[];unknown_dates=0;foreign_dates=0
        for bar in orig:
            if not isinstance(bar,dict):continue
            date=(_date_key(bar.get('date')) or _date_key(bar.get('trade_date'))
                  or _date_key(bar.get('dt')) or _date_key(bar.get('time'))
                  or _date_key(bar.get('cntr_tm')))
            if not date:unknown_dates+=1;continue
            if date!=target:foreign_dates+=1;continue
            normalized=copy.copy(bar)
            clock=_clock_from_bar(bar)
            if not clock:
                # A dated candle without a parseable minute time is not usable
                # for morning/afternoon trading-window analysis.
                unknown_dates+=1
                continue
            normalized['date']=date
            normalized['time']=clock
            valid.append(normalized)
        # Critical: no silent mixing of other days, no falling back to undated bars.
        chart['bars']=valid
        date_note=f'{target}: 당일 날짜 확인 {len(valid)}개, 다른 날 제외 {foreign_dates}개, 날짜 미상 제외 {unknown_dates}개'
    else:date_note='날짜가 확인된 분봉이 전달되지 않음'
    result=v2.evaluate({'context':ctx})
    result['engine']='newheart_jongba_v3'
    result['trade_date']=target
    result['date_filter']=date_note
    result['snapshot_kind']='실시간 증거' if now.date().isoformat()==target and now.weekday()<5 and (15<=now.hour<20) else '사후 검증'
    # v2 previously presents stale/current TOP5 as "확인" even when unrelated to trade time.
    for criterion in result['criteria']:
        if criterion['criterion']=='종배 TOP5 후보 여부' and result['snapshot_kind']=='사후 검증':
            criterion['state']='관찰'
            criterion['evidence']='사후 조회 TOP5: '+criterion['evidence']
    result['decision']='증거 수집 중 · 매수 판정 아님'
    result['notice']='검증 결과는 주문 신호가 아닙니다. 현재 증거는 선택한 거래일만 사용하며 주문·예약을 실행하지 않습니다.'
    return result

def _read():
    try:
        with FILE.open('r',encoding='utf-8') as f:data=json.load(f)
        return data if isinstance(data,list) else []
    except (OSError,ValueError):return []

def save(payload):
    # Explicit confirmation button only; no collection or saving without a user action.
    result=evaluate(payload)
    ctx=payload.get('context',payload)
    stock=result['stock'];now=datetime.now(KST)
    snap={'id':now.strftime('%Y%m%dT%H%M%S%f')+'_'+stock['code'], 'captured_at':now.isoformat(),
          'stock':stock,'trade_date':result['trade_date'],'snapshot_kind':result['snapshot_kind'],
          'criteria':result['criteria'],'date_filter':result['date_filter'],
          'source':'사용자 명시적 검증 요청 · 제공된 UI/키움 데이터',
          'is_historical':result['snapshot_kind']=='사후 검증'}
    FILE.parent.mkdir(parents=True,exist_ok=True)
    with LOCK:
        records=_read()
        records.append(snap);records=records[-500:]
        fd,tmp=tempfile.mkstemp(prefix='.newheart_v3_',suffix='.tmp',dir=str(FILE.parent))
        try:
            with os.fdopen(fd,'w',encoding='utf-8') as f:
                json.dump(records,f,ensure_ascii=False,separators=(',',':'));f.flush();os.fsync(f.fileno())
            os.replace(tmp,FILE)
        finally:
            if os.path.exists(tmp):os.unlink(tmp)
    return {'ok':True,'record':snap,'count':len(records),'audit':result}

def history(query=None):
    with LOCK:records=_read()
    code=str((query or {}).get('code') or '').strip()
    if code:records=[x for x in records if x.get('stock',{}).get('code')==code]
    return {'ok':True,'count':len(records),'rows':records[-100:][::-1],'note':'읽기 전용 검증 기록. 과거 데이터는 당시 기록처럼 재구성하지 않음.'}
