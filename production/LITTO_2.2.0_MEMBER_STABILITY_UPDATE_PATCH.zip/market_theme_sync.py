"""Read-only Kiwoom market-theme importer. No external scraper or hot-path calls."""
import re
from datetime import date

def _api_rows(client, api, body, key, pages=12, limit=2500):
    # Uses the existing Kiwoom client, shared API pacing and authentication.
    return client.rows(api, body, key, limit=limit, max_pages=pages)

def fetch_theme_map(client=None, progress=None, max_themes=600):
    if client is None: raise RuntimeError('키움 연결 후 시장테마를 갱신하세요.')
    groups=_api_rows(client,'ka90001',{'qry_tp':'0','stk_cd':'','date_tp':'10','thema_nm':'','flu_pl_amt_tp':'3','stex_tp':'1'},'thema_grp')
    catalog=[]; seen=set()
    for row in groups:
        if not isinstance(row,dict):continue
        group=str(row.get('thema_grp_cd') or '').strip()
        name=str(row.get('thema_nm') or row.get('thema_grp_nm') or '').strip()
        if group and name and group not in seen:
            catalog.append((group,name));seen.add(group)
    if not catalog: raise RuntimeError('키움 테마 목록이 비어 있거나 응답 형식이 다릅니다.')
    if len(catalog)>max_themes:
        # Never silently commit a partial theme catalogue as complete.
        raise RuntimeError(f'키움 테마 {len(catalog)}개: 안전 상한 {max_themes}개 초과, 데이터 보존')
    result={};valid=0;errors=0
    for i,(group,name) in enumerate(catalog,1):
        try:
            stocks=_api_rows(client,'ka90002',{'date_tp':'2','thema_grp_cd':group,'stex_tp':'1'},'thema_comp_stk',pages=5,limit=1000)
            codes=set()
            for stock in stocks:
                if not isinstance(stock,dict):continue
                raw=str(stock.get('stk_cd') or '').strip().upper()
                if re.fullmatch(r'A?\d{6}',raw):codes.add(raw[-6:])
            if codes:
                valid+=1
                for c in codes:result.setdefault(c,set()).add(name)
            else:errors+=1
        except Exception:
            errors+=1
        if progress and (i%10==0 or i==len(catalog)):
            progress(i,len(catalog),f'키움 시장테마 {i}/{len(catalog)} · 유효 {valid} · 종목 {len(result)}')
    if not result or valid<max(1,int(len(catalog)*0.8)):
        raise RuntimeError(f'키움 테마 구성종목 부족 ({valid}/{len(catalog)}) · 기존 섹터 유지')
    return {k:sorted(v) for k,v in result.items()}, {'themes':len(catalog),'valid_themes':valid,'stocks':len(result),'failed_list_pages':errors}

def merge_verified(existing, theme_map, max_length=100):
    """Replace only non-manual labels with Kiwoom market themes.

    Treat the upstream theme catalogue as authoritative for mapped stocks:
    never retain a stale broad industry label like '제조'.  Rows outside the
    catalogue remain untouched, and user-assigned rows are immutable.
    """
    out={k:dict(v) for k,v in existing.items()}
    changes=0
    for raw_code,names in theme_map.items():
        code=str(raw_code).strip().upper().removeprefix('A').zfill(6)
        if not re.fullmatch(r"\d{6}",code):
            continue
        old=out.get(code,{})
        source=str(old.get('source') or '').strip()
        if source.startswith('사용자 직접 지정'):
            continue
        parts=[]
        seen=set()
        for raw_name in names:
            for part in str(raw_name).split('/'):
                item=part.strip()
                if not item or item in seen:continue
                if len('/'.join(parts+[item]))>max_length:continue
                parts.append(item);seen.add(item)
        value='/'.join(parts)
        if not value:continue
        if old.get('sector')==value and source=='키움 시장테마 자동분류':
            continue
        out[code]={'sector':value,'source':'키움 시장테마 자동분류','asof':date.today().isoformat()}
        changes+=1
    return out,changes
