"""Run: python app.py. Python 3.10+, standard library only."""
from speed_runtime import SingleFlight
from http.server import BaseHTTPRequestHandler
from litto_bounded_http import LittoBoundedHTTPServer
from pathlib import Path
from urllib.parse import urlparse,parse_qs,quote_plus,urljoin,urlencode
import argparse,csv,io,json,os,secrets,threading,webbrowser,ctypes,base64,subprocess,time,re,copy,queue,random,sqlite3,calendar,hashlib,uuid
from datetime import datetime,timedelta
from html.parser import HTMLParser
import xml.etree.ElementTree as ET
from email.utils import parsedate_to_datetime
from urllib.request import Request,urlopen
from engine import scan_dataset,config,KST,code
import sectors
import sector_sync
import market_theme_sync
from yaksang import REVIEW_FIELDS
from importer import parse_file
from kiwoom import Kiwoom,ApiError,base_code,daily_bar,minute_bar
import kiwoom as _kiwoom_adapter
from demo import dataset
import search_panels
from domestic_realtime import DomesticRealtimeFeed
from orderbook_realtime import DomesticOrderbookFeed
import robot_reservations as robot_reservations
import robot_ai_commands
import market_calendar
import journal
import screener_history
import night_futures
import pattern_engine
import ai_brain
import ai_evolve
import litto_ai_developer
import litto_ai_live_patch
import litto_pdf_knowledge
import litto_ai_growth
import litto_persistent_history
import litto_market_extras
import litto_gemini
import litto_debate
import litto_newheart_jongba_v1
import litto_newheart_jongba_v2
import litto_newheart_jongba_v3
import litto_newheart_jongba_v4
import litto_newheart_jongba_v42

ROOT=Path(__file__).resolve().parent
# Approved AI source updates are applied BEFORE the server accepts connections.
# This never runs as a consequence of an AI response; a user must explicitly queue it.
try:
    _LITTO_STARTUP_PATCH_RESULT = litto_ai_developer.apply_scheduled_at_startup(ROOT)
except Exception as _litto_patch_error:
    print('[LITTO AI] 승인 예약 적용 보류:', str(_litto_patch_error), flush=True)
LITTO_VERSION='2.2.0'
journal.init(ROOT)
screener_history.init(ROOT)
ai_brain.init(ROOT)
litto_pdf_knowledge.init(ROOT)
litto_ai_growth.init(ROOT)
ai_evolve.init(ROOT)
LOCK=threading.RLock()
CSRF=secrets.token_urlsafe(32)
STATE={'version':LITTO_VERSION,'data':dataset(),'report':None,'settings':config(),'market':'unknown','client':None,
       'busy':False,'progress':'예시 데이터 준비됨','done':0,'total':0,'fetch_errors':[],
       'connected':False,'mock':False,'cancel':threading.Event(),
       'sector_busy':False,'sector_progress':'','sector_done':0,'sector_total':0,
       'realtime_rank':{'rows':[],'daily_rows':[],'updated_at':None,'source':'키움 ka00198 · 2초 확인','daily_source':'키움 ka00198 · 당일 누적','error':None},
       'realtime_rank_prev':{},
       'ranks':{'value_top':[],'change_top':[],'today_limit':[],'prev_limit':[],'source':'예시/미조회'},
       'scan_options':{'scope':'all','limit':100,'watchlist':'','formula_rank_limits':{'주도주 종배':30,'주도주 상따':30,'끼도주 종배':30},'today_limit_min_eok':1000}}
# R58.7: Bootstrap the public stock-universe cache on a clean installation.
# Existing user data is never overwritten; the cache is populated normally
# when the market data refresh runs.
_UNIVERSE_PATH = ROOT / 'data' / 'universe.json'
_UNIVERSE_PATH.parent.mkdir(parents=True, exist_ok=True)
if not _UNIVERSE_PATH.exists():
    try:
        with _UNIVERSE_PATH.open('x', encoding='utf-8') as _f:
            json.dump([], _f, ensure_ascii=False)
    except FileExistsError:  # concurrent startup created it
        pass
UNIVERSE = json.loads(_UNIVERSE_PATH.read_text(encoding='utf-8'))

LOOKUP={x['code']:x for x in UNIVERSE}
CANDIDATE_HISTORY=litto_persistent_history.file_path(ROOT,'candidate_history.json')
ORDERBOOK_LAST_FILE=ROOT/'data'/'orderbook_last.json'
ORDERBOOK_LAST_LOCK=threading.RLock()


# R45 experimental · Sign in with ChatGPT ---------------------------------------
# Personal/local open-source flow. No API key is required. The user signs in in
# the system browser and explicitly grants ChatGPT plan usage. Tokens are kept in
# the Python backend only and protected with Windows DPAPI when available.
SIWC_DIR=Path(os.getenv('LOCALAPPDATA') or (ROOT/'data'))/'LITTO'
SIWC_HOST_FILE=SIWC_DIR/'chatgpt_host.json'
SIWC_PROFILE_FILE=SIWC_DIR/'chatgpt_siwc.dat'
SIWC_AUTH_URL='https://auth.openai.com/api/accounts/authorize'
SIWC_TOKEN_URL='https://auth.openai.com/api/accounts/oauth/token'
SIWC_JWKS_URL='https://auth.openai.com/.well-known/jwks.json'
SIWC_DISCOVERY_URL='https://auth.openai.com/.well-known/openid-configuration'
SIWC_RESOURCE='https://api.openai.com/v1'
SIWC_RESPONSES_URL='https://api.openai.com/v1/responses'
SIWC_MODELS_URL='https://api.openai.com/v1/models'
SIWC_SCOPE='openid profile email offline_access resource.invoke chatgpt.tokens.use.direct'
SIWC_APP_NAME='LITTO'
SIWC_LOCK=threading.RLock()
SIWC_PENDING={}
SIWC_DISCOVERY_CACHE={'at':0.0,'data':{}}


def _merge_orderbook_initial_snapshot(live, static):
    """Use realtime ladder as authoritative; REST only fills missing reference fields.

    The slow/bootstrap REST path and the live event path must not paint
    different ladder generations during the first modal opening.
    """
    data=dict(live or {})
    if not isinstance(static,dict):
        return data
    live_has_ladder=any(float(x.get('price') or 0)>0 for side in ('asks','bids')
        for x in (data.get(side) or []) if isinstance(x,dict))
    for k in ('base_price','open','high','low','market_code'):
        if data.get(k) in (None,'') and static.get(k) not in (None,''):
            data[k]=static[k]
    if not live_has_ladder:
        for k in ('current_price','change_rate','ask_total','bid_total','orderbook_time','venue','source'):
            if data.get(k) in (None,'') and static.get(k) not in (None,''):
                data[k]=static[k]
        static_has_ladder=any(float(x.get('price') or 0)>0 for side in ('asks','bids')
            for x in (static.get(side) or []) if isinstance(x,dict))
        if static_has_ladder:
            data['asks']=static.get('asks',[])
            data['bids']=static.get('bids',[])
            data['fallback_snapshot']=True
    if static.get('static_error'):
        data['static_error']=static['static_error']
    return data

def _siwc_b64url(raw):
    return base64.urlsafe_b64encode(raw).decode('ascii').rstrip('=')


def _siwc_host_id():
    SIWC_DIR.mkdir(parents=True,exist_ok=True)
    try:
        if SIWC_HOST_FILE.exists():
            d=json.loads(SIWC_HOST_FILE.read_text(encoding='utf-8'))
            v=str((d or {}).get('ext_agent_host_id') or '').strip()
            if v.startswith('urn:uuid:'): return v
    except Exception: pass
    v='urn:uuid:'+str(uuid.uuid4())
    tmp=SIWC_HOST_FILE.with_suffix('.tmp')
    tmp.write_text(json.dumps({'ext_agent_host_id':v},ensure_ascii=False,indent=2),encoding='utf-8')
    tmp.replace(SIWC_HOST_FILE)
    try:
        if os.name!='nt': os.chmod(SIWC_HOST_FILE,0o600)
    except Exception: pass
    return v


def _siwc_profile_load():
    try:
        if not SIWC_PROFILE_FILE.exists(): return {}
        raw=SIWC_PROFILE_FILE.read_bytes()
        if os.name=='nt': raw=_dpapi_unprotect_bytes(raw)
        d=json.loads(raw.decode('utf-8'))
        return d if isinstance(d,dict) else {}
    except Exception:
        return {}


def _siwc_profile_save(profile):
    SIWC_DIR.mkdir(parents=True,exist_ok=True)
    raw=json.dumps(profile,ensure_ascii=False,indent=2).encode('utf-8')
    if os.name=='nt': raw=_dpapi_protect_bytes(raw)
    tmp=SIWC_PROFILE_FILE.with_suffix('.tmp')
    tmp.write_bytes(raw); tmp.replace(SIWC_PROFILE_FILE)
    try:
        if os.name!='nt': os.chmod(SIWC_PROFILE_FILE,0o600)
    except Exception: pass


def _siwc_profile_clear_tokens(keep_registration=True):
    p=_siwc_profile_load()
    if keep_registration and p.get('client_id'):
        keep={k:p.get(k) for k in ('client_id','email','name','subject','issuer','ext_agent_host_id') if p.get(k)}
        _siwc_profile_save(keep)
    else:
        try: SIWC_PROFILE_FILE.unlink(missing_ok=True)
        except Exception: pass


def _siwc_http_json(url,method='GET',body=None,headers=None,timeout=30):
    hdr=dict(headers or {})
    data=None
    if body is not None:
        if isinstance(body,dict):
            data=urlencode(body).encode('utf-8'); hdr.setdefault('Content-Type','application/x-www-form-urlencoded')
        else: data=body
    req=Request(url,data=data,headers=hdr,method=method)
    try:
        with urlopen(req,timeout=timeout) as r:
            raw=r.read().decode('utf-8','replace')
            return json.loads(raw) if raw.strip() else {}
    except Exception as e:
        detail=str(e)
        if hasattr(e,'read'):
            try:
                raw=e.read().decode('utf-8','replace'); j=json.loads(raw)
                detail=str((j.get('error') or {}).get('message') or j.get('detail') or detail)
            except Exception: pass
        raise ValueError(detail[:500])


def _siwc_discovery():
    now=time.time()
    if SIWC_DISCOVERY_CACHE['data'] and now-SIWC_DISCOVERY_CACHE['at']<3600:return SIWC_DISCOVERY_CACHE['data']
    try:d=_siwc_http_json(SIWC_DISCOVERY_URL,timeout=10)
    except Exception:d={}
    SIWC_DISCOVERY_CACHE.update({'at':now,'data':d or {}});return d or {}


def _siwc_import_jwt():
    try:
        import jwt
        return jwt
    except Exception:
        try:
            subprocess.run([os.sys.executable,'-m','pip','install','PyJWT[crypto]','-q'],check=True,timeout=120,capture_output=True)
            import jwt
            return jwt
        except Exception as e:
            raise ValueError('ChatGPT 로그인 검증 모듈 설치 실패: '+str(e))


def _siwc_verify_id_token(id_token,client_id,nonce):
    jwt=_siwc_import_jwt()
    try:
        header=jwt.get_unverified_header(id_token); alg=str(header.get('alg') or '')
        if alg not in ('RS256','ES256'): raise ValueError('지원하지 않는 ID 토큰 서명 방식')
        jwks=jwt.PyJWKClient(SIWC_JWKS_URL)
        key=jwks.get_signing_key_from_jwt(id_token).key
        claims=jwt.decode(id_token,key,algorithms=[alg],audience=client_id,issuer='https://auth.openai.com',options={'require':['sub','exp','iat']},leeway=5)
        if str(claims.get('nonce') or '')!=str(nonce or ''): raise ValueError('로그인 nonce 불일치')
        if not str(claims.get('sub') or ''): raise ValueError('ChatGPT 계정 식별자가 없습니다.')
        return claims
    except Exception as e:
        raise ValueError('ChatGPT 로그인 검증 실패: '+str(e))


def _siwc_token_exchange(form):
    return _siwc_http_json(SIWC_TOKEN_URL,'POST',form,timeout=30)


def siwc_start(port):
    with SIWC_LOCK:
        # Re-use a registered client when available. A fresh registration is used
        # only when this host has never connected an account before.
        profile=_siwc_profile_load(); saved_client=str(profile.get('client_id') or '').strip()
        client_id=saved_client or 'dynamic_agent_client'
        state=secrets.token_urlsafe(32); nonce=secrets.token_urlsafe(32); verifier=secrets.token_urlsafe(64)
        challenge=_siwc_b64url(hashlib.sha256(verifier.encode('ascii')).digest())
        redirect=f'http://127.0.0.1:{int(port)}/auth/callback'
        SIWC_PENDING.clear(); SIWC_PENDING.update({'state':state,'nonce':nonce,'verifier':verifier,'redirect_uri':redirect,'client_id':client_id,'started_at':time.time()})
        q={'client_id':client_id,'redirect_uri':redirect,'response_type':'code','scope':SIWC_SCOPE,
           'resource':SIWC_RESOURCE,'state':state,'nonce':nonce,'code_challenge_method':'S256','code_challenge':challenge,
           'ext_agent_host_id':_siwc_host_id()}
        if client_id=='dynamic_agent_client': q['agent_name_hint']=SIWC_APP_NAME
        else:
            if profile.get('id_token'): q['id_token_hint']=profile.get('id_token')
            if profile.get('email'): q['login_hint']=profile.get('email')
        url=SIWC_AUTH_URL+'?'+urlencode(q)
        threading.Thread(target=lambda:webbrowser.open(url,new=1,autoraise=True),daemon=True).start()
        return {'ok':True,'started':True}


def siwc_callback(query):
    with SIWC_LOCK:
        pending=dict(SIWC_PENDING)
        if not pending or time.time()-float(pending.get('started_at') or 0)>600: raise ValueError('로그인 요청이 만료되었습니다. 라이또에서 다시 로그인하세요.')
        state=str((query.get('state') or [''])[0]);
        if not state or state!=pending.get('state'): raise ValueError('로그인 state가 일치하지 않습니다.')
        err=str((query.get('error') or [''])[0])
        if err: raise ValueError('ChatGPT 로그인이 취소되었습니다: '+err)
        code=str((query.get('code') or [''])[0]); cb_client=str((query.get('client_id') or [''])[0])
        if not code: raise ValueError('로그인 승인 코드가 없습니다.')
        requested_client=str(pending.get('client_id') or '')
        if requested_client=='dynamic_agent_client':
            if not cb_client or cb_client=='dynamic_agent_client': raise ValueError('ChatGPT 앱 등록 client_id를 받지 못했습니다.')
            client_id=cb_client
        else:
            if cb_client and cb_client!=requested_client: raise ValueError('등록된 ChatGPT client_id가 일치하지 않습니다.')
            client_id=requested_client
        tok=_siwc_token_exchange({'grant_type':'authorization_code','client_id':client_id,'code':code,
                                  'code_verifier':pending['verifier'],'redirect_uri':pending['redirect_uri'],'resource':SIWC_RESOURCE})
        id_token=str(tok.get('id_token') or '');
        if not id_token: raise ValueError('ChatGPT ID 토큰을 받지 못했습니다.')
        claims=_siwc_verify_id_token(id_token,client_id,pending['nonce'])
        scopes=str(tok.get('scope') or '').split()
        profile={'email':claims.get('email') or '', 'name':claims.get('name') or claims.get('preferred_username') or '',
                 'issuer':claims.get('iss') or 'https://auth.openai.com','subject':claims.get('sub'),'client_id':client_id,
                 'ext_agent_host_id':_siwc_host_id(),'id_token':id_token,'access_token':tok.get('access_token') or '',
                 'refresh_token':tok.get('refresh_token') or '','token_type':tok.get('token_type') or 'Bearer',
                 'expires_in':int(tok.get('expires_in') or 3600),'scopes':scopes,'saved_at':time.time(),
                 'earliest_refresh_at':tok.get('earliest_refresh_at')}
        _siwc_profile_save(profile); SIWC_PENDING.clear()
        return profile


def _siwc_refresh(profile):
    if not profile.get('refresh_token') or not profile.get('client_id'): raise ValueError('ChatGPT 재로그인이 필요합니다.')
    tok=_siwc_token_exchange({'grant_type':'refresh_token','client_id':profile['client_id'],'refresh_token':profile['refresh_token'],'resource':SIWC_RESOURCE})
    scopes=str(tok.get('scope') or ' '.join(profile.get('scopes') or [])).split()
    profile.update({'access_token':tok.get('access_token') or '', 'refresh_token':tok.get('refresh_token') or profile.get('refresh_token') or '',
                    'id_token':tok.get('id_token') or profile.get('id_token') or '', 'expires_in':int(tok.get('expires_in') or 3600),
                    'scopes':scopes,'saved_at':time.time(),'earliest_refresh_at':tok.get('earliest_refresh_at')})
    _siwc_profile_save(profile);return profile


def _siwc_access_profile():
    with SIWC_LOCK:
        p=_siwc_profile_load()
        if not p.get('access_token'): raise ValueError('ChatGPT로 먼저 로그인하세요.')
        exp=float(p.get('saved_at') or 0)+float(p.get('expires_in') or 3600)
        if time.time()>exp-120:
            p=_siwc_refresh(p)
        if 'chatgpt.tokens.use.direct' not in set(p.get('scopes') or []): raise ValueError('ChatGPT 플랜 사용 권한이 꺼져 있습니다. 다시 로그인해 사용 권한을 허용하세요.')
        return p


def siwc_status(load_models=False):
    p=_siwc_profile_load(); connected=bool(p.get('access_token') and p.get('client_id'))
    sharing=connected and 'chatgpt.tokens.use.direct' in set(p.get('scopes') or [])
    out={'connected':connected,'sharing':sharing,'email':p.get('email') or '','name':p.get('name') or '',
         'client_id_hint':(('…'+str(p.get('client_id'))[-8:]) if p.get('client_id') else ''),'models':[],
         'brain':ai_brain.status(),'brain_mode_default':'max','live_web':'auto'}
    if load_models and sharing:
        try:out['models']=siwc_list_models()
        except Exception as e:out['model_error']=str(e)
    return out


def siwc_list_models():
    p=_siwc_access_profile(); d=_siwc_http_json(SIWC_MODELS_URL,headers={'Authorization':'Bearer '+p['access_token'],'User-Agent':'LITTO-R45/1.0'},timeout=20)
    rows=d.get('models') or d.get('data') or []
    out=[]
    for x in rows:
        if not isinstance(x,dict): continue
        if x.get('visibility') not in (None,'list'): continue
        slug=str(x.get('slug') or x.get('id') or '').strip()
        if slug: out.append({'slug':slug,'display_name':x.get('display_name') or slug})
    return out[:50]


def siwc_signout():
    with SIWC_LOCK:
        p=_siwc_profile_load(); refresh=str(p.get('refresh_token') or '')
        if refresh and p.get('client_id'):
            try:
                disc=_siwc_discovery(); revoke=disc.get('revocation_endpoint')
                if revoke:_siwc_http_json(revoke,'POST',{'token':refresh,'token_type_hint':'refresh_token','client_id':p['client_id']},timeout=15)
            except Exception: pass
        _siwc_profile_clear_tokens(keep_registration=True)
        return siwc_status()



# R53 · LITTO SMART BRAIN + MARKET INTELLIGENCE ----------------------------------------------------------
# Quality-first adaptive orchestration on top of Sign in with ChatGPT.
# - Auto-picks the strongest model exposed by the connected ChatGPT plan.
# - Adaptive reasoning: fast for simple UI commands, max/pro for hard analysis.
# - Persistent local memory + episodic recall.
# - Tool-grounded answers and a second verification pass for complex analysis.
# - No self-modifying code. Broker order submission/cancellation remains manual.

def _ai_compact(value, limit=24000):
    try:
        raw=json.dumps(value,ensure_ascii=False,default=str)
    except Exception:
        raw=str(value)
    if len(raw)<=limit:return value
    return {'truncated':True,'preview':raw[:limit]+'…'}


def _ai_mask_account_no(v):
    t=str(v or '').strip()
    if len(t)<=4:return t
    return ('*'*(len(t)-4))+t[-4:]


def _ai_model_score(slug,display=''):
    s=(str(slug)+' '+str(display)).lower()
    # Do not auto-pick specialist/non-chat models.
    bad=('audio','image','realtime','embedding','moderation','transcribe','tts','codex-mini','search-preview')
    if any(x in s for x in bad):return -100000
    m=re.search(r'gpt[- ]?(\d+)(?:[.](\d+))?',s)
    ver=(int(m.group(1))*100+(int(m.group(2) or 0) if m else 0)) if m else 0
    tier=0
    if 'astra' in s:tier=50000
    elif re.search(r'(^|[- ])pro($|[- ])',s):tier=47000
    elif 'sol' in s:tier=40000
    elif 'luna' in s:tier=30000
    elif 'gpt' in s:tier=20000
    return tier+ver


def _ai_pick_model(requested='', msg=''):
    rows=siwc_list_models()
    req=str(requested or '').strip()
    if req and req.lower() not in ('auto','best','strongest'):
        if any(str(x.get('slug'))==req for x in rows):return req,rows
        # Let an explicitly selected model through if the list endpoint is stale.
        return req,rows
    if not rows:return 'gpt-6.1-sol',rows
    # R55: AUTO is deliberately pinned to GPT-6.1 Sol for trading work.
    # Astra is available only when the user explicitly selects it in the UI.
    for x in rows:
        slug=str(x.get('slug') or '')
        name=str(x.get('display_name') or '')
        if slug=='gpt-6.1-sol' or '6.1 Sol' in name or '6.1-sol' in name.lower():
            return slug or 'gpt-6.1-sol',rows
    # If Sol is temporarily absent, prefer the strongest non-Astra model first.
    non_astra=[x for x in rows if 'astra' not in (str(x.get('slug') or '')+' '+str(x.get('display_name') or '')).lower()]
    ranked=sorted(non_astra or rows,key=lambda x:_ai_model_score(x.get('slug'),x.get('display_name')),reverse=True)
    return str(ranked[0].get('slug') or 'gpt-6.1-sol'),rows


def _ai_is_simple_control(msg):
    t=str(msg or '').strip().lower()
    if len(t)>120:return False
    analysis_words=('분석','비교','왜','판단','추천','확률','전략','리스크','위험','복기','매수해','매도해','좋아','어때','전망','가능성','이유')
    if any(w in t for w in analysis_words):return False
    control_words=('열어','닫아','켜','꺼','보여','이동','전환','추가','삭제','새로고침','실행','바꿔','설정','호가창','차트')
    return any(w in t for w in control_words)


def _ai_is_complex_question(msg):
    t=str(msg or '').strip().lower()
    if not t:return False
    if len(t)>=180:return True
    complex_words=(
      '종합분석','상세분석','깊게','정밀','비교해','전략','시나리오','확률','리스크','위험','복기',
      '왜 올랐','왜 내렸','급등','급락','재료','공시','뉴스','미국장','한국장 영향','시장 영향',
      '다음 거래일','전망','가능성','매수 판단','매도 판단','종베','포트폴리오','계좌 분석','수급 분석',
      '교차검증','검증해','분석해줘','판단해줘','어떻게 될','어떻게 보여'
    )
    return any(w in t for w in complex_words)

def _ai_needs_verification(msg,intent_plan=None):
    if _ai_is_simple_control(msg):return False
    if _ai_is_complex_question(msg):return True
    intent=str((intent_plan or {}).get('intent') or '')
    return intent in ('us_close_korea_impact','us_market','stock_catalyst','disclosure')

def _ai_reasoning_profiles(model,msg,quality='auto'):
    simple=_ai_is_simple_control(msg)
    complex_q=_ai_is_complex_question(msg)
    q=str(quality or 'auto').lower()
    if q in ('fast','quick') or simple:
        return [ {'effort':'low'} , {'effort':'medium'} ]
    if q=='max':
        return [ {'effort':'max','mode':'pro'}, {'effort':'max'}, {'effort':'xhigh'}, {'effort':'high'}, {'effort':'medium'} ]
    # AUTO: ordinary questions stay responsive; complex work gets deeper reasoning.
    return ([{'effort':'xhigh'},{'effort':'high'},{'effort':'medium'}] if complex_q else [{'effort':'medium'},{'effort':'low'}])


def _ai_web_intent(msg):
    """Return whether a request materially benefits from live external information."""
    t=str(msg or '').strip().lower()
    if not t:return False
    keys=(
      '최신','오늘','지금','뉴스','기사','속보','공시','dart','다트','거래소','krx','회사 ir','ir ',
      '외부','웹','인터넷','검색해','찾아봐','왜 올랐','왜 내렸','급등','급락','재료','이슈','호재','악재',
      '실적발표','실적 발표','수주','계약','자사주','유상증자','무상증자','감자','합병','인수','정책','금리','환율',
      '미국장','나스닥','s&p','엔비디아','연준','fed','관세','정부 발표','보도자료',
      # R56 GENERAL BRAIN: non-stock live information should work like a normal assistant.
      '날씨','기온','강수','비 와','비와','눈 와','눈와','우산','미세먼지','대기질','태풍','예보',
      '현재 시간','지금 몇시','몇 시','오늘 날짜','무슨 요일','환전','환율','스포츠 결과','경기 결과','일정','영업시간'
    )
    return any(k in t for k in keys)


def _ai_intent_plan(msg):
    """Deterministic routing for high-value stock questions.

    The model can still reason freely, but it no longer decides whether basic
    evidence should be collected.  This fixes the common failure mode where a
    strong model gives a cautious generic answer without first fetching the
    market facts the user explicitly asked to verify.
    """
    t=str(msg or '').strip().lower()
    plan={'intent':'general','force_web':False,'prefetch_market':False,'must_chart':False,'must_stock_full':False,'must_disclosure':False,'checklist':[]}
    if not t:return plan
    if _ai_is_simple_control(msg):
        plan.update(intent='ui_control')
        plan['checklist']=['요청한 화면/차트/기능 제어']
        return plan
    # R56 GENERAL BRAIN: route ordinary live-information questions before stock-specific routing.
    weather_terms=('날씨','기온','강수','비 와','비와','눈 와','눈와','우산','미세먼지','대기질','태풍','예보')
    general_live_terms=('현재 시간','지금 몇시','몇 시','오늘 날짜','무슨 요일','환율','환전','스포츠 결과','경기 결과','영업시간','최신 정보','최신뉴스','최신 뉴스')
    if any(x in t for x in weather_terms):
        plan.update(intent='weather',force_web=True)
        plan['checklist']=['질문 속 지역/날짜 확인','현재 상태 또는 요청한 날짜 예보','기온·강수 등 핵심 수치','최신 출처 확인']
        return plan
    if any(x in t for x in general_live_terms):
        plan.update(intent='general_live',force_web=True)
        plan['checklist']=['사용자가 요구한 최신 사실','기준 시각/날짜','신뢰 가능한 최신 출처']
        return plan
    us_terms=('미장','미국장','미국 시장','미국증시','나스닥','다우','s&p','sp500','s&p500','sox','필라델피아 반도체')
    korea_impact=('한국장','국내장','코스피 영향','코스닥 영향','한국 시장 영향','국내 증시 영향')
    catalyst_terms=('왜 올랐','왜올랐','왜 내렸','왜내렸','급등 이유','급락 이유','재료','호재','악재','이슈')
    disclosure_terms=('공시','dart','다트','kind','거래소 공시','실적발표','실적 발표','수주','계약','유상증자','무상증자','감자','합병','자사주')
    chart_terms=('차트','캔들','봉','눌림','돌파','지지','저항','윗꼬리','아랫꼬리','거래량','이평','이동평균','추세','매물대')
    stock_judge=('이 종목','종목 어때','매수해','매도해','진입','종배','상따','전망','가능성','판단','분석해')
    if any(x in t for x in us_terms) and (any(x in t for x in korea_impact) or '영향' in t):
        plan.update(intent='us_close_korea_impact',force_web=True,prefetch_market=True)
        plan['checklist']=['미국 주요지수(Dow/S&P500/Nasdaq)','SOX·NVDA·MU','미국 10년물','달러인덱스·원달러','WTI','핵심 당일 뉴스','한국 업종/관심종목 영향']
    elif any(x in t for x in us_terms):
        plan.update(intent='us_market',force_web=True,prefetch_market=True)
        plan['checklist']=['미국 주요지수','SOX·NVDA·MU','미국 10년물','달러·WTI','핵심 뉴스']
    elif any(x in t for x in catalyst_terms):
        plan.update(intent='stock_catalyst',force_web=True,must_stock_full=True)
        plan['checklist']=['현재 차트/거래량','공시·회사IR','최신 뉴스','재료 발생 시각','가격반응 일치 여부']
    elif any(x in t for x in disclosure_terms):
        plan.update(intent='disclosure',force_web=True,must_disclosure=True)
        plan['checklist']=['DART/KIND 원문','회사 IR/보도자료','발표 시각','핵심 숫자/조건']
    elif any(x in t for x in chart_terms):
        plan.update(intent='chart_analysis',must_chart=True)
        plan['checklist']=['현재 표시 캔들','거래량','이평선','지지/저항','무효화 조건']
    elif any(x in t for x in stock_judge):
        plan.update(intent='stock_judgment',must_stock_full=True)
        plan['checklist']=['차트','F존/B-S','종베5/라이또봇','수급/거래대금','필요 시 뉴스·공시']
    return plan


def _ai_market_intelligence_snapshot(force=True):
    """Read-only US/global market packet independent of the AI web tool.

    Primary: Yahoo chart endpoint already used by LITTO.  Kiwoom's US-market
    snapshot is attached as a second source when available.  Missing fields stay
    explicit so the model can retry with web_search instead of inventing values.
    """
    symbols={
      'dow':'^DJI','sp500':'^GSPC','nasdaq':'^IXIC','sox':'^SOX',
      'nvda':'NVDA','micron':'MU','us10y':'^TNX','dxy':'DX-Y.NYB',
      'wti':'CL=F','usdkrw':'KRW=X'
    }
    quotes={}
    for key,sym in symbols.items():
        try: quotes[key]=_header_yahoo_quote(sym,force=bool(force))
        except Exception as e: quotes[key]={'symbol':sym,'price':None,'change_rate':None,'error':str(e)[:240]}
    try: kiwoom=us_market_snapshot(force=bool(force))
    except Exception as e: kiwoom={'error':str(e)[:300]}
    verified=sum(1 for x in quotes.values() if x.get('price') is not None and x.get('change_rate') is not None)
    return {
      'updated_at':datetime.now(KST).isoformat(),'quotes':quotes,'kiwoom_us_market':_ai_compact(kiwoom,16000),
      'coverage':{'verified_quotes':verified,'total_quotes':len(symbols)},
      'rule':'수치는 source/market_time이 있는 항목만 확정값으로 사용. 누락·stale이면 web_search로 재검증.',
      'sources':['Yahoo Finance chart','Kiwoom US market REST (when connected)']
    }


def _ai_external_tool(quality='max'):
    # ChatGPT-plan SIWC supports Responses web_search subject to the signed-in
    # account/workspace policy. Keep it live and bounded for desktop latency.
    return {
      'type':'web_search',
      'search_context_size':'high' if str(quality).lower()=='max' else 'medium',
      'external_web_access':True,
    }


def _ai_dev_requested(message):
    """Expose developer tools only on an explicit present-turn request.

    Distinguish diagnosis/read requests from mutation prohibitions.  This is a
    conservative tool-visibility gate, NOT authorization to apply code.
    """
    import re
    t = str(message or '').strip().lower()
    if not t:
        return False
    target = any(x in t for x in (
        '라이또', 'litto', 'app.py', '프로그램', '소스', '코드', '개발 도구',
        '검색기', '분봉', 'f존', '관심종목', '등락률', '퍼센트', 'top5',
        '주문 엔진', '차트 오류', 'ai 기능', 'ai 수정'))
    if not target:
        return False
    # An explicitly requested read/diagnosis is valid even with "do not edit".
    read = bool(re.search(
        r'(?:코드|소스|app\.py|프로그램|도구).{0,12}(?:읽|보여|확인|조회|분석|진단)'
        r'|(?:읽|확인|조회|진단).{0,12}(?:코드|소스|app\.py|개발 도구)'
        r'|(?:오류|버그|문제).{0,8}(?:찾아|진단|분석|원인|확인)', t))
    # Ignore explicit negations when looking for a request to modify.
    cleaned = re.sub(
        r'(?:수정|고치|고쳐|패치|디버그|개발|변경|적용)\s*(?:은|는|을|를|도)?\s*'
        r'(?:하(?:지|지는|지도)|해\s*주지|하지|하지는|하지도)?\s*'
        r'(?:마|말아|말고|않아|않을|금지)'
        r'|(?:수정|변경|적용|패치)\s*(?:금지|하지\s*마|하면\s*안)'
        r"|(?:don't|do not|never)\s+(?:fix|modify|patch|edit|apply)",
        ' ', t)
    # Removal of negated segments is not enough: prohibit patch generation when
    # the user is explicitly asking to avoid it, unless another clear action remains.
    modify = bool(re.search(
        r'(?:수정|고쳐|고치|패치|디버그|버그\s*잡|오류\s*잡|오류\s*해결|'
        r'고장\s*고쳐|문제\s*고쳐|fix\s+bug|debug\s+code|'
        r'개선\s*해|기능\s*추가|만들어\s*줘)', cleaned))
    return bool(read or modify)


def _ai_dev_tools():
    obj=lambda props,req:{'type':'object','properties':props,'required':req,'additionalProperties':False}
    return [
      {'type':'function','name':'litto_dev_read_source',
       'description':'Read bounded lines of allowlisted LITTO source for a user-requested diagnosis. Never access secret/account files.',
       'parameters':obj({'filename':{'type':'string'},'needle':{'type':'string'},'line':{'type':'integer'}},['filename','needle','line']),'strict':True},
      {'type':'function','name':'litto_dev_propose_patch',
       'description':'Stage ONE exact-string source replacement in an isolated proposal, run syntax check, return diff and ID. Never apply it; leave original untouched. No live trading tests.',
       'parameters':obj({'filename':{'type':'string'},'find':{'type':'string'},'replace':{'type':'string'},'reason':{'type':'string'}},['filename','find','replace','reason']),'strict':True},
      {'type':'function','name':'litto_dev_read_proposal',
       'description':'View a previously staged patch by proposal ID. Does not apply it.',
       'parameters':obj({'id':{'type':'string'}},['id']),'strict':True},
    ]


# LITTO read-only diagnostics and optional image connector (no trading side effects).
def _litto_three_diagnostics(kind, stock_code=''):
    now=datetime.now(KST)
    if kind=='prior':
        today=now.date().isoformat()
        snaps=_prior_candidate_snapshots(today,2)
        return {'kind':'prior','today':today,'source':str(CANDIDATE_HISTORY),'exists':CANDIDATE_HISTORY.exists(),
                'snapshots':[{'date':x.get('date'),'stage':x.get('stage'),'recorded':x.get('recorded'),
                              'saved_at':x.get('saved_at'),'count':len(x.get('stocks') or {})} for x in snaps],
                'note':'전일 후보는 실제 이전 거래일 저장 기록만 사용합니다. PC 미실행/검색 실패일은 자동 보충하지 않습니다.'}
    if kind!='minute':raise ValueError('지원 진단: minute 또는 prior')
    c=base_code(stock_code)
    if not c:raise ValueError('3분봉 진단에는 종목코드가 필요합니다.')
    with LOCK:client=STATE.get('client');connected=bool(STATE.get('connected'))
    cache=_chart_history_load(c,'3',360)
    result={'kind':'minute','code':c,'connected':connected,'cache_count':len(cache),
            'api_id':'ka10080','tic_scope':'3','provider':'KRX' if getattr(client,'mock',False) else 'SOR(_AL)',
            'live_checked':False,'warning':'현재 연결에서는 조회하지 않았음'}
    if not client:return result
    try:
        provider=c if getattr(client,'mock',False) else c+'_AL'
        # Exactly one provider request; do not trigger 3,000-bar F-zone fetching.
        t=time.monotonic()
        rows=_kiwoom_call(client.rows,'ka10080',{'stk_cd':provider,'tic_scope':'3','upd_stkpc_tp':'1'},
                          'stk_min_pole_chart_qry',360,1,kind='chart')
        result.update(live_checked=True,raw_rows=len(rows or []),elapsed_ms=round((time.monotonic()-t)*1000),warning=None)
        if not rows:result['warning']='키움 요청 성공했지만 3분봉 응답이 비어 있습니다. 종목코드/거래시장/시간대를 점검하세요.'
    except Exception as e:
        result.update(live_checked=True,error=str(e)[:400],warning='키움 ka10080 3분봉 요청 실패')
    return result

def _litto_image_status():
    # SIWC login tokens are NEVER used for image API calls.
    return {'available':bool(os.getenv('LITTO_IMAGE_API_KEY')),
            'provider':'OpenAI image generation (optional separate API key)',
            'requirements':'LITTO_IMAGE_API_KEY 환경변수와 별도 이미지 API 권한이 필요합니다. ChatGPT 로그인만으로는 보장되지 않습니다.',
            'storage':'data/ai_generated_images','login_unchanged':True}

def _litto_generate_image(prompt):
    key=os.getenv('LITTO_IMAGE_API_KEY','').strip()
    if not key:raise ValueError('이미지 연결 안 됨: LITTO_IMAGE_API_KEY가 필요합니다. ChatGPT 계정 로그인과 별개의 권한입니다.')
    prompt=str(prompt or '').strip()
    if not 2<=len(prompt)<=2000:raise ValueError('이미지 설명은 2~2000자로 입력하세요.')
    # Explicit tool request only; no silent invocation. No credentials in logs.
    payload=json.dumps({'model':'gpt-image-1','prompt':prompt,'size':'1024x1024','n':1}).encode('utf-8')
    request=Request('https://api.openai.com/v1/images/generations',data=payload,
                    headers={'Authorization':'Bearer '+key,'Content-Type':'application/json'},method='POST')
    try:
        with urlopen(request,timeout=115) as response:data=json.loads(response.read(22_000_000))
        encoded=(data.get('data') or [{}])[0].get('b64_json')
        if not encoded:raise ValueError('이미지 API가 PNG 데이터를 반환하지 않았습니다.')
        blob=base64.b64decode(encoded,validate=True)
        if not blob.startswith(b'\x89PNG\r\n\x1a\n'):raise ValueError('이미지 API 결과가 PNG가 아닙니다.')
        directory=ROOT/'data'/'ai_generated_images';directory.mkdir(parents=True,exist_ok=True)
        name='LITTO_AI_'+datetime.now(KST).strftime('%Y%m%d_%H%M%S')+'_'+secrets.token_hex(4)+'.png'
        (directory/name).write_bytes(blob)
        return {'ok':True,'file':str(directory/name),'url':'/api/ai-generated-image?name='+name,
                'bytes':len(blob),'note':'라이또 로컬 PC에 PNG 저장 완료. 주문/차트 관련 코드 변경 없음.'}
    except Exception as e:
        # Never return secret-bearing HTTP headers or request body.
        raise ValueError('이미지 생성 요청 실패: '+str(e)[:220])

def _ai_tool_definitions():
    obj=lambda props,req=[]:{'type':'object','properties':props,'required':req,'additionalProperties':False}
    return [
      {'type':'function','name':'litto_diagnose_litto','description':'Diagnose a 3-minute candle API failure using one live ka10080 call, or explain missing prior-day candidates from local saved history. Read only.','parameters':obj({'kind':{'type':'string','enum':['minute','prior']},'code':{'type':'string'}},['kind','code']),'strict':True},
      {'type':'function','name':'litto_image_status','description':'Check whether the optional image generation API is configured. Never claim ChatGPT login automatically grants image creation.','parameters':obj({}),'strict':True},
      {'type':'function','name':'litto_generate_image','description':'Generate and save a PNG image only when user explicitly requests an image. Requires separately configured LITTO_IMAGE_API_KEY; do not claim it works otherwise.','parameters':obj({'prompt':{'type':'string'}},['prompt']),'strict':True},
      {'type':'function','name':'litto_pdf_list','description':'List all registered searchable PDF documents, including filenames, page counts, text extraction status. Use for any question about which PDFs are available or comparing all registered PDFs. No market API use.','parameters':obj({}),'strict':True},
      {'type':'function','name':'litto_pdf_search','description':'Search actual locally indexed PDF text across all documents or one named document; returns exact document names, page numbers, and bounded original text excerpts. Use for PDF-based principles, precise page citations, and cross-document comparison. Search each claim before citing. No market API use.','parameters':obj({'query':{'type':'string'},'document':{'type':'string'},'limit':{'type':'integer','minimum':1,'maximum':24}},['query','document','limit']),'strict':True},
      {'type':'function','name':'litto_analysis_save','description':'Explicitly save an evidence-labeled stock analysis as pending verification in local SQLite. Does not submit orders or change rules. Returns durable record ID. Use only when user asks to save an analysis.','parameters':obj({'symbol':{'type':'string'},'thesis':{'type':'string'},'evidence':{'type':'string'},'invalidation':{'type':'string'}},['symbol','thesis','evidence','invalidation']),'strict':True},
      {'type':'function','name':'litto_analysis_list','description':'Retrieve persisted past stock analyses and their pending/reviewed status from local SQLite. Read-only.','parameters':obj({'query':{'type':'string'},'limit':{'type':'integer','minimum':1,'maximum':12}},['query','limit']),'strict':True},
      {'type':'function','name':'litto_analysis_review','description':'Mark a previously saved pending analysis as reviewed or invalidated ONLY with explicitly verified outcome evidence supplied by the user or confirmed through tools. Never auto-claim win rate.','parameters':obj({'id':{'type':'integer','minimum':1},'status':{'type':'string','enum':['reviewed','invalidated']},'result_note':{'type':'string'}},['id','status','result_note']),'strict':True},
      {'type':'function','name':'litto_get_ai_capabilities','description':'Truthfully report actual local AI tools, whether developer code tools are enabled in the current user request, and what has not been verified. Use before saying a tool does not exist. Read only.','parameters':obj({}), 'strict':True},
      {'type':'function','name':'litto_get_overview','description':'Read current LITTO UI/backend context: chart stock, TOP5, LITTO BOT, F-zone, B/S, market state and active screen.','parameters':obj({}), 'strict':True},
      {'type':'function','name':'litto_get_market_intelligence','description':'Read a deterministic US/global market packet for market-impact questions: Dow, S&P500, Nasdaq, SOX, NVDA, MU, US 10Y, DXY, WTI, USDKRW plus Kiwoom US-market data. Use before answering US-market or Korea-impact questions; retry missing facts with web_search.','parameters':obj({'force':{'type':'boolean'}},['force']), 'strict':True},
      {'type':'function','name':'litto_get_chart','description':'Read and analyze the actual LITTO chart. Prefer the exact currently visible candles from the UI when available; otherwise read LITTO/Kiwoom chart data. Returns OHLCV plus technical structure so you can judge trend, pullback, breakout, wicks, volume, support/resistance and invalidation levels instead of merely opening the chart.','parameters':obj({'code':{'type':'string'},'timeframe':{'type':'string','enum':['','current','daily','m1','m3','m15']},'limit':{'type':'integer','minimum':20,'maximum':400},'refresh':{'type':'boolean'}},['code','timeframe','limit','refresh']), 'strict':True},
      {'type':'function','name':'litto_get_stock_full','description':'Read the fullest currently available LITTO state for one stock: loaded stock snapshot, chart analysis, F-zone/B-S context and local metadata. Use when the user asks for a complete judgment of a stock.','parameters':obj({'code':{'type':'string'},'timeframe':{'type':'string','enum':['','current','daily','m1','m3','m15']}},['code','timeframe']), 'strict':True},
      {'type':'function','name':'litto_get_scanner','description':'Read scanner/search-panel results already loaded in LITTO.','parameters':obj({'panel':{'type':'string'},'limit':{'type':'integer','minimum':1,'maximum':100}},['panel','limit']), 'strict':True},
      {'type':'function','name':'litto_search_stock','description':'Search LITTO/Kiwoom stock lookup by Korean name or stock code.','parameters':obj({'query':{'type':'string'},'limit':{'type':'integer','minimum':1,'maximum':20}},['query','limit']), 'strict':True},
      {'type':'function','name':'litto_get_account','description':'Read current account summary and holdings. Read-only; account number is masked.','parameters':obj({'force':{'type':'boolean'}},['force']), 'strict':True},
      {'type':'function','name':'litto_get_daily_pnl','description':'Read one month of day-by-day realized P/L from LITTO account data.','parameters':obj({'year':{'type':'integer','minimum':2020,'maximum':2100},'month':{'type':'integer','minimum':1,'maximum':12}},['year','month']), 'strict':True},
      {'type':'function','name':'litto_get_bs','description':'Read cached LITTO B/S trade markers for a stock without forcing heavy historical network refresh.','parameters':obj({'code':{'type':'string'}},['code']), 'strict':True},
      {'type':'function','name':'litto_get_journal','description':'Read recent LITTO trading-journal entries for review.','parameters':obj({'limit':{'type':'integer','minimum':1,'maximum':200}},['limit']), 'strict':True},
      {'type':'function','name':'litto_get_performance','description':'Read accumulated performance for LITTO BOT or closing TOP5.','parameters':obj({'engine':{'type':'string','enum':['littobot','top5']}},['engine']), 'strict':True},
      {'type':'function','name':'litto_get_top5_factor_review','description':'Read only: compare historical NEXT-DAY observed performance by TOP5 selection reason, tag, and grade. For user requests to explain successful/failed closing-bet picks. No market API, no trading actions. Distinguish correlation from causation and missing data.','parameters':obj({'min_sample':{'type':'integer','minimum':3,'maximum':100}},['min_sample']), 'strict':True},
      {'type':'function','name':'litto_memory','description':'Use LITTO local long-term memory. Save only explicit durable user preferences/rules/corrections; search or list when prior context matters. Never save secrets, credentials, account numbers, transient prices, or inferred sensitive traits.','parameters':obj({
          'action':{'type':'string','enum':['search','save','delete','list','status']},'query':{'type':'string'},'key':{'type':'string'},'value':{'type':'string'},
          'kind':{'type':'string','enum':['','preference','rule','correction','workflow','note']},'limit':{'type':'integer','minimum':1,'maximum':30}
        },['action','query','key','value','kind','limit']), 'strict':True},
      {'type':'function','name':'litto_get_ai_experience','description':'Search recent past LITTO AI interactions for similar questions/decisions. Use this to stay consistent and learn from prior corrections; do not treat past answers as market truth.','parameters':obj({'query':{'type':'string'},'limit':{'type':'integer','minimum':1,'maximum':20}},['query','limit']), 'strict':True},
      {'type':'function','name':'litto_control_ui','description':'Control LITTO screens/UI, analytics, refreshes, watchlist and prepare an order ticket. Final broker submission/cancellation is intentionally not exposed.','parameters':obj({
          'action':{'type':'string','enum':['open_chart','close_chart','set_timeframe','toggle_fzone','toggle_bs','toggle_markers','chart_split4','open_account','open_daily_pnl','open_trade_scanner','open_watchlist','activate_panel','run_scan','watch_add','watch_remove','switch_page','switch_trade_subtab','open_stock_action','open_investor_flow','open_news','open_orderbook','close_orderbook','open_checklist','open_memo','open_history','refresh_account','refresh_watchlist','refresh_market_core','prepare_order']},
          'code':{'type':'string'},'name':{'type':'string'},'timeframe':{'type':'string','enum':['','daily','m1','m3','m15']},
          'enabled':{'type':['boolean','null']},'year':{'type':['integer','null']},'month':{'type':['integer','null']},'panel':{'type':'string'},
          'page':{'type':'string','enum':['','trade','alerts','market','us','journal','core']},'subtab':{'type':'string','enum':['','scanner','watch']},
          'side':{'type':'string','enum':['','buy','sell']},'order_type':{'type':'string','enum':['','limit','market']},
          'price':{'type':['number','null']},'qty':{'type':['integer','null']},'amount':{'type':['number','null']}
        },['action','code','name','timeframe','enabled','year','month','panel','page','subtab','side','order_type','price','qty','amount']), 'strict':True},
    ]


def _ai_tool_scanner(args,session_ctx=None):
    panel_name=str((args or {}).get('panel') or '').strip(); limit=max(1,min(100,int((args or {}).get('limit') or 30)))
    # The TOP5 is computed in the browser. The server scanner report has no
    # authoritative copy of these five ranked rows. Use the same UI snapshot
    # already attached to the AI chat request instead of returning a false zero.
    canonical='종배 TOP5'
    aliases={'종배 TOP5','종배TOP5','종배5','top5','TOP5','closing top5','closing_top5','오늘 TOP5','오늘 종배5'}
    if panel_name in aliases or panel_name.lower() in ('top5','closing top5','closing_top5'):
        ctx=session_ctx if isinstance(session_ctx,dict) else {}
        ui_rows=ctx.get('top5')
        if isinstance(ui_rows,list):
            return {'panel':canonical,'source':'live_browser_ai_context','count':len(ui_rows),'rows':ui_rows[:limit],'asof':ctx.get('asof'),'complete':len(ui_rows)<=limit}
        return {'panel':canonical,'source':'ui_context_unavailable','count':None,'rows':[], 'available':False,'reason':'브라우저 TOP5 화면 상태가 AI 요청에 포함되지 않았습니다. 0개로 판단할 수 없습니다.'}

    with LOCK:
        report=copy.deepcopy(STATE.get('report') or {})
    panels=((report.get('search_panels') or {}).get('panels') or {})
    if panel_name:
        hit=panels.get(panel_name) or {}; rows=(hit.get('rows') or [])[:limit]
        return _ai_compact({'panel':panel_name,'rows':rows,'count':len(hit.get('rows') or [])},18000)
    summary=[]
    for name,panel in panels.items():
        rows=panel.get('rows') or []; summary.append({'panel':name,'count':len(rows),'top':rows[:min(5,limit)]})
    return _ai_compact({'panels':summary[:40]},20000)



def _ai_num(v):
    try:
        n=float(v)
        return n if n==n and abs(n)!=float('inf') else None
    except Exception:return None


def _ai_chart_features(bars,timeframe='daily'):
    rows=[]
    for b in (bars or []):
        if not isinstance(b,dict):continue
        o,h,l,c=(_ai_num(b.get(k)) for k in ('open','high','low','close'))
        if None in (o,h,l,c) or min(o,h,l,c)<=0:continue
        rows.append({'date':b.get('date'),'time':b.get('time'),'open':o,'high':h,'low':l,'close':c,'volume':_ai_num(b.get('volume')),'value':_ai_num(b.get('value')),'complete':b.get('complete',True)})
    if not rows:return {'count':0,'timeframe':timeframe,'bars':[]}
    def avg(vals):
        vals=[x for x in vals if x is not None]
        return sum(vals)/len(vals) if vals else None
    def sma(n):return avg([x['close'] for x in rows[-n:]]) if len(rows)>=n else None
    last=rows[-1]; prev=rows[-2] if len(rows)>1 else None
    closes=[x['close'] for x in rows]
    vols=[x['volume'] for x in rows if x['volume'] is not None]
    def pct(a,b):return ((a/b)-1)*100 if a is not None and b not in (None,0) else None
    hi20=max(x['high'] for x in rows[-20:]); lo20=min(x['low'] for x in rows[-20:])
    hi60=max(x['high'] for x in rows[-60:]) if len(rows)>=60 else max(x['high'] for x in rows)
    lo60=min(x['low'] for x in rows[-60:]) if len(rows)>=60 else min(x['low'] for x in rows)
    prior20=max((x['high'] for x in rows[-21:-1]),default=None)
    prior20lo=min((x['low'] for x in rows[-21:-1]),default=None)
    ma5,ma20,ma60=sma(5),sma(20),sma(60)
    ranges=[]
    trs=[]
    for i,x in enumerate(rows[-20:]):
        if x['low']>0:ranges.append((x['high']/x['low']-1)*100)
    for i in range(max(1,len(rows)-14),len(rows)):
        x=rows[i];pc=rows[i-1]['close']
        trs.append(max(x['high']-x['low'],abs(x['high']-pc),abs(x['low']-pc)))
    atr14=avg(trs)
    rng=max(last['high']-last['low'],1e-9);body=last['close']-last['open']
    upper=last['high']-max(last['open'],last['close']);lower=min(last['open'],last['close'])-last['low']
    vavg20=avg([x['volume'] for x in rows[-20:] if x['volume'] is not None])
    vratio=(last['volume']/vavg20) if last['volume'] is not None and vavg20 not in (None,0) else None
    up=down=0
    for i in range(len(rows)-1,0,-1):
        d=rows[i]['close']-rows[i-1]['close']
        if d>0 and down==0:up+=1
        elif d<0 and up==0:down+=1
        else:break
    trend='혼조'
    if None not in (ma5,ma20,ma60):
        if last['close']>ma5>ma20>ma60:trend='정배열 상승'
        elif last['close']<ma5<ma20<ma60:trend='역배열 하락'
        elif last['close']>ma20:trend='중기선 위'
        elif last['close']<ma20:trend='중기선 아래'
    elif ma20 is not None:trend='중기선 위' if last['close']>ma20 else '중기선 아래'
    pos20=((last['close']-lo20)/(hi20-lo20)*100) if hi20>lo20 else None
    feature={
      'count':len(rows),'timeframe':timeframe,'last_stamp':last.get('date') or last.get('time'),'last_close':last['close'],
      'change_1bar_pct':pct(last['close'],prev['close'] if prev else None),'change_3bar_pct':pct(last['close'],rows[-4]['close'] if len(rows)>=4 else None),
      'change_5bar_pct':pct(last['close'],rows[-6]['close'] if len(rows)>=6 else None),'change_20bar_pct':pct(last['close'],rows[-21]['close'] if len(rows)>=21 else None),
      'ma5':ma5,'ma20':ma20,'ma60':ma60,'trend':trend,'high20':hi20,'low20':lo20,'high60':hi60,'low60':lo60,'position_20bar_pct':pos20,
      'distance_ma20_pct':pct(last['close'],ma20),'distance_ma60_pct':pct(last['close'],ma60),'drawdown_from_20high_pct':pct(last['close'],hi20),
      'breakout_above_prior20':bool(prior20 is not None and last['close']>prior20),'breakdown_below_prior20low':bool(prior20lo is not None and last['close']<prior20lo),
      'volume_ratio_20':vratio,'avg_range_20_pct':avg(ranges),'atr14':atr14,'atr14_pct':(atr14/last['close']*100) if atr14 and last['close'] else None,
      'last_candle':{'open':last['open'],'high':last['high'],'low':last['low'],'close':last['close'],'body_pct_of_range':body/rng*100,'upper_wick_pct_of_range':upper/rng*100,'lower_wick_pct_of_range':lower/rng*100},
      'consecutive_up_bars':up,'consecutive_down_bars':down,
      'candidate_support':[x for x in (lo20,lo60,ma20,ma60) if x is not None],
      'candidate_resistance':[x for x in (prior20,hi20,hi60) if x is not None],
      'bars':rows,
    }
    return feature


def _ai_chart_snapshot(args,session_ctx):
    args=args if isinstance(args,dict) else {}
    cur=(session_ctx or {}).get('current_stock') or {}
    c=base_code(str(args.get('code') or cur.get('code') or ''))
    if not c:raise ValueError('차트를 읽을 종목코드가 필요합니다.')
    req_tf=str(args.get('timeframe') or 'current').lower()
    cur_tf=str((session_ctx or {}).get('chart_timeframe') or 'daily')
    tf=cur_tf if req_tf in ('','current') else req_tf
    if tf not in ('daily','m1','m3','m15'):tf='daily'
    limit=max(20,min(400,int(args.get('limit') or 180)))
    ui=(session_ctx or {}).get('chart_snapshot') or {}
    bars=[];source='';visible=False
    if base_code(str(ui.get('code') or ''))==c and str(ui.get('timeframe') or '')==tf and isinstance(ui.get('bars'),list) and ui.get('bars'):
        bars=list(ui.get('bars') or [])[-limit:];source='현재 라이또 화면에 실제 표시된 캔들';visible=True
    if not bars:
        with LOCK:
            client=STATE.get('client'); loaded=copy.deepcopy((STATE.get('data') or {}).get('stocks') or [])
        stock=next((x for x in loaded if base_code(x.get('code',''))==c),None) or {}
        if tf=='daily':
            bars=list(stock.get('daily') or [])
            if (bool(args.get('refresh')) or len(bars)<min(80,limit)) and client:
                try:
                    raw=_kiwoom_call(client.daily_history_rows,c,max(180,limit),kind='chart')
                    fresh=[daily_bar(r) for r in raw if isinstance(r,dict)]
                    fresh=[x for x in fresh if x and x.get('date')];fresh.sort(key=lambda x:x.get('date',''))
                    if fresh:bars=fresh
                except Exception:pass
            source='라이또/키움 일봉 데이터'
        else:
            key={'m1':'m1','m3':'m3','m15':'m15'}[tf]
            bars=list(stock.get(key) or [])
            if not bars:
                mins={'m1':'1','m3':'3','m15':'15'}[tf]
                bars=_chart_history_load(c,mins,limit)
            if (bool(args.get('refresh')) or len(bars)<min(80,limit)) and client:
                try:
                    mins={'m1':'1','m3':'3','m15':'15'}[tf]
                    provider=c if bool(getattr(client,'mock',False)) else c+'_AL'
                    raw=_kiwoom_call(client.rows,'ka10080',{'stk_cd':provider,'tic_scope':mins,'upd_stkpc_tp':'1'},'stk_min_pole_chart_qry',max(360,limit),4,kind='chart')
                    now=datetime.now(KST);fresh=[]
                    for r in raw:
                        x=minute_bar(r,now,int(mins))
                        if x:fresh.append(x)
                    if fresh:bars=sorted(fresh,key=lambda x:x.get('time',''))
                except Exception:pass
            source='라이또/키움 분봉 데이터'
        bars=bars[-limit:]
    out=_ai_chart_features(bars,tf)
    # Freshness is evidence metadata, not a reason to trigger implicit broker traffic.
    # The existing 'refresh' parameter is the only opt-in for a network read.
    latest=(bars[-1] if bars else {}) or {}
    bar_clock=latest.get('time') or latest.get('date') or ''
    now_kst=datetime.now(KST)
    age_minutes=None
    if tf in ('m1','m3','m15') and bar_clock:
        try:
            raw_clock=str(bar_clock).strip()
            import re as _re
            digits=''.join(_re.findall(r'\d',raw_clock))
            if len(digits)>=12:
                bar_dt=datetime.strptime(digits[:12],'%Y%m%d%H%M').replace(tzinfo=KST)
                age_minutes=round((now_kst-bar_dt).total_seconds()/60,1)
        except Exception:pass
    fresh_label='unknown'
    if age_minutes is not None:
        fresh_label='future_or_clock_mismatch' if age_minutes < -5 else ('stale' if age_minutes > max(12,{'m1':3,'m3':9,'m15':35}[tf]) and 8<=now_kst.hour<20 else 'recent_or_session_closed')
    out['freshness']={'latest_bar_time':str(bar_clock),'age_minutes':age_minutes,'status':fresh_label,'retrieval':'user_requested_refresh' if bool(args.get('refresh')) else 'cache_or_screen','checked_at':now_kst.isoformat(),'note':'Cache age must be checked against source market/session; stale bars are NOT a live quote. Refresh only if necessary.'}
    out.update({'code':c,'name':str(ui.get('name') or cur.get('name') or (LOOKUP.get(c) or {}).get('name') or c),'source':source,'exact_visible_chart':visible,'requested_limit':limit})
    if visible:
        for k in ('visible_start','visible_end','zoom_bars','pan_offset','levels','fib','thirds','crosshair','fzone','bs'):
            if k in ui:out[k]=ui[k]
    return _ai_compact(out,42000)


def _ai_stock_full(args,session_ctx):
    c=base_code(str((args or {}).get('code') or ((session_ctx or {}).get('current_stock') or {}).get('code') or ''))
    if not c:raise ValueError('종목코드가 필요합니다.')
    with LOCK:
        loaded=copy.deepcopy((STATE.get('data') or {}).get('stocks') or [])
    stock=next((x for x in loaded if base_code(x.get('code',''))==c),None) or {}
    meta=LOOKUP.get(c) or {}
    chart=_ai_chart_snapshot({'code':c,'timeframe':(args or {}).get('timeframe') or 'current','limit':220,'refresh':False},session_ctx)
    bs=chart_bs_snapshot(c,'',mode='cache')
    return _ai_compact({'code':c,'meta':meta,'loaded_stock':stock,'chart':chart,'bs':bs,'ui_fzone':(session_ctx or {}).get('fzone'),'ui_littobot':(session_ctx or {}).get('littobot'),'ui_top5':(session_ctx or {}).get('top5')},50000)

def _ai_tool_dispatch(name,args,session_ctx,ui_actions):
    args=args if isinstance(args,dict) else {}
    if name=='litto_diagnose_litto':return _litto_three_diagnostics(args.get('kind',''),args.get('code',''))
    if name=='litto_image_status':return _litto_image_status()
    if name=='litto_generate_image':return _litto_generate_image(args.get('prompt',''))
    if name=='litto_pdf_list':return litto_pdf_knowledge.ai_documents()
    if name=='litto_pdf_search':return litto_pdf_knowledge.ai_search(args.get('query',''),args.get('document',''),args.get('limit',12))
    if name=='litto_analysis_save':return litto_ai_growth.add_reflection(args.get('symbol'),args.get('thesis'),args.get('evidence'),args.get('invalidation'))
    if name=='litto_analysis_list':return {'ok':True,'items':litto_ai_growth.recent(args.get('query',''),args.get('limit',5))}
    if name=='litto_analysis_review':return litto_ai_growth.review_reflection(args.get('id'),args.get('result_note'),args.get('status'))
    if name=='litto_get_ai_capabilities':
        return {'available_core_tools':[t.get('name') for t in _ai_tool_definitions() if t.get('type')=='function'],
                'developer_tools_names':[t.get('name') for t in _ai_dev_tools()],
                'developer_tools_visibility':'only when current user message qualifies as explicit local source read/diagnosis/patch request',
                'code_apply':'never AI-callable; explicit local UI approval only',
                'hot_apply':'only _ai_dev_requested in app.py if strict AST checks pass',
                'other_changes':'restart required','windows_live_test':'not verified by this tool'}
    if name=='litto_dev_read_source':
        return litto_ai_developer.inspect(ROOT,args.get('filename',''),args.get('needle',''),args.get('line',1))
    if name=='litto_dev_propose_patch':
        return litto_ai_developer.propose(ROOT,args.get('filename',''),args.get('find',''),args.get('replace',''),args.get('reason',''))
    if name=='litto_dev_read_proposal':
        return litto_ai_developer.pending(ROOT,args.get('id',''))
    if name=='litto_get_overview':
        ctx=session_ctx if isinstance(session_ctx,dict) else {}
        # Compact, schema-stable overview; avoid copying massive backend report
        # and accidentally truncating the TOP5 and other high-value signals.
        with LOCK:
            state_summary={'connected':bool(STATE.get('connected')),'busy':bool(STATE.get('busy')),'market':STATE.get('market')}
            report=STATE.get('report') or {}
            panels=((report.get('search_panels') or {}).get('panels') or {})
            backend_counts={k:len(v.get('rows') or []) for k,v in panels.items() if isinstance(v,dict)}
        top5=ctx.get('top5')
        return {'asof':ctx.get('asof'),'ui':{k:ctx.get(k) for k in ('active_panel','page','trade_subtab','current_stock','chart_timeframe','fzone','bs','littobot','watchlist')},'top5':{'source':'live_browser_ai_context' if isinstance(top5,list) else 'unavailable','count':len(top5) if isinstance(top5,list) else None,'rows':top5 if isinstance(top5,list) else [],'asof':ctx.get('asof')},'scanner_panel_counts':ctx.get('scanner_panel_counts') or backend_counts,'backend':state_summary}

    if name=='litto_get_chart':return _ai_chart_snapshot(args,session_ctx)
    if name=='litto_get_stock_full':return _ai_stock_full(args,session_ctx)
    if name=='litto_get_market_intelligence':return _ai_market_intelligence_snapshot(force=bool(args.get('force',True)))
    if name=='litto_get_scanner':return _ai_tool_scanner(args,session_ctx)
    if name=='litto_search_stock':
        result=stock_search_snapshot(str(args.get('query') or ''),max(1,min(20,int(args.get('limit') or 10))))
        # The watchlist lives in the active browser. The backend stock-name master
        # cannot determine membership. Use the exact request's browser snapshot.
        ctx=session_ctx if isinstance(session_ctx,dict) else {}
        watch=ctx.get('watchlist')
        if isinstance(watch,list):
            watch_codes={code(x.get('code')) for x in watch if isinstance(x,dict) and x.get('code')}
            for row in result.get('rows',[]):row['watched']=code(row.get('code')) in watch_codes
            result['watchlist_source']='live_browser_ai_context'
            result['watchlist_complete']=bool(ctx.get('watchlist_complete',False))
        else:
            for row in result.get('rows',[]):row['watched']=None
            result['watchlist_source']='unavailable'
            result['watchlist_complete']=False
        return _ai_compact(result,16000)
    if name=='litto_get_account':
        d=copy.deepcopy(account_status_snapshot(force=bool(args.get('force'))))
        if isinstance(d,dict):d['account_no']=_ai_mask_account_no(d.get('account_no'))
        return _ai_compact(d,26000)
    if name=='litto_get_daily_pnl':return _ai_compact(account_daily_pnl_snapshot(int(args.get('year')),int(args.get('month')),force=False),22000)
    if name=='litto_get_bs':return _ai_compact(chart_bs_snapshot(code(str(args.get('code') or '')),'',mode='cache'),24000)
    if name=='litto_get_journal':return _ai_compact(journal.snapshot(ROOT,limit=max(1,min(200,int(args.get('limit') or 30)))),24000)
    if name=='litto_get_performance':return _ai_compact(littobot_performance_snapshot() if args.get('engine')=='littobot' else top5_performance_snapshot(),24000)
    if name=='litto_get_top5_factor_review':
        from litto_top5_factor_review import analyze_top5
        return _ai_compact(analyze_top5(_top5_perf_load(), int(args.get('min_sample') or 10)), 24000)
    if name=='litto_memory':
        action=str(args.get('action') or 'search')
        if action=='status':return ai_brain.status()
        if action=='list':return {'memories':ai_brain.memories(max(1,min(30,int(args.get('limit') or 10))))}
        if action=='search':return {'memories':ai_brain.recall(str(args.get('query') or ''),max(1,min(30,int(args.get('limit') or 8))))}
        if action=='save':return ai_brain.remember(str(args.get('key') or ''),str(args.get('value') or ''),str(args.get('kind') or 'preference'),1.0)
        if action=='delete':return ai_brain.forget(str(args.get('key') or ''),str(args.get('kind') or ''))
    if name=='litto_get_ai_experience':return {'episodes':ai_brain.search_episodes(str(args.get('query') or ''),max(1,min(20,int(args.get('limit') or 6))))}
    if name=='litto_control_ui':
        action=str(args.get('action') or '')
        allowed={'open_chart','close_chart','set_timeframe','toggle_fzone','toggle_bs','toggle_markers','chart_split4','open_account','open_daily_pnl','open_trade_scanner','open_watchlist','activate_panel','run_scan','watch_add','watch_remove','switch_page','switch_trade_subtab','open_stock_action','open_investor_flow','open_news','open_orderbook','close_orderbook','open_checklist','open_memo','open_history','refresh_account','refresh_watchlist','refresh_market_core','prepare_order'}
        if action not in allowed:raise ValueError('허용되지 않은 LITTO UI 제어입니다.')
        clean={'action':action}
        for k in ('code','name','timeframe','panel','page','subtab','side','order_type'):
            if args.get(k) not in (None,''):clean[k]=str(args.get(k))[:120]
        if isinstance(args.get('enabled'),bool):clean['enabled']=args['enabled']
        if args.get('year') is not None:clean['year']=int(args['year'])
        if args.get('month') is not None:clean['month']=int(args['month'])
        for k in ('price','amount'):
            if args.get(k) is not None:clean[k]=float(args[k])
        if args.get('qty') is not None:clean['qty']=int(args['qty'])
        ui_actions.append(clean)
        return {'ok':True,'queued':clean,'note':'라이또 화면/조회/분석/주문표 준비까지 제어함. 실제 증권사 주문 전송·취소는 사용자 최종 확인을 유지함.'}
    raise ValueError('알 수 없는 LITTO 도구: '+str(name))


def _siwc_stream_turn(access_token,body):
    req=Request(SIWC_RESPONSES_URL,data=json.dumps(body,ensure_ascii=False).encode('utf-8'),headers={'Authorization':'Bearer '+access_token,'Content-Type':'application/json','User-Agent':'LITTO-R56/1.0'},method='POST')
    text=[];completed=False;failed='';output_items=[];tool_calls=[];sources=[];web_used=False
    try:
        with urlopen(req,timeout=120) as resp:
            for raw in resp:
                line=raw.decode('utf-8','replace').strip()
                if not line.startswith('data:'):continue
                payload=line[5:].strip()
                if not payload or payload=='[DONE]':continue
                try:ev=json.loads(payload)
                except Exception:continue
                typ=str(ev.get('type') or '')
                if typ=='response.output_text.delta':text.append(str(ev.get('delta') or ''))
                elif typ=='response.output_item.done':
                    item=ev.get('item') or {}
                    if isinstance(item,dict):
                        output_items.append(item)
                        itype=str(item.get('type') or '')
                        if itype=='function_call':tool_calls.append(item)
                        elif itype=='web_search_call':
                            web_used=True
                            action=item.get('action') or {}
                            for src in (action.get('sources') or []):
                                if not isinstance(src,dict):continue
                                url=str(src.get('url') or '').strip(); title=str(src.get('title') or src.get('name') or url).strip()
                                if url.startswith(('http://','https://')) and not any(x.get('url')==url for x in sources):sources.append({'url':url,'title':title[:220]})
                        elif itype=='message':
                            for part in (item.get('content') or []):
                                if not isinstance(part,dict):continue
                                for ann in (part.get('annotations') or []):
                                    if not isinstance(ann,dict) or ann.get('type')!='url_citation':continue
                                    url=str(ann.get('url') or '').strip(); title=str(ann.get('title') or url).strip()
                                    if url.startswith(('http://','https://')) and not any(x.get('url')==url for x in sources):sources.append({'url':url,'title':title[:220]})
                elif typ=='response.failed':
                    er=((ev.get('response') or {}).get('error') or {});failed=str(er.get('message') or er.get('code') or '응답 실패')
                elif typ=='response.completed':completed=True
                elif typ=='response.incomplete':failed='응답이 완료되지 않았습니다.'
    except Exception as e:
        detail=str(e)
        if hasattr(e,'read'):
            try:
                raw=e.read().decode('utf-8','replace');j=json.loads(raw);er=j.get('error') or {};detail=str(er.get('message') or er.get('code') or j.get('detail') or detail)
            except Exception:pass
        raise ValueError('ChatGPT 플랜 호출 실패: '+detail[:700])
    if failed:raise ValueError(failed)
    if not completed:raise ValueError('ChatGPT 응답이 완료되기 전에 연결이 종료되었습니다.')
    return {'text':''.join(text).strip(),'output_items':output_items,'tool_calls':tool_calls,'sources':sources[:20],'web_used':bool(web_used)}


def _litto_ai_context(payload):
    ctx=payload.get('context') if isinstance(payload,dict) else {}
    if not isinstance(ctx,dict):ctx={}
    allowed={}
    for k in ('current_stock','chart_timeframe','littobot','top5','fzone','bs','market','active_panel','page','trade_subtab','watchlist','scanner_panel_counts','watchlist_complete','asof'):
        if k in ctx:allowed[k]=ctx[k]
    raw=json.dumps(allowed,ensure_ascii=False,default=str)
    if len(raw)>36000:raw=raw[:36000]+'…'
    return raw


def _ai_call_with_reasoning(access_token,base_body,profiles):
    last=None
    for r in profiles:
        body=dict(base_body);body['reasoning']=dict(r)
        try:return _siwc_stream_turn(access_token,body),r
        except Exception as e:
            last=e
            msg=str(e).lower()
            # Only downgrade capability/parameter mismatches. Do not hide auth/quota/network errors.
            capability=any(x in msg for x in ('reasoning','effort','mode','unsupported','invalid parameter','invalid_request','not supported'))
            if not capability:raise
    if last:raise last
    return _siwc_stream_turn(access_token,base_body),{}


def _ai_review_answer(access_token,model,msg,draft,evidence,memory,quality):
    if _ai_is_simple_control(msg):return draft,False
    # Second pass is a verifier/editor, not a second independent market guess.
    review_in=(
      '[사용자 요청]\n'+str(msg)[:6000]+'\n\n[1차 답변]\n'+str(draft)[:14000]+
      '\n\n[도구 근거 요약]\n'+str(evidence)[:26000]+
      '\n\n[관련 장기기억]\n'+json.dumps(memory,ensure_ascii=False,default=str)[:8000]
    )
    body={'model':model,'instructions':(
        '너는 LITTO AI의 최종 검증 편집자다. 내부 사고과정은 출력하지 말고 최종 답변만 반환해라. '
        '도구 근거에 없는 현재 시세/수치/사실을 새로 만들지 말고, 1차 답변의 모순·과장·누락된 리스크를 고쳐라. '
        '사용자 요청을 실제로 수행한 UI 제어는 수행했다고 명확히 말하고, 수행하지 않은 것은 했다고 하지 마라. '
        '투자 판단은 확률적 판단으로 표현하고 수익을 보장하지 마라. 한국어 반말로 간결하지만 필요한 근거는 남겨라.'),
        'input':[{'role':'user','content':review_in}], 'store':False,'stream':True}
    profiles=[{'effort':'max','mode':'pro'},{'effort':'xhigh'},{'effort':'high'},{'effort':'medium'}] if str(quality).lower()!='fast' else [{'effort':'medium'}]
    try:
        turn,_=_ai_call_with_reasoning(access_token,body,profiles)
        out=str(turn.get('text') or '').strip()
        return (out or draft),bool(out)
    except Exception:
        return draft,False


AI_PROGRESS_LOCK=threading.RLock()
AI_PROGRESS={}

def _ai_progress_set(req_id,stage,detail='',done=False,error=''):
    rid=str(req_id or '').strip()[:120]
    if not rid:return
    now=time.time()
    with AI_PROGRESS_LOCK:
        prev=AI_PROGRESS.get(rid) or {'started_at':now}
        AI_PROGRESS[rid]={
            'request_id':rid,'stage':str(stage or ''),'detail':str(detail or ''),
            'started_at':float(prev.get('started_at') or now),'updated_at':now,
            'done':bool(done),'error':str(error or '')[:500]
        }
        # keep memory bounded
        if len(AI_PROGRESS)>80:
            old=sorted(AI_PROGRESS.items(),key=lambda kv:kv[1].get('updated_at',0))[:-60]
            for k,_ in old:AI_PROGRESS.pop(k,None)

def _ai_progress_get(req_id):
    rid=str(req_id or '').strip()[:120]
    with AI_PROGRESS_LOCK:
        d=dict(AI_PROGRESS.get(rid) or {})
    if not d:return {'ok':True,'request_id':rid,'stage':'대기중','detail':'요청 상태를 준비 중이야.','done':False,'elapsed':0}
    d['ok']=True; d['elapsed']=max(0,int(time.time()-float(d.get('started_at') or time.time())))
    return d

def openai_litto_chat(payload):
    req_id=str((payload or {}).get('request_id') or uuid.uuid4().hex)[:120]
    _ai_progress_set(req_id,'연결 확인중','ChatGPT 플랜 연결 상태를 확인하고 있어.')
    msg=str((payload or {}).get('message') or '').strip()
    # Normalize common polite order phrases before both the robot router and parser.
    robot_msg=re.sub(r'추가로\s*(?:사줘|사|매수해|매수|사달라)', '추매', msg)
    robot_msg=re.sub(r'추가\s*매수', '추매', robot_msg)
    robot_msg=re.sub(r'팔아(?:주세요|달라)', '팔아줘', robot_msg)
    robot_msg=re.sub(r'사(?:주세요|달라)', '사줘', robot_msg)
    if (payload or {}).get('_debate_readonly'):robot_msg=''  # Debate cannot route to robot orders.
    # Strict AI-to-robot intake: an explicit imperative is the authorization.
    # No second modal; unclear orders fail closed without touching Kiwoom.
    if re.search(r'(예약|매수|매도|사줘|팔아줘|주문|추매|익절)',robot_msg) and re.search(r'(매수|매도|사줘|팔아줘|추매|익절)',robot_msg):
        try:
            # Use the already-loaded name master, not just the scanner's narrow universe.
            with STOCK_NAME_LOCK:
                robot_names=[{'code':k,'name':v} for k,v in STOCK_NAME_CACHE.items()]
            parsed=robot_ai_commands.parse(robot_msg,(payload or {}).get('context') or {},robot_names+list(UNIVERSE),holding_lookup=lambda stock: _auto_sell_account_guard(stock,force=True)['safe_available'])
            if parsed:
                kind,params=parsed
                if kind=='cost_trigger':
                    guard=_auto_sell_account_guard(params['code'],force=True)
                    holding=guard.get('holding') or {}
                    avg=float(holding.get('avg_price') or 0)
                    if avg<=0 or int(guard.get('qty') or 0)<=0:
                        raise ValueError('키움 계좌의 해당 종목 보유 평단이 확인되지 않아 등록하지 않았어.')
                    params['baseline_avg']=avg
                if kind=='timed_batch':
                    q=_robot_broker_quote(params['orders'][0]['code'])
                    px=q['ask'] if params['orders'][0]['side']=='buy' else q['bid']
                    if px<=0:raise ValueError('유효한 현재 호가가 없어 예약하지 않았어.')
                    limit=(px*103//100 if params['orders'][0]['side']=='buy' else max(1,px*97//100))
                    for leg in params['orders']:
                        leg['price_limit']=limit
                if kind=='once' and not params.get('price_limit'):
                    # Require a live quote; fixed bounded envelope avoids an unrestricted order.
                    q=_robot_broker_quote(params['code'])
                    px=q['ask'] if params['side']=='buy' else q['bid']
                    if px<=0:raise ValueError('유효한 현재 호가가 없어 예약하지 않았어.')
                    params['price_limit']=(px*103//100 if params['side']=='buy' else max(1,px*97//100))
                    params['price_limit_auto']=True
                params['source_request_id']=req_id
                params['source_command_text']=msg
                result=(robot_reservations.create_price_trigger(params) if kind=='price_trigger' else robot_reservations.create_cost_trigger(params) if kind=='cost_trigger' else robot_reservations.create_timed_batch(params) if kind=='timed_batch'
                    else robot_reservations.create_split(params) if kind=='split' else robot_reservations.create_order(params))
                if kind=='price_trigger':
                    item=result['item']
                    _ai_progress_set(req_id,'완료','가격 조건부 예약 등록 완료',done=True)
                    return {'ok':True,'text':f"목표가격 조건부 {'매수' if item['side']=='buy' else '매도'} 예약 {'기존 예약 확인' if result.get('already_exists') else '등록 완료'}: {item['name']}({item['code']}) · {item['target_price']:,}원 {'이하' if item['side']=='buy' else '이상'} · {item['value']:,}주 · 상태 {item['status']}. 실제 주문/체결 여부는 키움 주문내역에서 확인해.",'model':'LITTO-ROBOT','actions':[],'robot_order':item}
                if kind=='cost_trigger':
                    item=result['item']
                    _ai_progress_set(req_id,'완료','평단 조건부 예약 등록 완료',done=True)
                    t=item['trigger_pct']; val=f"{item['value']:,}"+({'shares':'주','amount':'원','holding_percent':'% 보유수량'}[item['unit']])
                    return {'ok':True,'text':f"평단 조건부 {'익절' if item['side']=='sell' else '추매'} 1회 예약 완료: {item['name']} · 기준 평단 {item['baseline_avg']:,.2f}원 · {t:+g}% · {val}. 실제 주문 접수/체결 여부는 키움 주문내역에서 확인해.",'model':'LITTO-ROBOT','actions':[],'robot_order':item}
                if kind=='timed_batch':
                    items=result['items']
                    _ai_progress_set(req_id,'완료','시간별 로봇 예약 등록 완료',done=True)
                    text=' / '.join(f"{x['when']} {x['value']:,}{'원' if x['unit']=='amount' else '주'}" for x in items)
                    return {'ok':True,'text':f"시간별 로봇 {'매수' if items[0]['side']=='buy' else '매도'} 예약 {len(items)}건 등록 완료: {items[0]['name']}({items[0]['code']}), {text}. 주문 시각에 계좌 조건을 재확인해.",'model':'LITTO-ROBOT','actions':[],'robot_orders':items}
                item=result['item'];_ai_progress_set(req_id,'완료','로봇 주문 자동 등록 완료',done=True)
                if kind=='split':
                    desc=' / '.join(f"{s['price']:,}원 {s['percent']}% ({s['shares']}주)" for s in item['steps'])
                    answer=f"로봇 {'매수' if item['side']=='buy' else '매도'} 분할 예약 자동 등록 완료: {item['name']}({item['code']}), {desc}. 취소는 로봇매수매도 탭에서 할 수 있어."
                else:
                    answer=f"로봇 {'매수' if item['side']=='buy' else '매도'} 예약 자동 등록 완료: {item['name']}({item['code']}), {item['when']}, {item['value']:,}{'원' if item['unit']=='amount' else '주'}, 허용가격 {item['price_limit']:,}원. 취소는 로봇매수매도 탭에서 할 수 있어."
                return {'ok':True,'text':answer,'model':'LITTO-ROBOT','actions':[],'robot_order':item}
        except ValueError as exc:
            _ai_progress_set(req_id,'완료','주문 조건 미충족: 등록하지 않음',done=True)
            return {'ok':True,'text':'주문 미등록: '+str(exc),'model':'LITTO-ROBOT','actions':[]}

    # An explicit order must never fall through to a free-form AI response.
    if re.search(r'(매수|매도|사줘|팔아줘|추매|익절)', robot_msg):
        _ai_progress_set(req_id,'완료','로봇매매 명령 인식 실패: 등록하지 않음',done=True)
        return {'ok':True,'text':'로봇 주문 미등록: 주문 조건을 정확히 인식하지 못했어. 종목명, 평단 대비 상승/하락 퍼센트, 주문 주수 또는 금액을 명확히 입력해 줘. 예약 목록을 확인해 줘.','model':'LITTO-ROBOT','actions':[]}
    if not msg:raise ValueError('질문을 입력하세요.')
    if len(msg)>8000:raise ValueError('질문은 8,000자 이하로 입력하세요.')
    p=_siwc_access_profile()
    intent_plan=_ai_intent_plan(msg)
    quality=str((payload or {}).get('quality') or 'auto').strip().lower()
    if quality not in ('auto','max','fast'):quality='auto'
    _ai_progress_set(req_id,'대화 준비중','최근 대화와 라이또 컨텍스트를 정리하고 있어.')
    history=(payload or {}).get('history') or [];clean=[]
    if isinstance(history,list):
        for x in history[-24:]:
            if not isinstance(x,dict):continue
            role=str(x.get('role') or '');content=str(x.get('content') or '').strip()
            if role in ('user','assistant') and content:clean.append({'role':role,'content':content[:7000]})
    ctx_obj=(payload or {}).get('context') or {};context=_litto_ai_context(payload)
    _ai_progress_set(req_id,'라이또 데이터 확인중','현재 종목·차트·F존·B/S·종베5·계좌 등 필요한 내부 데이터를 준비하고 있어.')
    model,model_rows=_ai_pick_model((payload or {}).get('model'),msg)
    memory=ai_brain.recall(msg,8)
    similar=ai_brain.search_episodes(msg,4)
    # AI-only: bounded local reflections; never starts provider or market-data work.
    try: reflections=litto_ai_growth.recent(msg,4)
    except Exception: reflections=[]
    instructions=(
      '너는 LITTO의 상주 AI 두뇌이면서 범용 개인 비서다. 주식 질문만 처리하는 봇이 아니다. 일반 상식·생활·기술·문서·여행·날씨·시간·환율 등도 자연스럽게 답해라. 라이또의 데이터·도구·화면이 필요한 질문에서는 이를 적극 사용해서 추측보다 실제 프로그램 상태를 우선해라. '
      '종목/계좌/성과/검색기 정보가 필요하면 관련 도구로 확인하고, 사용자의 명시적 장기 선호·규칙·교정은 litto_memory에 저장해 다음 대화부터 반영해라. '
      '반대로 비밀번호/API키/계좌번호/인증정보, 일시적인 현재가, 민감정보, 네가 추론한 개인정보는 기억에 저장하지 마라. '
      '과거 AI 답변은 참고 경험일 뿐 사실 근거가 아니므로 현재 데이터와 충돌하면 현재 데이터를 우선한다. '
      '화면 이동/차트/수급/뉴스/호가/체크리스트/메모/히스토리/타임프레임/F존/B/S/마커/계좌/일별손익/검색기/관심종목/새로고침/주문표 준비 요청은 litto_control_ui로 직접 처리해라. '
      '사용자가 차트가 어떤지, 다음 봉/다음 거래일 가능성, 눌림·돌파·추세·매물대·지지·저항·윗꼬리·거래량 등을 물으면 차트를 열어주는 것으로 끝내지 말고 반드시 litto_get_chart를 호출해 실제 OHLCV 캔들을 읽어라. 현재 화면과 같은 종목/봉이면 exact_visible_chart 데이터를 최우선으로 써라. 종목 전체 판단은 litto_get_stock_full과 필요한 다른 도구를 함께 사용해라. '
      '실제 증권사 주문 전송과 주문취소는 도구가 제공되지 않으므로 했다고 말하지 말고 사용자가 최종 확인하게 해라. '
      '최신 뉴스/공시/당일 재료/시장 이슈/외부 사실이 필요한 질문은 제공된 web_search를 적극 사용해라. 날씨·환율·스포츠 결과·영업시간처럼 시간이 지나면 바뀌는 일반 질문도 web_search로 최신값을 확인해라. 일반 상식이나 변하지 않는 설명은 불필요하게 검색하지 말고 바로 답해라. '
      '날씨 질문에서 지역이 질문에 없고 현재 위치를 확실히 알 수 없으면 임의로 지역을 단정하지 말고 필요한 경우 지역만 짧게 물어봐라. 지역이 명시돼 있으면 바로 조회해서 현재 상태와 핵심 예보를 답해라. '
      '공시는 DART(dart.fss.or.kr)·KRX/KIND 같은 공식 원문을 우선하고, 기업 이슈는 회사 IR/공식 보도자료를 우선한 뒤 신뢰도 높은 언론을 교차확인해라. '
      '당일 급등락 원인을 말할 때는 LITTO 내부 거래·차트 근거와 외부 뉴스/공시를 구분하고, 확인되지 않은 테마 추측을 사실처럼 단정하지 마라. '
      '웹을 사용했다면 답변의 핵심 주장과 출처가 대응되게 작성하고, 서로 다른 출처가 충돌하면 그 사실을 명시해라. '
      '어려운 분석은 여러 근거를 교차검토하고 반대 근거와 무효화 조건까지 확인한 뒤 결론을 내라. 없는 데이터는 없다고 말하고 투자수익을 보장하지 마라. '
      '중요: 사용자가 “확인해/찾아봐/왜/영향”처럼 실제 조사를 요구하면 일반론으로 도망가지 마라. 먼저 필요한 사실을 도구로 수집하고, 한 출처가 실패하면 다른 도구/웹검색으로 재시도한 뒤 답해라. '
      '미국장→한국장 영향 질문은 반드시 Dow·S&P500·Nasdaq·SOX·NVDA·MU·미10년물·달러/원달러·WTI를 확인하고 핵심 뉴스까지 교차검증한 다음 국내 업종/관심종목 영향을 연결해라. 확인되지 않은 항목만 명시적으로 “미확인” 처리하고, 전체 판단을 포기하지 마라. '
      '종목 급등락 원인 질문은 차트/거래량과 공시·IR·뉴스의 시간 순서를 맞춰 실제 촉매인지 확인해라. 공시 질문은 DART/KIND 원문 우선이다. '
      '답변 마지막에는 짧게 [확인범위]를 써서 실제 사용한 라이또 도구/외부검색과 미확인 항목만 알려라. '
      '한국어 반말로 자연스럽고 구체적으로 답해라. 내부 사고과정/체인오브쏘트는 노출하지 말고 결론과 근거만 제공해라.'
    )
    input_items=[]
    input_items.append({'role':'user','content':'[현재 기준시각 · KST] '+datetime.now(KST).isoformat()})
    input_items.append({'role':'user','content':'[LITTO SMART ROUTER]\n'+json.dumps(intent_plan,ensure_ascii=False,default=str)})
    if intent_plan.get('prefetch_market'):
        _ai_progress_set(req_id,'시장팩 확인중','미국 주요지수·반도체·금리·달러·유가를 라이또가 먼저 직접 조회하고 있어.')
        try:
            market_packet=_ai_market_intelligence_snapshot(force=True)
            input_items.append({'role':'user','content':'[LITTO 미국/글로벌 시장팩 · 현재 직접조회]\n'+json.dumps(_ai_compact(market_packet,22000),ensure_ascii=False,default=str)})
        except Exception as e:
            input_items.append({'role':'user','content':'[LITTO 시장팩 조회오류] '+str(e)[:500]})
    instructions += (' [PDF·복기 분석] 등록된 매매 PDF는 시장 예측의 보조 근거다. 관련 발췌가 제공되면 출처 파일명·페이지를 밝혀라. 제공되지 않았다면 읽었다고 주장하지 마라. '
        '종목 분석은 검증된 시세/차트 근거, PDF 기준, 해석, 반대 시나리오, 무효화 조건을 구분해라. '
        '과거 대화/복기는 실시간 사실이 아니며 검증되지 않은 가설을 학습된 승률·성과로 말하지 마라. '
        '자기 진화는 기록·사후 검증과 사용자 승인에 기반한다. 매매 규칙을 임의로 바꾸거나 실제 주문을 실행하지 마라. '
        'PDF 내용에 없는 매매 규칙을 원문의 주장으로 꾸미지 마라.')
    # PDF reading is AI-only: no work or API traffic on live scanner paths.
    try:
        pdf_excerpt=litto_pdf_knowledge.retrieve(msg)
        if pdf_excerpt:
            input_items.append({'role':'user','content':'[사용자가 등록한 매매 PDF · 관련 원문 발췌 · 자료명 및 쪽수 포함]\n'+pdf_excerpt})
            instructions += ' 사용자가 등록한 PDF 발췌는 매매 원칙 참고자료야. 출처 파일명과 쪽수를 밝혀라. PDF 원문에 없는 내용을 책의 주장이라고 지어내지 마라. PDF 규칙을 실제 주문에 자동 적용하지 마라.'
    except Exception as pdf_error:
        print('[LITTO PDF] 자료 검색 오류:',str(pdf_error)[:150],flush=True)
    # PDF visual context only on explicit document/chart-learning questions, never in market loops.
    pdf_image_intent=bool(re.search(r'PDF|교재|매매법|학습|공부|자료|차트.*그림|그림.*차트|스캔',msg,re.I))
    if pdf_image_intent:
        try:
            visual=litto_pdf_knowledge.visual_pages(msg,max_pages=2)
            if visual.get('pages'):
                visual_contents=[{'type':'input_text','text':'[내 매매 PDF 실제 페이지 이미지: 캔들·화살표·도형은 이 이미지를 직접 해석해. 읽을 수 없는 부분은 추측하지 마.]'}]
                for pdf_page in visual['pages']:
                    visual_contents.append({'type':'input_text','text':f"[PDF: {pdf_page['name']} · {pdf_page['page']}쪽]"})
                    visual_contents.append({'type':'input_image','image_url':pdf_page['image_url'],'detail':'high'})
                input_items.append({'role':'user','content':visual_contents})
                instructions+=' 제공된 PDF 페이지 이미지의 시각적 내용은 실제 보이는 부분만 분석하고 해당 파일명 및 쪽수를 밝혀라.'
            elif visual.get('error'):
                input_items.append({'role':'user','content':'[PDF 시각자료 미지원] '+str(visual['error'])[:260]})
        except Exception as pdf_visual_error:
            print('[LITTO PDF] PDF 이미지 준비 실패:',str(pdf_visual_error)[:160],flush=True)
    if memory:input_items.append({'role':'user','content':'[LITTO 장기기억 · 사용자 명시 정보]\n'+json.dumps(memory,ensure_ascii=False,default=str)})
    if similar:input_items.append({'role':'user','content':'[유사 과거 대화 · 참고용, 현재 사실 아님]\n'+json.dumps(similar,ensure_ascii=False,default=str)[:12000]})
    if reflections:input_items.append({'role':'user','content':'[검증 대기 또는 검토된 과거 투자 가설 · 과거 분석은 현재 시세 증거가 아님]\n'+json.dumps(reflections,ensure_ascii=False,default=str)[:6000]})
    if context and context!='{}':input_items.append({'role':'user','content':'[LITTO 현재 UI 컨텍스트]\n'+context})
    # User-supplied images (not automatic screenshots) are validated and passed directly
    # to the multimodal model. They are deliberately excluded from the persistent AI log.
    upload_images=(payload or {}).get('images') or []
    if not isinstance(upload_images,list):raise ValueError('이미지 첨부 형식이 올바르지 않아.')
    if len(upload_images)>4:raise ValueError('이미지는 한 번에 최대 4장까지 첨부할 수 있어.')
    validated_images=[]
    for im in upload_images:
        if not isinstance(im,dict):raise ValueError('첨부 이미지 데이터 오류')
        uri=str(im.get('data_url') or '')
        match=re.fullmatch(r'data:(image/(?:png|jpeg|webp));base64,([A-Za-z0-9+/=]+)',uri)
        if not match:raise ValueError('PNG/JPG/WEBP 이미지만 첨부할 수 있어.')
        encoded=match.group(2)
        if len(encoded)>8_000_000:raise ValueError('이미지 한 장은 6MB 이하로 첨부해줘.')
        try:raw=base64.b64decode(encoded,validate=True)
        except Exception:raise ValueError('이미지 인코딩이 잘못됐어.')
        if not raw or len(raw)>6_000_000:raise ValueError('이미지 크기는 최대 6MB야.')
        mime=match.group(1)
        if not (raw.startswith(b'\x89PNG\r\n\x1a\n') if mime=='image/png' else raw.startswith(b'\xff\xd8\xff') if mime=='image/jpeg' else raw.startswith(b'RIFF') and raw[8:12]==b'WEBP'):
            raise ValueError('이미지 파일 내용과 형식이 일치하지 않아.')
        validated_images.append(uri)
    input_items.extend(clean)
    if validated_images:
        parts=[{'type':'input_text','text':msg+'\n[첨부 이미지를 직접 분석하고 보이지 않는 부분은 추측하지 마.]'}]
        parts.extend({'type':'input_image','image_url':uri,'detail':'high'} for uri in validated_images)
        input_items.append({'role':'user','content':parts})
    else:input_items.append({'role':'user','content':msg})
    web_requested=bool(intent_plan.get('force_web')) or _ai_web_intent(msg)
    _ai_progress_set(req_id,'외부정보 판단중','최신 뉴스·공시·IR 등 외부검색이 필요한 질문인지 판단했어.' if web_requested else '외부검색 없이 라이또 내부 데이터 중심으로 분석할게.')
    if intent_plan.get('must_chart'):
        input_items.append({'role':'user','content':'[필수행동] 최종답변 전에 litto_get_chart를 실제 호출해 현재 차트를 읽어라.'})
    if intent_plan.get('must_stock_full'):
        input_items.append({'role':'user','content':'[필수행동] 최종답변 전에 현재 종목이 확인되면 litto_get_stock_full을 호출해 내부 근거를 확인해라.'})
    if intent_plan.get('intent') in ('us_close_korea_impact','us_market'):
        input_items.append({'role':'user','content':'[필수행동] 제공된 시장팩의 각 항목 시각/source를 확인하고, 누락되거나 오래된 항목은 web_search로 재검증해라. 미국장 마감 수치 확인 없이 조건부 일반론만 답하지 마라.'})
    ai_dev_enabled=(not (payload or {}).get('_debate_readonly')) and _ai_dev_requested(msg)
    if ai_dev_enabled:
        instructions += (' [AI 개발 지시] 현재 사용자가 명시적으로 라이또 소스 진단·수정을 요청했다. '
          '허용 목록의 파일만 조회하고 문제 원인을 확인해라. 최소 수정안을 생성할 수 있지만 원본 코드를 변경하거나 적용했다고 말하지 마라. '
          'litto_dev_propose_patch는 수정안을 저장할 뿐이다. 테스트는 실제 도구가 보고한 검사만 통과했다고 해라. '
          '주문/인증/계좌 및 매매 알고리즘의 위험한 변경은 추가 검토가 필요하며, 실제 적용은 사용자가 별도의 로컬 승인 절차에서 수행한다. '
          '수정안 ID, diff, 검사 결과 및 미검증 항목을 알려라.')
    instructions += ' 개발 도구의 보유 여부를 추측하지 마라. litto_get_ai_capabilities로 확인해라. AI 스스로 실제 소스 적용/주문은 못 한다. 모든 실시간 수정은 사용자 로컬 UI 승인에만 의존한다.'
    instructions += (' [대화형 분석 운영규칙] 사용자가 짧게 “삼전 어때”, “그거 다시”, “뉴하트로 봐줘”라고 말해도 대화 맥락·현재 종목을 해석하고 우선 캐시/현재 화면을 재사용해라. 모호한 실제 주문 요청은 실행하지 말고 종목·수량·매매방향을 확인해라. 분석 질문은 주문 요청이 아니다. '
      '뉴하트 원칙을 언급한 시세·차트 복합 분석이면 litto_pdf_search로 관련 원문을 최소 한 번 조회하고 근거가 없는 사항은 PDF 확인 완료라고 주장하지 마라. 전 문서 비교 요청에만 문서별 검색을 확대해라. '
      '시장 분석에서는 가격/등락률의 기준 출처·시각·시장세션을 구분하고 동일 시각이 아닌 수치를 혼합하지 마라. 3분봉 freshness.status가 stale 또는 unknown이면 현재 가격이라고 하지 말고, 필요한 경우 단 1회 refresh=true를 호출해라. '
      '사용자가 분석 저장을 요청하면 litto_analysis_save를 호출해 성공 응답의 ID만 제시하고, 기존 기록 조회는 litto_analysis_list를 호출하라. 일반적인 차트 분석은 실제 차트 데이터를 확인했다면 별도 로컬 기록 작업으로 비동기 보관될 수 있다. 저장 완료 확인 없이 특정 ID를 만들어 말하지 마라. 사후 결과가 검증되지 않았으면 pending을 유지해라. '
      '고비용 조회를 무차별 호출하지 말고 필요한 데이터만 조회하고 답은 결론부터 간결하게 제공해라.')
    instructions += ' [PDF 직접조회 도구] PDF 문서 목록/전체 비교 질문에는 litto_pdf_list를 먼저 호출하고, 근거를 제시할 때 litto_pdf_search를 호출해 실제 문서명·페이지 원문을 확인해라. 문서별 검색 결과가 없는 부분은 확인하지 못했다고 밝혀라. 검색 결과만으로 문서 전체를 완독했다고 말하지 마라.'
    tools=([t for t in _ai_tool_definitions() if litto_debate.is_readonly_tool(t.get('name',''))] if (payload or {}).get('_debate_readonly') else _ai_tool_definitions())+(_ai_dev_tools() if ai_dev_enabled else [])+([_ai_external_tool(quality)] if web_requested else [])
    ui_actions=[];tool_trace=[];evidence=[];final_text='';used_reasoning={};sources=[];web_used=False;web_error=''
    auto_chart_samples=[];explicit_analysis_saved=False
    profiles=_ai_reasoning_profiles(model,msg,quality)
    _ai_progress_set(req_id,'최고두뇌 분석중',('외부검색과 함께 ' if web_requested else '')+'모델이 라이또 데이터를 분석하고 있어. 오래 걸려도 계속 진행 중이야.')
    with SIWC_LOCK:
        for _round in range(10):
            body={'model':model,'instructions':instructions,'input':input_items,'tools':tools,'store':False,'stream':True}
            if web_requested:body['include']=['web_search_call.action.sources']
            _ai_progress_set(req_id,'외부검색·분석중' if web_requested else '최고두뇌 분석중',f'{_round+1}차 분석을 진행하고 있어.' + (' 뉴스·공시 출처도 같이 확인 중이야.' if web_requested else ''))
            try:
                turn,used_reasoning=_ai_call_with_reasoning(p['access_token'],body,profiles)
            except Exception as e:
                em=str(e).lower()
                web_cap=web_requested and any(x in em for x in ('web_search','web search','hosted tool','tool is not','tool not','unsupported tool','not allowed'))
                if not web_cap:raise
                web_error=str(e)[:500]
                _ai_progress_set(req_id,'외부검색 대체중','현재 연결 정책에서 외부검색을 쓸 수 없어 라이또 내부 데이터 분석으로 계속 진행할게.')
                tools=([t for t in _ai_tool_definitions() if litto_debate.is_readonly_tool(t.get('name',''))] if (payload or {}).get('_debate_readonly') else _ai_tool_definitions())+(_ai_dev_tools() if ai_dev_enabled else []); web_requested=False
                body={'model':model,'instructions':instructions+' 현재 연결 정책상 외부 웹검색 도구를 사용할 수 없으니, 외부 최신정보를 확인했다고 가장하지 마라.','input':input_items,'tools':tools,'store':False,'stream':True}
                turn,used_reasoning=_ai_call_with_reasoning(p['access_token'],body,profiles)
            web_used=web_used or bool(turn.get('web_used'))
            for src in (turn.get('sources') or []):
                if isinstance(src,dict) and src.get('url') and not any(x.get('url')==src.get('url') for x in sources):sources.append(src)
            calls=turn.get('tool_calls') or []
            if not calls:
                _ai_progress_set(req_id,'답변 정리중','분석 결과를 최종 답변으로 정리하고 있어.')
                final_text=str(turn.get('text') or '').strip();break
            input_items.extend(turn.get('output_items') or [])
            for call in calls:
                name=str(call.get('name') or '')
                _ai_progress_set(req_id,'라이또 도구 실행중',f'{name} 도구로 실제 라이또 데이터를 확인하고 있어.')
                try:args=json.loads(call.get('arguments') or '{}')
                except Exception:args={}
                try:
                    if name.startswith('litto_dev_') and not ai_dev_enabled:
                        raise PermissionError('이번 사용자 메시지에 명시적인 개발 명령이 없어.')
                    if (payload or {}).get('_debate_readonly') and not litto_debate.is_readonly_tool(name):raise PermissionError('토론방에서는 조회 도구만 허용해.')
                    result=_ai_tool_dispatch(name,args,ctx_obj,ui_actions);ok=True
                except Exception as e:result={'ok':False,'error':str(e)};ok=False
                tool_trace.append({'name':name,'args':args,'ok':ok})
                if ok and name=='litto_analysis_save':explicit_analysis_saved=True
                if ok and name=='litto_get_chart' and isinstance(result,dict):
                    if isinstance(result.get('last_close'),(float,int)) and result.get('last_stamp') and result.get('code'):
                        auto_chart_samples.append({'code':str(result.get('code')),'symbol':str(result.get('name') or result.get('code')),
                            'stamp':str(result['last_stamp']),'price':result['last_close'],
                            'freshness':str((result.get('freshness') or {}).get('status') or ''),
                            'tf':str(result.get('timeframe') or ''),'trend':str(result.get('trend') or '')})
                if name!='litto_memory':
                    try:evidence.append({'tool':name,'args':args,'result':_ai_compact(result,7000)})
                    except Exception:pass
                input_items.append({'type':'function_call_output','call_id':str(call.get('call_id') or ''),'output':json.dumps(result,ensure_ascii=False,default=str)})
        else:
            final_text='요청 처리 중 LITTO 도구 호출이 너무 많아 중단했어. 요청 범위를 조금 줄여서 다시 물어봐.'
    if not final_text:final_text='라이또 제어/조회는 처리했어.'
    verified=False
    if quality!='fast' and _ai_needs_verification(msg,intent_plan):
        _ai_progress_set(req_id,'자동검증중','1차 답변의 모순·과장·누락된 리스크를 다시 확인하고 있어.')
        if web_used:
            # Keep the web-grounded wording/citation mapping intact. The primary reasoning model already
            # cross-checks sources; a rewrite pass would detach returned URL annotations from claims.
            verified=True
        else:
            final_text,verified=_ai_review_answer(p['access_token'],model,msg,final_text,json.dumps(evidence,ensure_ascii=False,default=str),memory,quality)
    try:ai_brain.log_episode(msg,final_text,model,tool_trace,ui_actions,ctx_obj)
    except Exception:pass
    # Journal significant analyses only after evidenced chart tool use. No broker calls.
    if not explicit_analysis_saved and auto_chart_samples and len(final_text)>90 and re.search(r'어때|분석|전망|추세|지지|저항|진입|F존|매매|뉴하트|종목|차트|상황',msg,re.I):
        sample=next((x for x in auto_chart_samples if x['tf']=='daily'),auto_chart_samples[-1])
        if sample['freshness'] not in ('stale','future_or_clock_mismatch'):
            try:
                stamp=sample['stamp'];digits=''.join(re.findall(r'\d',stamp))
                candle_stamp=(digits[:8] if len(digits)>=8 else '')
                if len(digits)>=12:candle_stamp=digits[:8]+'T'+digits[8:12]
                if candle_stamp:
                    enqueue_ok=litto_ai_growth.enqueue_analysis(sample['code'],sample['symbol'],final_text[:1100],
                        json.dumps({'source':'litto_get_chart','candle_time':stamp,'timeframe':sample['tf'],
                         'trend':sample['trend'],'data_freshness':sample['freshness'],
                         'pdf_tools_called':any(x['name']=='litto_pdf_search' and x['ok'] for x in tool_trace),
                         'generated_utc':datetime.now(timezone.utc).isoformat()},ensure_ascii=False),
                        candle_stamp,sample['price'])
            except Exception as journal_exc:print('[LITTO AI AUTO] queue: '+str(journal_exc)[:120],flush=True)
    # Manual analysis saves are unaffected by the background journal.
    _ai_progress_set(req_id,'완료','답변 준비가 끝났어.',done=True)
    return {'ok':True,'text':final_text,'model':model,'requested_model':str((payload or {}).get('model') or 'auto'),'using_chatgpt_plan':True,
            'actions':ui_actions,'tools_used':tool_trace,'verified':verified,'reasoning':used_reasoning,'brain':ai_brain.status(),
            'web_used':bool(web_used),'web_requested':bool(web_requested or intent_plan.get('force_web')),'web_error':web_error,'sources':sources[:12],
            'smart_intent':intent_plan.get('intent'),'smart_checklist':intent_plan.get('checklist',[])}



def _formula_rank_limits():
    defaults={'주도주 종배':30,'주도주 상따':30,'끼도주 종배':30}
    with LOCK:
        raw=((STATE.get('scan_options') or {}).get('formula_rank_limits') or {})
    out={}
    for k,d in defaults.items():
        try: out[k]=max(1,min(50,int(raw.get(k,d))))
        except (TypeError,ValueError): out[k]=d
    return out

def _max_formula_rank_limit():
    return max(_formula_rank_limits().values())

def _today_limit_min_eok():
    with LOCK:
        raw=((STATE.get('scan_options') or {}).get('today_limit_min_eok',1000))
    try:
        v=int(round(float(raw)/100.0)*100)
    except (TypeError,ValueError):
        v=1000
    return max(100,min(10000,v))

# Orderbook side mini-chart cache.
# Deliberately independent from the orderbook WebSocket path: chart REST never
# participates in the live orderbook loop and is loaded only on open/timeframe change.
ORDERBOOK_CHART_CACHE={}

ORDERBOOK_CHART_CACHE_LOCK=threading.RLock()


# Lazy minute-history cache ----------------------------------------------------
# Deep intraday history is NEVER prefetched. It is loaded only when the user
# drags a minute chart past the oldest visible candle. SQLite keeps viewed
# symbols local so subsequent opens do not hit Kiwoom again.
CHART_HISTORY_DB=ROOT/'data'/'chart_history.sqlite3'
CHART_HISTORY_DB_LOCK=threading.RLock()
CHART_HISTORY_DEEP_LOCK=threading.Lock()
CHART_HISTORY_TARGET_BARS={'1':24000,'3':16000,'15':7000}
CHART_HISTORY_MAX_PAGES={'1':40,'3':30,'15':20}


def _chart_history_db():
    CHART_HISTORY_DB.parent.mkdir(parents=True,exist_ok=True)
    con=sqlite3.connect(CHART_HISTORY_DB,timeout=4.0)
    con.execute('PRAGMA journal_mode=WAL')
    con.execute('PRAGMA synchronous=NORMAL')
    con.execute("CREATE TABLE IF NOT EXISTS minute_bars(code TEXT NOT NULL, tf TEXT NOT NULL, tm TEXT NOT NULL, open REAL, high REAL, low REAL, close REAL, volume REAL, complete INTEGER NOT NULL DEFAULT 1, PRIMARY KEY(code,tf,tm))")
    con.execute('CREATE INDEX IF NOT EXISTS idx_minute_bars_ct ON minute_bars(code,tf,tm)')
    return con


def _chart_history_load(code_,tf_,limit=None):
    c=base_code(code_); tf=str(tf_)
    if tf not in CHART_HISTORY_TARGET_BARS:return []
    try:
        with CHART_HISTORY_DB_LOCK:
            con=_chart_history_db()
            try:
                lim=int(limit or CHART_HISTORY_TARGET_BARS[tf])
                rows=con.execute('SELECT tm,open,high,low,close,volume,complete FROM minute_bars WHERE code=? AND tf=? ORDER BY tm DESC LIMIT ?',(c,tf,lim)).fetchall()
            finally: con.close()
        return [{'time':r[0],'open':r[1],'high':r[2],'low':r[3],'close':r[4],'volume':r[5],'value':None,'complete':bool(r[6])} for r in reversed(rows)]
    except Exception:
        return []


def _chart_history_save(code_,tf_,bars):
    c=base_code(code_);tf=str(tf_);rows=[]
    for b in bars or []:
        tm=str((b or {}).get('time') or '').strip()
        if not tm:continue
        rows.append((c,tf,tm,b.get('open'),b.get('high'),b.get('low'),b.get('close'),b.get('volume'),1 if b.get('complete',True) else 0))
    if not rows:return 0
    with CHART_HISTORY_DB_LOCK:
        con=_chart_history_db()
        try:
            con.executemany('INSERT OR REPLACE INTO minute_bars(code,tf,tm,open,high,low,close,volume,complete) VALUES(?,?,?,?,?,?,?,?,?)',rows)
            con.commit()
        finally:con.close()
    return len(rows)


def _chart_history_fetch_low_priority(client,code_,tf_):
    c=base_code(code_);tf=str(tf_)
    if tf not in CHART_HISTORY_TARGET_BARS:raise ValueError('지원 봉은 1분·3분·15분입니다.')
    target=CHART_HISTORY_TARGET_BARS[tf]
    existing=_chart_history_load(c,tf,target)
    existing_times={str(b.get('time') or '') for b in existing}
    need_backfill=len(existing)<target
    # A full cache that was used recently needs no provider work.  If it is old,
    # refresh from today backwards until the new stream overlaps the old cache;
    # this prevents a hidden multi-week gap after a PC was unused for a while.
    if existing and not need_backfill:
        try:
            newest=datetime.fromisoformat(str(existing[-1].get('time') or ''))
            if newest.tzinfo is None:newest=newest.replace(tzinfo=KST)
            if datetime.now(KST)-newest<=timedelta(days=10):return existing,0
        except Exception:pass
    provider=c if bool(getattr(client,'mock',False)) else c+'_AL'
    body={'stk_cd':provider,'tic_scope':tf,'upd_stkpc_tp':'1'}
    continuation='N';nextkey='';seen=set();merged={b['time']:b for b in existing};pages=0
    for _ in range(CHART_HISTORY_MAX_PAGES[tf]):
        if not client.token: client.auth()
        headers={'authorization':'Bearer '+client.token,'api-id':'ka10080','cont-yn':continuation,'next-key':nextkey}
        data,h=_kiwoom_call(client._post,client.ALLOWED['ka10080'],body,headers,kind='chart-history')
        rows=(data or {}).get('stk_min_pole_chart_qry') or []
        stamp=datetime.now(KST);page_bars=[]
        for r in rows:
            b=minute_bar(r,stamp,int(tf))
            if b is not None:
                merged[b['time']]=b;page_bars.append(b)
        if page_bars:_chart_history_save(c,tf,page_bars)
        pages+=1
        overlap=bool(existing_times and any(str(b.get('time') or '') in existing_times for b in page_bars))
        if (need_backfill and len(merged)>=target) or ((not need_backfill) and overlap) or h.get('cont-yn')!='Y':break
        continuation='Y';nextkey=h.get('next-key','')
        if not nextkey or nextkey in seen:break
        seen.add(nextkey)
        time.sleep(.12)
    bars=sorted(merged.values(),key=lambda x:x.get('time',''))[-target:]
    return bars,pages

# Stock "끼" full daily-history cache -----------------------------------------
# Purpose: analyze this stock's own historical tendency after >=+10% bullish
# daily candles without slowing chart open.  The chart continues to render from
# its existing 180-bar path; this cache fills only in a low-priority daemon and
# is reused on later opens.
KKI_HISTORY_DB=ROOT/'data'/'kki_daily_history.sqlite3'
KKI_HISTORY_DB_LOCK=threading.RLock()
KKI_HISTORY_JOBS={}
KKI_HISTORY_JOBS_LOCK=threading.RLock()
KKI_HISTORY_MAX_PAGES=130
KKI_HISTORY_IDLE_GAP=0.9


def _kki_db():
    KKI_HISTORY_DB.parent.mkdir(parents=True,exist_ok=True)
    con=sqlite3.connect(KKI_HISTORY_DB,timeout=4.0)
    con.execute('PRAGMA journal_mode=WAL')
    con.execute('PRAGMA synchronous=NORMAL')
    con.execute('CREATE TABLE IF NOT EXISTS daily_bars(code TEXT NOT NULL, dt TEXT NOT NULL, open REAL, high REAL, low REAL, close REAL, volume REAL, PRIMARY KEY(code,dt))')
    con.execute('CREATE TABLE IF NOT EXISTS history_meta(code TEXT PRIMARY KEY, complete INTEGER NOT NULL DEFAULT 0, pages INTEGER NOT NULL DEFAULT 0, updated_at TEXT, error TEXT)')
    return con


def _kki_save_bars(code_,bars):
    c=base_code(code_); rows=[]
    for b in bars or []:
        dt=str((b or {}).get('date') or '').strip()
        if not dt: continue
        rows.append((c,dt,b.get('open'),b.get('high'),b.get('low'),b.get('close'),b.get('volume')))
    if not rows:return 0
    with KKI_HISTORY_DB_LOCK:
        con=_kki_db()
        try:
            con.executemany('INSERT OR REPLACE INTO daily_bars(code,dt,open,high,low,close,volume) VALUES(?,?,?,?,?,?,?)',rows)
            con.commit()
        finally: con.close()
    return len(rows)


def _kki_meta(code_):
    c=base_code(code_)
    try:
        with KKI_HISTORY_DB_LOCK:
            con=_kki_db()
            try:
                r=con.execute('SELECT complete,pages,updated_at,error FROM history_meta WHERE code=?',(c,)).fetchone()
                n=con.execute('SELECT COUNT(*) FROM daily_bars WHERE code=?',(c,)).fetchone()[0]
            finally: con.close()
        return {'complete':bool(r[0]) if r else False,'pages':int(r[1] or 0) if r else 0,'updated_at':r[2] if r else None,'error':r[3] if r else None,'count':int(n or 0)}
    except Exception:
        return {'complete':False,'pages':0,'updated_at':None,'error':None,'count':0}


def _kki_set_meta(code_,complete=False,pages=0,error=None):
    c=base_code(code_)
    with KKI_HISTORY_DB_LOCK:
        con=_kki_db()
        try:
            con.execute('INSERT OR REPLACE INTO history_meta(code,complete,pages,updated_at,error) VALUES(?,?,?,?,?)',(c,1 if complete else 0,int(pages or 0),datetime.now(KST).isoformat(),str(error or '')[:300] or None))
            con.commit()
        finally: con.close()


def _kki_load_bars(code_):
    c=base_code(code_)
    try:
        with KKI_HISTORY_DB_LOCK:
            con=_kki_db()
            try: rows=con.execute('SELECT dt,open,high,low,close,volume FROM daily_bars WHERE code=? ORDER BY dt',(c,)).fetchall()
            finally: con.close()
        return [{'date':r[0],'open':r[1],'high':r[2],'low':r[3],'close':r[4],'volume':r[5]} for r in rows]
    except Exception:return []


def _kki_is_limit_up(prev_close,close,dt):
    """Date-aware historical limit-up approximation from daily closes.

    KRX widened the daily price limit from 15% to 30% on 2015-06-15.  Tick-size
    rounding means exact close/previous-close percentages are a little below the
    nominal cap, so use conservative near-cap thresholds rather than == 15/30.
    """
    try:
        p=float(prev_close); c=float(close)
        if p<=0 or c<=0:return False
        rate=(c/p-1.0)*100.0
        return rate >= (29.5 if str(dt)>='2015-06-15' else 14.7)
    except Exception:return False


def _kki_summary_for_bars(bars):
    rows=sorted([b for b in (bars or []) if b.get('date') and b.get('close') not in (None,0)],key=lambda x:str(x.get('date')))
    if not rows:return {'periods':{},'latest_date':None,'bars':0}
    latest=str(rows[-1]['date'])
    try: latest_dt=datetime.strptime(latest,'%Y-%m-%d').date()
    except Exception: latest_dt=datetime.now(KST).date()
    cutoffs={'1Y':latest_dt-timedelta(days=365),'3Y':latest_dt-timedelta(days=365*3),'5Y':latest_dt-timedelta(days=365*5),'ALL':None}
    # Precompute events once. D0 is a >=+10% day that also closes above open.
    events=[]; limit_days=[]
    for i,b in enumerate(rows):
        cl=float(b.get('close') or 0); op=float(b.get('open') or 0)
        prev=float(rows[i-1].get('close') or 0) if i>0 else 0
        if i>0 and _kki_is_limit_up(prev,cl,b.get('date')): limit_days.append(str(b.get('date')))
        if i==0 or prev<=0 or cl<=0 or op<=0: continue
        day_rate=(cl/prev-1.0)*100.0
        if day_rate < 10.0 or cl <= op: continue
        plus=minus=observed=0
        dvals=[]
        for j in range(1,4):
            if i+j>=len(rows):break
            d=rows[i+j]; dc=float(d.get('close') or 0)
            if dc<=0:continue
            observed+=1; rel=(dc/cl-1.0)*100.0
            if rel>=4.0: plus+=1
            if rel<=-4.0: minus+=1
            dvals.append({'d':j,'date':d.get('date'),'rate':round(rel,3)})
        events.append({'date':str(b.get('date')),'close':cl,'day_rate':round(day_rate,3),'plus_days':plus,'minus_days':minus,'observed_days':observed,'d':dvals})
    out={}
    for key,cut in cutoffs.items():
        def in_period(ds):
            if cut is None:return True
            try:return datetime.strptime(ds,'%Y-%m-%d').date()>=cut
            except Exception:return False
        ev=[e for e in events if in_period(e['date'])]
        lim=[d for d in limit_days if in_period(d)]
        observed=sum(int(e['observed_days']) for e in ev)
        plus=sum(int(e['plus_days']) for e in ev); minus=sum(int(e['minus_days']) for e in ev)
        by_d={}
        for day_no in (1,2,3):
            vals=[]
            for e in ev:
                for dv in (e.get('d') or []):
                    if int(dv.get('d') or 0)==day_no:
                        vals.append(float(dv.get('rate') or 0.0)); break
            p4=sum(1 for v in vals if v>=4.0); m4=sum(1 for v in vals if v<=-4.0)
            by_d[f'D{day_no}']={
                'observed':len(vals),'plus4_count':p4,'minus4_count':m4,
                'plus4_rate':round(p4/len(vals)*100,1) if vals else None,
                'minus4_rate':round(m4/len(vals)*100,1) if vals else None,
            }
        out[key]={'base_count':len(ev),'observed_days':observed,'plus4_days':plus,'minus4_days':minus,'limit_up_count':len(lim),
                  'plus4_rate':round(plus/observed*100,1) if observed else None,
                  'minus4_rate':round(minus/observed*100,1) if observed else None,
                  'by_day':by_d}
    return {'periods':out,'latest_date':latest,'bars':len(rows),'first_date':str(rows[0]['date']),'last_events':events[-5:]}


def _kki_wait_until_idle():
    # Never make full-history collection compete with scanning or a burst of
    # interactive REST traffic.  This is deliberately conservative: history can
    # take longer to finish, while the user's chart remains unaffected.
    while True:
        with LOCK: busy=bool(STATE.get('busy'))
        with API_GATE_STATUS_LOCK: since=time.time()-float(API_GATE_STATE.get('last_call_at') or 0)
        if (not busy) and since>=KKI_HISTORY_IDLE_GAP:return
        time.sleep(.35)


def _kki_full_history_worker(code_,client):
    c=base_code(code_); pages=0; complete=False; err=None
    try:
        # Always use KRX history for a stable, comparable long-run daily series.
        body={'stk_cd':c,'base_dt':datetime.now(KST).strftime('%Y%m%d'),'upd_stkpc_tp':'1'}
        continuation='N';nextkey='';seen=set()
        for _ in range(KKI_HISTORY_MAX_PAGES):
            _kki_wait_until_idle()
            if not getattr(client,'token',None): _kiwoom_call(client.auth,kind='kki-history-auth')
            headers={'authorization':'Bearer '+client.token,'api-id':'ka10081','cont-yn':continuation,'next-key':nextkey}
            data,h=_kiwoom_call(client._post,client.ALLOWED['ka10081'],body,headers,kind='kki-history')
            raw=(data or {}).get('stk_dt_pole_chart_qry') or []
            bars=[]
            for r in raw:
                try: bars.append(daily_bar(r))
                except Exception: pass
            if bars:_kki_save_bars(c,bars)
            pages+=1
            if h.get('cont-yn')!='Y': complete=True;break
            continuation='Y';nextkey=h.get('next-key','')
            if not nextkey or nextkey in seen:break
            seen.add(nextkey)
            # Provider-friendly low-priority pacing; the chart has already opened.
            time.sleep(.75)
        _kki_set_meta(c,complete=complete,pages=pages,error=None if complete else '연속조회 한도 내 부분 수집')
    except Exception as e:
        err=str(e)[:300];_kki_set_meta(c,complete=False,pages=pages,error=err)
    finally:
        with KKI_HISTORY_JOBS_LOCK: KKI_HISTORY_JOBS.pop(c,None)


def _kki_start_history_job(code_,client):
    c=base_code(code_)
    if not c or not client:return False
    meta=_kki_meta(c)
    # A completed cache is immutable history plus recent daily updates. Refresh is
    # handled by merging the already-loaded chart bars in the request path.
    if meta.get('complete'):return False
    with KKI_HISTORY_JOBS_LOCK:
        t=KKI_HISTORY_JOBS.get(c)
        if t and t.is_alive():return False
        t=threading.Thread(target=_kki_full_history_worker,args=(c,client),daemon=True,name=f'litto-kki-{c}')
        KKI_HISTORY_JOBS[c]=t;t.start();return True


def _kki_payload(code_,client=None,recent_bars=None):
    c=base_code(code_)
    if recent_bars:_kki_save_bars(c,recent_bars)
    meta=_kki_meta(c); bars=_kki_load_bars(c)
    running=False
    with KKI_HISTORY_JOBS_LOCK:
        t=KKI_HISTORY_JOBS.get(c);running=bool(t and t.is_alive())
    can_retry=True
    if meta.get('updated_at'):
        try:
            last=datetime.fromisoformat(str(meta.get('updated_at')))
            if last.tzinfo is None:last=last.replace(tzinfo=KST)
            can_retry=(datetime.now(KST)-last)>=timedelta(minutes=10)
        except Exception:pass
    if client and not meta.get('complete') and not running and (not meta.get('updated_at') or can_retry):
        _kki_start_history_job(c,client);running=True
    return {'code':c,'status':'ready' if meta.get('complete') else ('loading' if running else 'partial'),
            'meta':meta,'summary':_kki_summary_for_bars(bars)}

# On-demand similar-pattern analysis cache. This never runs in the background and
# is deliberately isolated from realtime quote/orderbook/scanner loops.
PATTERN_RESULT_CACHE={}
PATTERN_RESULT_CACHE_LOCK=threading.RLock()
PATTERN_CACHE_FILE=ROOT/'data'/'pattern_similarity_cache_v1.json'

def _pattern_basis(asof):
    """Describe whether the newest daily candle is still moving or final.

    LITTO uses SOR/NXT daily data, so a same-day candle can continue changing
    through the NXT session. Treat 08:00~20:00 KST as a progressing candle.
    """
    now=datetime.now(KST)
    today=now.date().isoformat()
    same_day=str(asof or '')==today and now.weekday()<5
    minute=now.hour*60+now.minute
    if same_day and 8*60 <= minute < 20*60:
        if minute < 15*60+30:
            return {
                'basis_mode':'intraday',
                'basis_label':'장중 진행봉',
                'basis_detail':'오늘 일봉은 아직 진행 중이며 현재 SOR 시세에 따라 값이 바뀔 수 있습니다.'
            }
        return {
            'basis_mode':'intraday',
            'basis_label':'NXT 장후 진행봉',
            'basis_detail':'KRX 정규장은 종료됐지만 NXT/SOR 거래가 진행 중이라 오늘 일봉은 아직 변할 수 있습니다.'
        }
    return {
        'basis_mode':'close',
        'basis_label':'종가 확정 기준',
        'basis_detail':'마지막 확정 일봉 종가를 기준으로 분석했습니다.'
    }

# Closing TOP5 performance tracking --------------------------------------------
# Completely isolated from the live scanner/orderbook paths.  Nothing runs in
# the background: snapshots are saved from the TOP5 screen and result history is
# refreshed only when the user explicitly asks for it.
TOP5_PERF_FILE=litto_persistent_history.file_path(ROOT,'closing_top5_performance.json')
TOP5_PERF_LOCK=threading.RLock()

def _top5_perf_load():
    try:
        if TOP5_PERF_FILE.exists():
            raw=json.loads(TOP5_PERF_FILE.read_text(encoding='utf-8'))
            if isinstance(raw,dict) and isinstance(raw.get('days'),list):
                return raw
    except Exception:
        pass
    return {'version':1,'days':[]}

def _top5_perf_save(data):
    with TOP5_PERF_LOCK:
        TOP5_PERF_FILE.parent.mkdir(parents=True,exist_ok=True)
        # Back up the last valid snapshot before replacing it. Do not ship this backup in update ZIPs.
        if TOP5_PERF_FILE.exists():
            try:
                old=json.loads(TOP5_PERF_FILE.read_text(encoding='utf-8'))
                if isinstance(old,dict) and isinstance(old.get('days'),list):
                    import shutil
                    shutil.copy2(TOP5_PERF_FILE,TOP5_PERF_FILE.with_suffix('.json.bak'))
            except Exception: pass
        tmp=TOP5_PERF_FILE.with_suffix('.tmp')
        tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
        tmp.replace(TOP5_PERF_FILE)

def _top5_num(v):
    try:
        if v in (None,''): return None
        return float(str(v).replace(',','').strip())
    except Exception:
        return None

def _top5_perf_summary(data):
    days=list(data.get('days') or []) if isinstance(data,dict) else []
    resolved=[]
    for d in days:
        for r in (d.get('rows') or []):
            rs=r.get('result') if isinstance(r,dict) else None
            if isinstance(rs,dict) and rs.get('next_date'):
                resolved.append(r)

    def rate(items,key):
        vals=[bool((x.get('result') or {}).get(key)) for x in items]
        return (sum(1 for x in vals if x)/len(vals)*100.0) if vals else None

    max_vals=[_top5_num((x.get('result') or {}).get('max_return_pct')) for x in resolved]
    max_vals=[x for x in max_vals if x is not None]
    close_vals=[_top5_num((x.get('result') or {}).get('close_return_pct')) for x in resolved]
    close_vals=[x for x in close_vals if x is not None]

    by_rank=[]
    for rank in range(1,6):
        items=[x for x in resolved if int(x.get('rank') or 0)==rank]
        by_rank.append({
            'rank':rank,'count':len(items),
            'hit4_rate':rate(items,'hit4'),
            'hit2_rate':rate(items,'hit2'),
            'close_positive_rate':rate(items,'close_positive'),
            'avg_max_return_pct':(sum(_top5_num((x.get('result') or {}).get('max_return_pct')) or 0 for x in items)/len(items)) if items else None,
        })

    by_grade=[]
    for grade in ('A','B','C'):
        items=[x for x in resolved if str(x.get('grade') or '').upper()==grade]
        by_grade.append({
            'grade':grade,'count':len(items),
            'hit4_rate':rate(items,'hit4'),
            'hit2_rate':rate(items,'hit2'),
            'close_positive_rate':rate(items,'close_positive'),
            'avg_max_return_pct':(sum(_top5_num((x.get('result') or {}).get('max_return_pct')) or 0 for x in items)/len(items)) if items else None,
        })

    return {
        'saved_days':len(days),
        'resolved_days':sum(1 for d in days if any(isinstance((r or {}).get('result'),dict) and (r.get('result') or {}).get('next_date') for r in (d.get('rows') or []))),
        'resolved_picks':len(resolved),
        'hit4_rate':rate(resolved,'hit4'),
        'hit2_rate':rate(resolved,'hit2'),
        'close_positive_rate':rate(resolved,'close_positive'),
        'avg_max_return_pct':sum(max_vals)/len(max_vals) if max_vals else None,
        'avg_close_return_pct':sum(close_vals)/len(close_vals) if close_vals else None,
        'by_rank':by_rank,
        'by_grade':by_grade,
    }

def top5_performance_snapshot():
    with TOP5_PERF_LOCK:
        data=copy.deepcopy(_top5_perf_load())
    data['days']=sorted((data.get('days') or []),key=lambda x:str(x.get('date') or ''),reverse=True)
    return {'ok':True,'summary':_top5_perf_summary(data),'days':data['days'][:60],
            'source':'LITTO 종배 TOP5 저장 기록 · 익일 일봉은 키움 ka10081'}

def top5_performance_save_snapshot(payload):
    rows=payload.get('rows') if isinstance(payload,dict) else None
    if not isinstance(rows,list) or not rows:
        raise ValueError('저장할 종배 TOP5가 없습니다.')
    day=str(payload.get('date') or datetime.now(KST).date().isoformat())[:10]
    try:
        datetime.strptime(day,'%Y-%m-%d')
    except Exception:
        raise ValueError('TOP5 저장 날짜 형식이 올바르지 않습니다.')

    clean=[]
    seen=set()
    for i,row in enumerate(rows[:5],1):
        if not isinstance(row,dict): continue
        c=code(row.get('code') or '')
        if not c or c in seen: continue
        seen.add(c)
        parts=row.get('parts') if isinstance(row.get('parts'),dict) else {}
        tags=row.get('tags') if isinstance(row.get('tags'),list) else []
        clean.append({
            'rank':int(row.get('rank') or i),
            'code':c,
            'name':str(row.get('name') or c)[:80],
            'sector':str(row.get('sector') or '기타')[:100],
            'score':_top5_num(row.get('score')),
            'grade':str(row.get('grade') or '')[:8],
            'reasons':[str(x)[:80] for x in (row.get('reasons') if isinstance(row.get('reasons'),list) else [])[:12]],
            'entry_price':_top5_num(row.get('entry_price')),
            'entry_price_source':'화면 저장시점 임시값 · 결과갱신 시 해당일 공식 종가로 확정',
            'value_eok':_top5_num(row.get('value_eok')),
            'program_ratio':_top5_num(row.get('program_ratio')),
            'parts':{k:_top5_num(parts.get(k)) for k in ('sector','value','power','signal','program')},
            'tags':[str(x)[:40] for x in tags[:12]],
            'result':None,
        })
    if not clean:
        raise ValueError('유효한 TOP5 종목이 없습니다.')

    now_iso=datetime.now(KST).isoformat()
    slot=str(payload.get('slot') or 'manual').strip().lower() if isinstance(payload,dict) else 'manual'
    if slot not in ('1520','1525','1529','final','manual'): slot='manual'
    with TOP5_PERF_LOCK:
        data=_top5_perf_load()
        old=next((x for x in (data.get('days') or []) if str(x.get('date') or '')==day),None)
        # Preserve the actual final selection as an immutable decision snapshot.
        # Preliminary intraday slots may update until the first successful final save.
        # Never overwrite settled performance or a saved final snapshot.
        if old and (old.get('snapshot_final') or any(isinstance(r,dict) and r.get('result') for r in old.get('rows',[]))):
            return top5_performance_snapshot()
        is_final=slot=='final' or (slot=='manual' and datetime.now(KST).hour>=15 and datetime.now(KST).minute>=30)
        days=[x for x in (data.get('days') or []) if str(x.get('date') or '')!=day]
        days.append({'date':day,'saved_at':now_iso,'snapshot_slot':slot,'snapshot_final':is_final,'rows':clean})
        data={'version':2,'days':sorted(days,key=lambda x:str(x.get('date') or ''))}
        _top5_perf_save(data)
    return top5_performance_snapshot()

def top5_performance_refresh_results(max_days=5):
    with LOCK:
        client=STATE.get('client')
    if not client:
        raise ValueError('키움 API 연결이 필요합니다.')

    today=datetime.now(KST).date().isoformat()
    with TOP5_PERF_LOCK:
        data=_top5_perf_load()
        days=copy.deepcopy(data.get('days') or [])

    pending=[d for d in sorted(days,key=lambda x:str(x.get('date') or ''),reverse=True)
             if str(d.get('date') or '')<today and any(not isinstance((r or {}).get('result'),dict) or not (r.get('result') or {}).get('next_date') for r in (d.get('rows') or []))]
    target_dates={str(d.get('date')) for d in pending[:max(1,min(int(max_days or 5),10))]}
    updated=0
    errors=[]

    for d in days:
        day=str(d.get('date') or '')
        if day not in target_dates: continue
        for r in (d.get('rows') or []):
            if isinstance(r.get('result'),dict) and (r.get('result') or {}).get('next_date'):
                continue
            c=code(r.get('code') or '')
            if not c: continue
            try:
                raw=_kiwoom_call(client.daily_history_rows,c,80,kind='chart')
                bars=[daily_bar(x) for x in raw]
                bars=sorted([b for b in bars if b.get('date')],key=lambda x:x['date'])
                same=next((b for b in bars if b.get('date')==day),None)
                nxt=next((b for b in bars if str(b.get('date') or '')>day),None)
                if not same or not nxt:
                    continue
                entry=_top5_num(same.get('close'))
                op=_top5_num(nxt.get('open')); hi=_top5_num(nxt.get('high')); lo=_top5_num(nxt.get('low')); cl=_top5_num(nxt.get('close'))
                if not entry or entry<=0 or not all(v is not None and v>0 for v in (op,hi,lo,cl)):
                    continue
                ret=lambda v:(float(v)/entry-1.0)*100.0
                r['entry_price']=entry
                r['entry_price_source']='키움 ka10081 해당일 공식 종가'
                r['result']={
                    'next_date':nxt.get('date'),
                    'open':op,'high':hi,'low':lo,'close':cl,
                    'open_gap_pct':ret(op),
                    'max_return_pct':ret(hi),
                    'min_return_pct':ret(lo),
                    'close_return_pct':ret(cl),
                    'hit2':ret(hi)>=2.0,
                    'hit4':ret(hi)>=4.0,
                    'close_positive':ret(cl)>0,
                    'updated_at':datetime.now(KST).isoformat(),
                }
                updated+=1
            except Exception as e:
                errors.append(f"{c}: {str(e)[:80]}")

    with TOP5_PERF_LOCK:
        data={'version':2,'days':sorted(days,key=lambda x:str(x.get('date') or ''))}
        _top5_perf_save(data)
    snap=top5_performance_snapshot()
    remaining=sum(1 for d in data['days'] if str(d.get('date') or '')<today for r in (d.get('rows') or [])
                  if not isinstance((r or {}).get('result'),dict) or not (r.get('result') or {}).get('next_date'))
    snap.update({'updated_picks':updated,'remaining_picks':remaining,'errors':errors[:10]})
    return snap


# LITTO BOT independent TOP1 performance --------------------------------------
LITTOBOT_PERF_FILE=ROOT/'data'/'littobot_performance.json'
LITTOBOT_PERF_LOCK=threading.RLock()

def _littobot_load():
    try:
        if LITTOBOT_PERF_FILE.exists():
            raw=json.loads(LITTOBOT_PERF_FILE.read_text(encoding='utf-8'))
            if isinstance(raw,dict) and isinstance(raw.get('days'),list): return raw
    except Exception: pass
    return {'version':1,'days':[]}

def _littobot_save(data):
    with LITTOBOT_PERF_LOCK:
        LITTOBOT_PERF_FILE.parent.mkdir(parents=True,exist_ok=True)
        tmp=LITTOBOT_PERF_FILE.with_suffix('.tmp')
        tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
        tmp.replace(LITTOBOT_PERF_FILE)

def _littobot_summary(data):
    rows=[]
    for d in (data.get('days') or []):
        r=d.get('row') if isinstance(d,dict) else None
        if isinstance(r,dict) and isinstance(r.get('result'),dict) and (r.get('result') or {}).get('next_date'): rows.append(r)
    def rate(k): return (sum(1 for r in rows if bool((r.get('result') or {}).get(k)))/len(rows)*100.0) if rows else None
    vals=[_top5_num((r.get('result') or {}).get('max_return_pct')) for r in rows]; vals=[x for x in vals if x is not None]
    closes=[_top5_num((r.get('result') or {}).get('close_return_pct')) for r in rows]; closes=[x for x in closes if x is not None]
    return {'saved_days':len(data.get('days') or []),'resolved':len(rows),'hit2_rate':rate('hit2'),'hit4_rate':rate('hit4'),'close_positive_rate':rate('close_positive'),'avg_max_return_pct':sum(vals)/len(vals) if vals else None,'avg_close_return_pct':sum(closes)/len(closes) if closes else None}

def littobot_performance_snapshot():
    with LITTOBOT_PERF_LOCK: data=copy.deepcopy(_littobot_load())
    data['days']=sorted((data.get('days') or []),key=lambda x:str(x.get('date') or ''),reverse=True)
    return {'ok':True,'summary':_littobot_summary(data),'days':data['days'][:90],'source':'LITTO BOT 독립 TOP1 · 익일 일봉은 키움 ka10081'}

def _littobot_clean_pick(row):
    if not isinstance(row,dict): return None
    c=code(row.get('code') or '')
    if not c:return None
    parts=row.get('parts') if isinstance(row.get('parts'),dict) else {}
    return {'code':c,'name':str(row.get('name') or c)[:80],'sector':str(row.get('sector') or '기타')[:100],
            'score':_top5_num(row.get('score')),'entry_price':_top5_num(row.get('entry_price')),
            'value_eok':_top5_num(row.get('value_eok')),
            'reasons':[str(x)[:100] for x in (row.get('reasons') if isinstance(row.get('reasons'),list) else [])[:10]],
            'risks':[str(x)[:100] for x in (row.get('risks') if isinstance(row.get('risks'),list) else [])[:10]],
            'parts':{k:_top5_num(parts.get(k)) for k in ('liquidity','close_quality','momentum','breakout','risk')},'result':None}

def littobot_performance_save(payload):
    row=payload.get('row') if isinstance(payload,dict) else None
    if not isinstance(row,dict): raise ValueError('저장할 라이또봇 종목이 없습니다.')
    day=str(payload.get('date') or datetime.now(KST).date().isoformat())[:10]
    try: datetime.strptime(day,'%Y-%m-%d')
    except Exception: raise ValueError('저장 날짜 형식이 올바르지 않습니다.')
    clean=_littobot_clean_pick(row)
    if not clean: raise ValueError('라이또봇 종목코드가 없습니다.')
    challenger=_littobot_clean_pick(payload.get('challenger')) if isinstance(payload,dict) else None
    with LITTOBOT_PERF_LOCK:
        data=_littobot_load(); days=[x for x in (data.get('days') or []) if str(x.get('date') or '')!=day]
        item={'date':day,'saved_at':datetime.now(KST).isoformat(),'row':clean}
        if challenger:item['challenger']=challenger
        days.append(item); data={'version':2,'days':sorted(days,key=lambda x:str(x.get('date') or ''))}; _littobot_save(data)
    # Creating a challenger is automatic, promotion is never automatic.
    try: ai_evolve.maybe_propose(littobot_performance_snapshot())
    except Exception: pass
    return littobot_performance_snapshot()

def _littobot_resolve_pick(client,day,r,bars_cache):
    if not isinstance(r,dict):return False
    if isinstance(r.get('result'),dict) and (r.get('result') or {}).get('next_date'):return False
    c=code(r.get('code') or '')
    if not c:return False
    if c not in bars_cache:
        raw=_kiwoom_call(client.daily_history_rows,c,80,kind='chart')
        bars_cache[c]=sorted([daily_bar(x) for x in raw if daily_bar(x).get('date')],key=lambda x:x['date'])
    bars=bars_cache[c]
    same=next((b for b in bars if b.get('date')==day),None); nxt=next((b for b in bars if str(b.get('date') or '')>day),None)
    if not same or not nxt:return False
    entry=_top5_num(same.get('close')); op=_top5_num(nxt.get('open')); hi=_top5_num(nxt.get('high')); lo=_top5_num(nxt.get('low')); cl=_top5_num(nxt.get('close'))
    if not entry or entry<=0 or not all(v is not None and v>0 for v in (op,hi,lo,cl)):return False
    ret=lambda v:(float(v)/entry-1.0)*100.0
    r['entry_price']=entry; r['result']={'next_date':nxt.get('date'),'open':op,'high':hi,'low':lo,'close':cl,'open_gap_pct':ret(op),'max_return_pct':ret(hi),'min_return_pct':ret(lo),'close_return_pct':ret(cl),'hit2':ret(hi)>=2.0,'hit4':ret(hi)>=4.0,'close_positive':ret(cl)>0,'updated_at':datetime.now(KST).isoformat()}
    return True

def littobot_performance_refresh(max_days=5):
    with LOCK: client=STATE.get('client')
    if not client: raise ValueError('키움 API 연결이 필요합니다.')
    today=datetime.now(KST).date().isoformat()
    with LITTOBOT_PERF_LOCK: data=_littobot_load(); days=copy.deepcopy(data.get('days') or [])
    pending=[]
    for d in sorted(days,key=lambda x:str(x.get('date') or ''),reverse=True):
        day=str(d.get('date') or '')
        if day>=today:continue
        main=d.get('row') if isinstance(d.get('row'),dict) else None
        ch=d.get('challenger') if isinstance(d.get('challenger'),dict) else None
        need_main=main and (not isinstance(main.get('result'),dict) or not (main.get('result') or {}).get('next_date'))
        need_ch=ch and (not isinstance(ch.get('result'),dict) or not (ch.get('result') or {}).get('next_date'))
        if need_main or need_ch: pending.append(d)
    targets={str(d.get('date')) for d in pending[:max(1,min(int(max_days or 5),10))]}; updated=0; errors=[]; bars_cache={}
    for d in days:
        day=str(d.get('date') or '')
        if day not in targets:continue
        for key in ('row','challenger'):
            r=d.get(key)
            if not isinstance(r,dict):continue
            try:
                if _littobot_resolve_pick(client,day,r,bars_cache): updated+=1
            except Exception as e: errors.append(f"{key}:{code(r.get('code') or '')}: {str(e)[:80]}")
    with LITTOBOT_PERF_LOCK: data={'version':2,'days':sorted(days,key=lambda x:str(x.get('date') or ''))}; _littobot_save(data)
    try: ai_evolve.maybe_propose({'days':days})
    except Exception: pass
    snap=littobot_performance_snapshot(); snap.update({'updated_picks':updated,'errors':errors[:10],'evolve':ai_evolve.status({'days':days},auto_propose=True)}); return snap

def _load_last_orderbooks():
    try:
        if ORDERBOOK_LAST_FILE.exists():
            raw=json.loads(ORDERBOOK_LAST_FILE.read_text(encoding='utf-8'))
            return raw if isinstance(raw,dict) else {}
    except Exception:
        pass
    return {}

def _save_last_orderbook(stock_code,payload):
    c=code(stock_code) if stock_code else ''
    if not c or not isinstance(payload,dict): return
    asks=[x for x in (payload.get('asks') or []) if isinstance(x,dict) and float(x.get('price') or 0)>0]
    bids=[x for x in (payload.get('bids') or []) if isinstance(x,dict) and float(x.get('price') or 0)>0]
    if not asks and not bids: return
    with ORDERBOOK_LAST_LOCK:
        cache=_load_last_orderbooks()
        keep={k:payload.get(k) for k in ('asks','bids','ask_total','bid_total','orderbook_time','venue','market_code','source') if k in payload}
        keep['saved_at']=datetime.now(KST).isoformat()
        cache[c]=keep
        try:
            ORDERBOOK_LAST_FILE.parent.mkdir(parents=True,exist_ok=True)
            tmp=ORDERBOOK_LAST_FILE.with_suffix('.tmp')
            tmp.write_text(json.dumps(cache,ensure_ascii=False),encoding='utf-8')
            tmp.replace(ORDERBOOK_LAST_FILE)
        except Exception:
            pass

def _get_last_orderbook(stock_code,max_days=7):
    c=code(stock_code) if stock_code else ''
    if not c:return None
    with ORDERBOOK_LAST_LOCK:
        row=_load_last_orderbooks().get(c)
    if not isinstance(row,dict):return None
    try:
        saved=datetime.fromisoformat(str(row.get('saved_at') or ''))
        if saved.tzinfo is None:saved=saved.replace(tzinfo=KST)
        if datetime.now(KST)-saved>timedelta(days=max_days):return None
    except Exception:
        return None
    return row


# Stock-name master/cache -------------------------------------------------------
# Ranking APIs may legitimately return only a stock code.  Keep a process-wide
# name cache fed by the full Kiwoom universe and, for genuinely unknown codes,
# resolve them asynchronously so the 2-second rank loop never blocks.
STOCK_NAME_CACHE_FILE=ROOT/'data'/'stock_name_cache.json'
STOCK_MASTER_DAILY_FILE=ROOT/'data'/'stock_master_daily_refresh.json'
STOCK_MASTER_DAILY_LOCK=threading.RLock()
STOCK_MASTER_DAILY_RUNNING=False
STOCK_NAME_LOCK=threading.RLock()
STOCK_NAME_PENDING=set()
STOCK_NAME_Q=queue.Queue(maxsize=256)
try:
    STOCK_NAME_CACHE={str(k).zfill(6):str(v).strip() for k,v in json.loads(STOCK_NAME_CACHE_FILE.read_text(encoding='utf-8')).items() if str(v).strip()} if STOCK_NAME_CACHE_FILE.exists() else {}
except Exception:
    STOCK_NAME_CACHE={}
for _c,_row in list(LOOKUP.items()):
    _n=str((_row or {}).get('name') or '').strip() if isinstance(_row,dict) else ''
    if _n and _n!=_c: STOCK_NAME_CACHE[_c]=_n

def _save_stock_name_cache():
    try:
        with STOCK_NAME_LOCK: payload=dict(STOCK_NAME_CACHE)
        tmp=STOCK_NAME_CACHE_FILE.with_suffix('.tmp')
        tmp.write_text(json.dumps(payload,ensure_ascii=False,sort_keys=True),encoding='utf-8')
        tmp.replace(STOCK_NAME_CACHE_FILE)
    except Exception:
        pass

def _cache_stock_name(stock_code,name):
    c=code(stock_code) if stock_code else ''
    n=str(name or '').strip()
    if not c or not n or n==c or (n.isdigit() and code(n)==c): return False
    changed=False
    with STOCK_NAME_LOCK:
        if STOCK_NAME_CACHE.get(c)!=n:
            STOCK_NAME_CACHE[c]=n;changed=True
    # Also enrich the in-memory master used throughout LITTO.
    row=LOOKUP.get(c)
    if isinstance(row,dict): row['name']=n
    elif c: LOOKUP[c]={'code':c,'name':n}
    return changed

def _queue_stock_name_lookup(stock_code):
    c=code(stock_code) if stock_code else ''
    if not c:return
    with STOCK_NAME_LOCK:
        if c in STOCK_NAME_CACHE or c in STOCK_NAME_PENDING:return
        STOCK_NAME_PENDING.add(c)
    try:STOCK_NAME_Q.put_nowait(c)
    except queue.Full:
        with STOCK_NAME_LOCK:STOCK_NAME_PENDING.discard(c)

def _stock_name_lookup_worker():
    while True:
        c=STOCK_NAME_Q.get()
        try:
            with LOCK: client=STATE.get('client')
            if not client:
                continue
            # Quote lookup is light and usually includes the provider stock name.
            q=_kiwoom_call(client.quote,c,'SOR',kind='name')
            n=(q.get('name') or q.get('stk_nm') or '').strip() if isinstance(q,dict) else ''
            if n:
                if _cache_stock_name(c,n): _save_stock_name_cache()
        except Exception:
            pass
        finally:
            with STOCK_NAME_LOCK: STOCK_NAME_PENDING.discard(c)
            STOCK_NAME_Q.task_done()

def _refresh_stock_name_master_worker(client):
    """Refresh the full listed-code -> name master and return success metadata."""
    global UNIVERSE,LOOKUP
    rows=_kiwoom_call(client.universe,kind='name_master')
    if not rows:
        return {'ok':False,'rows':0,'added':0,'changed_names':0}

    old_codes=set(LOOKUP.keys())
    changed=False
    for r in rows:
        if not isinstance(r,dict):continue
        rawc=r.get('code') or r.get('stk_cd') or r.get('stock_code')
        if not rawc:continue
        c=code(rawc)
        n=str(r.get('name') or r.get('stk_nm') or r.get('stock_name') or '').strip()
        if c and n:
            changed=_cache_stock_name(c,n) or changed

    # Merge into a separate map first. Never clear the live master during refresh.
    by={code(x.get('code')):dict(x) for x in (UNIVERSE or []) if isinstance(x,dict) and x.get('code')}
    for r in rows:
        if not isinstance(r,dict):continue
        rawc=r.get('code') or r.get('stk_cd') or r.get('stock_code')
        if not rawc:continue
        c=code(rawc);base=by.get(c,{})
        base.update({k:v for k,v in r.items() if v not in (None,'')})
        base['code']=c
        if STOCK_NAME_CACHE.get(c):base['name']=STOCK_NAME_CACHE[c]
        by[c]=base

    UNIVERSE=list(by.values())
    LOOKUP={x['code']:x for x in UNIVERSE if x.get('code')}
    if changed:_save_stock_name_cache()
    return {
        'ok':True,
        'rows':len(rows),
        'added':len(set(LOOKUP.keys())-old_codes),
        'changed_names':1 if changed else 0,
    }


def _stock_master_daily_last_date():
    try:
        raw=json.loads(STOCK_MASTER_DAILY_FILE.read_text(encoding='utf-8'))
        return str(raw.get('date') or '')
    except Exception:
        return ''


def _mark_stock_master_daily_success(day,result):
    try:
        STOCK_MASTER_DAILY_FILE.parent.mkdir(parents=True,exist_ok=True)
        tmp=STOCK_MASTER_DAILY_FILE.with_suffix('.tmp')
        tmp.write_text(json.dumps({
            'date':day,
            'updated_at':datetime.now(KST).isoformat(),
            'rows':int((result or {}).get('rows') or 0),
            'added':int((result or {}).get('added') or 0),
            'source':'Kiwoom ka10099'
        },ensure_ascii=False,indent=2),encoding='utf-8')
        tmp.replace(STOCK_MASTER_DAILY_FILE)
    except Exception:
        pass


def _start_daily_stock_master_refresh(client):
    """Run ka10099 once after the first successful login of each KST day."""
    global STOCK_MASTER_DAILY_RUNNING
    if not client:return False
    day=datetime.now(KST).date().isoformat()
    with STOCK_MASTER_DAILY_LOCK:
        if STOCK_MASTER_DAILY_RUNNING:return False
        if _stock_master_daily_last_date()==day:return False
        STOCK_MASTER_DAILY_RUNNING=True

    def worker():
        global STOCK_MASTER_DAILY_RUNNING
        try:
            result=_refresh_stock_name_master_worker(client)
            if result.get('ok'):
                _mark_stock_master_daily_success(day,result)
                STATE['progress']=f"종목DB 일일 업데이트 완료 · {result.get('rows',0):,}종목 확인 · 신규 {result.get('added',0):,}개"
        except Exception as ex:
            try:STATE['progress']='종목DB 일일 업데이트 실패 · 다음 로그인 때 재시도 · '+str(ex)[:180]
            except Exception:pass
        finally:
            with STOCK_MASTER_DAILY_LOCK:
                STOCK_MASTER_DAILY_RUNNING=False

    threading.Thread(target=worker,daemon=True,name='litto-daily-stock-master').start()
    return True

threading.Thread(target=_stock_name_lookup_worker,daemon=True,name='litto-name-resolver').start()

NEWS_CACHE={}
NEWS_CACHE_TTL=120

# On-demand investor flow popup cache.  This feature is intentionally detached
# from the Page-1 live loop: provider calls happen only when the user clicks a
# stock name, so the frozen 2-second scanner remains untouched.
INVESTOR_FLOW_CACHE={}
INVESTOR_FLOW_CACHE_TTL=60

ORDERBOOK_STATIC_WARM_LOCK=threading.RLock()
ORDERBOOK_STATIC_WARMING=set()
def _warm_orderbook_static(client,stock_code):
    c=code(stock_code)
    if not c:return
    with ORDERBOOK_STATIC_WARM_LOCK:
        if c in ORDERBOOK_STATIC_WARMING:return
        ORDERBOOK_STATIC_WARMING.add(c)
    def worker():
        try:
            static=client.domestic_orderbook(c,'SOR')
            static['_ts']=time.time()
            cache=getattr(client,'_orderbook_rest_cache',{})
            if not isinstance(cache,dict):cache={}
            cache[c]=dict(static);client._orderbook_rest_cache=cache
        except Exception:
            pass
        finally:
            with ORDERBOOK_STATIC_WARM_LOCK:ORDERBOOK_STATIC_WARMING.discard(c)
    threading.Thread(target=worker,daemon=True,name=f'litto-ob-warm-{c}').start()

def _flow_num(v):
    try:
        if v is None or v=='': return 0.0
        return float(str(v).replace(',','').replace('+',''))
    except Exception:
        return 0.0

FLOW_FLIGHT=SingleFlight()

def investor_flow_snapshot(stock_code,force=False):
    return FLOW_FLIGHT.run((STATE.get('client'),code(stock_code)),lambda:_investor_flow_snapshot(stock_code,force))

def _investor_flow_snapshot(stock_code,force=False):
    c=code(stock_code)
    if not c: raise ValueError('종목코드가 필요합니다.')
    with LOCK: client=STATE.get('client')
    if not client: raise ValueError('키움 API 연결이 필요합니다.')
    now=time.time();cache_key=(client,c);cached=INVESTOR_FLOW_CACHE.get(cache_key)
    if not force and cached and now-cached.get('ts',0)<INVESTOR_FLOW_CACHE_TTL:
        return cached['data']
    # 1051-style investor data: use the official stock-by-investor/institution
    # request (ka10059) first.  It returns the same investor buckets used by
    # Kiwoom's stock investor trend screens.  Keep ka10060 as a compatibility
    # fallback because older LITTO/provider builds may still expose that key.
    body_base={'dt':datetime.now(KST).strftime('%Y%m%d'),'amt_qty_tp':'1','trde_tp':'0','unit_tp':'1000'}
    rows=None;last=None;used_code=None;used_api=None
    for provider_code in (c+'_AL',c):
        try:
            rows=_kiwoom_call(client.rows,'ka10059',{**body_base,'stk_cd':provider_code},'stk_invsr_orgn',12,3,kind='flow')
            used_code=provider_code; used_api='ka10059'
            if rows is not None: break
        except Exception as e:
            last=e
    if rows is None:
        for provider_code in (c+'_AL',c):
            try:
                rows=_kiwoom_call(client.rows,'ka10060',{**body_base,'stk_cd':provider_code},'stk_invsr_orgn_chart',12,3,kind='flow')
                used_code=provider_code; used_api='ka10060'
                if rows is not None: break
            except Exception as e:
                last=e
    if rows is None:
        raise last or ValueError('투자자별 수급 조회에 실패했습니다.')
    # Provider normally returns newest first.  Keep one row per trade date.
    seen=set();days=[]
    fields=('ind_invsr','frgnr_invsr','orgn','fnnc_invt','insrnc','invtrt','etc_fnnc','bank','penfnd_etc','samo_fund','natn','etc_corp','natfor')
    for r in rows:
        d=str(r.get('dt') or '').strip()
        if not d or d in seen: continue
        seen.add(d)
        item={'date':d,'price':abs(_flow_num(r.get('cur_prc'))),'trading_value':abs(_flow_num(r.get('acc_trde_prica')))}
        item.update({k:_flow_num(r.get(k)) for k in fields})
        days.append(item)
        if len(days)>=10: break
    totals={k:sum(float(x.get(k) or 0) for x in days) for k in fields}
    today=days[0] if days else {k:0.0 for k in fields}
    name=_best_known_stock_name(c,LOOKUP.get(c,{}))
    source_name='키움 ka10059 종목별투자자기관별 · 순매수 금액' if used_api=='ka10059' else '키움 ka10060 종목별투자자기관별차트 · 순매수 금액 (호환)'
    data={'code':c,'name':name,'provider_code':used_code,'api_id':used_api,'updated_at':datetime.now(KST).isoformat(),
          'source':source_name,
          'unit':'provider_amount','today':today,'ten_day':totals,'five_day':totals,'days':days}
    INVESTOR_FLOW_CACHE[cache_key]={'ts':time.time(),'data':data}
    while len(INVESTOR_FLOW_CACHE)>256:
        INVESTOR_FLOW_CACHE.pop(next(iter(INVESTOR_FLOW_CACHE)),None)
    return data


# Interest-watchlist program trading cache.
# Robust dual-path strategy:
#  1) ka90004 market-wide program snapshot (SOR integrated first, KRX fallback)
#  2) ka90013 direct per-stock daily program flow for any watched stock not found
PROGRAM_FLOW_CACHE={'ts':0.0,'key':None,'data':None}
PROGRAM_FLOW_CACHE_TTL=60
NXT_ELIGIBILITY_CACHE={'ts':0.0,'rows':{}}
NXT_ELIGIBILITY_CACHE_TTL=21600

def _nxt_enable_bool(v):
    if isinstance(v,bool): return v
    if v is None:return None
    s=str(v).strip().upper()
    if s in ('1','Y','YES','TRUE','T','O','가능','가능함','NXT'):return True
    if s in ('0','N','NO','FALSE','F','X','불가','불가능','KRX'):return False
    try:return bool(int(float(s)))
    except Exception:return None

def stock_venue_snapshot(stock_codes,force=False):
    """Return official ka10099 NXT eligibility for a compact set of stocks.

    No per-stock quote probing is used.  The result comes from Kiwoom's stock
    master (nxtEnable) and is cached for six hours so this label has negligible
    impact on trading/API latency.
    """
    wanted=[]
    for raw in stock_codes or []:
        c=code(raw)
        if c and c not in wanted:wanted.append(c)
    wanted=wanted[:120]
    if not wanted:return {'rows':{},'updated_at':datetime.now(KST).isoformat(),'source':'키움 ka10099 nxtEnable'}
    now=time.time()
    rows_cache=dict(NXT_ELIGIBILITY_CACHE.get('rows') or {})
    missing=[c for c in wanted if c not in rows_cache]
    # First use the already-loaded local stock master.
    for c in list(missing):
        m=LOOKUP.get(c,{}) if isinstance(LOOKUP,dict) else {}
        raw=m.get('nxtEnable') if isinstance(m,dict) else None
        if raw is None and isinstance(m,dict):raw=m.get('nxt_enable')
        b=_nxt_enable_bool(raw)
        if b is not None:
            rows_cache[c]={'nxt':b,'venue':'NXT' if b else 'KRX','source':'ka10099 cache'}
    missing=[c for c in wanted if c not in rows_cache]
    # If this process started before the daily master refresh, load ka10099 once.
    if missing and (force or now-float(NXT_ELIGIBILITY_CACHE.get('ts') or 0)>NXT_ELIGIBILITY_CACHE_TTL or not NXT_ELIGIBILITY_CACHE.get('rows')):
        with LOCK:client=STATE.get('client')
        if client:
            try:
                master=_kiwoom_call(client.universe,kind='name_master') or []
                for r in master:
                    if not isinstance(r,dict):continue
                    c=code(r.get('code') or r.get('stk_cd') or '')
                    if not c:continue
                    b=_nxt_enable_bool(r.get('nxtEnable') if 'nxtEnable' in r else r.get('nxt_enable'))
                    if b is not None:rows_cache[c]={'nxt':b,'venue':'NXT' if b else 'KRX','source':'ka10099 live'}
                NXT_ELIGIBILITY_CACHE['ts']=now
            except Exception:
                pass
    NXT_ELIGIBILITY_CACHE['rows']=rows_cache
    return {'rows':{c:rows_cache.get(c,{'nxt':None,'venue':'-'}) for c in wanted},
            'updated_at':datetime.now(KST).isoformat(),'source':'키움 ka10099 nxtEnable'}

def _program_num(v):
    try:
        if v is None or v=='': return 0.0
        return float(str(v).replace(',','').replace('+','').strip())
    except Exception:
        return 0.0

def _normalize_program_code(raw):
    raw=str(raw or '').strip()
    if raw.endswith('_AL') or raw.endswith('_NX'): raw=raw[:-3]
    if len(raw)==7 and raw.startswith('A') and raw[1:].isdigit(): raw=raw[1:]
    try:return code(raw)
    except Exception:return ''

def _program_rows_direct(client, provider_code, day):
    return _kiwoom_call(
        client.rows,'ka90013',
        {'amt_qty_tp':'1','stk_cd':provider_code,'date':day},
        'stk_daly_prm_trde_trnsn',30,2,kind='flow'
    )

def _program_market_rows(client, day, stex_tp):
    out=[]
    for market_name,mrkt_tp in (('KOSPI','P00101'),('KOSDAQ','P10102')):
        part=_kiwoom_call(
            client.rows,'ka90004',
            {'dt':day,'mrkt_tp':mrkt_tp,'stex_tp':stex_tp},
            'stk_prm_trde_prst',5000,30,kind='flow'
        )
        for r in part:
            c=_normalize_program_code(r.get('stk_cd'))
            if not c: continue
            out.append({
                'code':c,'name':str(r.get('stk_nm') or '').strip(),
                'program_net_eok':_program_num(r.get('netprps_prica'))/100.0,
                'program_buy_eok':_program_num(r.get('buy_cntr_amt'))/100.0,
                'program_sell_eok':_program_num(r.get('sel_cntr_amt'))/100.0,
                'program_trade_ratio':_program_num(r.get('all_trde_rt')),
                'market':market_name,'date':day,'source_api':'ka90004',
                'stex_tp':stex_tp
            })
    return out

def _latest_market_program_day(client):
    now_kst=datetime.now(KST)
    errors=[]
    for back in range(0,8):
        day=(now_kst-timedelta(days=back)).strftime('%Y%m%d')
        # SOR integrated first; some environments/accounts may only support KRX.
        for stex in ('3','1'):
            try:
                rows=_program_market_rows(client,day,stex)
                if rows:return day,rows,errors
            except Exception as e:
                errors.append(f'ka90004 {day} stex={stex}: {str(e)[:180]}')
    return None,[],errors


# Manual watchlist search/live --------------------------------------------------
MANUAL_WATCH_CACHE={}
MANUAL_WATCH_CACHE_LOCK=threading.RLock()
# After the integrated SOR session ends there are no fresh 0B ticks for a
# newly-started LITTO process.  Keep a short REST cache so the watchlist can
# still show Kiwoom's final SOR(_AL) price/change pair instead of falling back
# to a scanner row that may reflect the KRX close.
WATCH_AFTER_CLOSE_SOR_CACHE={}
WATCH_AFTER_CLOSE_SOR_TTL=60.0
# R17 watch quote recovery: never block the HTTP response on a whole watchlist.
WATCH_RESTORE_LOCK=threading.RLock()
WATCH_RESTORE_PENDING=set()
WATCH_RESTORE_NEXT={}
WATCH_RESTORE_QUEUE=None

def _watch_restore_schedule(client, stock_code, now_ts):
    """Queue one low-priority broker quote; the HTTP thread never waits on it."""
    global WATCH_RESTORE_QUEUE
    import queue
    with WATCH_RESTORE_LOCK:
        if stock_code in WATCH_RESTORE_PENDING or now_ts < WATCH_RESTORE_NEXT.get(stock_code,0):
            return
        if WATCH_RESTORE_QUEUE is None:
            WATCH_RESTORE_QUEUE=queue.Queue(maxsize=120)
            threading.Thread(target=_watch_restore_worker,daemon=True,name='litto-watch-restore').start()
        try:
            WATCH_RESTORE_QUEUE.put_nowait((client,stock_code))
        except queue.Full:
            return
        WATCH_RESTORE_PENDING.add(stock_code)
        WATCH_RESTORE_NEXT[stock_code]=now_ts+WATCH_AFTER_CLOSE_SOR_TTL

def _watch_restore_worker():
    while True:
        client,c=WATCH_RESTORE_QUEUE.get()
        try:
            # Shared Kiwoom throttle and lock are deliberately retained.
            quote=_kiwoom_call(client.quote,c,'SOR',kind='light')
            if isinstance(quote,dict) and float(quote.get('price') or 0)>0:
                with WATCH_RESTORE_LOCK:
                    WATCH_AFTER_CLOSE_SOR_CACHE[c]={'ts':time.time(),'quote':dict(quote)}
        except Exception:
            pass
        finally:
            with WATCH_RESTORE_LOCK:
                WATCH_RESTORE_PENDING.discard(c)
            WATCH_RESTORE_QUEUE.task_done()

# Broker-only, bounded fallback for watch symbols without a usable 0B tick.
WATCH_MISSING_QUOTE_NEXT={}
WATCH_MISSING_QUOTE_LOCK=threading.RLock()
WATCH_MISSING_QUOTE_TTL=90.0
WATCH_MISSING_QUOTE_WINDOW=[0.0,0]

def stock_search_snapshot(query,limit=20):
    q=str(query or '').strip()
    if not q:return {'query':'','rows':[]}
    qlow=q.lower()
    rows=[]
    seen=set()
    # Prefer full stock-name master/cache, then the in-memory universe.
    with STOCK_NAME_LOCK:
        items=list(STOCK_NAME_CACHE.items())
    for c,n in items:
        code6=code(c)
        name=str(n or '').strip()
        if not code6 or not name: continue
        if qlow in code6.lower() or qlow in name.lower():
            if code6 in seen: continue
            seen.add(code6); rows.append({'code':code6,'name':name})
    for c,row in LOOKUP.items():
        code6=code(c); name=str((row or {}).get('name') or '').strip()
        if not code6 or not name or code6 in seen: continue
        if qlow in code6.lower() or qlow in name.lower():
            seen.add(code6); rows.append({'code':code6,'name':name})
    # If the local name master has not finished loading yet, do one synchronous
    # Kiwoom master refresh and retry. This makes manual watch search work for
    # stocks that never appeared in the scanner (e.g. NAVER, 광전자).
    if not rows:
        with LOCK: client=STATE.get('client')
        if client:
            try:
                master=_kiwoom_call(client.universe,kind='name_master_search') or []
                changed=False
                for r in master:
                    if not isinstance(r,dict):
                        continue
                    rawc=r.get('code') or r.get('stk_cd') or r.get('stock_code')
                    if not rawc:
                        continue
                    c=code(rawc)
                    n=str(r.get('name') or r.get('stk_nm') or r.get('stock_name') or '').strip()
                    if c and n:
                        changed=_cache_stock_name(c,n) or changed
                if changed:
                    _save_stock_name_cache()
                # Retry against the freshly loaded full market master.
                with STOCK_NAME_LOCK:
                    items=list(STOCK_NAME_CACHE.items())
                for c,n in items:
                    code6=code(c); name=str(n or '').strip()
                    if not code6 or not name or code6 in seen:
                        continue
                    if qlow in code6.lower() or qlow in name.lower():
                        seen.add(code6); rows.append({'code':code6,'name':name})
            except Exception:
                pass

    # Exact 6-digit code fallback: resolve directly from Kiwoom when connected.
    if q.isdigit() and len(q)==6 and q not in seen:
        with LOCK: client=STATE.get('client')
        if client:
            try:
                qt=_kiwoom_call(client.quote,q,kind='light')
                n=str(qt.get('name') or '').strip()
                if n:
                    _cache_stock_name(q,n); rows.insert(0,{'code':q,'name':n})
            except Exception:
                pass
    # Exact/prefix matches first.
    def rank(r):
        c=r['code']; n=r['name']; nl=n.lower()
        if c==q:return (0,n)
        if nl==qlow:return (1,n)
        if c.startswith(q):return (2,n)
        if nl.startswith(qlow):return (3,n)
        return (4,n)
    rows=sorted(rows,key=rank)[:max(1,min(int(limit or 20),50))]
    try:
        mapping=sectors.load()
    except Exception:
        mapping={}
    for r in rows:
        m=mapping.get(r['code'],{}) if isinstance(mapping,dict) else {}
        r['sector']=str((m or {}).get('sector') or LOOKUP.get(r['code'],{}).get('sector') or '기타')
        r['watched']=None  # requires a live browser watchlist snapshot
    return {'query':q,'rows':rows,'count':len(rows)}

def manual_watch_live_snapshot(stock_codes,force=False):
    codes=[]
    for raw in stock_codes or []:
        c=code(raw)
        if c and c not in codes:codes.append(c)
    codes=codes[:30]
    with LOCK: client=STATE.get('client')
    if not client: raise ValueError('키움 API 연결이 필요합니다.')
    try:mapping=sectors.load()
    except Exception:mapping={}
    out=[];errors={}
    now=time.time()
    for c in codes:
        cached=None
        with MANUAL_WATCH_CACHE_LOCK:
            cached=MANUAL_WATCH_CACHE.get(c)
        if cached and not force and now-cached.get('ts',0)<30:
            out.append(dict(cached['data']));continue
        try:
            name=_best_known_stock_name(c,LOOKUP.get(c,{}))
            q=_kiwoom_call(client.quote,c,kind='light')
            if q.get('name'):name=q['name'];_cache_stock_name(c,name)
            sector=str((mapping.get(c,{}) or {}).get('sector') or LOOKUP.get(c,{}).get('sector') or '기타')
            detail=_kiwoom_call(client.stock,c,name,sector,kind='heavy')
            # Stocks manually added to the watchlist may never appear in the
            # scanner universe.  Derive the trading-value total from the latest
            # provider daily bar so the watch card has the same information as
            # scanner-originated stocks without estimating money from price*volume.
            value_eok=None
            daily_rows=detail.get('daily') if isinstance(detail,dict) else None
            if isinstance(daily_rows,list):
                for bar in reversed(daily_rows):
                    try:
                        raw_value=bar.get('value') if isinstance(bar,dict) else None
                        if raw_value is not None and float(raw_value)>0:
                            value_eok=float(raw_value)/100_000_000.0
                            break
                    except (TypeError,ValueError):
                        pass
            data={**detail,'code':c,'name':name,'sector':sector,'price':q.get('price'),'change':q.get('change'),'venue':q.get('venue'),'value_eok':value_eok,'manual_watch':True}
            with MANUAL_WATCH_CACHE_LOCK: MANUAL_WATCH_CACHE[c]={'ts':now,'data':data}
            out.append(data)
        except Exception as e:
            errors[c]=str(e)
    return {'rows':out,'errors':errors,'updated_at':datetime.now(KST).isoformat()}



def watch_realtime_snapshot(stock_codes):
    """Integrated watchlist quote snapshot.

    During the 08:00~20:00 SOR session, the shared Kiwoom 0B WebSocket stays
    authoritative.  Before 08:00 and after 20:00 a process started from scratch
    has no same-day 0B ticks, so we restore the final integrated SOR(_AL)
    price/change pair from ka10001 REST with a short cache.  This prevents a
    stale scanner/KRX close from becoming the watchlist percentage fallback.
    """
    codes=[]
    for raw in stock_codes or []:
        c=code(raw)
        if c and c not in codes:
            codes.append(c)
    codes=codes[:120]
    with LOCK:
        client=STATE.get('client')
    if not client:
        raise ValueError('키움 API 연결이 필요합니다.')

    feed=getattr(client,'_domestic_realtime_feed',None)
    if feed is None:
        feed=DomesticRealtimeFeed(client)
        client._domestic_realtime_feed=feed
    feed.ensure(codes,owner='watch')
    live,rt=feed.snapshot()

    now_dt=datetime.now(KST)
    hm=now_dt.hour*60+now_dt.minute
    after_close=(hm>=20*60 or hm<8*60)
    now_ts=time.time()
    rows={}

    for c in codes:
        # Outside the SOR session, deliberately prefer the broker's integrated
        # _AL REST snapshot.  A retained/stale WebSocket tick or scanner row must
        # not downgrade the watchlist back to a KRX-only percentage.
        if after_close and not bool(getattr(client,'mock',False)):
            with WATCH_RESTORE_LOCK:
                cached=WATCH_AFTER_CLOSE_SOR_CACHE.get(c)
            q=cached.get('quote') if isinstance(cached,dict) else None
            # Expired cache remains visible until broker supplies a fresh pair.
            if not cached or now_ts-float(cached.get('ts') or 0)>=WATCH_AFTER_CLOSE_SOR_TTL:
                _watch_restore_schedule(client,c,now_ts)
            if isinstance(q,dict) and float(q.get('price') or 0)>0:
                price=q.get('price')
                rate=q.get('change')
                base=q.get('base_price')
                if rate is None and base:
                    try:
                        if float(base)>0:rate=(float(price)/float(base)-1)*100
                    except (TypeError,ValueError,ZeroDivisionError):pass
                if rate is not None:
                    rows[c]={'code':c,'price':price,'change':rate,'change_rate':rate,
                             'received_at':cached.get('ts'),'venue':q.get('venue') or 'SOR',
                             'source':'Kiwoom REST ka10001 SOR(_AL) 장마감 통합값'}
                    continue
            # Paired live feed can be used until a broker SOR close is restored.
            live_q=live.get(c) or {}
            if live_q.get('price') is not None and live_q.get('change_rate') is not None:
                rows[c]={'code':c,'price':live_q['price'],'change':live_q['change_rate'],
                         'change_rate':live_q['change_rate'],'received_at':live_q.get('received_at'),
                         'source':'Kiwoom WebSocket 0B 실시간'}
            continue

        q=live.get(c) or {}
        # A current price without a rate is not enough for the watchlist.
        # Retrieve a PAIRED SOR quote at most once per 90s per missing symbol;
        # never substitute a scanner percentage or mix two quote sources.
        if q.get('price') is None or q.get('change_rate') is None:
            with WATCH_MISSING_QUOTE_LOCK:
                next_at=WATCH_MISSING_QUOTE_NEXT.get(c,0)
                if now_ts-WATCH_MISSING_QUOTE_WINDOW[0]>=2.0:
                    WATCH_MISSING_QUOTE_WINDOW[:]=[now_ts,0]
                if now_ts>=next_at and WATCH_MISSING_QUOTE_WINDOW[1]<4:
                    WATCH_MISSING_QUOTE_NEXT[c]=now_ts+WATCH_MISSING_QUOTE_TTL
                    WATCH_MISSING_QUOTE_WINDOW[1]+=1
                    do_rest=True
                else:
                    do_rest=False
            if do_rest:
                try:
                    rq=_kiwoom_call(client.quote,c,'SOR',kind='light')
                    if isinstance(rq,dict) and rq.get('price') is not None:
                        WATCH_AFTER_CLOSE_SOR_CACHE[c]={'ts':now_ts,'quote':dict(rq)}
                except Exception:
                    pass
            cached=WATCH_AFTER_CLOSE_SOR_CACHE.get(c) or {}
            rq=cached.get('quote') if now_ts-float(cached.get('ts') or 0)<WATCH_MISSING_QUOTE_TTL else None
            if isinstance(rq,dict) and rq.get('price') is not None:
                price=rq.get('price');rate=rq.get('change')
                base=rq.get('base_price')
                if rate is None and base is not None:
                    try:
                        if float(base)>0:rate=(float(price)/float(base)-1)*100
                    except (TypeError,ValueError,ZeroDivisionError):pass
                if rate is not None:
                    rows[c]={'code':c,'price':price,'change':rate,'change_rate':rate,
                             'base_price':base,'source':'Kiwoom REST ka10001 SOR quote fallback',
                             'received_at':now_ts}
                    continue
        if not q:
            continue
        rows[c]={
            'code':c,
            'price':q.get('price'),
            'change':q.get('change_rate'),
            'change_rate':q.get('change_rate'),
            'open':q.get('open'),'high':q.get('high'),'low':q.get('low'),
            'acc_volume':q.get('acc_volume'),'time':q.get('time'),
            'received_at':q.get('received_at'),
            'venue':q.get('venue'),
            'market_item':q.get('market_item'),
            'source':'Kiwoom WebSocket 0B 실시간'
        }
    return {'rows':rows,'realtime':rt,'after_close_restored':after_close,
            'updated_at':now_dt.isoformat()}

def program_flow_watch_snapshot(stock_codes=None,force=False):
    now=time.time()
    wanted=[]
    for raw in stock_codes or []:
        c=_normalize_program_code(raw)
        if c and c not in wanted:wanted.append(c)
    if not wanted:
        return {'rows':{},'updated_at':datetime.now(KST).isoformat(),'data_date':None,
                'source':'키움 프로그램매매 이중조회','errors':[],'failed_codes':[]}

    cache_key=tuple(sorted(wanted))
    cached=PROGRAM_FLOW_CACHE.get('data')
    if (not force and cached and PROGRAM_FLOW_CACHE.get('key')==cache_key and
        now-float(PROGRAM_FLOW_CACHE.get('ts') or 0)<PROGRAM_FLOW_CACHE_TTL):
        return cached

    with LOCK: client=STATE.get('client')
    if not client: raise ValueError('키움 API 연결이 필요합니다.')

    errors=[]; by_code={}; data_date=None

    # Path 1: market-wide snapshot.  This is efficient and gives every stock in one pass.
    day, market_rows, market_errors=_latest_market_program_day(client)
    errors.extend(market_errors)
    if day:
        data_date=day
        for r in market_rows:
            if r['code'] in wanted:
                # Prefer SOR integrated row if both SOR and KRX happen to be present.
                old=by_code.get(r['code'])
                if old is None or str(r.get('stex_tp'))=='3': by_code[r['code']]=r

    # Path 2: directly query only the stocks missing from ka90004.
    missing=[c for c in wanted if c not in by_code]
    if missing:
        # If ka90004 could not resolve a trading date at all, probe dates directly.
        probe_days=[]
        if data_date: probe_days=[data_date]
        else:
            now_kst=datetime.now(KST)
            probe_days=[(now_kst-timedelta(days=i)).strftime('%Y%m%d') for i in range(0,8)]
        for c in missing:
            got=None
            for d in probe_days:
                for provider_code in (c+'_AL',c):
                    try:
                        rows=_program_rows_direct(client,provider_code,d)
                        if not rows: continue
                        chosen=next((r for r in rows if str(r.get('dt') or '').strip()==d),rows[0])
                        row_day=str(chosen.get('dt') or d).strip()
                        got={
                            'code':c,'name':'',
                            'program_net_eok':_program_num(chosen.get('prm_netprps_amt'))/100.0,
                            'program_buy_eok':_program_num(chosen.get('prm_buy_amt'))/100.0,
                            'program_sell_eok':_program_num(chosen.get('prm_sell_amt'))/100.0,
                            'program_trade_ratio':None,
                            'market':'SOR' if provider_code.endswith('_AL') else 'KRX',
                            'date':row_day,'source_api':'ka90013','provider_code':provider_code
                        }
                        if not data_date:data_date=row_day
                        break
                    except Exception as e:
                        errors.append(f'ka90013 {c} {provider_code} {d}: {str(e)[:180]}')
                if got is not None: break
            if got is not None: by_code[c]=got

    failed=[c for c in wanted if c not in by_code]
    data={'rows':by_code,'updated_at':datetime.now(KST).isoformat(),
          'data_date':data_date,
          'source':'키움 프로그램매매 · ka90004 시장전체 + ka90013 종목직접 이중조회',
          'requested_codes':wanted,'returned_codes':list(by_code.keys()),
          'failed_codes':failed,'errors':errors[-60:]}
    PROGRAM_FLOW_CACHE['ts']=now;PROGRAM_FLOW_CACHE['key']=cache_key;PROGRAM_FLOW_CACHE['data']=data
    return data

# PAGE1 provider-call gate ------------------------------------------------------
# All Kiwoom REST calls used by the Page-1 live engine pass through this gate.
# Heavy scanning releases the gate between individual requests, so 2-second rank
# refreshes and lookup ranking can continue to make progress during a full scan.
# Scanner admission is bounded; orders and ordinary quote requests retain the
# existing serialized gate path. This does not interrupt any in-flight request.
from contextlib import contextmanager

@contextmanager
def _api_gate_entry(kind):
    if kind == 'heavy':
        obtained=API_GATE_LOCK.acquire(timeout=3.0)
        if not obtained:
            raise ApiError('검색 API 게이트 대기 초과 (3초): 이번 조회를 건너뜁니다.')
        try:
            yield
        finally:
            API_GATE_LOCK.release()
    else:
        with API_GATE_LOCK:
            yield

API_GATE_LOCK=threading.RLock()
API_GATE_STATUS_LOCK=threading.RLock()
API_GATE_STATE={'calls':0,'errors':0,'rate_errors':0,'backoff_until':0.0,
                'backoff_seconds':0.0,'last_call_at':0.0,'last_error':'','last_kind':'',
                'active_kind':'','active_since':0.0,'waiting':0,'last_wait_ms':0.0,
                'max_wait_ms':0.0,'last_call_ms':0.0,'max_call_ms':0.0,
                'slow_calls':0,'slow_waits':0}

def _is_rate_error(exc):
    t=str(exc or '').lower()
    return any(x in t for x in ('429','rate','too many','초과','제한','호출 횟수','과도'))

def _kiwoom_call(fn,*args,kind='light',**kwargs):
    """Serialize provider requests. Observability only: never timeout/retry orders."""
    queued_at=time.monotonic()
    with API_GATE_STATUS_LOCK:
        API_GATE_STATE['waiting']+=1
    acquired=False
    try:
        while True:
            with _api_gate_entry(kind):
                if not acquired:
                    acquired=True
                    waited_ms=(time.monotonic()-queued_at)*1000
                    with API_GATE_STATUS_LOCK:
                        API_GATE_STATE['waiting']-=1
                        API_GATE_STATE['last_wait_ms']=round(waited_ms,1)
                        API_GATE_STATE['max_wait_ms']=max(API_GATE_STATE['max_wait_ms'],round(waited_ms,1))
                        if waited_ms>3000:API_GATE_STATE['slow_waits']+=1
                with API_GATE_STATUS_LOCK:
                    wait=max(0.0,API_GATE_STATE['backoff_until']-time.time())
                if wait<=0:
                    started=time.monotonic()
                    with API_GATE_STATUS_LOCK:
                        API_GATE_STATE['active_kind']=str(kind)[:60]
                        API_GATE_STATE['active_since']=time.time()
                    try:
                        out=fn(*args,**kwargs)
                        with API_GATE_STATUS_LOCK:
                            API_GATE_STATE['calls']+=1
                            API_GATE_STATE['last_call_at']=time.time()
                            API_GATE_STATE['last_kind']=kind
                            API_GATE_STATE['backoff_seconds']/=2.0
                        return out
                    except Exception as e:
                        with API_GATE_STATUS_LOCK:
                            API_GATE_STATE['errors']+=1
                            API_GATE_STATE['last_error']=str(e)[:300]
                            API_GATE_STATE['last_kind']=kind
                            if _is_rate_error(e):
                                API_GATE_STATE['rate_errors']+=1
                                prev=API_GATE_STATE['backoff_seconds']
                                delay=2.0 if prev<2 else min(prev*2,8.0)
                                API_GATE_STATE.update(backoff_seconds=delay,backoff_until=time.time()+delay)
                        raise
                    finally:
                        elapsed_ms=(time.monotonic()-started)*1000
                        with API_GATE_STATUS_LOCK:
                            API_GATE_STATE['last_call_ms']=round(elapsed_ms,1)
                            API_GATE_STATE['max_call_ms']=max(API_GATE_STATE['max_call_ms'],round(elapsed_ms,1))
                            if elapsed_ms>3000:API_GATE_STATE['slow_calls']+=1
                            API_GATE_STATE['active_kind']=''
                            API_GATE_STATE['active_since']=0.0
            time.sleep(min(wait,0.5))
    finally:
        if not acquired:
            with API_GATE_STATUS_LOCK:API_GATE_STATE['waiting']-=1

def _api_gate_status():
    with API_GATE_STATUS_LOCK:
        return {**API_GATE_STATE,'active_seconds':round(max(0.0,time.time()-API_GATE_STATE['active_since']),1) if API_GATE_STATE['active_since'] else 0.0,'backoff_remaining':max(0.0,API_GATE_STATE['backoff_until']-time.time())}

PAGE1_RUNTIME_CACHE=ROOT/'data'/'page1_runtime_cache.json'

def _save_page1_runtime_cache():
    try:
        now=datetime.now(KST)
        with LOCK:
            payload={'saved_at':now.isoformat(),'session_date':now.date().isoformat(),'data':STATE.get('data'),
                     'ranks':STATE.get('ranks'),'settings':STATE.get('settings'),'market':STATE.get('market'),
                     'scan_options':STATE.get('scan_options')}
        tmp=PAGE1_RUNTIME_CACHE.with_suffix('.tmp')
        tmp.write_text(json.dumps(payload,ensure_ascii=False),encoding='utf-8')
        tmp.replace(PAGE1_RUNTIME_CACHE)
    except Exception:
        pass

def _restore_page1_runtime_cache():
    try:
        if not PAGE1_RUNTIME_CACHE.exists(): return False
        raw=json.loads(PAGE1_RUNTIME_CACHE.read_text(encoding='utf-8'))
        saved=datetime.fromisoformat(raw.get('saved_at'))
        if saved.tzinfo is None:
            saved=saved.replace(tzinfo=KST)
        now=datetime.now(KST)
        saved_day=saved.astimezone(KST).date().isoformat()
        today=now.date().isoformat()
        age_days=(now.date()-saved.astimezone(KST).date()).days
        if age_days < 0 or age_days > 4: return False
        data=raw.get('data'); ranks=raw.get('ranks')
        if not isinstance(data,dict) or not isinstance(data.get('stocks'),list): return False

        # PAGE1 runtime cache is only authoritative for the same KST trading date.
        # A prior-date cache may still be useful for settings/history, but must never
        # feed today's scanner formulas. Otherwise stale formula_quotes/base_price,
        # rank_quotes or old daily bars can make < +1% rows pass the closing formula.
        same_session=(saved_day==today and str(raw.get('session_date') or saved_day)==today)
        with LOCK:
            if same_session:
                STATE['data']=data
                if isinstance(ranks,dict): STATE['ranks']=ranks
            else:
                # Restore only non-market preferences. Session-sensitive market data
                # starts empty and is repopulated from today's Kiwoom responses.
                STATE['data']={'stocks':[]}
                STATE['ranks']={
                    'value_top':[], 'value_rank_map':{}, 'change_top':[],
                    'today_limit':[], 'prev_limit':[], 'quotes':{},
                    'formula_quotes':{}, 'rank_quotes':{},
                    'source':f'이전 거래일 캐시 차단 · {saved_day} 저장본',
                }
                STATE['fetch_errors']=[]
            if isinstance(raw.get('settings'),dict): STATE['settings']=config(raw.get('settings'))
            if raw.get('market') in ('unknown','weak','strong','mixed'): STATE['market']=raw.get('market')
            if isinstance(raw.get('scan_options'),dict): STATE['scan_options']=raw.get('scan_options')
            recompute()
            restored_report=copy.deepcopy(STATE.get('report') or {})
            STATE['progress']=('오늘 마지막 1페이지 상태 복구 완료 · 실시간 재연결 대기' if same_session else f"이전 거래일 캐시 차단 완료 · {saved_day} 저장본은 검색식에 사용하지 않음 · 오늘 데이터 대기")
        # 검색 이력은 과거 날짜 자체가 목적이므로, live STATE와 분리해 보존한다.
        try:
            screener_history.import_report_once(restored_report,saved_day,saved.astimezone(KST).isoformat())
        except Exception:
            pass
        return True
    except Exception:
        return False


# --- KRX market-action auto board -------------------------------------------------
# The public collector keeps only market-action notices that link back to KIND.
# It is intentionally isolated from the Newheart search formulas and trading logic.
MARKET_ACTION_CACHE_TTL=300
MARKET_ACTION_HISTORY=ROOT/'data'/'market_actions_clean_v3.json'
MARKET_ACTION_MEMORY={'at':0.0,'payload':None}
MARKET_ACTION_FEEDS=[
    # KRX-linked disclosure stream. Pages are walked backwards so a fresh install
    # can reconstruct enough history for 1~10 trading-day boards.
    'https://t.me/s/darthacking',
]

# Official KIND is collected in parallel as a completeness source.
# The Telegram/KRX-linked feed is still preferred whenever it supplies an
# explicit action/effective date, because the board's day counter is based on
# the action date, not simply on the disclosure submission date.
MARKET_ACTION_KIND_REPORT_TERMS=(
    '투자경고', '투자위험', '단기과열', '매매거래정지 예고',
)

# Regression fixture supplied by the user for 2026-09-16. It is used only when
# the live history is incomplete or disagrees with the verified same-day board.
# Future dates are never populated from this fixture.
MARKET_ACTION_REFERENCE_DATE='2026-09-18'
MARKET_ACTION_REFERENCE={
 'risk_designated':[],
 'halt_preview':[('좋은사람들',10,'투자위험예고')],
 'short_overheat_designated':[('에스엠벡셀',3,'단기과열 지정'),('드림시큐리티',3,'단기과열 지정')],
 'warning_release_judgment':[('엑시콘',10,'투자경고 해제 판단일')],
 'warning_preview_judgment':[],
 'short_preview_judgment':[],
 'warning_designated':[
   ('아이티센피엔에스',1,'투자경고 지정'),('인피니트헬스케어',1,'투자경고 지정'),
   ('샌즈랩',2,'투자경고 지정'),('한국첨단소재',2,'투자경고 지정'),('빛과전자',2,'투자경고 지정'),
   ('카티스',2,'투자경고 지정'),('타이거일렉',2,'투자경고 지정'),
   ('피에스케이홀딩스',3,'투자경고 지정'),('페니트리움바이오',4,'투자경고 지정'),
   ('키다리스튜디오',6,'투자경고 지정'),('테스',6,'투자경고 지정'),('서산',6,'투자경고 지정'),
   ('티에스이',6,'투자경고 지정'),('아이앤씨',7,'투자경고 지정'),('피델릭스',7,'투자경고 지정'),
   ('파두',8,'투자경고 지정')],
 'warning_preview':[
   ('아티스트컴퍼니',1,'투자경고 지정예고'),('한켐',1,'투자경고 지정예고'),
   ('미투온',1,'투자경고 지정예고'),('에이치엠넥스',1,'투자경고 지정예고'),('큐라티스',1,'투자경고 지정예고'),
   ('인텍플러스',2,'투자경고 지정예고'),
   ('한국첨단소재',3,'투자경고 지정예고'),('광전자',3,'투자경고 지정예고'),('삼익제약',3,'투자경고 지정예고'),
   ('카티스',4,'투자경고 지정예고'),('에스투더블유',4,'투자경고 지정예고'),
   ('알파칩스',5,'투자경고 지정예고'),('마이크로컨텍솔',5,'투자경고 지정예고'),
   ('테라뷰',6,'투자경고 지정예고'),('씨싸이트',6,'투자경고 지정예고'),
   ('신스틸',7,'투자경고 지정예고'),('삼미금속',7,'투자경고 지정예고'),('키다리스튜디오',7,'투자경고 지정예고'),
   ('유진테크',9,'투자경고 지정예고'),('삼익제약',9,'투자경고 지정예고'),('좋은사람들',9,'투자경고 지정예고')],
 'short_overheat_preview':[
   ('인벤테라',1,'단기과열 지정예고'),('동국산업',1,'단기과열 지정예고'),
   ('한컴위드',2,'단기과열 지정예고'),('지니언스',2,'단기과열 지정예고'),
   ('아이티센피엔에스',2,'단기과열 지정예고'),('인피니트헬스케어',2,'단기과열 지정예고'),
   ('아티스트컴퍼니',3,'단기과열 지정예고'),('라온시큐어',3,'단기과열 지정예고'),
   ('에스피소프트',4,'단기과열 지정예고'),('샌즈랩',4,'단기과열 지정예고'),
   ('에스투더블유',4,'단기과열 지정예고'),('엑스게이트',4,'단기과열 지정예고'),
   ('피아이이',5,'단기과열 지정예고'),('범한퓨얼셀',5,'단기과열 지정예고'),
   ('우리로',5,'단기과열 지정예고'),('엑스비스',5,'단기과열 지정예고'),
   ('우리기술',6,'단기과열 지정예고'),('씨싸이트',7,'단기과열 지정예고'),
   ('오르비텍',7,'단기과열 지정예고'),('한전기술',7,'단기과열 지정예고'),('라온피플',9,'단기과열 지정예고')]
}

# 2026-09-18 TODAY REPORT is the verified baseline.
# From the next trading day onward these rows roll forward automatically as event anchors.
MARKET_ACTION_VERIFIED_ADDITIONS={
 '2026-09-29':{
   # 9/29 user-verified reference anchors.  These are event anchors only; future
   # sessions continue to roll forward from the normal trading-day engine.
   'warning_designated':[
      ('토마토시스템',1,'투자경고종목 지정'),('씨씨에스',2,'투자경고종목 지정')],
   'warning_preview':[
      ('쓰리빌리언',1,'[투자주의]투자경고종목 지정예고'),
      ('인피니트헬스케어',2,'[투자주의]투자경고종목 지정예고')],
   'short_overheat_preview':[
      ('SH에너지화학',1,'(예고)단기과열종목 지정예고'),
      ('동국생명과학',1,'(예고)단기과열종목 지정예고'),
      ('지씨지놈',1,'(예고)단기과열종목 지정예고'),
      ('케이쓰리아이',2,'(예고)단기과열종목 지정예고'),
      ('토마토시스템',2,'(예고)단기과열종목 지정예고'),
      ('대한F&B',4,'(예고)단기과열종목 지정예고')],
   'warning_preview_judgment':[
      ('테일패스',10,'[투자주의]투자경고종목 지정예고')],
   'halt_preview':[
      ('씨씨에스',1,'매매거래정지 예고')],
 }
}

def _prev_trade_day(d):
    cur=d-timedelta(days=1)
    while not _is_trade_day(cur): cur-=timedelta(days=1)
    return cur

def _notice_date_from_asof_day(asof_text,day_no):
    """Reverse the board's trading-day counter back to the source notice date.

    A notice published on D becomes day-1 on the next trading day.
    """
    try:
        asof=datetime.strptime(str(asof_text),'%Y-%m-%d').date()
        n=max(1,int(day_no))
    except Exception:return ''
    day1=asof
    # Move backwards through trading days until we reach the day-1 session.
    left=n-1
    while left>0:
        day1=_prev_trade_day(day1);left-=1
    return _prev_trade_day(day1).isoformat()

def _verified_market_action_seed_rows():
    rows=[]
    # Promote the manually verified 09/16 board into durable event history.
    event_cats={'risk_designated','short_overheat_designated',
                'warning_designated','warning_preview','short_overheat_preview'}
    for cat,items in MARKET_ACTION_REFERENCE.items():
        if cat not in event_cats: continue
        for name,day,title in items:
            rows.append({'name':name,'code':_stock_code_by_name(name),
                         'date':_notice_date_from_asof_day(MARKET_ACTION_REFERENCE_DATE,day),
                         'title':title,'category':cat,'url':'','verified_seed':True,'date_role':'published'})
    # Add later user-verified new notices. Day counters will roll forward automatically.
    for asof,groups in MARKET_ACTION_VERIFIED_ADDITIONS.items():
        for cat,items in groups.items():
            for name,day,title in items:
                rows.append({'name':name,'code':_stock_code_by_name(name),
                             'date':_notice_date_from_asof_day(asof,day),
                             'title':title,'category':cat,'url':'','verified_seed':True,'date_role':'published'})
    return rows

def _strip_html_text(x):
    import html as _html
    x=re.sub(r'(?i)<br\s*/?>','\n',str(x or ''))
    x=re.sub(r'<[^>]+>',' ',x)
    x=_html.unescape(x)
    x=x.replace('\xa0',' ')
    x=re.sub(r'[ \t]+',' ',x)
    x=re.sub(r'\n\s+','\n',x)
    return x.strip()

def _kind_link_from_block(block):
    import html as _html
    for m in re.finditer(r'href=["\']([^"\']+)["\']',block or '',re.I):
        u=_html.unescape(m.group(1))
        if 'kind.krx.co.kr/common/disclsviewer.do' in u:
            return u.replace('&amp;','&')
    m=re.search(r'https://kind\.krx\.co\.kr/common/disclsviewer\.do\?[^\s<"\']+',block or '',re.I)
    return _html.unescape(m.group(0)).replace('&amp;','&') if m else ''

def _market_action_category(title):
    """Normalize KIND market-action notice titles into state-transition events."""
    t=re.sub(r'\s+','',str(title or ''))
    # Explicit trading-halt notices take priority over words such as
    # '투자경고종목 지정중' embedded in the halt title.
    if '매매거래정지' in t:
        if '예고' in t:
            return 'halt_preview'
        return 'halt_triggered'
    # 투자경고
    if '투자경고종목' in t:
        if '해제' in t or '해제예고' in t or '지정해제' in t:
            return 'warning_release'
        if '지정예고' in t or '재지정예고' in t:
            return 'warning_preview'
        if '지정' in t and '예고' not in t:
            return 'warning_designated'
    # 투자위험
    if '투자위험종목' in t:
        if '해제' in t or '지정해제' in t:
            return 'risk_release'
        if '지정예고' in t or '재지정예고' in t:
            return 'risk_preview'
        if '지정' in t and '예고' not in t:
            return 'risk_designated'
    # 단기과열
    if '단기과열종목' in t or '단기과열' in t:
        if '해제' in t or '종료' in t:
            return 'short_release'
        if '지정예고' in t or ('예고' in t and '지정' in t):
            return 'short_overheat_preview'
        if '지정' in t and '예고' not in t:
            return 'short_overheat_designated'
    return ''


def _market_action_categories(title):
    """Return visible state transitions represented by one notice title.

    Important: '지정해제 및 재지정 예고' is a release/re-designation notice,
    not a fresh ordinary '지정예고'.  Treating it as both release + preview was
    the main cause of the 1-day preview explosion after the close.
    """
    t=re.sub(r'\s+','',str(title or ''))
    if '투자경고종목' in t and ('지정해제' in t or '해제' in t) and ('재지정예고' in t or '재지정' in t):
        return ['warning_release']
    if '투자위험종목' in t and ('지정해제' in t or '해제' in t) and ('재지정예고' in t or '재지정' in t):
        return ['risk_release']
    one=_market_action_category(title)
    return [one] if one else []


# KRX trading calendar ----------------------------------------------------------
# Source of truth: Korea Exchange (KRX) official holiday schedule.
# We no longer infer exchange holidays from a generic Korean public-holiday feed.
# KRX data is fetched through the official Open KRX holiday page's OTP endpoint,
# then cached on disk.  A known-good cache is preserved across temporary outages.
KRX_TRADE_CALENDAR_CACHE=ROOT/'data'/'krx_trade_calendar_official.json'
_KRX_CAL_LOCK=threading.RLock()
_KRX_CAL_MEM={'years':{},'loaded':False}
_KRX_HOLIDAY_PAGE='https://open.krx.co.kr/contents/MKD/01/0110/01100305/MKD01100305.jsp'
_KRX_OTP_URL='https://open.krx.co.kr/contents/COM/GenerateOTP.jspx'
_KRX_VIEW_URL='https://open.krx.co.kr/contents/OPN/99/OPN99000001.jspx'
_KRX_HOLIDAY_BLD='MKD/01/0110/01100305/mkd01100305_01'


def _load_krx_calendar_cache():
    with _KRX_CAL_LOCK:
        if _KRX_CAL_MEM.get('loaded'):
            return _KRX_CAL_MEM
        try:
            raw=json.loads(KRX_TRADE_CALENDAR_CACHE.read_text(encoding='utf-8'))
            years=raw.get('years',{}) if isinstance(raw,dict) else {}
            if isinstance(years,dict): _KRX_CAL_MEM['years']=years
        except Exception:
            pass
        _KRX_CAL_MEM['loaded']=True
        return _KRX_CAL_MEM


def _save_krx_calendar_cache():
    try:
        KRX_TRADE_CALENDAR_CACHE.parent.mkdir(parents=True,exist_ok=True)
        tmp=KRX_TRADE_CALENDAR_CACHE.with_suffix('.tmp')
        with _KRX_CAL_LOCK:
            data={'updated_at':datetime.now(KST).isoformat(),'years':_KRX_CAL_MEM.get('years',{})}
        tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
        tmp.replace(KRX_TRADE_CALENDAR_CACHE)
    except Exception:
        pass


def _parse_krx_holiday_dates(payload,year):
    """Parse the official KRX holiday JSON response into ISO dates."""
    out=set(); year=int(year)
    rows=[]
    if isinstance(payload,dict):
        for key in ('block1','output','OutBlock_1','result'):
            val=payload.get(key)
            if isinstance(val,list): rows.extend(val)
        if not rows:
            for val in payload.values():
                if isinstance(val,list) and val and isinstance(val[0],dict): rows.extend(val)
    elif isinstance(payload,list): rows=payload
    for row in rows:
        if not isinstance(row,dict): continue
        # Current/legacy KRX responses use calnd_dd_dy.  Keep tolerant fallbacks
        # because KRX occasionally renames display columns.
        vals=[row.get('calnd_dd_dy'),row.get('calnd_dd'),row.get('date'),row.get('trd_dd')]
        text=' '.join(str(x or '') for x in vals)
        m=re.search(r'(20\d{2})[-./]?(\d{2})[-./]?(\d{2})',text)
        if not m: continue
        y,mo,dd=map(int,m.groups())
        if y==year:
            try: out.add(datetime(y,mo,dd).date().isoformat())
            except Exception: pass
    return out


def _fetch_krx_official_holidays(year):
    """Fetch KRX's own market holiday table using the official OTP workflow."""
    year=int(year); err=[]
    ua='Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 LITTO-KRXCalendar/1.0'
    try:
        q=urlencode({'bld':_KRX_HOLIDAY_BLD,'name':'form','_':str(int(time.time()*1000))})
        req=Request(_KRX_OTP_URL+'?'+q,headers={
            'User-Agent':ua,'Referer':_KRX_HOLIDAY_PAGE,'Accept':'text/plain,*/*'
        })
        with urlopen(req,timeout=8) as r:
            otp=r.read(20000).decode('utf-8','replace').strip()
        if not otp: raise ValueError('KRX OTP empty')
        body=urlencode({
            'search_bas_yy':str(year),'gridTp':'KRX',
            'pagePath':'/contents/MKD/01/0110/01100305/MKD01100305.jsp',
            'code':otp,'pageFirstCall':'Y'
        }).encode('utf-8')
        req=Request(_KRX_VIEW_URL,data=body,method='POST',headers={
            'User-Agent':ua,'Referer':_KRX_HOLIDAY_PAGE,
            'Origin':'https://open.krx.co.kr',
            'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8',
            'Accept':'application/json,text/javascript,*/*;q=0.8'
        })
        with urlopen(req,timeout=10) as r:
            raw=r.read(2_000_000).decode('utf-8','replace')
        payload=json.loads(raw)
        holidays=_parse_krx_holiday_dates(payload,year)
        if not holidays: raise ValueError('KRX holiday rows empty')
        return holidays,'KRX 공식 휴장일',None
    except Exception as e:
        err.append(str(e))
        return set(),'KRX 공식 휴장일 조회 실패','; '.join(err)


def _krx_calendar_year(year,force=False):
    """Return one year's KRX holiday set. Official KRX -> known-good cache -> degraded fallback."""
    mem=_load_krx_calendar_cache(); key=str(int(year)); now=time.time()
    with _KRX_CAL_LOCK:
        cur=(mem.get('years') or {}).get(key)
        if cur and not force and isinstance(cur.get('holidays'),list):
            try: age=now-float(cur.get('fetched_epoch') or 0)
            except Exception: age=10**9
            # Current year refreshes daily; historical years are effectively immutable.
            ttl=86400 if int(year)==datetime.now(KST).year else 30*86400
            if age<ttl and not cur.get('error'): return cur
    holidays,source,error=_fetch_krx_official_holidays(int(year))
    if holidays:
        cur={'holidays':sorted(holidays),'source':source,'fetched_at':datetime.now(KST).isoformat(),
             'fetched_epoch':now,'error':None,'official':True}
        with _KRX_CAL_LOCK: mem.setdefault('years',{})[key]=cur
        _save_krx_calendar_cache(); return cur
    # Never overwrite a known-good official cache on a temporary network/KRX failure.
    if cur and isinstance(cur.get('holidays'),list) and not cur.get('error'):
        return cur
    # Last-resort mode makes no holiday claim. Weekends are still deterministic;
    # the payload exposes the error so the board never pretends the calendar was verified.
    fallback={'holidays':[],'source':'KRX 공식 조회 대기 (주말만 판정)',
              'fetched_at':datetime.now(KST).isoformat(),'fetched_epoch':now,
              'error':error or 'KRX official holiday fetch unavailable','official':False}
    with _KRX_CAL_LOCK: mem.setdefault('years',{})[key]=fallback
    _save_krx_calendar_cache(); return fallback


def _is_trade_day(d):
    if d.weekday()>=5: return False
    cal=_krx_calendar_year(d.year)
    return d.isoformat() not in set(cal.get('holidays') or [])


def _next_trade_day(d):
    cur=d+timedelta(days=1)
    while not _is_trade_day(cur): cur+=timedelta(days=1)
    return cur


def _krx_calendar_status():
    d=datetime.now(KST).date(); cal=_krx_calendar_year(d.year)
    return {'date':d.isoformat(),'is_trade_day':_is_trade_day(d),'source':cal.get('source'),
            'official':bool(cal.get('official')),'fetched_at':cal.get('fetched_at'),'error':cal.get('error')}

def _market_action_asof_date(now_dt=None):
    """Trading-session date used by the market-action board.

    Day counters roll at midnight, not at 20:00. A disclosure published on D
    becomes day 1 as soon as the next trading date begins (00:00 KST).
    Weekends/holidays never advance the counter; on those dates the board keeps
    the most recent trading session as its as-of date.
    """
    now_dt=now_dt or datetime.now(KST)
    d=now_dt.date()
    while not _is_trade_day(d):
        d-=timedelta(days=1)
    return d

def _trade_day_no_from_effective_date(date_text,today=None):
    """Count trading-session age from the action's effective date, inclusively.

    Important source semantics:
    - The dated lines parsed from the market-action feed are the KRX action/effective
      dates shown in the notice, not the moment the notice was published.
    - A notice published on D for an action effective on the next session therefore
      appears as day 1 on that effective session.

    The previous build treated the feed date as the publication date and advanced it
    one extra trading day. That made every warning/preview age one session too small.
    """
    try: effective=datetime.strptime(date_text,'%Y-%m-%d').date()
    except Exception:return None
    start=effective if _is_trade_day(effective) else _next_trade_day(effective)
    end=today or _market_action_asof_date()
    if start>end:return 0
    cur=start;n=0
    while cur<=end:
        if _is_trade_day(cur):n+=1
        cur+=timedelta(days=1)
    return n

def _trade_day_no_from_notice(date_text,today=None):
    """Backward-compatible alias; feed dates are effective dates in this board."""
    return _trade_day_no_from_effective_date(date_text,today=today)

def _stock_code_by_name(name):
    target=re.sub(r'\s+','',str(name or '')).upper()
    if not target:return ''
    for x in UNIVERSE:
        if re.sub(r'\s+','',str(x.get('name',''))).upper()==target:
            return str(x.get('code',''))
    return ''

MARKET_ACTION_NAME_ALIASES={
    # Historical feed spelling typo. Keep one canonical stock name so judgment
    # cards do not show the same security twice.
    '액스비스':'엑스비스',
}

def _market_action_canonical_name(name):
    raw=' '.join(str(name or '').split()).strip()
    return MARKET_ACTION_NAME_ALIASES.get(raw,raw)

def _market_action_is_preferred_name(name):
    """The comparison report tracks common shares, not preferred-share notices."""
    n=re.sub(r'\s+','',str(name or '')).upper()
    if not n:return False
    return bool(re.search(r'(우|우B|우C|우선주|1우|2우B|3우C)$',n,re.I))

def _market_action_row_allowed(row):
    """Reject rows that are outside the common-share board scope."""
    if not isinstance(row,dict):return False
    name=_market_action_canonical_name(row.get('name',''))
    if not name:return False
    if _market_action_is_preferred_name(name):return False
    title=re.sub(r'\s+','',str(row.get('title','')))
    # Price-disparity short-overheat actions are preferred-share actions even on
    # pages where the company label was normalized to the common-share name.
    if row.get('category') in ('short_overheat_designated','short_overheat_preview') and '가격괴리율' in title:
        return False
    # Some KIND rows use the common-share company label but the notice itself targets
    # a preferred share, e.g. '(삼성전기우)'.  Exclude those from the common-share board.
    if re.search(r'\([^)]*(?:우|우B|우C|우선주|1우|2우B|3우C)\)', str(row.get('title','')), re.I):
        return False
    # Kiwoom's live universe contains KOSPI/KOSDAQ only.  Restrict only the
    # investment-risk card here; other market-action rows can still be hydrated
    # from collected KIND history even before the stock master is ready.
    if row.get('category')=='risk_designated' and not (row.get('code') or _stock_code_by_name(name)):
        return False
    return True

def _load_market_action_history():
    try:
        obj=json.loads(MARKET_ACTION_HISTORY.read_text(encoding='utf-8'))
        rows=obj.get('rows',[]) if isinstance(obj,dict) else []
        return rows if isinstance(rows,list) else []
    except Exception:return []

def _save_market_action_history(rows):
    try:
        MARKET_ACTION_HISTORY.parent.mkdir(parents=True,exist_ok=True)
        tmp=MARKET_ACTION_HISTORY.with_suffix('.tmp')
        tmp.write_text(json.dumps({'updated_at':datetime.now(KST).isoformat(),'rows':rows},ensure_ascii=False,indent=2),encoding='utf-8')
        tmp.replace(MARKET_ACTION_HISTORY)
    except Exception:pass

def _parse_market_action_feed(html_text):
    blocks=re.split(r'(?=<div[^>]+class=["\'][^"\']*tgme_widget_message_wrap)',html_text or '',flags=re.I)
    if len(blocks)<=1: blocks=re.split(r'(?=단기과열/투자경고\s*종목\s*현황)',html_text or '',flags=re.I)
    out=[]
    for block in blocks:
        text=_strip_html_text(block)
        if not any(k in text for k in ('투자경고','투자위험','단기과열','매매거래정지')): continue
        name_m=re.search(r'종목명\s*:\s*([^\n]+?)(?=\s*\d{4}-\d{2}-\d{2}\s*:)',text,re.S)
        if not name_m: continue
        name=' '.join(name_m.group(1).split()).strip(' -:')
        kind_url=_kind_link_from_block(block)
        # A row without a real KIND disclosure is not allowed to drive this board.
        if 'kind.krx.co.kr/' not in str(kind_url or ''):
            continue
        for m in re.finditer(r'(\d{4}-\d{2}-\d{2})\s*:\s*([^\n]+)',text):
            d,title=m.group(1),m.group(2).strip()
            title=re.split(r'공시링크\s*:',title,maxsplit=1)[0].strip()
            cats=_market_action_categories(title)
            for cat in cats:
                out.append({'name':name,'code':_stock_code_by_name(name),'date':d,'published_date':d,'date_role':'published','title':title,'category':cat,'url':kind_url})
    return out

def _telegram_before_cursor(html_text):
    vals=[int(x) for x in re.findall(r'[?&]before=(\d+)',html_text or '')]
    return min(vals) if vals else None

def _fetch_market_action_feed():
    """Fetch enough KRX-linked disclosure history even on a fresh install.

    The prior build read only the newest Telegram page, which made old active states
    disappear and produced wrong day numbers. This version walks older pages and
    stops after enough history has been collected.
    """
    rows=[];seen=set();last_error='';source='https://t.me/s/darthacking';url=source
    for _ in range(12):
        try:
            req=Request(url,headers={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36','Accept-Language':'ko-KR,ko;q=0.9'})
            with urlopen(req,timeout=12) as r:
                raw=r.read(5_000_000);text=_decode_web_bytes(raw,r.headers)
            page=_parse_market_action_feed(text)
            for x in page:
                k=(x.get('name'),x.get('date'),x.get('title'))
                if k not in seen:seen.add(k);rows.append(x)
            # Enough for 10 trading-day boards plus state transitions.
            dates=[x.get('date','') for x in rows if x.get('date')]
            if dates and min(dates) <= (datetime.now(KST).date()-timedelta(days=35)).isoformat():break
            cur=_telegram_before_cursor(text)
            if not cur:break
            nxt=f'{source}?before={cur}'
            if nxt==url:break
            url=nxt
        except Exception as e:
            last_error=str(e);break
    return rows,source,last_error if not rows else ''

def _kind_halt_preview_rows(days=21):
    """Fetch official KIND disclosures whose report title contains '매매거래정지 예고'.

    This collector is intentionally isolated from the existing market-action feed.
    Any KIND layout/network failure returns an empty list and NEVER breaks the
    rest of the market-action board.
    """
    endpoint='https://kind.krx.co.kr/disclosure/details.do'
    end=datetime.now(KST).date()
    start=end-timedelta(days=max(7,int(days or 21)))
    params={
        'method':'searchDetailsSub','forward':'details_sub',
        'currentPageSize':'100','pageIndex':'1','orderMode':'1','orderStat':'D',
        'searchCodeType':'','repIsuSrtCd':'','allRepIsuSrtCd':'','oldSearchCorpName':'',
        'disclosureType':'','disTypevalue':'','reportNm':'매매거래정지 예고','reportCd':'',
        'searchCorpName':'','business':'','marketType':'','kosdaqSegment':'',
        'settlementMonth':'','securities':'','submitOblgNm':'','enterprise':'',
        'reportNmTemp':'','reportNmPop':'','bfrDsclsType':'on',
        'fromDate':start.isoformat(),'toDate':end.isoformat(),
    }
    for cat in ('01','02','03','04','05','06','07','08','09','10','11','13','14','20'):
        params[f'disclosureType{cat}']=''
        params[f'pDisclosureType{cat}']=''
    try:
        req=Request(endpoint,data=urlencode(params).encode('utf-8'),headers={
            'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36',
            'Referer':'https://kind.krx.co.kr/disclosure/details.do?method=searchDetailsMain',
            'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8',
            'Accept-Language':'ko-KR,ko;q=0.9,en;q=0.6',
        },method='POST')
        with urlopen(req,timeout=12) as r:
            raw=r.read(5_000_000); html_text=_decode_web_bytes(raw,r.headers)
    except Exception:
        return [],endpoint,''

    rows=[];seen=set()
    # Details result rows are stable: No / time / company / title / submitter (+ chart).
    for tr in re.findall(r'<tr\b[^>]*>(.*?)</tr>',html_text or '',re.I|re.S):
        cells=re.findall(r'<td\b[^>]*>(.*?)</td>',tr,re.I|re.S)
        if len(cells)<5: continue
        time_text=_strip_html_text(cells[1])
        company=_strip_html_text(cells[2])
        title=_strip_html_text(cells[3])
        title_compact=re.sub(r'\s+','',title)
        if '매매거래정지예고' not in title_compact: continue
        if any(k in title_compact for k in ('투자경고종목','투자위험종목','단기과열종목')): continue
        # Company cell may include market icon alt text; anchor text is cleaner.
        am=re.search(r'<a\b[^>]*>(.*?)</a>',cells[2],re.I|re.S)
        if am:
            company=_strip_html_text(am.group(1))
        company=_market_action_canonical_name(' '.join(str(company or '').split()).strip())
        if not company or _market_action_is_preferred_name(company): continue
        # KIND may render YYYY-MM-DD HH:MM or MM-DD HH:MM depending on view.
        dm=re.search(r'(20\d{2})[-./](\d{1,2})[-./](\d{1,2})',time_text)
        if dm:
            d=f'{dm.group(1)}-{int(dm.group(2)):02d}-{int(dm.group(3)):02d}'
        else:
            dm=re.search(r'(\d{1,2})[-./](\d{1,2})',time_text)
            if not dm: continue
            y=end.year
            d=f'{y}-{int(dm.group(1)):02d}-{int(dm.group(2)):02d}'
        acpt=''
        mm=re.search(r"openDisclsViewer\('?(\d{10,})",cells[3],re.I)
        if mm: acpt=mm.group(1)
        url=(f'https://kind.krx.co.kr/common/disclsviewer.do?method=search&acptno={acpt}' if acpt else endpoint)
        key=(company,d,title)
        if key in seen: continue
        seen.add(key)
        rows.append({'name':company,'code':_stock_code_by_name(company),'date':d,'published_date':d,'date_role':'published',
                     'title':title,'category':'halt_preview','url':url,'kind_official':True})
    return rows,endpoint,''


def _kind_market_action_rows(days=45):
    """Collect market-action disclosures directly from KIND as a completeness source.

    Important:
    - These rows expose the disclosure submission date, so day 1 starts on the
      *next trading session* (the user-visible board rule: 오늘 공시 -> 다음 거래일 1일차).
    - If the KRX-linked feed has the same KIND disclosure with an explicit
      action/effective date, that feed row wins during merge.
    - Any network/layout failure is isolated and returns the rows collected so far.
    """
    endpoint='https://kind.krx.co.kr/disclosure/details.do'
    end=datetime.now(KST).date()
    start=end-timedelta(days=max(14,int(days or 45)))
    all_rows=[]; seen=set(); errors=[]

    base_params={
        'method':'searchDetailsSub','forward':'details_sub',
        'currentPageSize':'100','pageIndex':'1','orderMode':'1','orderStat':'D',
        'searchCodeType':'','repIsuSrtCd':'','allRepIsuSrtCd':'','oldSearchCorpName':'',
        'disclosureType':'','disTypevalue':'','reportCd':'',
        'searchCorpName':'','business':'','marketType':'','kosdaqSegment':'',
        'settlementMonth':'','securities':'','submitOblgNm':'','enterprise':'',
        'reportNmTemp':'','reportNmPop':'','bfrDsclsType':'on',
        'fromDate':start.isoformat(),'toDate':end.isoformat(),
    }
    for cat in ('01','02','03','04','05','06','07','08','09','10','11','13','14','20'):
        base_params[f'disclosureType{cat}']=''
        base_params[f'pDisclosureType{cat}']=''

    for term in MARKET_ACTION_KIND_REPORT_TERMS:
        params=dict(base_params); params['reportNm']=term
        try:
            req=Request(endpoint,data=urlencode(params).encode('utf-8'),headers={
                'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36',
                'Referer':'https://kind.krx.co.kr/disclosure/details.do?method=searchDetailsMain',
                'Content-Type':'application/x-www-form-urlencoded; charset=UTF-8',
                'Accept-Language':'ko-KR,ko;q=0.9,en;q=0.6',
            },method='POST')
            with urlopen(req,timeout=12) as r:
                raw=r.read(5_000_000); html_text=_decode_web_bytes(raw,r.headers)
        except Exception as e:
            errors.append(f'{term}: {e}')
            continue

        for tr in re.findall(r'<tr\b[^>]*>(.*?)</tr>',html_text or '',re.I|re.S):
            cells=re.findall(r'<td\b[^>]*>(.*?)</td>',tr,re.I|re.S)
            if len(cells)<5: continue
            time_text=_strip_html_text(cells[1])
            company=_strip_html_text(cells[2])
            title=_strip_html_text(cells[3])
            cats=_market_action_categories(title)
            if not cats: continue

            am=re.search(r'<a\b[^>]*>(.*?)</a>',cells[2],re.I|re.S)
            if am: company=_strip_html_text(am.group(1))
            company=_market_action_canonical_name(' '.join(str(company or '').split()).strip())
            if not company or _market_action_is_preferred_name(company): continue

            dm=re.search(r'(20\d{2})[-./](\d{1,2})[-./](\d{1,2})',time_text)
            if dm:
                d=f'{dm.group(1)}-{int(dm.group(2)):02d}-{int(dm.group(3)):02d}'
            else:
                dm=re.search(r'(\d{1,2})[-./](\d{1,2})',time_text)
                if not dm: continue
                d=f'{end.year}-{int(dm.group(1)):02d}-{int(dm.group(2)):02d}'

            acpt=''
            mm=re.search(r"openDisclsViewer\('?([0-9]{10,})",cells[3],re.I)
            if mm: acpt=mm.group(1)
            url=(f'https://kind.krx.co.kr/common/disclsviewer.do?method=search&acptno={acpt}' if acpt else endpoint)
            time_m=re.search(r'(\d{1,2}:\d{2})',time_text)
            published_time=time_m.group(1) if time_m else ''
            for cat in cats:
                key=(company,d,cat,acpt or re.sub(r'\s+','',title))
                if key in seen: continue
                seen.add(key)
                all_rows.append({
                    'name':company,'code':_stock_code_by_name(company),
                    'date':d,'published_date':d,'published_time':published_time,
                    'date_role':'published','title':title,'category':cat,
                    'url':url,'kind_official':True,
                })
    return all_rows,endpoint,'; '.join(errors)


def _normalize_market_action_rows(row):
    """Normalize one disclosure into one or more clean state-transition events.

    The disclosure title is authoritative. Old cached category/effective_date
    fields are not trusted. Combined notices such as "지정해제 및 재지정 예고"
    intentionally expand to both release and preview transitions.
    """
    if not isinstance(row,dict): return []
    base=dict(row)
    base['name']=_market_action_canonical_name(base.get('name',''))
    if not base.get('name'): return []
    title=str(base.get('title','')).strip()
    cats=_market_action_categories(title)
    if not cats:
        cat=str(base.get('category','')).strip()
        cats=[cat] if cat else []
    out=[]
    for cat in cats:
        x=dict(base); x['category']=cat
        if not x.get('code'): x['code']=_stock_code_by_name(x.get('name',''))
        role=str(x.get('date_role') or '').strip().lower()
        explicit_effective=(role=='effective' and bool(x.get('date')))
        if explicit_effective:
            x['date_role']='effective'
            if x.get('date'): x['effective_date']=x.get('effective_date') or x.get('date')
        else:
            # Feed/KIND/cache dates are disclosure publication dates unless a
            # detail parser has explicitly supplied an effective/action date.
            x['date_role']='published'; x.pop('effective_date',None)
        x.pop('day_no',None)
        if _market_action_row_allowed(x): out.append(x)
    return out


def _market_action_identity(x):
    """Stable event identity after title-based normalization."""
    if not isinstance(x,dict): return ('','','','')
    url=str(x.get('url','')); acpt=''
    m=re.search(r'acptno=(\d{10,})',url)
    if m: acpt=m.group(1)
    name=re.sub(r'\s+','',str(x.get('name','')))
    cat=str(x.get('category',''))
    title=re.sub(r'\s+','',str(x.get('title','')))
    if acpt: return ('acpt',acpt,cat,name)
    return ('fallback',name,cat,str(x.get('date',''))+'|'+title)


def _merge_market_action_rows(*sources):
    """Normalize/merge events; effective-date rows outrank publication-date rows."""
    merged={}
    for source in sources:
        for raw in source or []:
            for x in _normalize_market_action_rows(raw):
                ident=_market_action_identity(x); old=merged.get(ident)
                if old is None:
                    merged[ident]=dict(x); continue
                old_eff=str(old.get('date_role',''))=='effective'
                new_eff=str(x.get('date_role',''))=='effective'
                if new_eff and not old_eff:
                    merged[ident]=dict(x)
                elif new_eff==old_eff:
                    score=lambda r:(bool(r.get('url')),bool(r.get('code')),bool(r.get('published_time')))
                    if score(x)>score(old): merged[ident]={**old,**x}
    return list(merged.values())

def _latest_family_event(events, cats):
    cand=[x for x in events if x.get('category') in cats]
    if not cand:return None
    return max(cand,key=lambda x:(x.get('date',''),x.get('title','')))

def _today_market_action_groups(rows):
    """Build the existing 9 cards from disclosure-state transitions only."""
    by_stock={}
    for x in rows:
        if not isinstance(x,dict): continue
        x=dict(x)
        x['name']=_market_action_canonical_name(x.get('name',''))
        if not x.get('code') and x.get('name'):
            x['code']=_stock_code_by_name(x['name'])
        if not _market_action_row_allowed(x):
            continue
        name=str(x.get('name','')).strip()
        if name:
            by_stock.setdefault(name,[]).append(x)

    groups={k:[] for k in (
        'risk_designated','halt_preview','short_overheat_designated',
        'warning_release_judgment','warning_preview_judgment','short_preview_judgment',
        'warning_designated','warning_preview','short_overheat_preview')}

    def latest_any(events,cat):
        cand=[x for x in events if x.get('category')==cat]
        return max(cand,key=lambda x:(x.get('date',''),x.get('title',''))) if cand else None
    def newer(a,b):
        return bool(a and (not b or str(a.get('date',''))>str(b.get('date',''))))
    def active_day(x,max_day=10):
        try:n=int((x or {}).get('day_no') or 0)
        except Exception:return False
        return 1<=n<=max_day

    # 거래정지 예고는 day_no==1인 공시들 중 가장 최근 공시일 배치만 유효하다.
    # 긴 연휴 직전 공시와 연휴 중 새 공시가 모두 같은 next-trading-day를
    # 가리킬 수 있으므로, 가장 최신 공시일을 우선해야 한다.
    halt_day1_dates=[str(x.get('date','')) for x in rows
                     if isinstance(x,dict) and x.get('category')=='halt_preview'
                     and int(x.get('day_no') or 0)==1 and _market_action_row_allowed(x)]
    latest_halt_day1=max(halt_day1_dates) if halt_day1_dates else ''

    for name,events in by_stock.items():
        events=sorted(events,key=lambda x:(x.get('date',''),x.get('title',''),x.get('category','')))

        # 투자경고: preview -> designation -> release.
        wp=latest_any(events,'warning_preview')
        wd=latest_any(events,'warning_designated')
        wr=latest_any(events,'warning_release')

        # Preview remains active only until a later designation OR release/re-designation
        # notice supersedes it.  Older builds ignored release notices here, so stale
        # previews accumulated in the card for many sessions.
        if (wp and active_day(wp,10)
                and (not wd or str(wp.get('date',''))>str(wd.get('date','')))
                and (not wr or str(wp.get('date',''))>str(wr.get('date','')))):
            if int(wp.get('day_no') or 0)==10:
                groups['warning_preview_judgment'].append(wp)
            else:
                groups['warning_preview'].append(wp)

        if wd and active_day(wd,10) and newer(wd,wr):
            if int(wd.get('day_no') or 0)==10:
                groups['warning_release_judgment'].append(wd)
            else:
                groups['warning_designated'].append(wd)

        # 투자위험.
        rd=latest_any(events,'risk_designated')
        rr=latest_any(events,'risk_release')
        if rd and active_day(rd,10) and newer(rd,rr):
            groups['risk_designated'].append(rd)

        # 단기과열: preview -> designation(3 trading sessions) -> release.
        sp=latest_any(events,'short_overheat_preview')
        sd=latest_any(events,'short_overheat_designated')
        sr=latest_any(events,'short_release')

        # Warning and short-overheat measures can coexist.  A later investment-warning
        # designation must not implicitly erase a still-active short-overheat preview;
        # only a short-overheat designation/release supersedes that preview.
        if sp and active_day(sp,10) and (not sd or str(sp.get('date',''))>str(sd.get('date',''))):
            if int(sp.get('day_no') or 0)==10:
                groups['short_preview_judgment'].append(sp)
            else:
                groups['short_overheat_preview'].append(sp)

        if sd and active_day(sd,3) and newer(sd,sr):
            groups['short_overheat_designated'].append(sd)

        # 거래정지 예고는 다음 거래일 하루만 유효하다. 공시일이 휴일이어도
        # next-trading-date 계산으로 정확히 day_no==1이 된다.
        hp=latest_any(events,'halt_preview')
        ht=latest_any(events,'halt_triggered')
        if (hp and int(hp.get('day_no') or 0)==1
                and latest_halt_day1 and str(hp.get('date',''))==latest_halt_day1
                and (not ht or str(hp.get('date',''))>str(ht.get('date','')))):
            groups['halt_preview'].append(hp)

    for key,items in groups.items():
        uniq={}
        for x in items:
            uniq[x.get('name','')]=x
        items[:]=sorted(uniq.values(),key=lambda x:(int(x.get('day_no') or 0),x.get('name','')))
    return groups


def _reference_groups_for_today():
    today=datetime.now(KST).date().isoformat()
    if today!=MARKET_ACTION_REFERENCE_DATE:return None
    out={}
    for key,items in MARKET_ACTION_REFERENCE.items():
        out[key]=[]
        for name,day,title in items:
            out[key].append({'name':name,'code':_stock_code_by_name(name),'date':today,'day_no':day,'title':title,'category':key,'url':''})
    return out

def _group_signature(groups):
    return {k:[(x.get('name',''),int(x.get('day_no') or 0)) for x in v] for k,v in (groups or {}).items()}

def _hydrate_market_action_links(groups, history_rows=None):
    """Fill missing stock codes/KIND source links without changing market-action membership."""
    history_rows=history_rows or []
    exact={}
    any_by_name={}
    # history is normally newest first; keep the first usable KIND link.
    for r in history_rows:
        if not isinstance(r,dict): continue
        name=str(r.get('name','')).strip(); cat=str(r.get('category','')).strip(); url=str(r.get('url','')).strip()
        if not name or 'kind.krx.co.kr/' not in url: continue
        exact.setdefault((name,cat),url)
        any_by_name.setdefault(name,url)
    for cat,items in (groups or {}).items():
        for x in items or []:
            if not isinstance(x,dict): continue
            name=str(x.get('name','')).strip()
            if not x.get('code') and name:
                x['code']=_stock_code_by_name(name)
            url=str(x.get('url','')).strip()
            if 'kind.krx.co.kr/' not in url and name:
                # Same market-action category is preferred. A same-company KIND notice is only
                # a secondary fallback; the browser still has a company-summary fallback by code.
                x['url']=exact.get((name,cat),'') or any_by_name.get(name,'')
    return groups

def market_actions_snapshot(force=False):
    now=time.time()
    with LOCK:
        cached=MARKET_ACTION_MEMORY.get('payload')
        if cached and not force and now-float(MARKET_ACTION_MEMORY.get('at',0))<MARKET_ACTION_CACHE_TTL:
            cached['groups']=_hydrate_market_action_links(cached.get('groups',{}),_load_market_action_history())
            return cached

    fresh,source_url,error=_fetch_market_action_feed()
    # Clean-v2 history is isolated from every older market-action cache file.
    # This prevents stale test-build categories/effective dates from contaminating
    # the state engine after upgrades.
    previous=_load_market_action_history()
    # Regression fixtures are test-only; live membership comes only from collected KRX/KIND history.
    seed_rows=[]
    try:
        kind_rows,kind_source_url,kind_error=_kind_market_action_rows()
    except Exception as e:
        kind_rows=[];kind_source_url='https://kind.krx.co.kr/';kind_error=str(e)
    try:
        halt_rows,halt_source_url,halt_error=_kind_halt_preview_rows()
    except Exception as e:
        halt_rows=[];halt_source_url='https://kind.krx.co.kr/';halt_error=str(e)

    asof=_market_action_asof_date()

    # Rebuild from the verified historical baseline + clean-v2 cache + live collectors.
    # Old cache files are never imported. Live explicit-effective rows outrank
    # direct KIND publication rows for the same disclosure.
    merged_rows=_merge_market_action_rows(previous,fresh,kind_rows,halt_rows)

    cutoff=asof-timedelta(days=60)
    rows=[]
    for x in merged_rows:
        try:d=datetime.strptime(str(x.get('date','')),'%Y-%m-%d').date()
        except Exception:continue
        if d<cutoff: continue
        x=dict(x)
        role=str(x.get('date_role') or ('published' if x.get('kind_official') else 'effective'))
        if role=='published':
            # Direct KIND collectors expose submission dates. Their one-day validity is
            # handled by the specific card logic below; keep the historical convention.
            x['day_no']=_trade_day_no_from_effective_date(_next_trade_day(d).isoformat(),today=asof)
        else:
            # Feed dates are KRX action/effective dates: that session itself is day 1.
            x['day_no']=_trade_day_no_from_effective_date(x.get('effective_date') or x['date'],today=asof)
        rows.append(x)

    rows.sort(key=lambda x:(x.get('date',''),x.get('name',''),x.get('category','')),reverse=True)
    if fresh or kind_rows or halt_rows:
        _save_market_action_history(rows)

    groups=_today_market_action_groups(rows)
    groups=_hydrate_market_action_links(groups,rows)

    payload={
        'groups':groups,
        'updated_at':datetime.now(KST).isoformat(),
        'source':'KRX/KIND 연결 공시 자동 상태판',
        'source_url':source_url or 'https://kind.krx.co.kr/',
        'kind_source':'KIND 공식 상세검색 보강' if kind_rows else 'KIND 직접조회 대기/폴백',
        'kind_source_url':kind_source_url,
        'kind_source_error':kind_error or None,
        'halt_source':'KIND 공식 상세검색' if halt_rows else 'KIND 직접조회 대기/폴백',
        'halt_source_url':halt_source_url,
        'halt_source_error':halt_error or None,
        'error':None if (fresh or kind_rows) else (error or kind_error or '실시간 공시 조회 실패 · 마지막 저장 이력으로 표시'),
        'day_basis':'날짜 기준 · 공시 당일 0일차 · 다음 거래일 00:00부터 1일차 · 주말/휴일 제외 · 적용일 확인 행은 적용일 자체가 1일차',
        'mode':'market_action_live_session',
        'asof_trade_date':asof.isoformat(),
        'trade_calendar':_krx_calendar_status(),
        'verification':{'static_reference_used':False,'fresh_rows':len(fresh),'kind_rows':len(kind_rows),'kind_halt_rows':len(halt_rows),'clean_cache':True,'legacy_cache_used':False}
    }
    with LOCK:
        MARKET_ACTION_MEMORY['at']=now
        MARKET_ACTION_MEMORY['payload']=payload
    return payload




# --- MARKET CORE briefing ------------------------------------------------------
MARKET_CORE_FILE=ROOT/'data'/'market_core_timeline.json'
MARKET_CORE_LOCK=threading.RLock()
MARKET_CORE_CACHE={'ts':0.0,'data':None}
MARKET_CORE_NEWS_CACHE={'ts':0.0,'rows':[]}
MARKET_CORE_PRICE_HISTORY={}
MARKET_CORE_ALERT_COOLDOWN={}
MARKET_CORE_SLOTS=[('08:00',8,0),('09:00',9,0),('10:00',10,0),('11:00',11,0),('12:00',12,0),('13:00',13,0),('14:00',14,0),('15:00',15,0),('15:30',15,30),('16:00',16,0),('17:00',17,0),('18:00',18,0),('19:00',19,0),('20:00',20,0)]

def _market_core_load():
    try:
        raw=json.loads(MARKET_CORE_FILE.read_text(encoding='utf-8'))
        return raw if isinstance(raw,dict) else {'days':{}}
    except Exception:
        return {'days':{}}

def _market_core_save(obj):
    try:
        MARKET_CORE_FILE.parent.mkdir(parents=True,exist_ok=True)
        tmp=MARKET_CORE_FILE.with_suffix('.tmp')
        tmp.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
        tmp.replace(MARKET_CORE_FILE)
    except Exception:
        pass

def _mc_float(v,default=0.0):
    try:return float(v)
    except Exception:return default

def _market_core_candidates():
    with LOCK:
        report=copy.deepcopy(STATE.get('report') or {})
    panels=((report.get('search_panels') or {}).get('panels') or {})
    merged={}
    for panel_name in ('주도주 종배','주도주 상따','끼도주 종배'):
        for row in ((panels.get(panel_name) or {}).get('rows') or []):
            if not isinstance(row,dict): continue
            c=code(row.get('code') or '')
            if not c: continue
            old=merged.get(c)
            rec=dict(row); rec['code']=c; rec['panel_tags']=list((old or {}).get('panel_tags') or [])
            if panel_name not in rec['panel_tags']: rec['panel_tags'].append(panel_name)
            if old:
                rec['panel_tags']=list(dict.fromkeys((old.get('panel_tags') or [])+[panel_name]))
                # Keep the richer/larger turnover row while preserving tags.
                if _mc_float(old.get('value_eok'))>_mc_float(rec.get('value_eok')):
                    keep=dict(old); keep['panel_tags']=rec['panel_tags']; rec=keep
            merged[c]=rec
    return list(merged.values())

def _market_core_sector_summary(rows):
    sec={}
    for r in rows:
        name=str(r.get('sector') or '미분류').strip() or '미분류'
        if name=='미분류': continue
        x=sec.setdefault(name,{'sector':name,'count':0,'value_eok':0.0,'avg_change':0.0,'_changes':[]})
        x['count']+=1; x['value_eok']+=_mc_float(r.get('value_eok')); x['_changes'].append(_mc_float(r.get('change')))
    out=[]
    for x in sec.values():
        ch=x.pop('_changes',[])
        x['avg_change']=sum(ch)/len(ch) if ch else 0.0
        out.append(x)
    return sorted(out,key=lambda x:(-x['count'],-x['value_eok']))[:6]

def _market_core_news(rows,force=False):
    now=time.time()
    if MARKET_CORE_NEWS_CACHE.get('rows') and not force and now-MARKET_CORE_NEWS_CACHE.get('ts',0)<300:
        return copy.deepcopy(MARKET_CORE_NEWS_CACHE['rows'])
    picked=sorted(rows,key=lambda r:(-_mc_float(r.get('value_eok')),-abs(_mc_float(r.get('change')))))[:3]
    news=[]; seen=set()
    # Broad market headlines first. This reuses the existing no-key Naver News source.
    try:
        general,_=_fetch_naver_search_news('국내증시',6)
        for n in general[:3]:
            title=str(n.get('title') or '').strip()
            if not title or title in seen: continue
            seen.add(title); news.append({**n,'kind':'market','name':'시장전체','code':'','sector':'시장'})
    except Exception:
        pass
    for r in picked:
        try:
            pack=fetch_stock_news(r.get('code'),r.get('name') or '',3)
            for n in (pack.get('rows') or []):
                title=str(n.get('title') or '').strip()
                if not title or title in seen: continue
                seen.add(title); news.append({**n,'code':r.get('code'),'name':r.get('name'),'change':r.get('change'),'sector':r.get('sector')})
                if len(news)>=6: break
        except Exception:
            continue
        if len(news)>=6: break
    MARKET_CORE_NEWS_CACHE.update(ts=now,rows=copy.deepcopy(news))
    return news

def _market_core_mover_alerts(rows,news):
    now=time.time(); alerts=[]
    news_by={}
    for n in news or []: news_by.setdefault(str(n.get('code') or ''),[]).append(n)
    for r in rows:
        c=code(r.get('code') or ''); price=_mc_float(r.get('price'))
        if not c or price<=0: continue
        hist=MARKET_CORE_PRICE_HISTORY.setdefault(c,[])
        hist.append((now,price))
        hist[:]=[(t,p) for t,p in hist if now-t<=1200]
        def chg(age):
            target=now-age; before=[(t,p) for t,p in hist if t<=target]
            if not before:return None
            p0=max(before,key=lambda z:z[0])[1]
            return ((price/p0)-1)*100 if p0 else None
        c5,c15=chg(300),chg(900)
        hit=(c5 is not None and abs(c5)>=4.0) or (c15 is not None and abs(c15)>=6.0)
        if not hit: continue
        direction='급등' if ((c5 if c5 is not None and abs(c5)>=4 else c15) or 0)>0 else '급락'
        key=(c,direction)
        if now-MARKET_CORE_ALERT_COOLDOWN.get(key,0)<600: continue
        MARKET_CORE_ALERT_COOLDOWN[key]=now
        related=news_by.get(c,[])
        if related:
            reason='관련 뉴스 확인: '+str(related[0].get('title') or '')
            confidence='뉴스 확인'
        else:
            reason='신규 주요 뉴스는 현재 확인되지 않음 · 수급/거래량성 움직임 가능'
            confidence='원인 미확인'
        alerts.append({'time':datetime.now(KST).strftime('%H:%M'),'code':c,'name':r.get('name') or c,'direction':direction,'change_5m':c5,'change_15m':c15,'current_change':r.get('change'),'reason':reason,'confidence':confidence,'sector':r.get('sector'),'kind':'stock','urgent':False})
    return alerts

def _market_core_market_alerts(markets,news):
    now=time.time(); out=[]
    # Index shock alert. Daily move is used as a conservative whole-market emergency signal.
    for k,label in (('kospi','코스피'),('kosdaq','코스닥')):
        x=(markets or {}).get(k) or {}; ch=_mc_float(x.get('change_rate'))
        if abs(ch)<3.0: continue
        direction='급등' if ch>0 else '급락'; key=('market-index',k,direction)
        if now-MARKET_CORE_ALERT_COOLDOWN.get(key,0)<1800: continue
        MARKET_CORE_ALERT_COOLDOWN[key]=now
        out.append({'time':datetime.now(KST).strftime('%H:%M'),'code':'','name':label,'direction':direction,'current_change':ch,'reason':f'{label} 당일 변동률 {ch:+.2f}% · 시장 전체 변동성 확대','confidence':'지수 확인','sector':'시장','kind':'market','urgent':True})
    # High-impact headline keywords. We only surface what the headline actually says; no invented cause.
    keys=('전쟁','공습','미사일','테러','비상계엄','기준금리','금리 인상','금리 인하','FOMC','관세','경제제재','휴전','환율 급등','환율 급락')
    for n in news or []:
        if n.get('kind')!='market': continue
        title=str(n.get('title') or '')
        hit=next((k for k in keys if k.lower() in title.lower()),None)
        if not hit: continue
        key=('market-news',re.sub(r'\W+','',title.lower())[:80])
        if now-MARKET_CORE_ALERT_COOLDOWN.get(key,0)<3600: continue
        MARKET_CORE_ALERT_COOLDOWN[key]=now
        out.append({'time':datetime.now(KST).strftime('%H:%M'),'code':'','name':'시장전체','direction':'긴급','current_change':None,'reason':title,'confidence':'주요 뉴스 확인','sector':'시장','kind':'market','urgent':True,'url':n.get('url','')})
        if len(out)>=3: break
    return out

def _market_core_headlines(markets,sectors,rows):
    lines=[]
    for k,label in (('kospi','코스피'),('kosdaq','코스닥')):
        x=(markets or {}).get(k) or {}
        if x.get('change_rate') is not None:
            ch=_mc_float(x.get('change_rate')); lines.append(f"{label} {ch:+.2f}%")
    if sectors:
        s=sectors[0]; lines.append(f"주도 검색 섹터 {s['sector']} · {s['count']}종목")
    if rows:
        leader=max(rows,key=lambda r:_mc_float(r.get('value_eok')))
        lines.append(f"검색기 거래대금 선두 {leader.get('name')} · {_mc_float(leader.get('value_eok')):,.0f}억원")
    return lines[:4]

def _market_core_summary_text(markets,sectors,rows):
    bits=[]
    mk=[]
    for k,label in (('kospi','코스피'),('kosdaq','코스닥')):
        x=(markets or {}).get(k) or {}
        if x.get('change_rate') is not None: mk.append(f"{label} {_mc_float(x.get('change_rate')):+.2f}%")
    if mk: bits.append(' · '.join(mk))
    if sectors: bits.append(f"검색기에서는 {sectors[0]['sector']} 섹터가 {sectors[0]['count']}종목으로 가장 많이 포착")
    up=sum(1 for r in rows if _mc_float(r.get('change'))>0); down=sum(1 for r in rows if _mc_float(r.get('change'))<0)
    if rows: bits.append(f"검색기 후보 상승 {up} / 하락 {down} / 총 {len(rows)}종목")
    return ' | '.join(bits) if bits else '시장 데이터 수집 대기'



def _market_core_enrich_news(news):
    """Attach conservative, headline-only impact hints; never invent a cause."""
    pos=('수주','계약','증설','투자 확대','승인','호실적','흑자','신고가','상향','개선','성장','돌파')
    neg=('급락','하락','적자','하향','소송','조사','중단','리콜','제재','우려','감소','악화','철회')
    out=[]
    for raw in news or []:
        n=dict(raw); title=str(n.get('title') or '')
        if any(k in title for k in pos): impact='제목 기준 긍정 가능'
        elif any(k in title for k in neg): impact='제목 기준 부정 가능'
        else: impact='영향 확인 필요'
        related=[]
        if n.get('sector') and n.get('sector') not in ('시장','미분류'): related.append(str(n.get('sector')))
        if n.get('name') and n.get('name') not in ('시장전체','시장'): related.append(str(n.get('name')))
        n['impact']=impact; n['related']=' · '.join(dict.fromkeys(related)) if related else '시장전체'
        out.append(n)
    return out

def _market_core_candidate_states(rows):
    """Track 신규/유지/강화/약화 without touching screener formulas."""
    now=time.time()
    with MARKET_CORE_LOCK:
        db=_market_core_load(); state=db.setdefault('candidate_state',{})
        current={code(r.get('code') or ''):r for r in rows if code(r.get('code') or '')}
        result={}; departed=[]
        for c,r in current.items():
            prev=state.get(c) if isinstance(state.get(c),dict) else None
            rank=int(_mc_float(r.get('value_rank'),9999))
            ch=_mc_float(r.get('change'))
            if not prev:
                status='신규'; first_seen=now
            else:
                first_seen=float(prev.get('first_seen') or now)
                old_rank=int(_mc_float(prev.get('value_rank'),9999)); old_ch=_mc_float(prev.get('change'))
                if now-first_seen<=1800: status='신규'
                elif rank+5<=old_rank or ch-old_ch>=1.5: status='강화'
                elif rank>=old_rank+5 or old_ch-ch>=1.5: status='약화'
                else: status='유지'
            result[c]=status
            state[c]={'name':r.get('name'),'first_seen':first_seen,'last_seen':now,'value_rank':rank,'change':ch}
        for c,prev in list(state.items()):
            if c in current or not isinstance(prev,dict): continue
            if now-float(prev.get('last_seen') or 0)<=7200:
                departed.append({'code':c,'name':prev.get('name') or c,'status':'이탈'})
            if now-float(prev.get('last_seen') or 0)>86400: state.pop(c,None)
        _market_core_save(db)
    return result,departed[:10]

def _market_core_build_briefing(snapshot):
    """Create a concise, evidence-only hourly news briefing from collected data.

    This never invents a cause.  It summarizes the headlines already collected by
    LITTO, their conservative title-based impact labels, and the current screener
    state.  The full source headline remains available in the timeline card.
    """
    news=list(snapshot.get('news') or [])[:5]
    items=[]
    pos=neg=0
    for n in news[:3]:
        impact=str(n.get('impact') or '영향 확인 필요')
        if '긍정' in impact: pos+=1
        elif '부정' in impact: neg+=1
        items.append({
            'title':str(n.get('title') or '').strip(),
            'impact':impact,
            'related':str(n.get('related') or '시장전체'),
            'name':str(n.get('name') or '시장'),
            'time':str(n.get('time') or ''),
            'url':str(n.get('url') or ''),
        })
    if items:
        if pos>neg: tone='확인된 주요 헤드라인은 긍정 재료가 상대적으로 많음'
        elif neg>pos: tone='확인된 주요 헤드라인은 부정 재료가 상대적으로 많음'
        else: tone='확인된 주요 헤드라인은 긍정·부정 방향이 혼재'
        lead=f"주요 뉴스 {len(news)}건 확인 · {tone}"
    else:
        lead='이 시간대에 확인된 주요 뉴스가 없음'

    cand=list(snapshot.get('top_candidates') or [])
    new_names=[str(x.get('name') or '') for x in cand if x.get('status')=='신규'][:4]
    strong_names=[str(x.get('name') or '') for x in cand if x.get('status')=='강화'][:4]
    departed=[str(x.get('name') or '') for x in (snapshot.get('departed_candidates') or [])][:4]
    changes=[]
    if new_names: changes.append('신규 '+', '.join(new_names))
    if strong_names: changes.append('강화 '+', '.join(strong_names))
    if departed: changes.append('이탈 '+', '.join(departed))
    watch=' · '.join(changes) if changes else '검색기 핵심 종목의 큰 상태 변화 없음'

    return {
        'lead':lead,
        'items':items,
        'market':str(snapshot.get('summary') or ''),
        'watch':watch,
        'note':'뉴스 원인은 제목과 확인된 데이터만 요약하며, 확인되지 않은 인과관계는 단정하지 않음',
    }

def _market_core_maybe_store_slot(snapshot):
    now=datetime.now(KST); today=now.date().isoformat(); selected=None
    for label,h,m in MARKET_CORE_SLOTS:
        slot=now.replace(hour=h,minute=m,second=0,microsecond=0)
        if now>=slot and now-slot<=timedelta(minutes=25): selected=label
    if not selected:return
    with MARKET_CORE_LOCK:
        db=_market_core_load(); days=db.setdefault('days',{}); arr=days.setdefault(today,[])
        if any(x.get('slot')==selected for x in arr): return
        arr.append({'slot':selected,'saved_at':now.isoformat(),'summary':snapshot.get('summary'),'headlines':snapshot.get('headlines',[]),'sectors':snapshot.get('sectors',[])[:3],'top_candidates':snapshot.get('top_candidates',[])[:5],'departed_candidates':snapshot.get('departed_candidates',[])[:5],'news':snapshot.get('news',[])[:3],'briefing':_market_core_build_briefing(snapshot)})
        arr.sort(key=lambda x:x.get('slot','')); days[today]=arr[-20:]; _market_core_save(db)

def _market_core_alert_history(new_alerts):
    """Keep three KST calendar days inclusive, saving only newly detected events."""
    now=datetime.now(KST)
    today=now.date()
    cutoff=(today-timedelta(days=2)).isoformat()
    with MARKET_CORE_LOCK:
        db=_market_core_load()
        history=[x for x in (db.get('alert_history') or []) if isinstance(x,dict) and cutoff<=str(x.get('date') or '')<=today.isoformat()]
        known={str(x.get('id')) for x in history}
        changed=len(history)!=len(db.get('alert_history') or [])
        for a in new_alerts or []:
            if not isinstance(a,dict):continue
            item=copy.deepcopy(a)
            item['date']=today.isoformat()
            item['recorded_at']=now.isoformat()
            # Preserve separate alerts for repeated events, but do not duplicate one response.
            item['id']=f"{item['date']}|{item.get('time','')}|{item.get('code','')}|{item.get('name','')}|{item.get('direction','')}|{item.get('reason','')}"
            if item['id'] in known:continue
            known.add(item['id']);history.append(item);changed=True
        history.sort(key=lambda x:str(x.get('recorded_at') or ''),reverse=True)
        history=history[:3000]
        if changed:
            db['alert_history']=history
            _market_core_save(db)
        return copy.deepcopy(history)

def market_core_snapshot(force=False):
    now=time.time()
    if MARKET_CORE_CACHE.get('data') and not force and now-MARKET_CORE_CACHE.get('ts',0)<20:
        data=copy.deepcopy(MARKET_CORE_CACHE['data'])
        # Alerts are event-like; cached responses do not re-emit old alerts.
        data['alerts']=[]
        data['alert_history']=_market_core_alert_history([])
        return data
    try: ov=market_overview_snapshot(force=False)
    except Exception: ov={'markets':{}}
    markets=copy.deepcopy((ov or {}).get('markets') or {})
    rows=_market_core_candidates()
    sectors=_market_core_sector_summary(rows)
    top=sorted(rows,key=lambda r:(-_mc_float(r.get('value_eok')),-_mc_float(r.get('change'))))[:10]
    news=_market_core_enrich_news(_market_core_news(rows,force=force))
    states,departed=_market_core_candidate_states(rows)
    alerts=_market_core_market_alerts(markets,news)+_market_core_mover_alerts(rows,news)
    alert_history=_market_core_alert_history(alerts)
    top_rows=[]
    for r in top:
        c=code(r.get('code') or '')
        top_rows.append({'code':c,'name':r.get('name'),'sector':r.get('sector'),'change':r.get('change'),'value_eok':r.get('value_eok'),'value_rank':r.get('value_rank'),'panel_tags':r.get('panel_tags',[]),'status':states.get(c,'유지')})
    snapshot={'updated_at':datetime.now(KST).isoformat(),'markets':markets,'summary':_market_core_summary_text(markets,sectors,rows),'headlines':_market_core_headlines(markets,sectors,rows),'sectors':sectors,'top_candidates':top_rows,'departed_candidates':departed,'news':news,'alerts':alerts,'alert_history':alert_history,'rules':{'mover_5m':4.0,'mover_15m':6.0,'cooldown_minutes':10},'source':'LITTO 검색기 + 키움 시장종합 + 기존 뉴스 소스'}
    _market_core_maybe_store_slot(snapshot)
    with MARKET_CORE_LOCK:
        db=_market_core_load(); snapshot['timeline']=copy.deepcopy((db.get('days') or {}).get(datetime.now(KST).date().isoformat(),[]))
        for _x in snapshot['timeline']:
            if isinstance(_x,dict) and not _x.get('briefing'):
                _tmp={'summary':_x.get('summary',''),'news':_x.get('news',[]),'top_candidates':_x.get('top_candidates',[]),'departed_candidates':_x.get('departed_candidates',[])}
                _x['briefing']=_market_core_build_briefing(_tmp)
    MARKET_CORE_CACHE.update(ts=now,data=copy.deepcopy(snapshot))
    return snapshot


class _NaverFinanceNewsParser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.rows=[]; self.row=None; self.td_class=''; self.in_a=False; self.a_href=''; self.a_title=''; self.buf=[]
    def handle_starttag(self,tag,attrs):
        a=dict(attrs)
        if tag=='tr': self.row={'title':'','publisher':'','time':'','url':''}
        elif self.row is not None and tag=='td': self.td_class=a.get('class','') or ''
        elif self.row is not None and tag=='a':
            href=a.get('href','') or ''
            if 'news_read.naver' in href:
                self.in_a=True; self.a_href=href; self.a_title=a.get('title','') or ''; self.buf=[]
    def handle_data(self,data):
        if self.row is None: return
        t=' '.join(str(data).split())
        if not t: return
        if self.in_a: self.buf.append(t)
        elif 'info' in self.td_class: self.row['publisher']=(self.row.get('publisher','')+' '+t).strip()
        elif 'date' in self.td_class: self.row['time']=(self.row.get('time','')+' '+t).strip()
    def handle_endtag(self,tag):
        if tag=='a' and self.in_a:
            title=' '.join(self.buf).strip() or self.a_title.strip()
            if title:
                self.row['title']=title; self.row['url']=urljoin('https://finance.naver.com',self.a_href)
            self.in_a=False; self.a_href=''; self.a_title=''; self.buf=[]
        elif tag=='td': self.td_class=''
        elif tag=='tr':
            if self.row and self.row.get('title') and self.row.get('url'): self.rows.append(self.row)
            self.row=None; self.td_class=''

def _decode_web_bytes(raw, headers=None):
    """Decode Korean legacy pages without failing the whole news request."""
    candidates=[]
    try:
        if headers is not None and hasattr(headers,'get_content_charset'):
            c=headers.get_content_charset()
            if c: candidates.append(c)
    except Exception:
        pass
    candidates += ['euc-kr','cp949','utf-8']
    seen=set()
    for enc in candidates:
        if not enc or enc.lower() in seen: continue
        seen.add(enc.lower())
        try: return raw.decode(enc)
        except Exception: pass
    return raw.decode('utf-8','replace')


def _canonical_naver_news_url(href):
    """Convert Naver Finance redirect URLs to the canonical Naver News article URL.
    This avoids finance.news_read redirect/cluster mismatches where a displayed headline
    can open a different related article.
    """
    u=urljoin('https://finance.naver.com', str(href or ''))
    try:
        q=parse_qs(urlparse(u).query)
        oid=(q.get('office_id') or q.get('oid') or [''])[0]
        aid=(q.get('article_id') or q.get('aid') or [''])[0]
        if oid and aid:
            return f'https://n.news.naver.com/mnews/article/{oid}/{aid}'
    except Exception:
        pass
    return u

class _NaverSearchNewsParser(HTMLParser):
    """Extract direct publisher links from Naver News search results.
    Naver's markup changes over time, so this parser intentionally accepts both the
    legacy news_tit class and newer anchors carrying a title attribute with http links.
    """
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.rows=[]
    def handle_starttag(self,tag,attrs):
        if tag!='a': return
        a=dict(attrs); href=(a.get('href') or '').strip(); title=(a.get('title') or '').strip()
        cls=(a.get('class') or '')
        if not href.startswith('http'): return
        if 'news_tit' in cls and title:
            self.rows.append({'title':title,'publisher':'','time':'','url':href})

def _fetch_naver_search_news(stock_name, limit):
    """Fallback source with direct article URLs, not an intermediate RSS redirect."""
    q=quote_plus(f'"{stock_name}" 주식')
    url=f'https://search.naver.com/search.naver?where=news&query={q}&sort=1'
    req=Request(url,headers={
        'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36',
        'Accept-Language':'ko-KR,ko;q=0.9',
    })
    with urlopen(req,timeout=8) as r:
        raw=r.read(); headers=r.headers
    text=_decode_web_bytes(raw,headers)
    parser=_NaverSearchNewsParser(); parser.feed(text)
    out=[]; seen=set()
    for row in parser.rows:
        title=' '.join(str(row.get('title','')).split()).strip()
        href=(row.get('url') or '').strip()
        if not title or not href or title in seen: continue
        seen.add(title); out.append({'title':title,'publisher':'','time':'','url':href})
        if len(out)>=limit: break
    return out,url


def _fetch_naver_finance_news(c, limit):
    """Primary source. Naver Finance markup may change, so callers must have a fallback."""
    url=f'https://finance.naver.com/item/news_news.naver?code={c}&page=1&sm=title_entity_id.basic&clusterId='
    req=Request(url,headers={
        'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36',
        'Accept-Language':'ko-KR,ko;q=0.9',
        'Referer':f'https://finance.naver.com/item/main.naver?code={c}',
    })
    with urlopen(req,timeout=8) as r:
        raw=r.read(); headers=r.headers
    text=_decode_web_bytes(raw,headers)
    parser=_NaverFinanceNewsParser(); parser.feed(text)
    seen=set(); rows=[]
    for row in parser.rows:
        title=re.sub(r'\s+',' ',row.get('title','')).strip()
        if not title or title in seen: continue
        seen.add(title)
        rows.append({
            'title':title,
            'publisher':row.get('publisher','').strip(),
            'time':row.get('time','').strip(),
            'url':_canonical_naver_news_url(row.get('url',''))
        })
        if len(rows)>=limit: break
    return rows,url


def _news_name_aliases(stock_name):
    """Return conservative aliases for headline matching.
    Exact stock name is primary. Only preferred-share suffixes are relaxed so
    삼성전자우 can still match 삼성전자 headlines; generic group-name expansion is avoided.
    """
    n=' '.join(str(stock_name or '').split()).strip()
    if not n: return []
    aliases=[n]
    # Preferred-share names commonly use the ordinary-share company name in headlines.
    for suffix in ('우B','우C','우'):
        if n.endswith(suffix) and len(n)>len(suffix)+1:
            base=n[:-len(suffix)].strip()
            if base and base not in aliases: aliases.append(base)
            break
    # Compare both literal and whitespace-free forms, but do not broaden to group names.
    out=[]
    for a in aliases:
        for v in (a, re.sub(r'\s+','',a)):
            if v and v not in out: out.append(v)
    return out


def _headline_matches_stock(title, stock_name):
    """Strict relevance gate: headline must explicitly name the stock/company."""
    t=' '.join(str(title or '').split()).strip()
    if not t: return False
    t_compact=re.sub(r'\s+','',t).lower()
    for alias in _news_name_aliases(stock_name):
        a=re.sub(r'\s+','',alias).lower()
        if a and a in t_compact:
            return True
    return False


def _filter_stock_news_rows(rows, stock_name, limit):
    seen=set(); out=[]
    for row in rows or []:
        title=' '.join(str(row.get('title','')).split()).strip()
        if not _headline_matches_stock(title, stock_name):
            continue
        key=re.sub(r'[^0-9a-z가-힣]+','',title.lower())
        if not key or key in seen: continue
        seen.add(key)
        x=dict(row); x['title']=title; x['exact_match']=True
        out.append(x)
        if len(out)>=limit: break
    return out


def _fetch_google_news_rss(stock_name, limit):
    """No-key fallback. Query and results are both restricted to the exact stock/company name."""
    q=quote_plus(f'"{stock_name}" (주식 OR 증권 OR 코스피 OR 코스닥)')
    url=f'https://news.google.com/rss/search?q={q}&hl=ko&gl=KR&ceid=KR:ko'
    req=Request(url,headers={
        'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36',
        'Accept-Language':'ko-KR,ko;q=0.9',
    })
    with urlopen(req,timeout=8) as r:
        raw=r.read()
    root=ET.fromstring(raw)
    rows=[]; seen=set()
    for item in root.findall('.//item'):
        title=' '.join((item.findtext('title') or '').split()).strip()
        link=(item.findtext('link') or '').strip()
        source_el=item.find('source')
        publisher=(' '.join((source_el.text or '').split()).strip() if source_el is not None else '')
        pub=(item.findtext('pubDate') or '').strip()
        when=pub
        try:
            dt=parsedate_to_datetime(pub)
            if dt is not None:
                if dt.tzinfo is not None: dt=dt.astimezone(KST)
                when=dt.strftime('%Y.%m.%d %H:%M')
        except Exception:
            pass
        # Google often appends " - publisher" to the title; remove only when it exactly matches source.
        if publisher and title.endswith(' - '+publisher):
            title=title[:-(len(publisher)+3)].strip()
        if not title or not link or title in seen: continue
        seen.add(title)
        rows.append({'title':title,'publisher':publisher,'time':when,'url':link})
        if len(rows)>=limit: break
    return rows,url


NEWS_FLIGHT=SingleFlight()

def fetch_stock_news(code_value,name='',limit=10):
    return NEWS_FLIGHT.run((str(code_value),str(name),int(limit)),lambda:_fetch_stock_news(code_value,name,limit))

def _fetch_stock_news(code_value,name='',limit=10):
    c=''.join(ch for ch in str(code_value) if ch.isdigit())[:6]
    if len(c)!=6: raise ValueError('종목코드가 올바르지 않습니다.')
    stock_name=(name or LOOKUP.get(c,{}).get('name',c)).strip()
    limit=max(1,min(int(limit),15))
    key=(c,stock_name,limit)
    now=time.time(); cached=NEWS_CACHE.get(key)
    if cached and now-cached.get('ts',0)<NEWS_CACHE_TTL:
        return cached['data']

    errors=[]; rows=[]; source=''; source_url=''
    # 1) Naver Finance stock-code page, then strict headline relevance filter.
    try:
        raw_rows,source_url=_fetch_naver_finance_news(c,max(limit*3,20))
        rows=_filter_stock_news_rows(raw_rows,stock_name,limit)
        if rows: source='네이버 금융 · 종목명 정확일치'
        elif raw_rows: errors.append('네이버 금융: 종목명 정확일치 기사 0건')
        else: errors.append('네이버 금융: 기사 0건')
    except Exception as e:
        errors.append('네이버 금융: '+str(e))

    # 2) Naver News search fallback. This returns direct publisher/article links.
    if not rows:
        try:
            raw_rows,source_url=_fetch_naver_search_news(stock_name,max(limit*3,20))
            rows=_filter_stock_news_rows(raw_rows,stock_name,limit)
            if rows: source='네이버 뉴스검색 · 종목명 정확일치'
            elif raw_rows: errors.append('네이버 뉴스검색: 종목명 정확일치 기사 0건')
            else: errors.append('네이버 뉴스검색: 기사 0건')
        except Exception as e:
            errors.append('네이버 뉴스검색: '+str(e))

    # 3) Google News RSS is title discovery only. Google RSS article URLs can be
    # opaque/intermediate redirects, so each item opens an exact-headline news search
    # instead of risking a mismatched article.
    if not rows:
        try:
            raw_rows,source_url=_fetch_google_news_rss(stock_name,max(limit*3,20))
            raw_rows=_filter_stock_news_rows(raw_rows,stock_name,max(limit*3,20))
            safe=[]
            for row in raw_rows:
                x=dict(row)
                exact='"'+x.get('title','')+'"'
                x['url']='https://search.naver.com/search.naver?where=news&query='+quote_plus(exact)
                x['link_mode']='headline_search'
                safe.append(x)
            rows=safe[:limit]
            if rows: source='Google 뉴스 제목확인 · 정확 제목검색 연결'
            elif raw_rows: errors.append('Google 뉴스: 종목명 정확일치 기사 0건')
            else: errors.append('Google 뉴스: 기사 0건')
        except Exception as e:
            errors.append('Google 뉴스: '+str(e))

    # Always keep a direct search link available.
    naver_search=f'https://search.naver.com/search.naver?where=news&query={quote_plus('\"'+stock_name+'\" 주식')}'
    data={
        'code':c,
        'name':stock_name,
        'rows':rows,
        'source':source or '뉴스 검색',
        'source_url':source_url or naver_search,
        'search_url':naver_search,
        'updated_at':datetime.now(KST).isoformat(),
        'error':None if rows else ('뉴스 목록 조회 실패 · '+' / '.join(errors))
    }
    NEWS_CACHE[key]={'ts':time.time(),'data':data}
    while len(NEWS_CACHE)>256:
        NEWS_CACHE.pop(next(iter(NEWS_CACHE)),None)
    return data


# Kiwoom credentials are stored only on this Windows user account.
# App Key + Secret Key are encrypted together with Windows DPAPI.
# A legacy reader is kept so older LITTO credential files migrate automatically.
def _user_data_dir():
    base=os.getenv('LOCALAPPDATA')
    if base:
        return Path(base)/'LITTO'
    return ROOT/'data'

CREDENTIAL_DIR=_user_data_dir()
CREDENTIAL_FILE=CREDENTIAL_DIR/'kiwoom_credentials.dat'
LEGACY_CREDENTIAL_FILE=CREDENTIAL_DIR/'kiwoom_credentials.json'
REGISTRY_PATH=r'Software\LITTO'
REGISTRY_VALUE='KiwoomCredentials'
CREDENTIAL_LAST_ERROR=''
CREDENTIAL_BACKEND=''
CREDENTIAL_SAVED=False
CREDENTIAL_PS_FILE=CREDENTIAL_DIR/'kiwoom_credentials_ps.dat'
AUTOLOGIN_VERSION='AUTOLOGIN v4'


class _DATA_BLOB(ctypes.Structure):
    _fields_=[('cbData',ctypes.c_ulong),('pbData',ctypes.POINTER(ctypes.c_ubyte))]

def _dpapi_api():
    if os.name!='nt':
        raise RuntimeError('자동 저장은 Windows에서만 지원합니다.')
    crypt32=ctypes.WinDLL('crypt32',use_last_error=True)
    kernel32=ctypes.WinDLL('kernel32',use_last_error=True)
    crypt32.CryptProtectData.argtypes=[ctypes.POINTER(_DATA_BLOB),ctypes.c_wchar_p,ctypes.POINTER(_DATA_BLOB),ctypes.c_void_p,ctypes.c_void_p,ctypes.c_ulong,ctypes.POINTER(_DATA_BLOB)]
    crypt32.CryptProtectData.restype=ctypes.c_bool
    crypt32.CryptUnprotectData.argtypes=[ctypes.POINTER(_DATA_BLOB),ctypes.POINTER(ctypes.c_wchar_p),ctypes.POINTER(_DATA_BLOB),ctypes.c_void_p,ctypes.c_void_p,ctypes.c_ulong,ctypes.POINTER(_DATA_BLOB)]
    crypt32.CryptUnprotectData.restype=ctypes.c_bool
    kernel32.LocalFree.argtypes=[ctypes.c_void_p]
    kernel32.LocalFree.restype=ctypes.c_void_p
    return crypt32,kernel32

def _dpapi_protect_bytes(raw):
    crypt32,kernel32=_dpapi_api()
    buf=ctypes.create_string_buffer(raw)
    inp=_DATA_BLOB(len(raw),ctypes.cast(buf,ctypes.POINTER(ctypes.c_ubyte)))
    out=_DATA_BLOB()
    if not crypt32.CryptProtectData(ctypes.byref(inp),'LITTO Kiwoom credentials',None,None,None,0x1,ctypes.byref(out)):
        raise ctypes.WinError(ctypes.get_last_error())
    try:
        return ctypes.string_at(out.pbData,out.cbData)
    finally:
        kernel32.LocalFree(out.pbData)

def _dpapi_unprotect_bytes(raw):
    crypt32,kernel32=_dpapi_api()
    buf=ctypes.create_string_buffer(raw)
    inp=_DATA_BLOB(len(raw),ctypes.cast(buf,ctypes.POINTER(ctypes.c_ubyte)))
    out=_DATA_BLOB();desc=ctypes.c_wchar_p()
    if not crypt32.CryptUnprotectData(ctypes.byref(inp),ctypes.byref(desc),None,None,None,0x1,ctypes.byref(out)):
        raise ctypes.WinError(ctypes.get_last_error())
    try:
        return ctypes.string_at(out.pbData,out.cbData)
    finally:
        kernel32.LocalFree(out.pbData)
        if desc: kernel32.LocalFree(desc)



def _ps_protect_bytes(raw):
    if os.name!='nt':
        raise RuntimeError('PowerShell fallback is Windows only')
    script=r'''$ErrorActionPreference='Stop'
$inputText=[Console]::In.ReadToEnd()
$bytes=[Convert]::FromBase64String($inputText.Trim())
$enc=[Security.Cryptography.ProtectedData]::Protect($bytes,$null,[Security.Cryptography.DataProtectionScope]::CurrentUser)
[Console]::Out.Write([Convert]::ToBase64String($enc))'''
    r=subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-Command',script],input=base64.b64encode(raw).decode('ascii'),text=True,capture_output=True,timeout=15)
    if r.returncode!=0 or not r.stdout.strip():
        raise RuntimeError((r.stderr or 'PowerShell DPAPI protect failed').strip())
    return base64.b64decode(r.stdout.strip())

def _ps_unprotect_bytes(raw):
    if os.name!='nt':
        raise RuntimeError('PowerShell fallback is Windows only')
    script=r'''$ErrorActionPreference='Stop'
$inputText=[Console]::In.ReadToEnd()
$bytes=[Convert]::FromBase64String($inputText.Trim())
$dec=[Security.Cryptography.ProtectedData]::Unprotect($bytes,$null,[Security.Cryptography.DataProtectionScope]::CurrentUser)
[Console]::Out.Write([Convert]::ToBase64String($dec))'''
    r=subprocess.run(['powershell.exe','-NoProfile','-NonInteractive','-Command',script],input=base64.b64encode(raw).decode('ascii'),text=True,capture_output=True,timeout=15)
    if r.returncode!=0 or not r.stdout.strip():
        raise RuntimeError((r.stderr or 'PowerShell DPAPI unprotect failed').strip())
    return base64.b64decode(r.stdout.strip())

def _write_autologin_log(message):
    try:
        CREDENTIAL_DIR.mkdir(parents=True,exist_ok=True)
        with (CREDENTIAL_DIR/'autologin.log').open('a',encoding='utf-8') as f:
            f.write(datetime.now(KST).isoformat()+' '+str(message).replace('\n',' ')+'\n')
    except Exception:
        pass

def _legacy_dpapi_unprotect(encoded):
    return _dpapi_unprotect_bytes(base64.b64decode(encoded)).decode('utf-8')

def _registry_write_blob(encrypted):
    if os.name!='nt':
        return False
    import winreg
    key=winreg.CreateKeyEx(winreg.HKEY_CURRENT_USER,REGISTRY_PATH,0,winreg.KEY_SET_VALUE)
    try:
        winreg.SetValueEx(key,REGISTRY_VALUE,0,winreg.REG_SZ,base64.b64encode(encrypted).decode('ascii'))
    finally:
        winreg.CloseKey(key)
    return True

def _registry_read_blob():
    if os.name!='nt':
        return None
    import winreg
    try:
        key=winreg.OpenKey(winreg.HKEY_CURRENT_USER,REGISTRY_PATH,0,winreg.KEY_QUERY_VALUE)
        try:
            value,_=winreg.QueryValueEx(key,REGISTRY_VALUE)
        finally:
            winreg.CloseKey(key)
        return base64.b64decode(value) if value else None
    except FileNotFoundError:
        return None

def _registry_delete_blob():
    if os.name!='nt':
        return
    import winreg
    try:
        key=winreg.OpenKey(winreg.HKEY_CURRENT_USER,REGISTRY_PATH,0,winreg.KEY_SET_VALUE)
        try:
            winreg.DeleteValue(key,REGISTRY_VALUE)
        finally:
            winreg.CloseKey(key)
    except FileNotFoundError:
        pass

def _save_credentials(appkey,secretkey):
    global CREDENTIAL_LAST_ERROR,CREDENTIAL_BACKEND,CREDENTIAL_SAVED
    appkey=str(appkey or '').strip();secretkey=str(secretkey or '').strip()
    if not appkey or not secretkey: raise ValueError('App Key와 Secret Key를 모두 입력하세요.')
    payload=json.dumps({'appkey':appkey,'secretkey':secretkey,'saved_at':datetime.now(KST).isoformat()},ensure_ascii=False).encode('utf-8')
    errors=[];saved=False
    try:
        encrypted=_dpapi_protect_bytes(payload)
        try:
            if _registry_write_blob(encrypted):
                saved=True;CREDENTIAL_BACKEND='Windows 레지스트리(HKCU)+DPAPI'
        except Exception as e: errors.append('registry: '+str(e))
        try:
            CREDENTIAL_DIR.mkdir(parents=True,exist_ok=True)
            tmp=CREDENTIAL_FILE.with_suffix('.tmp');tmp.write_bytes(encrypted);tmp.replace(CREDENTIAL_FILE)
            saved=True
            if not CREDENTIAL_BACKEND:CREDENTIAL_BACKEND='LocalAppData+DPAPI'
        except Exception as e: errors.append('dpapi file: '+str(e))
    except Exception as e:
        errors.append('native dpapi: '+str(e))
    try:
        encrypted_ps=_ps_protect_bytes(payload)
        CREDENTIAL_DIR.mkdir(parents=True,exist_ok=True)
        tmp=CREDENTIAL_PS_FILE.with_suffix('.tmp');tmp.write_bytes(encrypted_ps);tmp.replace(CREDENTIAL_PS_FILE)
        saved=True
        CREDENTIAL_BACKEND=(CREDENTIAL_BACKEND+' + ' if CREDENTIAL_BACKEND else '')+'PowerShell DPAPI'
    except Exception as e:
        errors.append('powershell: '+str(e))
    CREDENTIAL_LAST_ERROR='; '.join(errors)
    _write_autologin_log('SAVE '+('OK '+CREDENTIAL_BACKEND if saved else 'FAIL '+CREDENTIAL_LAST_ERROR))
    CREDENTIAL_SAVED=saved
    if not saved:
        raise RuntimeError(CREDENTIAL_LAST_ERROR or '인증정보 저장 실패')

def _decode_credential_blob(blob):
    raw=json.loads(_dpapi_unprotect_bytes(blob).decode('utf-8'))
    a=str(raw.get('appkey') or '').strip();s=str(raw.get('secretkey') or '').strip()
    return (a,s) if a and s else ('','')

def _load_credentials():
    global CREDENTIAL_LAST_ERROR,CREDENTIAL_BACKEND,CREDENTIAL_SAVED
    CREDENTIAL_LAST_ERROR='';CREDENTIAL_BACKEND=''
    errors=[]
    try:
        blob=_registry_read_blob()
        if blob:
            a,ss=_decode_credential_blob(blob)
            if a and ss:
                CREDENTIAL_BACKEND='Windows 레지스트리(HKCU)+DPAPI';_write_autologin_log('LOAD OK registry');CREDENTIAL_SAVED=True;return a,ss
    except Exception as e: errors.append('registry load: '+str(e))
    try:
        if CREDENTIAL_FILE.exists():
            a,ss=_decode_credential_blob(CREDENTIAL_FILE.read_bytes())
            if a and ss:
                CREDENTIAL_BACKEND='LocalAppData+DPAPI';_write_autologin_log('LOAD OK dpapi file');CREDENTIAL_SAVED=True;return a,ss
    except Exception as e: errors.append('file load: '+str(e))
    try:
        if CREDENTIAL_PS_FILE.exists():
            raw=json.loads(_ps_unprotect_bytes(CREDENTIAL_PS_FILE.read_bytes()).decode('utf-8'))
            a=str(raw.get('appkey') or '').strip();ss=str(raw.get('secretkey') or '').strip()
            if a and ss:
                CREDENTIAL_BACKEND='PowerShell DPAPI';_write_autologin_log('LOAD OK powershell');CREDENTIAL_SAVED=True;return a,ss
    except Exception as e: errors.append('powershell load: '+str(e))
    try:
        if LEGACY_CREDENTIAL_FILE.exists():
            raw=json.loads(LEGACY_CREDENTIAL_FILE.read_text(encoding='utf-8'))
            a=_legacy_dpapi_unprotect(raw.get('appkey',''));ss=_legacy_dpapi_unprotect(raw.get('secretkey',''))
            if a and ss:
                _save_credentials(a,ss);CREDENTIAL_SAVED=True;return a,ss
    except Exception as e: errors.append('legacy load: '+str(e))
    CREDENTIAL_LAST_ERROR='; '.join(errors)
    _write_autologin_log('LOAD NONE '+CREDENTIAL_LAST_ERROR)
    CREDENTIAL_SAVED=False
    return '',''

def _delete_credentials():
    global CREDENTIAL_LAST_ERROR,CREDENTIAL_BACKEND,CREDENTIAL_SAVED
    try:_registry_delete_blob()
    except Exception as e:CREDENTIAL_LAST_ERROR='registry delete: '+str(e)
    for f in (CREDENTIAL_FILE,CREDENTIAL_PS_FILE,LEGACY_CREDENTIAL_FILE):
        try:f.unlink()
        except FileNotFoundError:pass
    CREDENTIAL_BACKEND=''
    CREDENTIAL_SAVED=False

def _startup_auto_connect():
    """Restore the Kiwoom session before the browser opens.

    After one successful live login, the user never needs to type App Key /
    Secret Key again on the same Windows account unless saved credentials are
    explicitly deleted or Kiwoom rejects/revokes them.
    """
    appkey,secretkey=_load_credentials()
    if not appkey or not secretkey:
        return False
    with LOCK:
        if STATE.get('connected') or STATE.get('client'):
            return True
        STATE['progress']='저장된 App Key / Secret Key로 자동 로그인 중...'
    try:
        client=Kiwoom(appkey,secretkey,False)
        client.auth()
        with LOCK:
            STATE.update(client=client,connected=True,mock=False,
                         progress='자동 로그인 성공 · 로그인 유지 · '+(CREDENTIAL_BACKEND or 'DPAPI'),
                         realtime_rank={'rows':[],'daily_rows':[],'updated_at':None,'source':'키움 ka00198 · 2초 확인','daily_source':'키움 ka00198 · 당일 누적','error':None},
                         realtime_rank_prev={})
        _start_daily_stock_master_refresh(client)
        try:
            mapping=sectors.load()
            mapped=sum(1 for v in mapping.values() if v.get('sector') and v.get('sector')!='미분류')
            if mapped < 100 and not STATE.get('sector_busy'):
                threading.Thread(target=sector_sync_worker,daemon=True).start()
        except Exception:
            pass
        start_page1_live_engine()
        return True
    except Exception as e:
        with LOCK:
            STATE.update(client=None,connected=False,
                         progress='자동 로그인 실패 · 저장정보 유지 · '+str(e))
        return False

def _load_candidate_history():
    try:
        raw=json.loads(CANDIDATE_HISTORY.read_text(encoding='utf-8'))
        return raw if isinstance(raw,dict) else {}
    except (OSError,ValueError,TypeError,json.JSONDecodeError):
        return {}

def _save_candidate_history(history):
    CANDIDATE_HISTORY.parent.mkdir(parents=True,exist_ok=True)
    tmp=CANDIDATE_HISTORY.with_suffix('.tmp')
    tmp.write_text(json.dumps(history,ensure_ascii=False,indent=2),encoding='utf-8')
    tmp.replace(CANDIDATE_HISTORY)

def _prior_krx_trade_dates(today, limit=2):
    """Return the exact prior KRX trading-session dates.

    D+1/D+2 tracking must be anchored to the market calendar, never to the
    most recent dates that happen to exist in candidate_history.json.  This
    prevents a PC that was turned off for several sessions from reviving an
    old setup as if it were yesterday's candidate.
    """
    try:
        d=datetime.strptime(str(today)[:10],'%Y-%m-%d').date()
    except Exception:
        d=datetime.now(KST).date()
    out=[]
    cur=d-timedelta(days=1)
    guard=0
    while len(out)<max(0,int(limit)) and guard<370:
        guard+=1
        if _is_trade_day(cur): out.append(cur.isoformat())
        cur-=timedelta(days=1)
    return out

def _prior_candidate_snapshots(today, limit=2):
    history=_load_candidate_history()
    expected=_prior_krx_trade_dates(today,limit)
    out=[]
    for i,d in enumerate(expected,1):
        item=history.get(d) or {}
        out.append({
            'date':d,
            'stage':f'D+{i}',
            'stocks':item.get('stocks') or {},
            'recorded':bool(item),
            'saved_at':item.get('saved_at') if isinstance(item,dict) else None,
        })
    return out

def _latest_prior_candidates(today):
    snaps=_prior_candidate_snapshots(today,1)
    return snaps[0] if snaps else {'date':None,'stage':'D+1','stocks':{}}

def _save_today_candidates(report, day, lookup_rows=None):
    panels=((report or {}).get('search_panels') or {}).get('panels') or {}
    stocks={}
    for panel_name in ('주도주 종배','주도주 상따','끼도주 종배'):
        for row in (panels.get(panel_name) or {}).get('rows',[]):
            c=code(row.get('code'))
            rec=stocks.setdefault(c,{'code':c,'name':row.get('name') or c,'sector':row.get('sector') or '미분류','tags':[]})
            if panel_name not in rec['tags']:rec['tags'].append(panel_name)
            # Save the D-day facts needed for next-day explanation/audit.
            for k in ('price','value_eok','value_rank','change_rank','formula_close','prev_close','open','high','low','today_value','today_limit'):
                if row.get(k) is not None:rec[k]=row.get(k)
    # 조회순위종배 is built in the browser from ka00198 realtime TOP20, not
    # from search_panels.build().  Persist the same provider ranks separately.
    # Its inclusion in the visible prior-candidate list does NOT silently
    # change the locked three-formula Heart/Needle eligibility.
    for row in (lookup_rows or []):
        if not isinstance(row,dict):
            continue
        c=code(row.get('code') or '') if row.get('code') else ''
        try:
            rank=int(row.get('rank'))
        except (TypeError, ValueError):
            continue
        if not c or not 1 <= rank <= 20:
            continue
        rec=stocks.setdefault(c,{'code':c,'name':row.get('name') or c,
                                'sector':row.get('sector') or '미분류','tags':[]})
        if '조회순위종배' not in rec['tags']:
            rec['tags'].append('조회순위종배')
        rec['lookup_rank']=rank
        if rec.get('name') in (None,'',c) and row.get('name'):
            rec['name']=row['name']
        if rec.get('sector') in (None,'','미분류') and row.get('sector'):
            rec['sector']=row['sector']
    history=_load_candidate_history()
    # Do not overwrite an existing non-empty daily snapshot with an empty one
    # when the provider returned errors (or a partial/cancelled search).
    previously=(history.get(day) or {}).get('stocks') or {}
    with LOCK:
        scan_errors=bool(STATE.get('fetch_errors')) or bool(STATE.get('cancel').is_set())
    scan_errors=scan_errors or bool((report or {}).get('errors'))
    if not stocks and previously and scan_errors:
        return
    history[day]={'date':day,'saved_at':datetime.now(KST).isoformat(),'stocks':stocks}
    # Keep a bounded local history; enough for weekends/holidays and audit.
    for old in sorted(history)[:-260]:history.pop(old,None)
    _save_candidate_history(history)

def recompute():
    sectors.apply(STATE['data'],sectors.load())
    STATE['report']=scan_dataset(STATE['data'],STATE['settings'],STATE['market'])
    STATE['report']['errors']+=STATE['fetch_errors']
    ranks=STATE.get('ranks') or {}
    ranks['formula_rank_limits']=_formula_rank_limits()
    ranks['fzone_watchlist_codes']=list(STATE.get('fzone_watchlist') or [])
    STATE['ranks']=ranks
    STATE['report']['search_panels']=search_panels.build(STATE['report'],ranks)

recompute()
_restore_page1_runtime_cache()

# ---------------------------------------------------------------------------
# LIVE 주도주 종배 v1
# Rank membership is refreshed from Kiwoom ka10032 every 2 seconds while price,
# rate and accumulated trading fields are overlaid from domestic WebSocket 0B.
# This is intentionally separate from the normal scanner so the existing search
# result remains a stable audit snapshot.
LIVE_LEADER_LOCK=threading.RLock()
LIVE_LEADER_CACHE={'rank_at':0.0,'rank_rows':[],'payload':None}
LIVE_LEADER_ENGINE={'thread':None,'generation':0,'client_id':None,'started_at':0.0}

def _live_leader_engine_loop(client, generation):
    while True:
        with LIVE_LEADER_LOCK:
            if generation != LIVE_LEADER_ENGINE.get('generation'):
                return
        with LOCK:
            if not STATE.get('connected') or STATE.get('client') is not client:
                return
        try:
            live_leader_snapshot(False)
        except Exception:
            pass
        time.sleep(0.75)

def start_live_leader_engine():
    with LOCK:
        client=STATE.get('client')
        connected=bool(STATE.get('connected'))
    if not client or not connected:
        return False
    cid=id(client)
    with LIVE_LEADER_LOCK:
        t=LIVE_LEADER_ENGINE.get('thread')
        if t and t.is_alive() and LIVE_LEADER_ENGINE.get('client_id')==cid:
            return True
        LIVE_LEADER_ENGINE['generation']=int(LIVE_LEADER_ENGINE.get('generation') or 0)+1
        gen=LIVE_LEADER_ENGINE['generation']
        t=threading.Thread(target=_live_leader_engine_loop,args=(client,gen),daemon=True,name='LITTO-LIVE-LEADER')
        LIVE_LEADER_ENGINE.update(thread=t,client_id=cid,started_at=time.time())
        t.start()
    return True

def stop_live_leader_engine():
    with LIVE_LEADER_LOCK:
        LIVE_LEADER_ENGINE['generation']=int(LIVE_LEADER_ENGINE.get('generation') or 0)+1
        LIVE_LEADER_ENGINE['client_id']=None
        LIVE_LEADER_CACHE['payload']=None
        LIVE_LEADER_CACHE['rank_rows']=[]
        LIVE_LEADER_CACHE['rank_at']=0.0
        LIVE_LEADER_CACHE['page1_raw_top']=[]
        LIVE_LEADER_CACHE['page1_raw_at']=0.0
        LIVE_LEADER_CACHE['page1_raw_limit']=0


def _live_num(v, absolute=False):
    try:
        z=float(str(v).replace(',',''))
        return abs(z) if absolute else z
    except (ValueError,TypeError):
        return None


def live_leader_snapshot(force_rank=False):
    with LOCK:
        client=STATE.get('client')
    if not client:
        return {'rows':[],'updated_at':None,'rank_updated_at':None,'source':'키움 미연결',
                'realtime':{'connected':False,'state':'미연결','error':'키움 미연결'},'error':'키움 미연결'}
    now=time.time()
    try:
        with LIVE_LEADER_LOCK:
            rank_at=float(LIVE_LEADER_CACHE.get('rank_at') or 0)
            rank_rows=list(LIVE_LEADER_CACHE.get('rank_rows') or [])
        if force_rank or not rank_rows or now-rank_at>=2.0:
            rank_limit=_formula_rank_limits().get('주도주 종배',30)
            # Share fresh integrated TOP50 obtained by PAGE1 so the separate
            # leader panel need not issue the same provider request again.
            # Only reuse if its universe covers the requested rank range.
            with LIVE_LEADER_LOCK:
                shared_raw=list(LIVE_LEADER_CACHE.get('page1_raw_top') or [])
                shared_at=float(LIVE_LEADER_CACHE.get('page1_raw_at') or 0)
                shared_limit=int(LIVE_LEADER_CACHE.get('page1_raw_limit') or 0)
            # Reuse the PAGE1 ranking within its own 2-second polling cycle.
            # A missed PAGE1 refresh must not silently freeze this independent
            # panel: after a short grace period use the SAME provider gate.
            with PAGE1_LIVE_LOCK:
                page1_running=bool(PAGE1_LIVE_ENGINE.get('client_id')==id(client)
                                   and PAGE1_LIVE_ENGINE.get('thread')
                                   and PAGE1_LIVE_ENGINE['thread'].is_alive())
            shared_ok=(bool(shared_raw) and shared_limit>=max(30,rank_limit))
            shared_age=now-shared_at
            if shared_ok and shared_age<2.5:
                raw=shared_raw
            elif page1_running and shared_ok and shared_age<5.0:
                # Avoid a second 2-second rank REST stream while PAGE1 is active.
                raw=shared_raw
            else:
                # The previous direct client.top() bypassed rate-limit/backoff
                # accounting and could run concurrently with PAGE1 ranking.
                raw=_kiwoom_call(client.top,max(30,rank_limit),kind='rank')
            parsed=[]
            from yaksang import excluded_product
            for r in raw:
                c=base_code(r.get('stk_cd',''))
                rk=_live_num(r.get('now_rank'))
                if not c or rk is None or int(rk)>rank_limit: continue
                name=(r.get('stk_nm') or r.get('name') or c).strip()
                reason=excluded_product({'name':name,'product_type':r.get('product_type'),
                                         'etf':r.get('etf'),'etn':r.get('etn'),
                                         'leveraged':r.get('leveraged'),'inverse':r.get('inverse')})
                if not reason and ('스팩' in name or 'SPAC' in name.upper()): reason='스팩'
                if reason: continue
                parsed.append({'code':c,'name':name,'rank':int(rk),
                               'price':_live_num(r.get('cur_prc'),True),
                               'change_rate':_live_num(r.get('flu_rt')),
                               'acc_value':_live_num(r.get('trde_prica'),True)})
            parsed.sort(key=lambda x:(x['rank'],x['code']))
            rank_rows=parsed; rank_at=now
            with LIVE_LEADER_LOCK:
                LIVE_LEADER_CACHE['rank_at']=rank_at; LIVE_LEADER_CACHE['rank_rows']=rank_rows
        feed=getattr(client,'_domestic_realtime_feed',None)
        if feed is None:
            feed=DomesticRealtimeFeed(client); client._domestic_realtime_feed=feed
        feed.ensure([x['code'] for x in rank_rows],owner='leader')
        live,rt=feed.snapshot()
        rows=[]
        with LOCK:
            loaded_by_code={base_code(s.get('code','')):s for s in (STATE.get('data') or {}).get('stocks',[])}
        for base in rank_rows:
            q=live.get(base['code']) or {}
            price=q.get('price') if q.get('price') is not None else base.get('price')
            provider_rate=q.get('change_rate') if q.get('change_rate') is not None else base.get('change_rate')
            # 거래대금은 반드시 ka10032 통합(KRX+NXT, stex_tp=3) 값을 유지한다.
            # WebSocket 0B의 누적거래대금은 수신 거래소(KRX/NXT)별 값일 수 있어
            # 통합 거래대금 위에 덮어쓰면 화면이 KRX↔NXT 값으로 왕복한다.
            acc_value=base.get('acc_value')
            # Locked formula B: 차트 [일] 1봉전 종가 대비 현재 SOR 가격 >= +1%.
            # provider flu_rt/base_price는 검색식 판정에 사용하지 않는다.
            st=loaded_by_code.get(base['code']) or {}
            daily=st.get('daily') or []
            prev_close=None
            if len(daily)>=2:
                try: prev_close=float(daily[-2].get('close'))
                except (TypeError,ValueError,AttributeError): prev_close=None
            rate=((float(price)/prev_close-1.0)*100.0) if price is not None and prev_close not in (None,0) else None
            if rate is None or rate<1.0: continue
            rows.append({**base,'price':price,'change_rate':rate,'provider_change_rate':provider_rate,
                         'prev_close':prev_close,'acc_value':acc_value,
                         'acc_volume':q.get('acc_volume'),'time':q.get('time'),
                         'live':bool(q),'received_at':q.get('received_at')})
        payload={'rows':rows,'updated_at':datetime.now(KST).isoformat(),
                 'rank_updated_at':datetime.fromtimestamp(rank_at,KST).isoformat() if rank_at else None,
                 'source':f'ka10032 통합 거래대금 원순위 TOP{rank_limit} (2초) + WebSocket 0B 주식체결',
                 'rank_refresh_seconds':2,'realtime':rt,'error':None}
        with LIVE_LEADER_LOCK: LIVE_LEADER_CACHE['payload']=payload
        return payload
    except Exception as e:
        with LIVE_LEADER_LOCK: old=LIVE_LEADER_CACHE.get('payload')
        if old:
            return {**old,'error':'실시간 종배 갱신 실패: '+str(e)}
        return {'rows':[],'updated_at':None,'rank_updated_at':None,'source':'실시간 종배',
                'realtime':{'connected':False,'state':'오류','error':str(e)},'error':str(e)}


# ---------------------------------------------------------------------------
# PAGE 1 realtime engine
#
# Architecture:
#   * Heavy REST scan: once after 20:00 KST on trading days, or manually
#   * Candidate/rank refresh: 2 seconds (ka10032 + ka10027)
#   * Price/change/value/open/high/low: Kiwoom WebSocket 0B tick stream
#   * Panel calculation: local memory only; no heavy REST re-scan per tick
#
# This keeps 섹터 수정/설정/other pages responsive while the heavy scan runs.
PAGE1_LIVE_LOCK=threading.RLock()
PAGE1_RECALC_EVENT=threading.Event()
PAGE1_HYDRATE_Q=queue.Queue(maxsize=120)
PAGE1_LIVE_ENGINE={'thread':None,'recalc_thread':None,'hydrate_thread':None,'generation':0,'client_id':None,
                   'rank_at':0.0,'last_tick_at':0.0,'error':'','state':'대기','hydrating':set(),
                   'data_version':0,'recalc_version':0,'last_recalc_at':0.0,
                   'recalc_count':0,'last_recalc_ms':0.0,
                   'last_heavy_at':0.0,'next_heavy_at':0.0,'heavy_count':0,
                   'market_phase':'CLOSED','candidate_count':0,'hourly_auto_slot':None,
                   'safe_connected_at':0.0,'safe_rank_at':0.0,'safe_next_at':0.0}

def _page1_market_phase(now_dt=None):
    """Return the Page-1 automatic-search market phase.

    Automatic scanning is intentionally limited to actual SOR trading days and
    the broad NXT trading window (08:00~20:00 KST).  Before 08:00, after 20:00,
    weekends and configured KRX holidays are manual-search only.

    The short auction/gap periods inside the 08:00~20:00 window stay enabled so
    the scanner does not flap on/off around KRX/NXT session hand-offs.
    """
    now=now_dt or datetime.now(KST)
    if now.tzinfo is None:
        now=now.replace(tzinfo=KST)
    else:
        now=now.astimezone(KST)
    if not _is_trade_day(now.date()):return 'CLOSED'
    hm=now.hour*60+now.minute
    if hm<480:return 'PRE'          # before NXT 08:00
    if hm<540:return 'NXT_PRE'      # 08:00~09:00 broad pre/hand-off window
    if hm<930:return 'REGULAR'      # 09:00~15:30 KRX/NXT main session window
    if hm<1200:return 'NXT_AFTER'   # 15:30~20:00 after-market window
    return 'CLOSED'

def _request_page1_recalc():
    with PAGE1_LIVE_LOCK:
        PAGE1_LIVE_ENGINE['data_version']=int(PAGE1_LIVE_ENGINE.get('data_version') or 0)+1
    PAGE1_RECALC_EVENT.set()

def _page1_recalc_loop(client,generation):
    """Coalesced local calculation outside the global state lock."""
    while True:
        with PAGE1_LIVE_LOCK:
            if generation!=PAGE1_LIVE_ENGINE.get('generation'):return
        PAGE1_RECALC_EVENT.wait(0.8)
        if not PAGE1_RECALC_EVENT.is_set():continue
        PAGE1_RECALC_EVENT.clear()
        # Coalesce a short burst of price/sector updates before the expensive
        # deep copy and scan. The tick overlay continues independently.
        time.sleep(0.12)
        PAGE1_RECALC_EVENT.clear()
        with PAGE1_LIVE_LOCK:version=PAGE1_LIVE_ENGINE.get('data_version',0)
        recalc_started=time.monotonic()
        with LOCK:
            data=copy.deepcopy(STATE.get('data') or {'stocks':[]})
            settings=copy.deepcopy(STATE.get('settings') or {})
            market=STATE.get('market','unknown')
            ranks=copy.deepcopy(STATE.get('ranks') or {})
            ranks['fzone_watchlist_codes']=list(STATE.get('fzone_watchlist') or [])
            errors=copy.deepcopy(STATE.get('fetch_errors') or [])
        try:
            sectors.apply(data,sectors.load())
            report=scan_dataset(data,settings,market)
            report['errors']+=errors
            report['search_panels']=search_panels.build(report,ranks)
        except Exception as e:
            with PAGE1_LIVE_LOCK:PAGE1_LIVE_ENGINE['error']='로컬 패널 계산: '+str(e)[:220]
            continue
        with PAGE1_LIVE_LOCK:
            current=PAGE1_LIVE_ENGINE.get('data_version',0)
        if current!=version:
            PAGE1_RECALC_EVENT.set();continue
        with PAGE1_LIVE_LOCK:
            if generation!=PAGE1_LIVE_ENGINE.get('generation'):
                return
        with LOCK:
            if STATE.get('client') is not client or not STATE.get('connected'):
                continue
            STATE['report']=report
        with PAGE1_LIVE_LOCK:
            PAGE1_LIVE_ENGINE['recalc_version']=version;PAGE1_LIVE_ENGINE['last_recalc_at']=time.time()
            PAGE1_LIVE_ENGINE['recalc_count']=int(PAGE1_LIVE_ENGINE.get('recalc_count') or 0)+1
            PAGE1_LIVE_ENGINE['last_recalc_ms']=round((time.monotonic()-recalc_started)*1000,1)

def _page1_rank_num(v, absolute=False):
    try:
        z=float(str(v).replace(',',''))
        return abs(z) if absolute else z
    except (ValueError,TypeError):
        return None


def _page1_rank_refresh(client):
    """Refresh only the light candidate/rank lists.  No full historical scan."""
    rank_limit=_max_formula_rank_limit()
    raw=_kiwoom_call(client.top,max(50,rank_limit),kind='rank')
    # Retain only a very short local snapshot; never reuse old ranking data.
    with LIVE_LEADER_LOCK:
        LIVE_LEADER_CACHE['page1_raw_top']=list(raw or [])
        LIVE_LEADER_CACHE['page1_raw_at']=time.time()
        LIVE_LEADER_CACHE['page1_raw_limit']=max(50,rank_limit)
    change_rows=_kiwoom_call(client.change_top,100,kind='rank')
    value_rank_map={}; value_top=[]; rank_quotes={}; candidates=[]
    from yaksang import excluded_product
    for r in raw:
        c=base_code(r.get('stk_cd',''))
        rk=_page1_rank_num(r.get('now_rank'))
        if not c or rk is None: continue
        rk=int(rk)
        value_rank_map[c]=rk
        value_top.append(c)
        # ka10032 trde_prica is million KRW. 100 million KRW == 1 eok,
        # therefore provider_value / 100 gives the display value in 억원.
        provider_value_million=_page1_rank_num(r.get('trde_prica'),True)
        provider_value_eok=(provider_value_million/100.0) if provider_value_million is not None else None
        rank_quotes[c]={'price':_page1_rank_num(r.get('cur_prc'),True),
                        'change':_page1_rank_num(r.get('flu_rt')),
                        '_session_date':datetime.now(KST).date().isoformat(),
                        'value_eok':provider_value_eok,
                        'trading_value_million_krw':provider_value_million,
                        'provider_rank':rk,'name':(r.get('stk_nm') or r.get('name') or '').strip(),
                        'source':'ka10032 stex_tp=3 · PAGE1 LIVE'}
        if rk>rank_limit: continue
        name=(r.get('stk_nm') or r.get('name') or c).strip()
        reason=excluded_product({'name':name,'product_type':r.get('product_type'),
                                 'etf':r.get('etf'),'etn':r.get('etn'),
                                 'leveraged':r.get('leveraged'),'inverse':r.get('inverse')})
        if not reason and ('스팩' in name or 'SPAC' in name.upper()): reason='스팩'
        if not reason: candidates.append((c,name))
    change_top=[base_code(r.get('stk_cd','')) for r in change_rows if base_code(r.get('stk_cd',''))]
    with LOCK:
        ranks=STATE.get('ranks') or {}
        ranks['value_top']=value_top
        ranks['value_rank_map']=value_rank_map
        ranks['rank_quotes']=rank_quotes
        ranks['change_top']=change_top
        ranks['source']='PAGE1 LIVE · ka10032/ka10027 2초 + 0B 틱'
        STATE['ranks']=ranks
        # Keep visible 거래대금 alive from the authoritative integrated ka10032
        # response even before/while the first WebSocket tick is arriving.
        # The 0B tick overlay below will then replace it with the newest value.
        for st in (STATE.get('data') or {}).get('stocks',[]):
            cc=base_code(st.get('code',''))
            # Keep each loaded/watch stock's provider 거래대금 원순위 in sync.
            # Clearing to None when it leaves TOP50 prevents a stale <=35 rank
            # from incorrectly passing the closing-bet checklist.
            st['value_rank']=value_rank_map.get(cc)
            rv=(rank_quotes.get(cc) or {}).get('value_eok')
            if rv is not None:
                st['value_eok']=rv
                daily=st.get('daily') or []
                if daily and str(daily[-1].get('date',''))[:10]==datetime.now(KST).date().isoformat():
                    daily[-1]['value']=rv*100_000_000.0
    _request_page1_recalc()
    return candidates


def _page1_hydrate_new_candidates(client, candidates):
    """Queue newly-entered candidates; provider calls run on a dedicated worker."""
    with LOCK:existing={base_code(x.get('code','')) for x in STATE.get('data',{}).get('stocks',[])}
    queued=0
    for c,n in candidates:
        if c in existing:continue
        with PAGE1_LIVE_LOCK:
            if c in PAGE1_LIVE_ENGINE['hydrating']:continue
            PAGE1_LIVE_ENGINE['hydrating'].add(c)
        try:
            PAGE1_HYDRATE_Q.put_nowait((c,n));queued+=1
        except queue.Full:
            with PAGE1_LIVE_LOCK:PAGE1_LIVE_ENGINE['hydrating'].discard(c)
            break
    return bool(queued)

def _page1_hydrate_loop(client,generation):
    while True:
        with PAGE1_LIVE_LOCK:
            if generation!=PAGE1_LIVE_ENGINE.get('generation'):return
        try:c,name=PAGE1_HYDRATE_Q.get(timeout=.5)
        except queue.Empty:continue
        try:
            with LOCK:
                if any(base_code(x.get('code',''))==c for x in STATE.get('data',{}).get('stocks',[])):continue
                old_by_code={base_code(x.get('code','')):x for x in STATE.get('data',{}).get('stocks',[])}
            mapping=sectors.load();sec=(mapping.get(c) or {}).get('sector') or '미분류'
            fq=_kiwoom_call(client.quote,c,'SOR',kind='hydrate')
            fq=dict(fq or {});fq['_session_date']=datetime.now(KST).date().isoformat()
            resolved=(fq.get('name') or name or LOOKUP.get(c,{}).get('name') or c).strip()
            st=_kiwoom_call(client.stock,c,resolved,sec,kind='hydrate')
            st['review']=old_by_code.get(c,{}).get('review',{})
            if c in mapping:st['sector_source']=(mapping[c].get('source','')+' '+mapping[c].get('asof','')).strip()
            with LOCK:
                stocks=STATE.get('data',{}).setdefault('stocks',[])
                if not any(base_code(x.get('code',''))==c for x in stocks):stocks.append(st)
                ranks=STATE.get('ranks') or {};fqmap=ranks.setdefault('formula_quotes',{});qmap=ranks.setdefault('quotes',{})
                fqmap[c]=fq;dq=dict(fq);dq['display_source']='PAGE1 LIVE · 신규후보 비동기 보충 + 0B';qmap[c]=dq
            _request_page1_recalc()
        except Exception as e:
            with PAGE1_LIVE_LOCK:PAGE1_LIVE_ENGINE['error']='신규후보 보충: '+str(e)[:220]
        finally:
            with PAGE1_LIVE_LOCK:PAGE1_LIVE_ENGINE['hydrating'].discard(c)
            PAGE1_HYDRATE_Q.task_done()

def _page1_apply_ticks(client):
    """Overlay WebSocket ticks onto the current candidate pool and recalc panels locally."""
    with LOCK:
        stocks=list(STATE.get('data',{}).get('stocks',[]))
        ranks=STATE.get('ranks') or {}
    codes=[base_code(x.get('code','')) for x in stocks if base_code(x.get('code',''))]
    if not codes:return False,{'connected':False,'state':'후보 대기','subscribed':0,'live_count':0}
    feed=getattr(client,'_domestic_realtime_feed',None)
    if feed is None:
        feed=DomesticRealtimeFeed(client);client._domestic_realtime_feed=feed
    feed.ensure(codes,owner='page1')
    live,rt=feed.snapshot()
    changed=False; now_day=datetime.now(KST).date().isoformat()
    with LOCK:
        fqmap=(STATE.get('ranks') or {}).setdefault('formula_quotes',{})
        qmap=(STATE.get('ranks') or {}).setdefault('quotes',{})
        rqmap=(STATE.get('ranks') or {}).setdefault('rank_quotes',{})
        for st in STATE.get('data',{}).get('stocks',[]):
            c=base_code(st.get('code',''));q=live.get(c)
            if not q: continue
            stamp=float(q.get('received_at') or 0)
            prev=float(st.get('_live_received_at') or 0)
            if stamp<=prev: continue
            st['_live_received_at']=stamp;changed=True
            price=q.get('price');rate=q.get('change_rate')
            # 가격/등락/OHLC/거래량은 0B WebSocket으로 실시간 갱신한다.
            # 단, 거래대금(value_eok / daily.value)은 여기서 절대 덮어쓰지 않는다.
            # 거래대금은 _page1_rank_refresh()의 ka10032 stex_tp=3 통합(KRX+NXT)
            # 값만 사용해야 KRX/NXT 체결 이벤트가 교대로 들어와도 화면이 깜박이지 않는다.
            if price is not None: st['price']=price
            if rate is not None: st['change']=rate
            daily=st.get('daily') or []
            if daily:
                t=daily[-1]
                if str(t.get('date',''))[:10]==now_day:
                    if price is not None:t['close']=price
                    if q.get('open') is not None:t['open']=q['open']
                    if q.get('high') is not None:t['high']=q['high']
                    if q.get('low') is not None:t['low']=q['low']
                    if q.get('acc_volume') is not None:t['volume']=q['acc_volume']
            fq=fqmap.setdefault(c,{})
            if price is not None:fq['price']=price
            if rate is not None:fq['change']=rate
            if q.get('open') is not None:fq['open']=q['open']
            dq=qmap.setdefault(c,{})
            if price is not None:dq['price']=price
            if rate is not None:dq['change']=rate
            dq['display_source']='Kiwoom WebSocket 0B 틱 실시간'
            rq=rqmap.setdefault(c,{})
            if price is not None:rq['price']=price
            if rate is not None:rq['change']=rate
        if changed:
            pass
    if changed:_request_page1_recalc()
    return changed,rt


PAGE1_HOURLY_SCAN_MARKER=ROOT/'data'/'page1_hourly_auto.json'

def _page1_hourly_marker_slot():
    try:
        return str(json.loads(PAGE1_HOURLY_SCAN_MARKER.read_text(encoding='utf-8')).get('slot') or '')
    except (OSError,ValueError,TypeError,AttributeError):
        return ''

# R4 safe schedule: keep all existing search criteria and API access unchanged.
# First background full scan is deferred until connection has been stable for
# 120 seconds and at least one normal rank refresh has succeeded.
# After each completed scan, the next attempt is at least 300 seconds later.
PAGE1_SAFE_LOGIN_SETTLE=120.0
PAGE1_SAFE_SCAN_INTERVAL=300.0

def _page1_start_heavy_scan(client, force=False):
    now_dt=datetime.now(KST)
    if not _is_trade_day(now_dt.date()) or _page1_market_phase(now_dt) in ('PRE','CLOSED'):
        return False
    now=time.monotonic()
    with PAGE1_LIVE_LOCK:
        connected_at=float(PAGE1_LIVE_ENGINE.get('safe_connected_at') or 0)
        rank_at=float(PAGE1_LIVE_ENGINE.get('safe_rank_at') or 0)
        next_at=float(PAGE1_LIVE_ENGINE.get('safe_next_at') or 0)
    if not connected_at or not rank_at or now-connected_at<PAGE1_SAFE_LOGIN_SETTLE:
        return False
    if next_at and now<next_at:
        return False
    with LOCK:
        if not STATE.get('connected') or STATE.get('client') is not client or STATE.get('busy'):
            return False
        opts=copy.deepcopy(STATE.get('scan_options') or {'scope':'all','limit':100,'watchlist':''})
        STATE.update(busy=True,done=0,total=0,progress='안전 5분 전체검색 · 검색 대상 조회 중')
        STATE['cancel'].clear()
    # Reserve the slot before the worker starts; no duplicate scan starts.
    with PAGE1_LIVE_LOCK:
        PAGE1_LIVE_ENGINE['safe_next_at']=now+PAGE1_SAFE_SCAN_INTERVAL
    try:
        threading.Thread(target=live_worker,args=(opts,True),daemon=True,name='LITTO-PAGE1-SAFE5MIN').start()
    except Exception:
        with LOCK:STATE['busy']=False
        with PAGE1_LIVE_LOCK:
            PAGE1_LIVE_ENGINE['safe_next_at']=time.monotonic()+PAGE1_SAFE_SCAN_INTERVAL
        raise
    return True

# A slow REST ranking request must not block the WebSocket tick overlay loop.
# Only one rank worker can run at a time, including across reconnect generations.
_PAGE1_RANK_WORKER_LOCK=threading.Lock()

def _page1_rank_worker(client, generation):
    try:
        with PAGE1_LIVE_LOCK:
            if generation!=PAGE1_LIVE_ENGINE.get('generation'):
                return
        candidates=_page1_rank_refresh(client)
        with PAGE1_LIVE_LOCK:
            if generation!=PAGE1_LIVE_ENGINE.get('generation'):
                return
            PAGE1_LIVE_ENGINE['rank_at']=time.time()
            PAGE1_LIVE_ENGINE['candidate_count']=len(candidates)
            if not PAGE1_LIVE_ENGINE.get('safe_rank_at'):
                PAGE1_LIVE_ENGINE['safe_rank_at']=time.monotonic()
        _page1_hydrate_new_candidates(client,candidates)
    except Exception as e:
        with PAGE1_LIVE_LOCK:
            if generation==PAGE1_LIVE_ENGINE.get('generation'):
                PAGE1_LIVE_ENGINE['error']='순위 조회: '+str(e)[:220]
    finally:
        _PAGE1_RANK_WORKER_LOCK.release()

def _page1_live_loop(client,generation):
    next_rank=0.0
    while True:
        with PAGE1_LIVE_LOCK:
            if generation!=PAGE1_LIVE_ENGINE.get('generation'):return
        with LOCK:
            if not STATE.get('connected') or STATE.get('client') is not client:return
        try:
            now=time.time(); phase=_page1_market_phase()
            with PAGE1_LIVE_LOCK:PAGE1_LIVE_ENGINE['market_phase']=phase
            # Protect live tick application from REST ranking latency. During a
            # heavy scan, rank REST polling is advisory and can run less often;
            # WebSocket 0B quote/price delivery remains on this fast loop.
            changed,rt=_page1_apply_ticks(client)
            with LOCK:
                scan_busy=bool(STATE.get('busy'))
            if now>=next_rank and phase not in ('CLOSED','PRE'):
                # Do not spawn additional workers while a REST call is in flight.
                # Keep the shared API gate untouched; the worker obeys it normally.
                gate_free=API_GATE_LOCK.acquire(blocking=False)
                if gate_free:
                    API_GATE_LOCK.release()
                if gate_free and _PAGE1_RANK_WORKER_LOCK.acquire(blocking=False):
                    try:
                        threading.Thread(target=_page1_rank_worker,args=(client,generation),
                                         daemon=True,name='LITTO-PAGE1-RANK').start()
                    except Exception:
                        _PAGE1_RANK_WORKER_LOCK.release()
                        raise
                    next_rank=now+(10.0 if scan_busy else 2.0)
                else:
                    next_rank=now+1.0
            _page1_start_heavy_scan(client,False)
            with PAGE1_LIVE_LOCK:
                PAGE1_LIVE_ENGINE['state']='LIVE' if rt.get('connected') else (rt.get('state') or '연결 중')
                PAGE1_LIVE_ENGINE['error']=rt.get('error') or PAGE1_LIVE_ENGINE.get('error','')
                if changed:PAGE1_LIVE_ENGINE['last_tick_at']=time.time()
            time.sleep(.35)
        except Exception as e:
            with PAGE1_LIVE_LOCK:
                PAGE1_LIVE_ENGINE['state']='재시도';PAGE1_LIVE_ENGINE['error']=str(e)[:300]
            time.sleep(1.0)

def start_page1_live_engine():
    with LOCK:client=STATE.get('client');connected=bool(STATE.get('connected'));mode=(STATE.get('data') or {}).get('mode')
    if not client or not connected:return False
    cid=id(client)
    with PAGE1_LIVE_LOCK:
        t=PAGE1_LIVE_ENGINE.get('thread')
        if t and t.is_alive() and PAGE1_LIVE_ENGINE.get('client_id')==cid:return True
        PAGE1_LIVE_ENGINE['generation']=int(PAGE1_LIVE_ENGINE.get('generation') or 0)+1
        gen=PAGE1_LIVE_ENGINE['generation'];now=time.time()
        PAGE1_LIVE_ENGINE.update(client_id=cid,state='시작 중',error='',next_heavy_at=0.0,
                                 safe_connected_at=time.monotonic(),safe_rank_at=0.0,safe_next_at=0.0)
        t=threading.Thread(target=_page1_live_loop,args=(client,gen),daemon=True,name='LITTO-PAGE1-LIVE')
        r=threading.Thread(target=_page1_recalc_loop,args=(client,gen),daemon=True,name='LITTO-PAGE1-RECALC')
        h=threading.Thread(target=_page1_hydrate_loop,args=(client,gen),daemon=True,name='LITTO-PAGE1-HYDRATE')
        PAGE1_LIVE_ENGINE.update(thread=t,recalc_thread=r,hydrate_thread=h)
        t.start();r.start();h.start()
    return True

def stop_page1_live_engine():
    with PAGE1_LIVE_LOCK:
        PAGE1_LIVE_ENGINE['generation']=int(PAGE1_LIVE_ENGINE.get('generation') or 0)+1
        PAGE1_LIVE_ENGINE['client_id']=None;PAGE1_LIVE_ENGINE['state']='중지'
    PAGE1_RECALC_EVENT.set()


def page1_live_status():
    with PAGE1_LIVE_LOCK:
        now=time.time();next_heavy=float(PAGE1_LIVE_ENGINE.get('next_heavy_at') or 0)
        base={'state':PAGE1_LIVE_ENGINE.get('state','대기'),'error':PAGE1_LIVE_ENGINE.get('error',''),
              'rank_refresh_seconds':2,
              'rank_updated_at':datetime.fromtimestamp(PAGE1_LIVE_ENGINE['rank_at'],KST).isoformat() if PAGE1_LIVE_ENGINE.get('rank_at') else None,
              'last_tick_at':datetime.fromtimestamp(PAGE1_LIVE_ENGINE['last_tick_at'],KST).isoformat() if PAGE1_LIVE_ENGINE.get('last_tick_at') else None,
              'last_recalc_at':datetime.fromtimestamp(PAGE1_LIVE_ENGINE['last_recalc_at'],KST).isoformat() if PAGE1_LIVE_ENGINE.get('last_recalc_at') else None,
              'last_heavy_at':datetime.fromtimestamp(PAGE1_LIVE_ENGINE['last_heavy_at'],KST).isoformat() if PAGE1_LIVE_ENGINE.get('last_heavy_at') else None,
              'next_heavy_seconds':None,
              'auto_scan_mode':'HOURLY_15_TO_20',
              'hourly_auto_slot':PAGE1_LIVE_ENGINE.get('hourly_auto_slot') or _page1_hourly_marker_slot(),
              'heavy_scan_seconds':None,'heavy_count':PAGE1_LIVE_ENGINE.get('heavy_count',0),
              'candidate_count':PAGE1_LIVE_ENGINE.get('candidate_count',0),'hydrating':len(PAGE1_LIVE_ENGINE.get('hydrating') or []),
              'recalc_count':PAGE1_LIVE_ENGINE.get('recalc_count',0),
              'last_recalc_ms':PAGE1_LIVE_ENGINE.get('last_recalc_ms',0),
              'market_phase':PAGE1_LIVE_ENGINE.get('market_phase','CLOSED')}
    with LOCK:
        client=STATE.get('client'); busy=bool(STATE.get('busy'))
    rt={}
    if client:
        try:
            feed=getattr(client,'_domestic_realtime_feed',None)
            if feed:_,rt=feed.snapshot()
        except Exception:pass
    base['busy']=busy;base['realtime']=rt;base['api_gate']=_api_gate_status()
    return base


def snapshot():
    sector_map=sectors.load()
    with LOCK:
        universe=UNIVERSE
        out={k:STATE.get(k) for k in ('report','busy','progress','done','total','connected','mock','fetch_errors',
             'sector_busy','sector_progress','sector_done','sector_total')}
    sector_stats=sectors.stats(universe,sector_map) if universe else {'total':0,'mapped':len(sector_map),'manual':sum(str(v.get('source','')).startswith('사용자 직접 지정') for v in sector_map.values()),'missing_count':0,'missing':[]}
    out.update(universe_count=len(universe),sector_count=sector_stats.get('mapped',len(sector_map)),
               sector_stats=sector_stats,page1_live=page1_live_status(),formula_rank_limits=_formula_rank_limits(),today_limit_min_eok=_today_limit_min_eok(),credential_saved=CREDENTIAL_SAVED,
               credential_backend=CREDENTIAL_BACKEND,credential_error=CREDENTIAL_LAST_ERROR,
               autologin_version=AUTOLOGIN_VERSION,
               credential_files={'native':CREDENTIAL_FILE.exists(),'powershell':CREDENTIAL_PS_FILE.exists()})
    return out


def _best_known_stock_name(stock_code,*sources):
    """Return the best non-code stock name already known locally.

    Never performs a provider request.  Ranking popups can therefore repair missing
    names without blocking the 2-second rank loop or the UI thread.
    """
    c=code(stock_code) if stock_code else ''
    if not c:return ''
    def valid(v):
        t=str(v or '').strip()
        return t if t and t!=c and not (t.isdigit() and code(t)==c) else ''
    for src in sources:
        if isinstance(src,dict):
            for k in ('name','stock_name','stk_nm','종목명'):
                v=valid(src.get(k))
                if v:return v
    base=LOOKUP.get(c) or LOOKUP.get(str(c)) or {}
    for k in ('name','stock_name','stk_nm','종목명'):
        v=valid(base.get(k) if isinstance(base,dict) else '')
        if v:
            _cache_stock_name(c,v)
            return v
    # Full-market master/cache is authoritative fallback for stocks that have
    # never appeared in LITTO's own scanner/ranking dataset.
    with STOCK_NAME_LOCK:
        v=valid(STOCK_NAME_CACHE.get(c))
    if v:return v
    # Scanner/live dataset is the next most reliable local source and is already
    # populated for names that may be newer than the bundled universe file.
    with LOCK:
        data=(STATE.get('data') or {})
        report=(STATE.get('report') or {})
    for st in (data.get('stocks') or []):
        try:sc=code(st.get('code')) if st.get('code') else ''
        except Exception:sc=''
        if sc==c:
            v=valid(st.get('name'))
            if v:return v
    for rr in (report.get('results') or []):
        try:rc=code(rr.get('code')) if rr.get('code') else ''
        except Exception:rc=''
        if rc==c:
            v=valid(rr.get('name'))
            if v:return v
    panels=((report.get('search_panels') or {}).get('panels') or {})
    for panel in panels.values():
        for rr in ((panel or {}).get('rows') or []):
            try:rc=code(rr.get('code')) if rr.get('code') else ''
            except Exception:rc=''
            if rc==c:
                v=valid(rr.get('name'))
                if v:return v
    # Do not block the ranking popup.  Queue a one-shot provider lookup and let
    # the next 2-second refresh replace the temporary code with the resolved name.
    _queue_stock_name_lookup(c)
    return c

REALTIME_RANK_FETCH_LOCK=threading.RLock()
REALTIME_DAILY_CACHE={'at':0.0,'rows':[],'updated_at':None,'error':None}
REALTIME_DAILY_TTL=300.0

def realtime_rank_snapshot(force=False):
    """Fetch/cache Kiwoom ka00198 lookup ranking without provider-call bursts.

    The 30-second provider ranking (qry_tp=5) keeps the existing fast refresh.
    The provider's day-cumulative ranking (qry_tp=4) is isolated behind a short
    cache because it changes slowly and must not make a transient failure block
    the live ranking.  No ranking/filtering formula is changed here.
    """
    with LOCK:
        client=STATE.get('client')
        cached=dict(STATE.get('realtime_rank') or {})
    if not client:
        return {'rows':[],'daily_rows':[],'updated_at':None,'source':'키움 ka00198 · 30초 확인','daily_source':'키움 ka00198 · 당일 누적','error':'키움 미연결'}

    # Manual refresh and the 30-second timer can overlap.  Only one provider
    # refresh is allowed at a time; followers re-check the freshly stored cache.
    with REALTIME_RANK_FETCH_LOCK:
        now=datetime.now(KST)
        with LOCK:
            cached=dict(STATE.get('realtime_rank') or {})
        old_at=cached.get('updated_at')
        if not force and old_at:
            try:
                if (now-datetime.fromisoformat(old_at)).total_seconds()<30.0:
                    return cached
            except (ValueError,TypeError):
                pass

        try:
            rows=_kiwoom_call(client.realtime_rank,'5',30,kind='popular')
        except Exception as e:
            if cached:
                cached['error']='조회순위 갱신 실패: '+str(e)
                cached['stale']=True
                try:
                    cached['stale_seconds']=max(0.0,(now-datetime.fromisoformat(cached.get('updated_at'))).total_seconds())
                except Exception:
                    cached['stale_seconds']=None
                return cached
            return {'rows':[],'daily_rows':[],'updated_at':None,
                    'source':'키움 ka00198 · 실시간종목조회순위 · 30초 확인',
                    'daily_source':'키움 ka00198 · 실시간종목조회순위 · 당일 누적',
                    'error':'조회순위 갱신 실패: '+str(e),'stale':True,'stale_seconds':None}

        try:
            rank_sector_map=sectors.load()
        except Exception:
            rank_sector_map={}
        def _rank_sector(c):
            m=(rank_sector_map.get(c) or {}) if isinstance(rank_sector_map,dict) else {}
            s=str((m or {}).get('sector') or '').strip()
            if s:
                return s
            base=(LOOKUP.get(c) or {}) if isinstance(LOOKUP,dict) else {}
            return str((base or {}).get('sector') or '기타').strip() or '기타'

        # qry_tp=4 is provider-calculated day cumulative.  Refreshing this every
        # 30 seconds doubles ka00198 traffic for little benefit, so keep the last
        # successful result for 15 seconds.  If it fails, live qry_tp=5 still
        # updates normally and the previous daily cumulative result is retained.
        now_ts=time.time()
        daily_error=None
        with LOCK:
            daily_rows=list(REALTIME_DAILY_CACHE.get('rows') or [])
            daily_at=float(REALTIME_DAILY_CACHE.get('at') or 0.0)
            daily_updated_at=REALTIME_DAILY_CACHE.get('updated_at')
        if force or not daily_rows or (now_ts-daily_at)>=REALTIME_DAILY_TTL:
            try:
                fresh_daily=_kiwoom_call(client.realtime_rank,'4',30,kind='popular')
                daily_rows=list(fresh_daily or [])
                daily_updated_at=now.isoformat()
                with LOCK:
                    REALTIME_DAILY_CACHE['at']=now_ts
                    REALTIME_DAILY_CACHE['rows']=daily_rows
                    REALTIME_DAILY_CACHE['updated_at']=daily_updated_at
                    REALTIME_DAILY_CACHE['error']=None
            except Exception as e:
                daily_error='당일 누적 갱신 지연: '+str(e)
                with LOCK:
                    REALTIME_DAILY_CACHE['error']=daily_error

        with LOCK:
            prev=dict(STATE.get('realtime_rank_prev') or {})
        current={}
        normalized=[]
        for r in rows:
            c=code(r.get('code')) if r.get('code') else ''
            rank=int(r['rank'])
            previous=prev.get(c) if c else None
            move=(int(previous)-rank) if previous is not None else None
            x=dict(r,code=c,previous_rank=previous,move=move,new=(previous is None))
            x['name']=_best_known_stock_name(c,r)
            x['sector']=_rank_sector(c)
            normalized.append(x)
            if c: current[c]=rank
        normalized_daily=[]
        for r in daily_rows:
            x=dict(r)
            c=code(x.get('code')) if x.get('code') else ''
            x['code']=c
            x['name']=_best_known_stock_name(c,r)
            x['sector']=_rank_sector(c)
            normalized_daily.append(x)
        payload={'rows':normalized,'daily_rows':normalized_daily,'updated_at':now.isoformat(),
                 'daily_updated_at':daily_updated_at,
                 'source':'키움 ka00198 · 실시간종목조회순위 · 30초 확인',
                 'daily_source':'키움 ka00198 · 실시간종목조회순위 · 당일 누적',
                 'daily_error':daily_error,'error':None,'stale':False,'stale_seconds':0.0}
        with LOCK:
            STATE['realtime_rank_prev']=current
            STATE['realtime_rank']=payload
        return payload


MARKET_MOVERS_LOCK=threading.RLock()
MARKET_MOVERS_CACHE={'at':0.0,'payload':None}

def _market_mover_sector(code_value, mapping):
    c=base_code(code_value)
    m=(mapping.get(c) or {}) if isinstance(mapping,dict) else {}
    sector=str(m.get('sector') or '').strip()
    if sector and sector not in {'미분류','기타'}:
        return sector
    base=(LOOKUP.get(c) or {}) if isinstance(LOOKUP,dict) else {}
    sector=str(base.get('sector') or '').strip()
    return sector or '기타'

def market_movers_snapshot(force=False):
    """HTS 0177-style 상승/하락 TOP20 + 상승 TOP20 섹터 그룹핑.

    0177 is the Kiwoom HTS screen number. The REST data source used here is
    ka10027 전일대비등락률상위 with integrated SOR (KRX+NXT), because REST
    does not expose HTS screen numbers directly.
    """
    with LOCK:
        client=STATE.get('client')
    if not client:
        return {
            'up':[],'down':[],'sector_groups':[],'updated_at':None,
            'source':'키움 미연결','error':'키움 API 연결이 필요합니다.'
        }

    now=time.time()
    with MARKET_MOVERS_LOCK:
        cached=MARKET_MOVERS_CACHE.get('payload')
        cached_at=float(MARKET_MOVERS_CACHE.get('at') or 0)
    if not force and cached and now-cached_at < 5.0:
        return cached

    try:
        up=_kiwoom_call(client.change_top_side,'up',20,kind='popular')
        down=_kiwoom_call(client.change_top_side,'down',20,kind='popular')
        mapping=sectors.load()

        def enrich(rows):
            out=[]
            for r in (rows or [])[:20]:
                x=dict(r)
                c=base_code(x.get('code') or '')
                x['code']=c
                x['name']=_best_known_stock_name(c,x)
                x['sector']=_market_mover_sector(c,mapping)
                out.append(x)
            return out

        up=enrich(up)
        down=enrich(down)

        groups={}
        for row in up:
            sector=str(row.get('sector') or '기타').strip() or '기타'
            # multi-tag sectors are grouped under each user-visible sector tag.
            tags=[x.strip() for x in re.split(r'[,;/|]+',sector) if x.strip()]
            if not tags:
                tags=['기타']
            for tag in tags:
                g=groups.setdefault(tag,{'sector':tag,'count':0,'stocks':[],'avg_change':0.0,'max_change':None})
                g['count']+=1
                g['stocks'].append({
                    'rank':row.get('rank'),'code':row.get('code'),'name':row.get('name'),
                    'price':row.get('price'),'change_rate':row.get('change_rate')
                })

        sector_groups=[]
        for g in groups.values():
            vals=[float(x.get('change_rate')) for x in g['stocks'] if x.get('change_rate') is not None]
            g['avg_change']=sum(vals)/len(vals) if vals else None
            g['max_change']=max(vals) if vals else None
            g['stocks'].sort(key=lambda x:(int(x.get('rank') or 999),str(x.get('code') or '')))
            sector_groups.append(g)
        sector_groups.sort(key=lambda g:(-int(g.get('count') or 0),
                                         -(float(g.get('avg_change')) if g.get('avg_change') is not None else -999),
                                         str(g.get('sector') or '')))

        payload={
            'up':up,'down':down,'sector_groups':sector_groups,
            'updated_at':datetime.now(KST).isoformat(),
            'source':'키움 HTS 0177 대응 · 상승/하락 + 거래대금순 · ka10032 통합시세(KRX+NXT) · 5초 캐시',
            'error':None
        }
        with MARKET_MOVERS_LOCK:
            MARKET_MOVERS_CACHE['at']=now
            MARKET_MOVERS_CACHE['payload']=payload
        return payload
    except Exception as e:
        with MARKET_MOVERS_LOCK:
            old=MARKET_MOVERS_CACHE.get('payload')
        if old:
            return {**old,'error':'0177 상승/하락 갱신 실패: '+str(e)}
        return {
            'up':[],'down':[],'sector_groups':[],'updated_at':None,
            'source':'키움 HTS 0177 대응','error':'0177 상승/하락 갱신 실패: '+str(e)
        }

def sector_sync_worker():
    global UNIVERSE,LOOKUP
    try:
        with LOCK:
            client=STATE.get('client');STATE['sector_busy']=True;STATE['sector_progress']='상장 종목 목록 조회 중';STATE['sector_done']=0;STATE['sector_total']=0
        if not client:raise ApiError('먼저 키움 API를 연결하세요.')
        universe=client.universe()
        if not universe:raise ApiError('상장 종목 목록을 가져오지 못했습니다.')
        with LOCK:
            UNIVERSE=universe;LOOKUP={x['code']:x for x in UNIVERSE};STATE['sector_total']=len(universe)
        def prog(done,total,msg):
            with LOCK:
                STATE['sector_done']=done;STATE['sector_total']=total;STATE['sector_progress']=msg
        current=sectors.load()
        # Primary source: Kiwoom's official industry catalogue + constituents.
        # This avoids relying on an external HTML layout. Manual assignments are
        # never overwritten. Naver remains a fallback only for still-missing rows.
        prog(0,len(universe),'키움 업종 자동분류 조회 중')
        official=client.industry_map()
        added=0
        for c,info in official.items():
            old=current.get(c) or {}
            if str(old.get('source','')).startswith('사용자 직접 지정'):
                continue
            if not old.get('sector') or old.get('sector')=='미분류':
                current[c]=info; added+=1
        # Fallback only for stocks Kiwoom did not classify.
        fallback,st=sector_sync.sync(universe,current,workers=6,progress=prog)
        for c,info in fallback.items():
            old=current.get(c) or {}
            if str(old.get('source','')).startswith('사용자 직접 지정'):
                continue
            if not old.get('sector') or old.get('sector')=='미분류':
                current[c]=info; added+=1
        sectors.save(current)
        stats=sectors.stats(universe,current)
        with LOCK:
            sectors.apply(STATE['data'],current);recompute();STATE['sector_progress']=f"자동 섹터 완료 · {stats['mapped']:,}/{stats['total']:,}종목 분류 · 신규 {added:,}개"
    except Exception as e:
        with LOCK:STATE['sector_progress']='섹터 동기화 실패: '+str(e)
    finally:
        with LOCK:STATE['sector_busy']=False

# Optional market-theme refresh. Never runs in scanner, websocket or order paths.
THEME_REFRESH_STATE={'busy':False,'progress':'시장테마 갱신 대기','done':0,'total':0}
THEME_REFRESH_LOCK=threading.Lock()
def market_theme_refresh_worker():
    def report(done,total,message):
        with THEME_REFRESH_LOCK:THEME_REFRESH_STATE.update(done=done,total=total,progress=message)
    try:
        with LOCK: theme_client=STATE.get('client')
        if theme_client is None: raise RuntimeError('키움 API 연결 후 다시 시도하세요.')
        new,stats=market_theme_sync.fetch_theme_map(client=theme_client,progress=report)
        old=sectors.load()
        merged,changed=market_theme_sync.merge_verified(old,new)
        # Keep a separate, verified provider snapshot for provenance diagnostics.
        # Never overwrite user-assigned sectors in the active mapping.
        theme_snapshot_path=sectors.DATA_DIR/'kiwoom_market_theme_snapshot.json'
        theme_snapshot_path.parent.mkdir(parents=True,exist_ok=True)
        snapshot_tmp=theme_snapshot_path.with_suffix('.tmp')
        snapshot_tmp.write_text(json.dumps({'asof':datetime.now(KST).isoformat(),
            'themes_by_code':{k:'/'.join(v) for k,v in new.items()}},ensure_ascii=False),encoding='utf-8')
        os.replace(snapshot_tmp,theme_snapshot_path)
        if changed:
            sectors.save(merged)
        # Reconcile screen rows even when the imported mapping was unchanged.
        # A previous scan or restored snapshot can still show a stale industry.
        with LOCK:
            sectors.apply(STATE['data'],merged)
        _request_page1_recalc()
        # Persist the successful daily refresh marker only after verified theme data is received.
        try:
            stamp=sectors.DATA_DIR/'market_theme_last_success.json'
            stamp.parent.mkdir(parents=True,exist_ok=True)
            stamp.write_text(json.dumps({'date':datetime.now(KST).date().isoformat(),'themes':stats['valid_themes'],'stocks':stats['stocks']},ensure_ascii=False),encoding='utf-8')
        except Exception:pass
        report(stats['valid_themes'],stats['themes'],f"시장테마 갱신 완료 · 테마 {stats['valid_themes']}개 · 종목 {stats['stocks']}개 · 갱신 {changed}개")
    except Exception as exc:
        report(0,0,'시장테마 갱신 실패 · 기존 데이터 유지: '+str(exc)[:180])
    finally:
        with THEME_REFRESH_LOCK:THEME_REFRESH_STATE['busy']=False

def _start_market_theme_refresh_if_stale():
    """One low-priority refresh at startup on a stale day, never in quote/search/order paths.
    Manual user rows are protected by merge_verified. Failed imports keep old sectors.
    """
    try:
        with LOCK: connected=STATE.get('client') is not None
        if not connected:return
        stamp=sectors.DATA_DIR/'market_theme_last_success.json'
        if stamp.exists():
            saved=json.loads(stamp.read_text(encoding='utf-8'))
            if saved.get('date')==datetime.now(KST).date().isoformat():return
        with THEME_REFRESH_LOCK:
            if THEME_REFRESH_STATE['busy']:return
            THEME_REFRESH_STATE.update(busy=True,progress='시장테마 자동 갱신 준비',done=0,total=0)
        threading.Thread(target=market_theme_refresh_worker,daemon=True,name='LITTO-MARKET-THEME').start()
    except Exception as exc:
        print('[theme] 자동 갱신 시작 실패:',str(exc)[:160],flush=True)

# Scanner-only progress telemetry. Never calls Kiwoom or acquires the API gate.
SCAN_TRACE_LOCK=threading.Lock()
SCAN_TRACE={'phase':'idle','symbol':'','step':0,'total':0,'updated_at':0.0,
            'started_at':0.0,'finished_at':0.0,'last_error':'','automatic':False}

def _scan_trace(phase, symbol='', step=None, total=None, error=None):
    now=time.time()
    with SCAN_TRACE_LOCK:
        SCAN_TRACE['phase']=str(phase)[:90]
        SCAN_TRACE['symbol']=str(symbol)[:16]
        SCAN_TRACE['updated_at']=now
        if step is not None:SCAN_TRACE['step']=int(step)
        if total is not None:SCAN_TRACE['total']=int(total)
        if error is not None:SCAN_TRACE['last_error']=str(error)[:300]

def _scan_trace_snapshot():
    with SCAN_TRACE_LOCK:result=dict(SCAN_TRACE)
    result['age_seconds']=round(max(0,time.time()-result['updated_at']),1) if result['updated_at'] else None
    with LOCK:result['busy']=bool(STATE.get('busy'))
    return result

def live_worker(options, automatic=False):
    """Run the three user formulas first, then the Newheart technique analysis.

    Search-core rule: do not mix display values with formula values.
    * value rank: ka10032 stex_tp=3 raw rank preserved; ETF/ETN/leveraged/inverse removed after top-N is fixed
    * change rank: ka10027 stex_tp=3
    * formula change: [일] 1봉전 종가 대비 0봉전 종가 직접 계산; 0봉 현재/open: SOR(_AL)
    * display current/change: same integrated SOR(_AL) quote as the formula (KRX+NXT, including after-market through 20:00)
    """
    collected=[];errors=[]
    with SCAN_TRACE_LOCK:
        SCAN_TRACE.update(started_at=time.time(),finished_at=0.0,last_error='',automatic=bool(automatic))
    _scan_trace('starting',step=0,total=0)
    try:
        with LOCK:client=STATE['client']
        if not client:raise ApiError('먼저 키움 API를 연결하세요.')
        n=int(options.get('limit',50))
        if n not in (20,50,100,200):raise ValueError('검색 상위 개수는 20/50/100/200입니다.')
        manual=[code(x.strip()) for x in options.get('watchlist','').replace('\n',',').split(',') if x.strip()]
        if len(manual)>200:raise ValueError('관심종목은 최대 200개입니다.')
        today=datetime.now(KST).date().isoformat()
        # Keep Needle/Heart on the original D+1/D+2 window, but let F-zone
        # quietly watch saved candidates through D+10.  This separation avoids
        # changing the proven D+1/D+2 techniques while extending only F-zone.
        prior_snapshots=_prior_candidate_snapshots(today,2)
        fzone_snapshots=_prior_candidate_snapshots(today,10)
        prior_snapshot=prior_snapshots[0] if prior_snapshots else {'date':None,'stage':'D+1','stocks':{}}
        prior_codes=[]
        for snap in prior_snapshots:
            for c in (snap.get('stocks') or {}):
                if c not in prior_codes: prior_codes.append(c)
        fzone_codes=[]
        for snap in fzone_snapshots:
            for c in (snap.get('stocks') or {}):
                if c not in fzone_codes: fzone_codes.append(c)

        # The three formulas share provider value-rank data but each has its own user-selected rank ceiling.
        # Pull through the largest selected ceiling so no panel can miss a valid candidate.
        formula_rank_limits=_formula_rank_limits()
        max_formula_rank=max(formula_rank_limits.values())
        # Only initial rank bootstrapping gets bounded gate-contention retries.
        # Successful calls take the original fast path without sleeps/extra API calls.
        # Never retry transport, rate-limit, or provider failures here.
        def _scan_initial_rank_call(fn, *call_args):
            """Wait briefly for bootstrap gate admission, without making extra provider calls.

            Only scanner bootstrap gets this behavior. A busy gate must not
            silently discard the first required ranking result; conversely
            orders, quotes, WebSocket and per-stock scan remain unchanged.
            """
            deadline = time.monotonic() + 15.0
            while True:
                if STATE['cancel'].is_set():
                    raise ApiError('사용자가 검색을 중지했습니다.')
                # A cheap, non-blocking gate check avoids repeated 1.25s
                # admissions and extra provider calls while another task runs.
                gate_free = API_GATE_LOCK.acquire(blocking=False)
                if gate_free:
                    API_GATE_LOCK.release()
                    try:
                        return _kiwoom_call(fn, *call_args, kind='heavy')
                    except ApiError as exc:
                        # The gate may have been taken between probe and call.
                        # Retry only on this transient contention, never on
                        # provider, transport, rate-limit or authentication errors.
                        if '검색 API 게이트 대기 초과 (3초)' not in str(exc):
                            raise
                if time.monotonic() >= deadline:
                    raise ApiError('초기 순위 조회: API 게이트 혼잡이 15초 지속되어 검색을 시작하지 못했습니다.')
                time.sleep(min(0.20, max(0.0, deadline - time.monotonic())))

        _scan_trace('initial_value_rank')
        value_rows=_scan_initial_rank_call(client.top,max(max_formula_rank,n))
        _scan_trace('initial_change_rank')
        change_rows=_scan_initial_rank_call(client.change_top,100)
        # Preserve Kiwoom's provider RAW integrated trading-value rank exactly.
        # IMPORTANT: ka10032 provides `now_rank`; never re-number rows by response order.
        # The locked formula universe is provider now_rank <= 30.
        raw_value_top=[base_code(r['stk_cd']) for r in value_rows]
        value_top=raw_value_top
        change_top=[base_code(r['stk_cd']) for r in change_rows]

        def _rank_num(v, absolute=False):
            try:
                z=float(str(v).replace(',',''))
                return abs(z) if absolute else z
            except (ValueError,TypeError):
                return None

        value_rank_map={}
        raw_formula_rows=[]
        for r in value_rows:
            c=base_code(r.get('stk_cd',''))
            if not c:
                continue
            provider_rank=_rank_num(r.get('now_rank'))
            if provider_rank is None:
                continue
            provider_rank=int(provider_rank)
            value_rank_map[c]=provider_rank
            if provider_rank <= max_formula_rank:
                raw_formula_rows.append(r)

        raw_formula_rows.sort(key=lambda r:(value_rank_map.get(base_code(r.get('stk_cd','')),99999),
                                           base_code(r.get('stk_cd',''))))
        # MTS target semantics:
        # 1) First fix the RAW integrated transaction-value ranks 1..30.
        # 2) Only AFTER rank positions are fixed, hide ETF/ETN/SPAC from the search result.
        #    Vacated ranks stay vacant; rank 36+ is never promoted.
        search_codes=[]
        rank_excluded=[]
        for r in raw_formula_rows:
            c=base_code(r.get('stk_cd',''))
            if not c:
                continue
            name=(r.get('stk_nm') or r.get('name') or '').strip()
            from yaksang import excluded_product
            reason=excluded_product({'name':name,'product_type':r.get('product_type'),
                                     'etf':r.get('etf'),'etn':r.get('etn'),
                                     'leveraged':r.get('leveraged'),'inverse':r.get('inverse')})
            upper_name=name.upper()
            if not reason and ('스팩' in name or 'SPAC' in upper_name):
                reason='스팩'
            if reason:
                rank_excluded.append({
                    'code':c,
                    'name':name,
                    'rank':value_rank_map.get(c),
                    'reason':reason,
                })
                continue
            search_codes.append(c)

        rank_quotes={}
        for r in value_rows:
            c=base_code(r.get('stk_cd',''))
            if not c: continue
            rank_quotes[c]={
                'price':_rank_num(r.get('cur_prc'),True),
                'change':_rank_num(r.get('flu_rt')),
                'provider_rank':_rank_num(r.get('now_rank')),
                'name':(r.get('stk_nm') or '').strip(),
                'source':'ka10032 stex_tp=3'
            }

        today_limit_codes=_kiwoom_call(client.limit_codes,False,kind='heavy')
        prev_limit_codes=_kiwoom_call(client.limit_codes,True,kind='heavy')
        # The F-zone watchlist must exist before rank_data captures it.
        # Otherwise an undefined local aborts the entire scanner.
        with LOCK:
            fzone_watch_codes=list(STATE.get('fzone_watchlist') or [])
        rank_data={'value_top':value_top,
                   'value_rank_map':value_rank_map,
                   'formula_rank_limits':formula_rank_limits,
                   'today_limit_min_eok':_today_limit_min_eok(),
                   'rank_excluded':rank_excluded,
                   'change_top':change_top,
                   'today_limit':today_limit_codes,
                   'prev_limit':prev_limit_codes,
                   'quotes':{},'formula_quotes':{},'rank_quotes':rank_quotes,
                   'prior_candidates':prior_snapshot,'prior_candidate_snapshots':prior_snapshots,
                   'fzone_candidate_snapshots':fzone_snapshots,
                   'fzone_watchlist_codes':fzone_watch_codes,
                   'source':'MTS 통합 20:00 기준 고정: ka10032 stex_tp=3 now_rank 원순위 1~30 + ka10027 stex_tp=3 + SOR(_AL) 통합 현재가/기준가/시가 + ka10081 _AL 통합 일봉 (KRX+NXT, 애프터마켓 포함)'}

        # Only the locked top-30 universe can pass the three formulas.
        # Extra watchlist stocks are fetched only for diagnosis/chart and cannot create false positives.
        names={base_code(r['stk_cd']):r.get('stk_nm',r['stk_cd']) for r in value_rows}
        targets={c:names.get(c,LOOKUP.get(c,{}).get('name',c)) for c in search_codes}
        # D+1/D+2 techniques must follow saved candidates even if they fell out of today's top-30.
        # F-zone alone keeps watching the same saved candidate source through D+10.
        for snap in fzone_snapshots:
            for c,rec in (snap.get('stocks') or {}).items():
                targets[c]=rec.get('name') or LOOKUP.get(c,{}).get('name',names.get(c,c))
        # Today's limit-up list is needed for the '오늘의 상한가' panel, and the
        # previous-session limit-up list is needed for the 약상 candidate panel.
        # Fetching these extra stocks never changes the locked three search formulas,
        # because those formulas still require value-rank A within the original top 30.
        for c in set(today_limit_codes)|set(prev_limit_codes):
            c=base_code(c)
            if c: targets[c]=LOOKUP.get(c,{}).get('name',names.get(c,c))
        for c in manual:targets[c]=LOOKUP.get(c,{}).get('name',names.get(c,c))
        for c in fzone_watch_codes:
            targets[c]=LOOKUP.get(c,{}).get('name',names.get(c,c))

        # D+3~D+10 candidates exist only to keep the F-zone watch alive.  Avoid the
        # normal 15-minute chart fetch for those older candidates: one SOR quote +
        # daily history is sufficient for the fallback F-zone levels and protects
        # scan speed as the tracking window grows.  Any stock also needed by today's
        # formulas, D+1/D+2 techniques, limit-up panels, or manual watchlist keeps the
        # full existing scan path.
        full_scan_codes=(set(search_codes)|set(prior_codes)|
                         {base_code(c) for c in set(today_limit_codes)|set(prev_limit_codes)}|
                         set(manual)|set(fzone_watch_codes))
        fzone_only_codes=set(fzone_codes)-full_scan_codes
        with LOCK:
            old={s['code']:s for s in STATE['data']['stocks']}
            STATE['total']=len(targets)
        # Basic industry fallback: ensure scanned rows do not stay '미분류' just
        # because the user has not run the full-market sector sync yet. Existing
        # user-assigned sectors always win; only missing rows are looked up.
        sector_map=sectors.load()
        sector_map_dirty=False

        def _scan_call_retry(stage, fn, *args, attempts=2, **kwargs):
            """Retry transient provider failures during per-stock full scan.

            The Page-1 API gate already serializes requests and applies rate-limit
            backoff. A single provider hiccup should not permanently drop a stock
            from the scan, so retry the exact same request up to 3 times.
            Final failures keep the stage name for diagnostics.
            Limit retries to two per-stock requests: never queue multiple long
            scanner retries behind real-time quote and order traffic.
            """
            last=None
            for attempt in range(1, attempts+1):
                if STATE['cancel'].is_set():
                    raise ApiError('사용자가 검색을 중지했습니다.')
                try:
                    # Only background scanner HTTP requests use the bounded timeout.
                    # Thread-local scope means manual orders, quotes and other workers
                    # retain their existing transport behavior.
                    _kiwoom_adapter._SCAN_HTTP_CONTEXT.enabled=True
                    try:
                        return _kiwoom_call(fn,*args,kind='heavy',**kwargs)
                    finally:
                        _kiwoom_adapter._SCAN_HTTP_CONTEXT.enabled=False
                except Exception as e:
                    last=e
                    if attempt >= attempts:
                        break
                    # Rate-limit backoff is handled by _kiwoom_call itself. For
                    # ordinary transient transport/server errors, use a small pause.
                    time.sleep(0.6 * attempt)
            raise ApiError(f'{stage}: {last}')

        _scan_trace('daily_begin',step=0,total=len(targets))
        for i,(c,name) in enumerate(targets.items(),1):
            if STATE['cancel'].is_set():break
            _scan_trace('daily_quote',symbol=c,step=i,total=len(targets))
            with LOCK:STATE['progress']=f'{i:,}/{len(targets):,} · {name} 통합 20:00 기준 일봉·현재가 조회'
            try:
                # Resolve the stock name from the provider quote first. Some ranking
                # responses can omit stk_nm; never leave a live row as code-only.
                fq=_scan_call_retry('SOR 현재가',client.quote,c,'SOR')
                _scan_trace('daily_stock',symbol=c,step=i,total=len(targets))
                fq=dict(fq or {});fq['_session_date']=today
                provider_name=(fq.get('name') or '').strip()
                resolved_name=(provider_name or (name if str(name).strip()!=c else '')
                               or LOOKUP.get(c,{}).get('name') or c)
                old_sector=old.get(c,{}).get('sector')
                mapped=sector_map.get(c) or {}
                # Persisted user/manual market themes override stale scan rows; avoid reverting
                # Kiwoom theme labels to an old generic industry such as '제조'.
                mapped_sector=str(mapped.get('sector') or '').strip()
                base_sector=(mapped_sector if mapped_sector and mapped_sector!='미분류'
                             else old_sector)
                # Older F-zone-only candidates do not need an external sector lookup.
                # Their sector is display metadata and must not add latency to D+10 tracking.
                if c not in fzone_only_codes and (not base_sector or base_sector=='미분류'):
                    try:
                        auto_sector=sector_sync.fetch_sector(c, timeout=1.5)
                    except Exception:
                        auto_sector=None
                    if auto_sector:
                        base_sector=auto_sector
                        sector_map[c]={'sector':auto_sector,'source':'네이버 증권 업종 자동조회','asof':today}
                        sector_map_dirty=True

                if c in fzone_only_codes:
                    ds=_scan_call_retry('F존 D+3~D+10 일봉',client.daily_history_rows,c,180)
                    daily={r['dt']:daily_bar(r) for r in (ds or []) if r.get('dt')}
                    stock={'code':c,'name':resolved_name,'sector':base_sector or '미분류',
                           'daily':sorted(daily.values(),key=lambda x:x['date']),'m15':[],'m3':[]}
                else:
                    stock=_scan_call_retry('일봉/종목정보',client.stock,c,resolved_name,base_sector or '미분류',fq)
                if c in sector_map:
                    stock['sector_source']=sector_map[c].get('source','')+' '+sector_map[c].get('asof','')
                stock['review']=old.get(c,{}).get('review',{})

                # FORMULA + DISPLAY quote: keep one market basis everywhere.
                # _AL is Kiwoom's integrated KRX+NXT quote; with the current market
                # structure it remains the integrated basis through 20:00, including
                # KRX/NXT after-market activity.  Do not mix an NXT-only display quote
                # into an integrated scanner result.
                rank_data['formula_quotes'][c]=fq
                dq=dict(fq)
                dq['display_source']='통합 SOR(_AL) 원문값 · KRX+NXT · 20:00 애프터마켓 포함'
                rank_data['quotes'][c]=dq
                collected.append(stock)
            except (ApiError,ValueError,KeyError,TypeError) as e:
                _msg=str(e)
                _stage=_msg.split(':',1)[0].strip() if ':' in _msg else '통합 조회'
                errors.append({'code':c,'name':(locals().get('resolved_name') or name or c),'stage':_stage,'error':_msg,'severity':'필수'})
            with LOCK:STATE['done']=i
            _scan_trace('daily_processed',symbol=c,step=i,total=len(targets))

        _scan_trace('daily_complete',step=len(targets),total=len(targets))
        if sector_map_dirty:
            sectors.save(sector_map)
        if not collected:
            raise ApiError('조회된 시세가 없습니다. 연결/등록 IP/이용 권한을 확인하세요.')

        # The scheduled intraday scan must not re-fetch 3-minute candles for
        # every stock every five minutes. Manual/post-market scans keep the
        # all-daily-stock 3-minute fetch requested by the user.
        # Fetch 3-minute candles for EVERY stock whose daily scan completed.
        # Do not gate on D+1/D+2 prior candidates. This keeps the same daily
        # target universe and the same F-zone formulas, while making m3
        # available to scan_dataset for all successfully collected stocks.
        # Network traffic increases substantially with the number of stocks.
        _scan_trace('minute_begin',step=0,total=(0 if automatic else len(collected)))
        for idx, st in enumerate(collected if not automatic else [], 1):
            if STATE['cancel'].is_set():
                break
            c=base_code(st.get('code',''))
            if not c:
                continue
            try:
                with LOCK:
                    STATE['progress']=f"3분봉 전체 조회 · {st.get('name') or c} ({idx}/{len(collected)})"
                _scan_trace('minute_fetch',symbol=c,step=idx,total=len(collected))
                # Retry 3-minute history at most twice; preserve error reporting on failure.
                # The scanner gate still bounds waiting behind other API calls.
                bars=_scan_call_retry('전체 3분봉',client.minute,c,3,attempts=2)
                _scan_trace('minute_received',symbol=c,step=idx,total=len(collected))
                st['m3']=bars or []
                # Share fetched candles with the local chart cache. Cache
                # failures must never invalidate a successful scanner result.
                if st['m3']:
                    try:
                        _scan_trace('minute_cache_save',symbol=c,step=idx,total=len(collected))
                        _chart_history_save(c,'3',st['m3'])
                        _scan_trace('minute_cache_saved',symbol=c,step=idx,total=len(collected))
                    except Exception:
                        pass
            except Exception as e:
                _msg=str(e)
                _stage=_msg.split(':',1)[0].strip() if ':' in _msg else '전체 3분봉'
                errors.append({'code':c,'name':(st.get('name') or c),'stage':_stage,'error':_msg,'severity':'보조'})
                st['m3']=[]
            _scan_trace('minute_processed',symbol=c,step=idx,total=len(collected))

        _scan_trace('minute_complete',step=(0 if automatic else len(collected)),total=(0 if automatic else len(collected)))
        # A user may edit sectors while this background scan is still running.
        # Re-apply the latest persisted mapping immediately before publishing the
        # new scan result so a stale sector_map loaded at scan start can never
        # overwrite a manual edit.
        try:
            latest_sector_map=sectors.load()
            for st in collected:
                c=base_code(st.get('code',''))
                mapped=latest_sector_map.get(c) or {}
                sec=(mapped.get('sector') or '').strip()
                if sec:
                    st['sector']=sec
                    st['sector_source']=(mapped.get('source','')+' '+mapped.get('asof','')).strip()
        except Exception:
            pass

        now=datetime.now(KST).isoformat()
        new_data={'mode':'import' if client.mock else 'live','asof':now,'stocks':collected,
                  'scope':('키움 모의 서버 · 실제 매매 판단용 아님 · ' if client.mock else '')+
                          f"3식 거래대금 사용자 순위 기준: 종배 {formula_rank_limits['주도주 종배']} / 상따 {formula_rank_limits['주도주 상따']} / 끼도주 {formula_rank_limits['끼도주 종배']}위 + 관심종목"}
        # CPU-heavy panel calculation is done outside LOCK so sector editing,
        # navigation and journal actions remain responsive during publication.
        _scan_trace('calculate_begin',step=len(collected),total=len(collected))
        calc_data=copy.deepcopy(new_data); sectors.apply(calc_data,sectors.load())
        calc_report=scan_dataset(calc_data,copy.deepcopy(STATE.get('settings') or {}),STATE.get('market','unknown'))
        _scan_trace('calculate_complete',step=len(collected),total=len(collected))
        _scan_trace('publish',step=len(collected),total=len(collected))
        calc_report['errors']+=errors
        calc_report['search_panels']=search_panels.build(calc_report,rank_data)
        _scan_trace('publish_lock_wait',step=len(collected),total=len(collected))
        with LOCK:
            _scan_trace('publish_lock_acquired',step=len(collected),total=len(collected))
            STATE['data']=new_data
            STATE['fetch_errors']=errors
            STATE['ranks']=rank_data
            STATE['report']=calc_report

        # Disk writes and history persistence must never hold the shared state LOCK.
        # --- ka10032 / 주도주 종배 원본 진단 파일 자동 저장 -----------------
        # 검색식은 바꾸지 않는다. 키움이 실제로 준 거래대금 순위와
        # 프로그램의 A/B 판정값을 그대로 파일로 남겨 MTS와 1:1 대조한다.
        try:
            diag_dir=ROOT/'diagnostics'
            diag_dir.mkdir(parents=True,exist_ok=True)

            # 1) ka10032 원문 전체(최대 조회 개수) JSON
            (diag_dir/'KA10032_RAW.json').write_text(
                json.dumps({
                    'saved_at':datetime.now(KST).isoformat(),
                    'request':{'mrkt_tp':'000','mang_stk_incls':'1','stex_tp':'3'},
                    'rows':value_rows,
                },ensure_ascii=False,indent=2),
                encoding='utf-8'
            )

            # 2) 거래대금 순위 1~50 핵심값 CSV
            with (diag_dir/'KA10032_TOP50.csv').open('w',newline='',encoding='utf-8-sig') as f:
                w=csv.writer(f)
                w.writerow(['now_rank','code','name','cur_prc','flu_rt','trde_prica','product_type',
                            'etf','etn','leveraged','inverse','top30','search_target'])
                search_set=set(search_codes)
                for r in sorted(value_rows,key=lambda z:(value_rank_map.get(base_code(z.get('stk_cd','')),99999),
                                                         base_code(z.get('stk_cd','')))):
                    c=base_code(r.get('stk_cd',''))
                    rk=value_rank_map.get(c)
                    if rk is None or rk>50:
                        continue
                    w.writerow([
                        rk,c,(r.get('stk_nm') or r.get('name') or ''),
                        r.get('cur_prc'),r.get('flu_rt'),r.get('trde_prica'),
                        r.get('product_type'),r.get('etf'),r.get('etn'),
                        r.get('leveraged'),r.get('inverse'),
                        'Y' if rk<=30 else 'N',
                        'Y' if c in search_set else 'N'
                    ])

            # 3) 실제 주도주 종배 A/B 판정 CSV
            diag_rows=((calc_report or {}).get('search_panels') or {}).get('panels',{}).get('검색 진단',{}).get('rows',[])
            with (diag_dir/'JUDOJOO_DIAG.csv').open('w',newline='',encoding='utf-8-sig') as f:
                w=csv.writer(f)
                w.writerow(['value_rank','code','name','prev_close','formula_price','formula_change',
                            'provider_rank_change','provider_sor_change','status','reasons'])
                for x in diag_rows:
                    w.writerow([
                        x.get('value_rank'),x.get('code'),x.get('name'),
                        x.get('prev_close'),x.get('formula_price'),x.get('formula_change'),
                        x.get('provider_rank_change'),x.get('provider_sor_change'),
                        x.get('status'),' | '.join(x.get('reasons') or [])
                    ])
        except Exception as _diag_e:
            errors.append({'code':'진단파일','error':str(_diag_e)})
        # -------------------------------------------------------------------

        # Snapshot ka00198 TOP20 once at scan publication.  The front-end
        # 조회순위종배 panel is generated from this ranking, so it cannot be
        # obtained by reading the three-formula backend search panels.
        lookup_rows=[]
        try:
            rank_snapshot=realtime_rank_snapshot(force=False)
            updated=rank_snapshot.get('updated_at')
            fresh=False
            if updated:
                stamp=datetime.fromisoformat(updated)
                fresh=abs((datetime.now(KST)-stamp).total_seconds()) < 120
            if fresh and not rank_snapshot.get('stale'):
                lookup_rows=rank_snapshot.get('rows') or []
            else:
                errors.append({'code':'조회순위종배','stage':'전일 후보 저장',
                               'error':'조회순위 최신 스냅샷 없음 · 이번 검색에서는 조회순위 후보 저장 생략',
                               'severity':'보조'})
        except Exception as rank_err:
            errors.append({'code':'조회순위종배','stage':'전일 후보 저장',
                           'error':str(rank_err),'severity':'보조'})
        _save_today_candidates(calc_report,today,lookup_rows=lookup_rows)
        try:
            screener_history.save_report(calc_report,today,datetime.now(KST).isoformat())
        except Exception as _history_e:
            errors.append({'code':'검색이력','error':str(_history_e)})
        prior_msg=(f" · D+1/D+2 추적 {len(prior_codes)}종목" if prior_codes else ' · 이전 저장 후보 없음')
        with LOCK:
            STATE['fetch_errors']=errors
            STATE['progress']=('중지됨 · 부분 결과 ' if STATE['cancel'].is_set() else '검색 완료 · ')+f'{len(collected):,}종목 / 조회 오류 {len(errors)}개'+prior_msg
        _scan_trace('cancelled' if STATE['cancel'].is_set() else 'completed',step=len(collected),total=len(collected))
    except Exception as e:
        _scan_trace('failed',error=f'{type(e).__name__}: {e}')
        with LOCK:
            STATE['fetch_errors']=errors
            STATE['progress']=str(e)
            if STATE['report']:
                STATE['report']=dict(STATE['report'],errors=STATE['report'].get('errors',[])+errors+[{'code':'검색','error':str(e)}])
    finally:
        with SCAN_TRACE_LOCK:SCAN_TRACE['finished_at']=time.time()
        with LOCK:STATE['busy']=False
        now_ts=time.time()
        with PAGE1_LIVE_LOCK:
            PAGE1_LIVE_ENGINE['last_heavy_at']=now_ts;PAGE1_LIVE_ENGINE['next_heavy_at']=0.0
            # Reschedule from completion, never from the previous scan start.
            PAGE1_LIVE_ENGINE['safe_next_at']=time.monotonic()+PAGE1_SAFE_SCAN_INTERVAL
            PAGE1_LIVE_ENGINE['heavy_count']=int(PAGE1_LIVE_ENGINE.get('heavy_count') or 0)+1
        _save_page1_runtime_cache()

def journal_import_from_kiwoom(date_text=None):
    """Import one trading day's realized sell P/L into the local journal.

    For review purposes ka10073 (realized P/L) is preferred because it follows
    the sell-side realized result shown by HTS more closely. ka10170 remains a
    fallback when realized-P/L lookup is unavailable.
    """
    client=STATE.get('client')
    if not client: raise ValueError('키움 API 연결이 필요합니다.')
    try:
        dt=datetime.strptime((date_text or datetime.now(KST).date().isoformat())[:10],'%Y-%m-%d').date()
    except ValueError:
        raise ValueError('날짜 형식은 YYYY-MM-DD 입니다.')
    iso=dt.isoformat(); ymd=dt.strftime('%Y%m%d')
    notes=[]; normalized=[]; source=''
    try:
        result=client.realized_pnl(ymd,ymd)
        rows=result.get('rows') or []
        if rows:
            normalized=[journal.normalize_ka10073(r,iso) for r in rows]
            normalized=[r for r in normalized if float(r.get('sell_qty') or 0)>0]
            source='ka10073'
        else:
            notes.append('ka10073 정상 응답 · 실현손익 0건')
    except Exception as e:
        notes.append('ka10073: '+str(e))
    if not normalized:
        try:
            result=client.daily_trading_journal(ymd)
            rows=result.get('rows') or []
            if rows:
                normalized=[journal.normalize_ka10170(r,iso) for r in rows]
                normalized=[r for r in normalized if float(r.get('sell_qty') or 0)>0]
                source='ka10170'
            else:
                notes.append('ka10170 정상 응답 · 완료 매매 0건')
        except Exception as e:
            notes.append('ka10170: '+str(e))
    inserted,updated=journal.upsert_import(ROOT,normalized)
    msg=' / '.join(notes)
    journal.log_import(ROOT,iso,source or '키움 계좌조회',len(normalized),msg)
    return {'date':iso,'source':source or 'none','rows':len(normalized),'inserted':inserted,'updated':updated,'message':msg}

def safe_cell(x):
    s='' if x is None else str(x)
    return "'"+s if s.startswith(('=','+','-','@','\t','\r')) else s


BS_FILL_REFRESH={}
BS_FILL_LOCK=threading.RLock()
BS_HISTORY_SYNC_FILE=ROOT/'data'/'bs_history_sync.json'
def _bs_num(v):
    try:return float(str(v or '0').replace(',','').replace('+','').strip())
    except Exception:return 0.0

def _bs_code(v):
    raw=str(v or '').strip()
    if not raw:return ''
    if len(raw)>=7 and raw[0] in 'AJQ' and raw[1:7].isdigit(): raw=raw[1:7]
    return base_code(raw)

def _bs_side(row):
    # For ka10076 per-side queries, the request side is authoritative.
    hint=str(row.get('_litto_side_hint') or '').strip().lower()
    if hint in ('buy','sell'):return hint
    raw=' '.join(str(row.get(k) or '') for k in ('io_tp_nm','ord_tp_nm','trde_tp_nm','sell_tp_nm','trde_tp','sell_tp','io_tp')).strip()
    if '매수' in raw:return 'buy'
    if '매도' in raw:return 'sell'
    tokens=[x for x in raw.replace(',',' ').split() if x]
    if any(x in ('2','02','BUY','buy') for x in tokens):return 'buy'
    if any(x in ('1','01','SELL','sell') for x in tokens):return 'sell'
    return ''

def _normalize_bs_fill(row,trade_date,source='ka10076',side_hint=''):
    c=_bs_code(row.get('stk_cd') or row.get('code'))
    if source=='kt00015':
        side=side_hint
        price=abs(_bs_num(row.get('trde_unit')))
        qty=abs(_bs_num(row.get('trde_qty_jwa_cnt')))
        # kt00015 is reliable for trade DATE, but proc_tm is a processing time,
        # not guaranteed to be the actual fill time.  Keep it daily-only.
        if qty<=0 and price>0:
            amt=abs(_bs_num(row.get('trde_amt')))
            if amt>0:
                qty=round(amt/price,8)
        d=str(row.get('cntr_dt') or row.get('trde_dt') or trade_date or '').strip()
        if len(d)==8 and d.isdigit():d=f'{d[:4]}-{d[4:6]}-{d[6:8]}'
        tm=''
        ono=str(row.get('trde_no') or '').strip()
        cno=str(row.get('rcpy_no') or '').strip()
        name=str(row.get('stk_nm') or '').strip()
    elif source=='kt00009':
        side=side_hint or _bs_side(row)
        qty=abs(_bs_num(row.get('cntr_qty') or row.get('ord_qty')))
        price=abs(_bs_num(row.get('cntr_uv') or row.get('ord_uv')))
        d=str(trade_date or '').strip()
        if len(d)==8 and d.isdigit():d=f'{d[:4]}-{d[4:6]}-{d[6:8]}'
        tm=str(row.get('cntr_tm') or row.get('ord_tm') or '').strip().replace(':','')
        ono=str(row.get('ord_no') or '').strip()
        cno=str(row.get('cntr_no') or '').strip()
        name=str(row.get('stk_nm') or '').strip()
    else:
        side=_bs_side(row)
        qty=_bs_num(row.get('cntr_qty') or row.get('exec_qty') or row.get('fill_qty') or row.get('qty') or row.get('ord_qty'))
        price=_bs_num(row.get('cntr_pric') or row.get('exec_pric') or row.get('fill_price') or row.get('price') or row.get('ord_pric'))
        d=trade_date
        tm=str(row.get('cntr_tm') or row.get('tm') or row.get('ord_tm') or row.get('time') or '').strip().replace(':','')
        ono=str(row.get('ord_no') or row.get('order_no') or '').strip()
        cno=str(row.get('cntr_no') or row.get('exec_no') or row.get('fill_no') or '').strip()
        name=str(row.get('stk_nm') or row.get('name') or '').strip()
    if not c or side not in ('buy','sell') or qty<=0:return None
    tm=''.join(ch for ch in tm if ch.isdigit())
    if len(tm)>=6:tm=tm[-6:]
    elif len(tm)==4:tm=tm+'00'
    else:tm=''
    rawkey='|'.join((str(d),c,side,ono,cno,tm,str(qty),str(price)))
    return {'source_key':source+'|'+rawkey,'trade_date':str(d),'trade_time':tm,'stock_code':c,'stock_name':name,'side':side,'qty':qty,'price':price or None,'order_no':ono,'exact_time':bool(tm),'source':source}

def _bs_history_sync_load():
    try:
        x=json.loads(BS_HISTORY_SYNC_FILE.read_text(encoding='utf-8')) if BS_HISTORY_SYNC_FILE.exists() else {}
        return x if isinstance(x,dict) else {}
    except Exception:return {}

def _bs_history_sync_save(x):
    try:
        BS_HISTORY_SYNC_FILE.parent.mkdir(parents=True,exist_ok=True)
        tmp=BS_HISTORY_SYNC_FILE.with_suffix('.tmp');tmp.write_text(json.dumps(x,ensure_ascii=False,indent=2),encoding='utf-8');tmp.replace(BS_HISTORY_SYNC_FILE)
    except Exception:pass

def refresh_bs_fills_from_kiwoom(stock_code='',force=False):
    client=STATE.get('client')
    if not client:return {'rows':0,'source':'local-only'}
    c=code(stock_code) if stock_code else ''
    key=c or '*'
    now=time.time()
    with BS_FILL_LOCK:
        ent=BS_FILL_REFRESH.get(key) or {}
        if not force and now-float(ent.get('ts') or 0)<8:
            return {'rows':len(ent.get('rows') or []),'source':'ka10076 cache'}
    raw=_kiwoom_call(client.filled_orders,2000,c,kind='account')
    today=datetime.now(KST).strftime('%Y-%m-%d')
    norm=[]
    for r in raw or []:
        n=_normalize_bs_fill(r,today,'ka10076')
        if n and (not c or n.get('stock_code')==c):norm.append(n)
    # Remove stale rows written by older BS versions (notably BUY fills that
    # were misclassified as SELL), then rebuild today's ka10076 rows exactly.
    if c:
        journal.delete_bs_fills(ROOT,c,today,'ka10076')
    journal.upsert_bs_fills(ROOT,norm)
    with BS_FILL_LOCK:BS_FILL_REFRESH[key]={'ts':time.time(),'rows':norm}
    return {'rows':len(norm),'source':'ka10076'}

def _bs_history_side(row):
    # kt00015 tp=3 fallback: infer side from the provider's descriptive fields.
    raw=' '.join(str(row.get(k) or '') for k in ('trde_kind_nm','rmrk_nm','trde_stle','io_tp_nm','crd_deal_tp_nm')).strip()
    up=raw.upper()
    if '매수' in raw or 'BUY' in up:return 'buy'
    if '매도' in raw or 'SELL' in up:return 'sell'
    return ''

def refresh_bs_recent_exact_from_kiwoom(stock_code,force=False,lookback_days=14):
    """Refresh only recent exact fills (kt00009) without blocking on long history.

    Successful dates are persisted even when they contain no fills, so reopening
    the same chart does not re-query every recent weekday forever.
    """
    client=STATE.get('client');c=code(stock_code)
    if not client or not c:return {'rows':0,'source':'local-only'}
    today=datetime.now(KST).date()
    meta=_bs_history_sync_load();ent=meta.get(c) if isinstance(meta.get(c),dict) else {}
    checked=set(str(x) for x in (ent.get('kt00009_checked_dates') or []) if x)
    dates=[]
    for back in range(1,max(1,int(lookback_days))+1):
        d0=today-timedelta(days=back)
        if d0.weekday()<5:dates.append(d0.isoformat())
    norm=[];errors=[];successful=[]
    for d in dates:
        if not force and d in checked:continue
        try:
            rawx=_kiwoom_call(client.order_fills_by_date,d.replace('-',''),c,'all',5000,kind='account')
        except Exception as e:
            errors.append('kt00009 '+d+' '+str(e)[:100]);continue
        successful.append(d)
        ex=[]
        for r in rawx or []:
            rr=dict(r) if isinstance(r,dict) else {}
            if not _bs_code(rr.get('stk_cd')):rr['stk_cd']=c
            side=_bs_side(rr)
            if side not in ('buy','sell'):continue
            n=_normalize_bs_fill(rr,d,'kt00009',side)
            if n and n.get('stock_code')==c:ex.append(n)
        # A successful date query is authoritative for kt00009: rebuild it,
        # including the empty case, so stale rows cannot survive provider changes.
        try:journal.delete_bs_fills(ROOT,c,d,'kt00009')
        except Exception:pass
        if ex:
            journal.upsert_bs_fills(ROOT,ex);norm.extend(ex)
    if successful:
        checked.update(successful)
        # Keep compact metadata only; recent exact lookup never needs years of dates.
        ent=dict(ent);ent['kt00009_checked_dates']=sorted(checked)[-80:]
        ent['kt00009_checked_at']=datetime.now(KST).isoformat(timespec='seconds')
        meta[c]=ent;_bs_history_sync_save(meta)
    return {'rows':len(norm),'source':'kt00009 recent','error':' / '.join(errors)}

def refresh_bs_history_from_kiwoom(stock_code,force=False):
    client=STATE.get('client');c=code(stock_code)
    if not client or not c:return {'rows':0,'source':'local-only'}
    today=datetime.now(KST).date();end=today
    if end.year<2000:return {'rows':0,'source':'none'}
    meta=_bs_history_sync_load();ent=meta.get(c) if isinstance(meta.get(c),dict) else {}
    last=str(ent.get('last_end') or '')
    # Speed path: a completed history sync through today is immutable enough for
    # repeated chart opens. Recent today/yesterday fills are handled separately
    # by ka10076/kt00009, so do not re-query kt00015 on every reopen.
    if last==today.isoformat() and not force:
        return {'rows':0,'source':'kt00015 current-cache','error':''}
    # First sync: three years is enough for the large-chart review window.
    if last and not force:
        try:start=max(datetime.strptime(last,'%Y-%m-%d').date()-timedelta(days=3),today-timedelta(days=45))
        except Exception:start=today-timedelta(days=365*3+10)
    else:start=today-timedelta(days=365*3+10)
    if start>end:return {'rows':0,'source':'kt00015 current'}
    norm=[];errors=[]
    # Query in <=180-day windows.  This is slower only on first sync and avoids
    # provider-side date-range truncation that can hide older BUY transactions.
    windows=[];ws=start
    while ws<=end:
        we=min(end,ws+timedelta(days=179));windows.append((ws,we));ws=we+timedelta(days=1)
    for side in ('buy','sell'):
        for ws,we in windows:
            try:raw=_kiwoom_call(client.brokerage_transactions,ws.strftime('%Y%m%d'),we.strftime('%Y%m%d'),c,side,5000,kind='account')
            except Exception as e:errors.append(str(e)[:120]);continue
            for r in raw or []:
                rr=dict(r) if isinstance(r,dict) else {}
                if not _bs_code(rr.get('stk_cd')): rr['stk_cd']=c
                n=_normalize_bs_fill(rr,'','kt00015',side)
                if n and n.get('stock_code')==c:norm.append(n)

    # Independent historical BUY fallback. Some accounts/providers return no rows
    # for kt00015 tp=4 while the same executions are present under tp=3 (all trades).
    # Query only a recent window so this does not add meaningful load to chart open.
    if not any(x.get('side')=='buy' for x in norm):
        fb_start=max(start,today-timedelta(days=60))
        try:
            raw_all=_kiwoom_call(client.brokerage_transactions,fb_start.strftime('%Y%m%d'),end.strftime('%Y%m%d'),c,'all',5000,kind='account')
        except Exception as e:
            errors.append('all-trade fallback '+str(e)[:100]);raw_all=[]
        for r in raw_all or []:
            rr=dict(r) if isinstance(r,dict) else {}
            side=_bs_history_side(rr)
            if side!='buy':continue
            if not _bs_code(rr.get('stk_cd')):rr['stk_cd']=c
            n=_normalize_bs_fill(rr,'','kt00015','buy')
            if n and n.get('stock_code')==c:norm.append(n)

    # Exact historical fills from kt00009.
    # IMPORTANT: kt00015 can expose a fill only on its later processing/settlement day
    # (e.g. a 10/07 execution may not appear there on 10/08).  Therefore recent
    # order dates must be queried directly instead of being derived only from
    # kt00015's already-visible dates.  This makes yesterday's BUY/SELL markers
    # available immediately and also supplies the authoritative cntr_tm for minutes.
    hist_dates=set(str(x.get('trade_date') or '') for x in norm
                   if str(x.get('trade_date') or '') and str(x.get('trade_date') or '') < today.isoformat())
    for back in range(1,15):
        d0=today-timedelta(days=back)
        if d0.weekday()<5:
            hist_dates.add(d0.isoformat())
    hist_dates=sorted(hist_dates,reverse=True)
    try:
        cached_exact=journal.list_bs_fills(ROOT,c)
        exact_done={(str(x.get('trade_date') or ''),str(x.get('side') or '')) for x in cached_exact if str(x.get('source') or '')=='kt00009' and x.get('exact_time')}
    except Exception:
        exact_done=set()
    checked_dates=set(str(x) for x in (ent.get('kt00009_checked_dates') or []) if x)
    successful_exact_dates=[]
    # Minute charts only need recent history.  Cap at the most recent 24 trade dates
    # for this stock; daily markers still come from all kt00015 history.
    for d in hist_dates[:24]:
        dt8=d.replace('-','')
        # One all-side call per date is both more reliable and lighter than
        # separate BUY/SELL calls.  The response's io_tp_nm/trde_tp decides side.
        if not force and d in checked_dates:
            continue
        try:
            rawx=_kiwoom_call(client.order_fills_by_date,dt8,c,'all',5000,kind='account')
        except Exception as e:
            errors.append('kt00009 '+d+' '+str(e)[:100]);continue
        successful_exact_dates.append(d)
        ex=[]
        for r in rawx or []:
            rr=dict(r) if isinstance(r,dict) else {}
            if not _bs_code(rr.get('stk_cd')):rr['stk_cd']=c
            side=_bs_side(rr)
            if side not in ('buy','sell') or (d,side) in exact_done:
                continue
            n=_normalize_bs_fill(rr,d,'kt00009',side)
            if n and n.get('stock_code')==c:ex.append(n)
        if ex:
            try:journal.delete_bs_fills(ROOT,c,d,'kt00009')
            except Exception:pass
            journal.upsert_bs_fills(ROOT,ex)
            norm.extend(ex)

    # De-duplicate before persistence because tp=4 and tp=3 can expose the same fill.
    uniq={}
    for n in norm:
        uniq[n.get('source_key')]=n
    norm=list(uniq.values())
    if norm:journal.upsert_bs_fills(ROOT,norm)
    ent=dict(meta.get(c) if isinstance(meta.get(c),dict) else ent or {})
    if successful_exact_dates:
        checked_dates.update(successful_exact_dates)
        ent['kt00009_checked_dates']=sorted(checked_dates)[-80:]
        ent['kt00009_checked_at']=datetime.now(KST).isoformat(timespec='seconds')
    if not errors:
        ent['last_end']=end.isoformat();ent['updated_at']=datetime.now(KST).isoformat(timespec='seconds')
    meta[c]=ent;_bs_history_sync_save(meta)
    return {'rows':len(norm),'source':'kt00015','error':' / '.join(errors)}

def _chart_bs_cached_rows(c,start_date=''):
    exact=journal.list_bs_fills(ROOT,c,start_date)
    # If exact kt00009/ka10076 fills exist for a date+side, suppress the
    # kt00015 daily aggregate for that same date+side.  Keep all exact fills.
    exact_keys={(str(x.get('trade_date')),str(x.get('side'))) for x in exact if x.get('exact_time')}
    exact=[x for x in exact if x.get('exact_time') or (str(x.get('trade_date')),str(x.get('side'))) not in exact_keys]
    seen={(str(x.get('trade_date')),str(x.get('side'))) for x in exact}
    daily=[]
    for x in journal.journal_bs_daily_rows(ROOT,c,start_date):
        if (str(x.get('trade_date')),str(x.get('side'))) not in seen:daily.append(x)
    rows=exact+daily
    rows.sort(key=lambda x:(str(x.get('trade_date') or ''),str(x.get('trade_time') or ''),str(x.get('side') or '')))
    return rows

def chart_bs_snapshot(stock_code,start_date='',mode='full'):
    c=code(stock_code)
    if not c:raise ValueError('종목코드가 필요합니다.')
    mode=str(mode or 'full').lower();notes=[]
    if mode in ('recent','full'):
        try:refresh_bs_fills_from_kiwoom(c,False)
        except Exception as e:notes.append('당일체결 '+str(e)[:100])
        try:refresh_bs_recent_exact_from_kiwoom(c,False,14)
        except Exception as e:notes.append('최근체결 '+str(e)[:100])
    if mode in ('history','full'):
        try:refresh_bs_history_from_kiwoom(c,False)
        except Exception as e:notes.append('과거체결 '+str(e)[:100])
    rows=_chart_bs_cached_rows(c,start_date)
    buy_count=sum(1 for x in rows if x.get('side')=='buy');sell_count=sum(1 for x in rows if x.get('side')=='sell')
    return {'code':c,'rows':rows,'count':len(rows),'buy_count':buy_count,'sell_count':sell_count,'exact_count':sum(1 for x in rows if x.get('exact_time')),'source':'LITTO 영구캐시 + ka10076 당일 + kt00009 최근 실제체결시간 + kt00015 과거일자','mode':mode,'note':' / '.join(notes)}

def account_daily_pnl_snapshot(year=None,month=None,force=False):
    """Monthly day-by-day realized P/L for the independent account screen.

    Uses Kiwoom ka10074, which is specifically the day-by-day realized-P/L API.
    It is demand-loaded only when the user opens the daily-return card, so it
    never participates in the 2-second account holdings refresh loop.
    """
    client=_account_client()
    if not client:
        raise ValueError('키움 로그인 연결이 필요합니다.')
    now_dt=datetime.now(KST)
    try:y=int(year or now_dt.year)
    except Exception:y=now_dt.year
    try:m=int(month or now_dt.month)
    except Exception:m=now_dt.month
    if y<2000 or y>now_dt.year+1 or m<1 or m>12:
        raise ValueError('조회 연월이 올바르지 않습니다.')
    last_day=calendar.monthrange(y,m)[1]
    start=f'{y:04d}{m:02d}01';end=f'{y:04d}{m:02d}{last_day:02d}'
    if y==now_dt.year and m==now_dt.month:
        end=now_dt.strftime('%Y%m%d')
    key=f'{y:04d}-{m:02d}'
    now=time.time()
    ttl=60.0 if (y==now_dt.year and m==now_dt.month) else 86400.0
    with ACCOUNT_DAILY_PNL_LOCK:
        ent=ACCOUNT_DAILY_PNL_CACHE.get(key)
        if ent and not force and now-float(ent.get('ts') or 0)<ttl:
            return copy.deepcopy(ent.get('data') or {})
    raw=_kiwoom_call(client.daily_realized_pnl,start,end,kind='account')
    def num(v):
        if v in (None,''):return 0.0
        try:return float(str(v).replace(',','').strip())
        except Exception:return 0.0
    rows=[]
    for r in (raw.get('rows') or []):
        if not isinstance(r,dict):continue
        d=str(r.get('dt') or '').strip().replace('-','')
        if len(d)!=8 or not d.isdigit():continue
        buy=num(r.get('buy_amt'));sell=num(r.get('sell_amt'));pnl=num(r.get('tdy_sel_pl'))
        fee=num(r.get('tdy_trde_cmsn'));tax=num(r.get('tdy_trde_tax'))
        rate=(pnl/buy*100.0) if buy else None
        rows.append({
            'date':f'{d[:4]}-{d[4:6]}-{d[6:8]}','day':int(d[6:8]),
            'buy_amount':buy,'sell_amount':sell,'pnl':pnl,
            'fee':fee,'tax':tax,'fees_tax':fee+tax,'profit_rate':rate,
        })
    rows.sort(key=lambda x:x['date'])
    sm=raw.get('summary') or {}
    total_buy=num(sm.get('tot_buy_amt')) if sm else sum(x['buy_amount'] for x in rows)
    total_sell=num(sm.get('tot_sell_amt')) if sm else sum(x['sell_amount'] for x in rows)
    total_pnl=num(sm.get('rlzt_pl')) if sm else sum(x['pnl'] for x in rows)
    total_fee=num(sm.get('trde_cmsn')) if sm else sum(x['fee'] for x in rows)
    total_tax=num(sm.get('trde_tax')) if sm else sum(x['tax'] for x in rows)
    total_rate=(total_pnl/total_buy*100.0) if total_buy else None
    data={
        'year':y,'month':m,'start':start,'end':end,'rows':rows,
        'summary':{'buy_amount':total_buy,'sell_amount':total_sell,'pnl':total_pnl,
                   'fee':total_fee,'tax':total_tax,'fees_tax':total_fee+total_tax,
                   'profit_rate':total_rate},
        'source':'키움 ka10074 일자별실현손익','updated_at':now_dt.isoformat(),
    }
    with ACCOUNT_DAILY_PNL_LOCK:
        ACCOUNT_DAILY_PNL_CACHE[key]={'ts':time.time(),'data':copy.deepcopy(data)}
    return data

MARKET_OVERVIEW_CACHE={'ts':0,'data':None}
MARKET_INVESTOR_HISTORY_CACHE={}
MARKET_INVESTOR_HISTORY_LOCK=threading.RLock()
HEADER_INDEX_CACHE={}
HEADER_INDEX_LOCK=threading.RLock()
US_MARKET_CACHE={'ts':0,'data':None}
US_WATCHLIST_CACHE={'ts':0,'key':'','data':None}


# Persistent intraday market investor-flow recorder ---------------------------
# The UI previously stored these points only in browser localStorage.  If the
# desktop window was restarted/reloaded during the session, the chart could stop
# at the last locally recorded minute.  Keep an independent server-side minute
# history so UI reloads and file replacements do not break the line.
INTRADAY_MARKET_FLOW_FILE=ROOT/'data'/'intraday_market_flow.json'
INTRADAY_MARKET_FLOW_LOCK=threading.RLock()
INTRADAY_MARKET_FLOW_THREAD=None


def _intraday_market_flow_today():
    return datetime.now(KST).date().isoformat()


def _intraday_market_flow_load():
    today=_intraday_market_flow_today()
    with INTRADAY_MARKET_FLOW_LOCK:
        try:
            x=json.loads(INTRADAY_MARKET_FLOW_FILE.read_text(encoding='utf-8')) if INTRADAY_MARKET_FLOW_FILE.exists() else {}
        except Exception:
            x={}
        if not isinstance(x,dict) or x.get('date')!=today:
            return {'date':today,'markets':{'kospi':[],'kosdaq':[]}}
        mk=x.get('markets') if isinstance(x.get('markets'),dict) else {}
        def clean(rows):
            out=[r for r in list(rows or []) if isinstance(r,dict)]
            # Remove the isolated synthetic 15:30 endpoint written by the first
            # persistence experiment.  A genuine 15:30 sample is kept when the
            # preceding observed minute is close enough.
            if len(out)>=2 and str(out[-1].get('time') or '')=='15:30':
                def minute(v):
                    m=re.search(r'(\d{1,2}):(\d{2})',str(v or ''))
                    return int(m.group(1))*60+int(m.group(2)) if m else None
                a,b=minute(out[-2].get('time')),minute(out[-1].get('time'))
                if a is not None and b is not None and b-a>5:
                    out=out[:-1]
            return out
        return {'date':today,'markets':{
            'kospi':clean(mk.get('kospi') or []),
            'kosdaq':clean(mk.get('kosdaq') or []),
        }}


def _intraday_market_flow_save(data):
    with INTRADAY_MARKET_FLOW_LOCK:
        try:
            INTRADAY_MARKET_FLOW_FILE.parent.mkdir(parents=True,exist_ok=True)
            tmp=INTRADAY_MARKET_FLOW_FILE.with_suffix('.tmp')
            tmp.write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
            tmp.replace(INTRADAY_MARKET_FLOW_FILE)
        except Exception:
            pass


def _intraday_market_flow_record_point(market,personal,foreign,institution,stamp=None):
    stamp=stamp or datetime.now(KST)
    minute=stamp.hour*60+stamp.minute
    if minute<540 or minute>930:
        return
    vals=(personal,foreign,institution)
    if any(v is None for v in vals):
        return
    data=_intraday_market_flow_load()
    rows=data['markets'].setdefault(market,[])
    t=f'{stamp.hour:02d}:{stamp.minute:02d}'
    row={'time':t,'personal':float(personal),'foreign':float(foreign),'institution':float(institution)}
    if rows and str(rows[-1].get('time') or '')==t:
        rows[-1]=row
    else:
        rows.append(row)
    # one point per minute is enough; keep a little headroom.
    if len(rows)>480:
        del rows[:-480]
    _intraday_market_flow_save(data)


def _intraday_market_flow_capture_from_overview(data):
    """Persist only a real regular-session snapshot.

    Never synthesize a 15:30 point from a post-close snapshot.  The chart should
    contain only values actually observed during 09:00~15:30.
    """
    try:
        stamp=datetime.now(KST)
        minute=stamp.hour*60+stamp.minute
        if minute<540 or minute>930:
            return
        for market in ('kospi','kosdaq'):
            inv=(((data or {}).get('markets') or {}).get(market) or {}).get('investor') or {}
            def num(v):
                try:return float(v)
                except (TypeError,ValueError):return None
            _intraday_market_flow_record_point(
                market,num(inv.get('personal')),num(inv.get('foreign')),num(inv.get('institution')),stamp
            )
    except Exception:
        pass


def intraday_market_flow_import_snapshot(payload):
    """Merge browser-local observed rows into the persistent day file in one write."""
    if not isinstance(payload,dict):
        return {'ok':False,'error':'invalid payload'}
    today=_intraday_market_flow_today()
    if str(payload.get('date') or '')!=today:
        return {'ok':False,'error':'date mismatch'}
    markets=payload.get('markets') if isinstance(payload.get('markets'),dict) else {}
    data=_intraday_market_flow_load()
    imported=0
    for market in ('kospi','kosdaq'):
        merged={}
        for row in data['markets'].get(market,[]):
            if isinstance(row,dict) and row.get('time'):
                merged[str(row.get('time'))]=dict(row)
        for row in list(markets.get(market) or []):
            if not isinstance(row,dict):
                continue
            raw=str(row.get('time') or '').strip()
            m=re.search(r'(\d{1,2}):(\d{2})',raw)
            if not m:
                continue
            hh,mm=int(m.group(1)),int(m.group(2))
            minute=hh*60+mm
            if minute<540 or minute>930:
                continue
            def num(v):
                try:return float(v)
                except (TypeError,ValueError):return None
            vals=(num(row.get('personal')),num(row.get('foreign')),num(row.get('institution')))
            if any(v is None for v in vals):
                continue
            t=f'{hh:02d}:{mm:02d}'
            merged[t]={'time':t,'personal':vals[0],'foreign':vals[1],'institution':vals[2]}
            imported+=1
        data['markets'][market]=[merged[k] for k in sorted(merged,key=lambda x:tuple(map(int,x.split(':'))))][-480:]
    _intraday_market_flow_save(data)
    return {'ok':True,'imported':imported,'date':today}


def intraday_market_flow_history_snapshot():
    data=_intraday_market_flow_load()
    data['updated_at']=datetime.now(KST).isoformat()
    data['source']='LITTO 서버측 장중 누적 · 키움 업종별투자자순매수(ka10051)'
    return data


def _intraday_market_flow_collector_loop():
    # Lightweight safety recorder.  It only runs during the regular session and
    # requests investor snapshots; index minute bars remain on the normal path.
    while True:
        try:
            now=datetime.now(KST)
            minute=now.hour*60+now.minute
            client=STATE.get('client')
            if client and 540<=minute<=930 and now.weekday()<5:
                for market,mrkt,inds in (('kospi','0','001'),('kosdaq','1','101')):
                    try:
                        # Background flow collection must never queue behind live quotes/scans.
                        # Non-blocking gate probe; the RLock stays held through this one provider
                        # call, so a competing foreground request cannot slip in between checks.
                        if not API_GATE_LOCK.acquire(blocking=False):
                            continue
                        try:
                            rows=_kiwoom_call(
                                client.rows,'ka10051',
                                {'mrkt_tp':mrkt,'amt_qty_tp':'0','base_dt':now.strftime('%Y%m%d'),'stex_tp':'3'},
                                'inds_netprps',300,10,kind='flow'
                            )
                        finally:
                            API_GATE_LOCK.release()
                        r=next((x for x in rows if str(x.get('inds_cd','')).split('_')[0]==inds), rows[0] if rows else {})
                        def n(v):
                            try:return float(str(v or '0').replace(',','').replace('+',''))
                            except Exception:return None
                        _intraday_market_flow_record_point(market,n(r.get('ind_netprps')),n(r.get('frgnr_netprps')),n(r.get('orgn_netprps')),now)
                    except Exception:
                        continue
        except Exception:
            pass
        time.sleep(30)


def _ensure_intraday_market_flow_collector():
    global INTRADAY_MARKET_FLOW_THREAD
    if INTRADAY_MARKET_FLOW_THREAD and INTRADAY_MARKET_FLOW_THREAD.is_alive():
        return
    INTRADAY_MARKET_FLOW_THREAD=threading.Thread(
        target=_intraday_market_flow_collector_loop,daemon=True,name='litto-intraday-market-flow'
    )
    INTRADAY_MARKET_FLOW_THREAD.start()


def _enrich_market_overview(data):
    data=dict(data or {})
    mk=data.get('markets') or {}
    values=[]
    for key in ('kospi','kosdaq'):
        x=mk.get(key) or {}
        v=x.get('trading_value_krw')
        if v is None and x.get('trading_value') is not None:
            try: v=float(x.get('trading_value'))*1_000_000
            except Exception: v=None
        if v is not None: values.append(float(v))
    data['total_trading_value_krw']=sum(values) if values else None
    return data


def _sector_calendar_market_closed(date_obj):
    """Use the same fetched/cached KRX trading calendar as market actions."""
    return not _is_trade_day(date_obj)

def sector_strength_calendar_snapshot(month=None):
    """Monthly strong-sector calendar derived from the user's daily LITTO candidates.

    A stock is counted once per day even when it matched multiple techniques.
    Source universe = 주도주 종배 + 주도주 상따 + 끼도주 종배, the same candidate
    snapshot already persisted for D+1 tracking.  The current day is overlaid from
    the live report so the calendar does not have to wait for the next disk save.
    """
    now=datetime.now(KST)
    try:
        if month:
            m=datetime.strptime(str(month)[:7],'%Y-%m')
        else:
            m=now.replace(day=1,tzinfo=None)
    except Exception:
        raise ValueError('month는 YYYY-MM 형식이어야 합니다.')
    month_key=f'{m.year:04d}-{m.month:02d}'
    history=_load_candidate_history()

    # Overlay today's live candidates.  This also makes manual sector edits visible
    # immediately without waiting for the next 5-minute full scan/history write.
    today=now.date().isoformat()
    with LOCK:
        report=copy.deepcopy(STATE.get('report') or {})
    panels=((report.get('search_panels') or {}).get('panels') or {})
    live_stocks={}
    for panel_name in ('주도주 종배','주도주 상따','끼도주 종배'):
        for row in ((panels.get(panel_name) or {}).get('rows') or []):
            c=code(row.get('code')) if row.get('code') else ''
            if not c: continue
            rec=live_stocks.setdefault(c,{'code':c,'name':row.get('name') or c,'sector':row.get('sector') or '미분류','tags':[]})
            # Prefer the latest sector value in case one panel carried a fresher edit.
            if row.get('sector'): rec['sector']=row.get('sector')
            if panel_name not in rec['tags']: rec['tags'].append(panel_name)
    if live_stocks and not _sector_calendar_market_closed(now.date()):
        history[today]={'date':today,'saved_at':now.isoformat(),'stocks':live_stocks}

    days=[]
    month_totals={}
    for day,item in sorted(history.items()):
        if not str(day).startswith(month_key+'-'): continue
        try:
            day_obj=datetime.strptime(str(day)[:10],'%Y-%m-%d').date()
        except Exception:
            continue
        if _sector_calendar_market_closed(day_obj):
            continue
        stocks=(item or {}).get('stocks') or {}
        sec_map={}
        valid_count=0
        for c,rec in stocks.items():
            sec=str((rec or {}).get('sector') or '미분류').strip() or '미분류'
            if sec=='미분류': continue
            valid_count+=1
            ent=sec_map.setdefault(sec,{'sector':sec,'count':0,'stocks':[]})
            ent['count']+=1
            ent['stocks'].append({'code':code((rec or {}).get('code') or c),'name':(rec or {}).get('name') or c,'tags':(rec or {}).get('tags') or []})
            month_totals[sec]=month_totals.get(sec,0)+1
        sectors_out=sorted(sec_map.values(),key=lambda x:(-x['count'],x['sector']))
        days.append({'date':day,'candidate_count':len(stocks),'classified_count':valid_count,'sectors':sectors_out})
    monthly=sorted(({'sector':k,'count':v} for k,v in month_totals.items()),key=lambda x:(-x['count'],x['sector']))
    return {
        'month':month_key,
        'days':days,
        'monthly_sectors':monthly,
        'source':'LITTO 일별 후보 · 주도주 종배 + 주도주 상따 + 끼도주 종배',
        'rule':'종목은 하루 1회만 집계 · 미분류 제외',
        'updated_at':now.isoformat(),
        'history_days':len(history),
    }

def market_overview_snapshot(force=False):
    now=time.time()
    if not force and MARKET_OVERVIEW_CACHE.get('data') and now-MARKET_OVERVIEW_CACHE.get('ts',0)<30:
        # Even a cache hit is a valid current-session investor snapshot.  Persist
        # it for the active minute so UI reloads / patch replacement cannot leave
        # a hole in the intraday flow history.
        try:_intraday_market_flow_capture_from_overview(MARKET_OVERVIEW_CACHE['data'])
        except Exception:pass
        return _enrich_market_overview(MARKET_OVERVIEW_CACHE['data'])
    client=STATE.get('client')
    if not client:
        return _enrich_market_overview({'updated_at':None,'source':'키움 공식 REST','markets':{},'error':'키움 미연결'})
    try:
        data=client.market_overview(); MARKET_OVERVIEW_CACHE.update(ts=now,data=data); _intraday_market_flow_capture_from_overview(data); return _enrich_market_overview(data)
    except Exception as e:
        old=MARKET_OVERVIEW_CACHE.get('data')
        if old:
            return _enrich_market_overview({**old,'error':str(e)})
        return _enrich_market_overview({'updated_at':None,'source':'키움 공식 REST','markets':{},'error':str(e)})



def market_investor_history_snapshot(market='kospi',days=10,force=False):
    market=str(market or '').lower().strip()
    if market not in ('kospi','kosdaq'):
        raise ValueError('market은 kospi 또는 kosdaq 이어야 합니다.')
    days=max(1,min(int(days or 10),20))
    key=(market,days)
    now=time.time()
    with MARKET_INVESTOR_HISTORY_LOCK:
        old=MARKET_INVESTOR_HISTORY_CACHE.get(key)
        if old and not force and now-old.get('ts',0)<300:
            return copy.deepcopy(old['data'])
    client=STATE.get('client')
    if not client:
        return {'market':market,'rows':[],'totals':{},'error':'키움 미연결','updated_at':None}
    try:
        data=client.market_investor_history(market,days)
        with MARKET_INVESTOR_HISTORY_LOCK:
            MARKET_INVESTOR_HISTORY_CACHE[key]={'ts':now,'data':copy.deepcopy(data)}
        return data
    except Exception as e:
        with MARKET_INVESTOR_HISTORY_LOCK:
            old=MARKET_INVESTOR_HISTORY_CACHE.get(key)
        if old and old.get('data'):
            return {**copy.deepcopy(old['data']),'error':str(e)}
        return {'market':market,'rows':[],'totals':{},'error':str(e),'updated_at':None}


def _header_yahoo_quote(symbol,force=False):
    """Small cached Yahoo chart quote used only for the header index strip."""
    sym=str(symbol or '').strip()
    now=time.time()
    with HEADER_INDEX_LOCK:
        old=HEADER_INDEX_CACHE.get(sym)
        if old and not force and now-old.get('ts',0)<15 and old.get('data'):
            return dict(old['data'])
    last_err=None
    for host in ('query1.finance.yahoo.com','query2.finance.yahoo.com'):
        try:
            from urllib.parse import quote as _urlquote
            url=(f'https://{host}/v8/finance/chart/{_urlquote(sym,safe="")}'
                 '?interval=1m&range=1d&includePrePost=true&events=div%2Csplits')
            req=Request(url,headers={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124 Safari/537.36',
                                     'Accept':'application/json,text/plain,*/*','Referer':'https://finance.yahoo.com/'})
            with urlopen(req,timeout=5) as resp:
                payload=json.loads(resp.read(1_500_000))
            result=((payload.get('chart') or {}).get('result') or [None])[0]
            if not isinstance(result,dict): raise RuntimeError('지수 응답 없음')
            meta=result.get('meta') or {}
            price=None
            for k in ('regularMarketPrice','postMarketPrice','preMarketPrice'):
                try:
                    v=meta.get(k)
                    if v not in (None,''): price=float(v); break
                except Exception: pass
            if price is None:
                closes=((((result.get('indicators') or {}).get('quote') or [{}])[0] or {}).get('close') or [])
                for c in reversed(closes):
                    try:
                        if c is not None: price=float(c); break
                    except Exception: pass
            prev=None
            for k in ('chartPreviousClose','previousClose','regularMarketPreviousClose'):
                try:
                    v=meta.get(k)
                    if v not in (None,''): prev=float(v); break
                except Exception: pass
            if price is None or prev in (None,0): raise RuntimeError('지수 현재가/전일종가 없음')
            rate=(price-prev)/prev*100.0
            ts=meta.get('regularMarketTime') or meta.get('postMarketTime') or meta.get('preMarketTime')
            try:
                market_time=datetime.fromtimestamp(float(ts),KST).isoformat() if ts else None
            except Exception:
                market_time=None
            data={'symbol':sym,'price':price,'previous_close':prev,'change_rate':rate,'source':'Yahoo Finance chart',
                  'market_state':meta.get('marketState'),'market_time':market_time,'exchange':meta.get('exchangeName'),
                  'currency':meta.get('currency')}
            with HEADER_INDEX_LOCK: HEADER_INDEX_CACHE[sym]={'ts':now,'data':dict(data)}
            return data
        except Exception as e:
            last_err=e
    with HEADER_INDEX_LOCK:
        old=HEADER_INDEX_CACHE.get(sym)
        if old and old.get('data'):
            return {**old['data'],'stale':True,'error':str(last_err or '')}
    return {'price':None,'previous_close':None,'change_rate':None,'error':str(last_err or '조회 실패')}


NASDAQ_FUTURES_CHART_CACHE={'ts':0.0,'data':None}
NASDAQ_FUTURES_CHART_LOCK=threading.RLock()

def nasdaq_futures_chart_snapshot(force=False):
    """On-demand NQ=F intraday chart for the header popup only.

    This endpoint is never called by the normal header refresh. It therefore
    adds no background polling/API load to the existing LITTO runtime.
    """
    now=time.time()
    with NASDAQ_FUTURES_CHART_LOCK:
        old=NASDAQ_FUTURES_CHART_CACHE.get('data')
        if old and not force and now-NASDAQ_FUTURES_CHART_CACHE.get('ts',0)<20:
            return dict(old)
    last_err=None
    for host in ('query1.finance.yahoo.com','query2.finance.yahoo.com'):
        try:
            from urllib.parse import quote as _urlquote
            sym='NQ=F'
            url=(f'https://{host}/v8/finance/chart/{_urlquote(sym,safe="")}'
                 '?interval=1m&range=1d&includePrePost=true&events=div%2Csplits')
            req=Request(url,headers={
                'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124 Safari/537.36',
                'Accept':'application/json,text/plain,*/*','Referer':'https://finance.yahoo.com/'})
            with urlopen(req,timeout=6) as resp:
                payload=json.loads(resp.read(2_000_000))
            result=((payload.get('chart') or {}).get('result') or [None])[0]
            if not isinstance(result,dict): raise RuntimeError('나스닥 선물 차트 응답 없음')
            ts=result.get('timestamp') or []
            q=(((result.get('indicators') or {}).get('quote') or [{}])[0] or {})
            opens=q.get('open') or []; highs=q.get('high') or []; lows=q.get('low') or []; closes=q.get('close') or []
            n=min(len(ts),len(opens),len(highs),len(lows),len(closes))
            bars=[]
            for i in range(n):
                try:
                    o=float(opens[i]);h=float(highs[i]);l=float(lows[i]);c=float(closes[i]);t=int(ts[i])
                    if not all(map(lambda x: x==x and abs(x)!=float('inf'),(o,h,l,c))): continue
                    bars.append({'t':t,'o':o,'h':h,'l':l,'c':c})
                except Exception:
                    continue
            if len(bars)<2: raise RuntimeError('나스닥 선물 차트 데이터 부족')
            meta=result.get('meta') or {}
            prev=None
            for k in ('chartPreviousClose','previousClose','regularMarketPreviousClose'):
                try:
                    v=meta.get(k)
                    if v not in (None,''): prev=float(v); break
                except Exception: pass
            price=bars[-1]['c']
            rate=((price-prev)/prev*100.0) if prev not in (None,0) else None
            data={'symbol':'NQ=F','name':'NASDAQ 100 선물','interval':'1m','range':'1d','price':price,
                  'previous_close':prev,'change_rate':rate,'bars':bars,'source':'Yahoo Finance NQ=F',
                  'updated_at':datetime.now(KST).isoformat()}
            with NASDAQ_FUTURES_CHART_LOCK:
                NASDAQ_FUTURES_CHART_CACHE.update(ts=now,data=dict(data))
            return data
        except Exception as e:
            last_err=e
    with NASDAQ_FUTURES_CHART_LOCK:
        old=NASDAQ_FUTURES_CHART_CACHE.get('data')
        if old:
            return {**old,'stale':True,'error':str(last_err or '')}
    return {'symbol':'NQ=F','name':'NASDAQ 100 선물','bars':[],'error':str(last_err or '조회 실패'),
            'source':'Yahoo Finance NQ=F','updated_at':datetime.now(KST).isoformat()}

ESIGNAL_NQ_URL='https://esignal.co.kr/kospi200-futures-night/'
ESIGNAL_NQ_CACHE={'ts':0.0,'data':None}
ESIGNAL_NQ_LOCK=threading.RLock()

def _parse_esignal_nasdaq_futures(raw):
    """Extract the Nasdaq futures percentage from eSignal Korea HTML/embedded data.

    The page has changed markup before, so use label proximity instead of a
    brittle CSS selector. We only accept realistic daily percentage values.
    """
    try:
        import html as _html
        s=_html.unescape(str(raw or ''))
    except Exception:
        s=str(raw or '')
    if not s:
        return None
    # Normalize escaped JSON and HTML while retaining nearby labels/values.
    s=s.replace('\\u0025','%').replace('\\/','/').replace('&nbsp;',' ')
    compact=re.sub(r'\s+',' ',re.sub(r'<[^>]+>',' ',s))
    labels=[
        r'나스닥\s*100\s*선물', r'나스닥\s*선물',
        r'NASDAQ\s*100\s*FUTURES?', r'NASDAQ\s*FUTURES?',
        r'E[-\s]*MINI\s*NASDAQ(?:[-\s]*100)?', r'\bNQ\b'
    ]
    pct=r'([+\-−]?\s*\d{1,2}(?:\.\d{1,4})?)\s*%'
    candidates=[]
    for label in labels:
        # value after label
        for m in re.finditer(label+r'.{0,280}?'+pct,compact,re.I):
            candidates.append(m.group(1))
        # value before label (table layouts sometimes place % first)
        for m in re.finditer(pct+r'.{0,160}?'+label,compact,re.I):
            candidates.append(m.group(1))
    # Embedded JS/JSON key fallbacks.
    json_patterns=[
        r'(?:nasdaq|nq)[_\- ]?(?:futures?|future|선물)[^\n\r]{0,180}?(?:change[_\- ]?(?:rate|percent|pct)|rate|percent|pct)["\'\s:=]+([+\-−]?\d{1,2}(?:\.\d{1,4})?)',
        r'(?:change[_\- ]?(?:rate|percent|pct)|rate|percent|pct)["\'\s:=]+([+\-−]?\d{1,2}(?:\.\d{1,4})?)[^\n\r]{0,180}?(?:nasdaq|nq)[_\- ]?(?:futures?|future|선물)'
    ]
    for pat in json_patterns:
        for m in re.finditer(pat,s,re.I): candidates.append(m.group(1))
    for v in candidates:
        try:
            n=float(str(v).replace('−','-').replace(' ',''))
            if -15.0 <= n <= 15.0:
                return n
        except Exception:
            pass
    return None

def _esignal_nasdaq_futures(force=False):
    """eSignal Korea Nasdaq futures percentage, cached for 15 seconds."""
    now=time.time()
    with ESIGNAL_NQ_LOCK:
        old=ESIGNAL_NQ_CACHE.get('data')
        if old and not force and now-ESIGNAL_NQ_CACHE.get('ts',0)<15:
            return dict(old)
    err=None
    try:
        req=Request(ESIGNAL_NQ_URL,headers={
            'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124 Safari/537.36',
            'Accept':'text/html,application/xhtml+xml,application/xml;q=0.9,image/avif,image/webp,*/*;q=0.8',
            'Accept-Language':'ko-KR,ko;q=0.9,en-US;q=0.7,en;q=0.6',
            'Referer':'https://esignal.co.kr/',
            'Cache-Control':'no-cache',
            'Pragma':'no-cache',
        })
        with urlopen(req,timeout=6) as resp:
            raw=resp.read(2_500_000).decode(resp.headers.get_content_charset() or 'utf-8','ignore')
        rate=_parse_esignal_nasdaq_futures(raw)
        if rate is None:
            raise RuntimeError('eSignal 페이지에서 나스닥선물 등락률을 찾지 못했습니다.')
        data={'price':None,'previous_close':None,'change_rate':rate,'source':'eSignal Korea','url':ESIGNAL_NQ_URL}
        with ESIGNAL_NQ_LOCK:
            ESIGNAL_NQ_CACHE.update(ts=now,data=dict(data))
        return data
    except Exception as e:
        err=str(e)
    with ESIGNAL_NQ_LOCK:
        old=ESIGNAL_NQ_CACHE.get('data')
        # For temporary network/WAF failures, prefer a recent eSignal value for
        # up to 10 minutes before switching to the fallback feed.
        if old and now-ESIGNAL_NQ_CACHE.get('ts',0)<600:
            return {**old,'stale':True,'error':err}
    return {'price':None,'previous_close':None,'change_rate':None,'source':'eSignal Korea','error':err}


TV_FUTURES_CACHE={}
TV_FUTURES_LOCK=threading.RLock()

def _tradingview_futures_quote(symbol,force=False):
    """TradingView scanner quote for a continuous KRX futures symbol.

    Example symbols: KRX:K2I1! (KOSPI200), KRX:KQI1! (KOSDAQ150).
    Returns close and daily percentage change. If the public scanner rejects the
    request, callers receive an empty quote rather than a fabricated value.
    """
    sym=str(symbol or '').strip()
    now=time.time()
    with TV_FUTURES_LOCK:
        old=TV_FUTURES_CACHE.get(sym)
        if old and not force and now-old.get('ts',0)<15 and old.get('data'):
            return dict(old['data'])
    err=None
    try:
        payload={'symbols':{'tickers':[sym],'query':{'types':[]}},'columns':['close','change']}
        req=Request('https://scanner.tradingview.com/global/scan',
                    data=json.dumps(payload).encode('utf-8'),
                    headers={'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124 Safari/537.36',
                             'Content-Type':'application/json','Accept':'application/json','Origin':'https://www.tradingview.com','Referer':'https://www.tradingview.com/'},
                    method='POST')
        with urlopen(req,timeout=6) as resp:
            d=json.loads(resp.read(1_000_000))
        rows=d.get('data') or []
        vals=(rows[0].get('d') if rows and isinstance(rows[0],dict) else None) or []
        if len(vals)<2: raise RuntimeError('TradingView 선물 응답 없음')
        price=float(vals[0]) if vals[0] not in (None,'') else None
        rate=float(vals[1]) if vals[1] not in (None,'') else None
        data={'price':price,'change_rate':rate,'source':'TradingView '+sym}
        with TV_FUTURES_LOCK: TV_FUTURES_CACHE[sym]={'ts':now,'data':dict(data)}
        return data
    except Exception as e:
        err=str(e)
    with TV_FUTURES_LOCK:
        old=TV_FUTURES_CACHE.get(sym)
        if old and old.get('data'):
            return {**old['data'],'stale':True,'error':err}
    return {'price':None,'change_rate':None,'source':'TradingView '+sym,'error':err or '조회 실패'}

def header_indices_snapshot(force=False):
    """Compact KOSPI / KOSDAQ / NASDAQ futures percentage strip."""
    kospi={'change_rate':None,'price':None,'source':'키움 시장종합'}
    kosdaq={'change_rate':None,'price':None,'source':'키움 시장종합'}
    try:
        mk=market_overview_snapshot(force=force).get('markets') or {}
        kp=mk.get('kospi') or {}
        kq=mk.get('kosdaq') or {}
        if kp.get('change_rate') is not None:
            kospi={'change_rate':float(kp.get('change_rate')),'price':kp.get('price'),'source':'키움 공식 REST'}
        if kq.get('change_rate') is not None:
            kosdaq={'change_rate':float(kq.get('change_rate')),'price':kq.get('price'),'source':'키움 공식 REST'}
    except Exception as e:
        kospi['error']=str(e)
        kosdaq['error']=str(e)
    if kospi.get('change_rate') is None:
        fb=_header_yahoo_quote('^KS11',force=force)
        kospi={**fb,'source':'Yahoo KOSPI fallback'}
    if kosdaq.get('change_rate') is None:
        fb=_header_yahoo_quote('^KQ11',force=force)
        kosdaq={**fb,'source':'Yahoo KOSDAQ fallback'}
    # Nasdaq futures: eSignal Korea is the primary display source because it
    # matches the value users monitor in the study room. Yahoo NQ=F is only a
    # fallback when eSignal cannot be read and there is no recent eSignal cache.
    nqf=_esignal_nasdaq_futures(force=force)
    if nqf.get('change_rate') is None:
        fb=_header_yahoo_quote('NQ=F',force=force)
        nqf={**fb,'source':'Yahoo NQ=F fallback','primary_error':nqf.get('error')}
    # KRX continuous futures for the compact trading header.
    # K2I1! = KOSPI200 futures, KQI1! = KOSDAQ150 futures.
    kpf=_tradingview_futures_quote('KRX:K2I1!',force=force)
    kqf=_tradingview_futures_quote('KRX:KQI1!',force=force)
    return {'updated_at':datetime.now(KST).isoformat(),
            'items':{'kospi':kospi,'kosdaq':kosdaq,'kospi_futures':kpf,'kosdaq_futures':kqf,'nasdaq_futures':nqf}}

def us_market_snapshot(force=False):
    now=time.time()
    if not force and US_MARKET_CACHE.get('data') and now-US_MARKET_CACHE.get('ts',0)<30:
        return US_MARKET_CACHE['data']
    client=STATE.get('client')
    if not client:
        return {'updated_at':None,'source':'키움 미국주식 REST','sections':{},'errors':{'all':'키움 API 연결이 필요합니다.'}}
    try:
        data=client.us_market_snapshot();US_MARKET_CACHE.update(ts=now,data=data);return data
    except Exception as e:
        old=US_MARKET_CACHE.get('data')
        if old:return {**old,'errors':{**(old.get('errors') or {}),'all':str(e)}}
        return {'updated_at':None,'source':'키움 미국주식 REST','sections':{},'errors':{'all':str(e)}}


def account_watchlist_groups_snapshot():
    with LOCK:
        client=STATE.get('client')
    if not client:
        return {'connected':False,'groups':[],'error':'키움 로그인이 필요합니다.','source':'Kiwoom ka01300'}
    try:
        rows=_kiwoom_call(client.watchlist_groups,kind='light')
        return {'connected':True,'groups':rows,'count':len(rows),'source':'Kiwoom ka01300 · HTS 저장 관심종목 그룹'}
    except Exception as e:
        return {'connected':True,'groups':[],'error':str(e)[:220],'source':'Kiwoom ka01300'}

def account_watchlist_group_snapshot(group_code):
    with LOCK:
        client=STATE.get('client')
    if not client:
        return {'connected':False,'rows':[],'error':'키움 로그인이 필요합니다.','source':'Kiwoom ka01301'}
    g=str(group_code or '').strip()
    if not g:
        raise ValueError('관심종목 그룹을 선택해 주세요.')
    rows=_kiwoom_call(client.watchlist_group,g,kind='light')
    sector_map=sectors.load()
    out=[]
    for raw in rows:
        c=str(raw.get('code') or '').strip()
        if not c:
            continue
        live=LOOKUP.get(c,{}) if isinstance(LOOKUP,dict) else {}
        name=(live.get('name') or STOCK_NAME_CACHE.get(c) or c)
        sinfo=sector_map.get(c,{}) if isinstance(sector_map,dict) else {}
        sector=(live.get('sector') or sinfo.get('sector') or '기타')
        out.append({
            'code':c,'name':str(name),'sector':str(sector),
            'bookmark':raw.get('bookmark',''),
            'bookmark_color':raw.get('bookmark_color','')
        })
        if name==c:
            _queue_stock_name_lookup(c)
    return {
        'connected':True,'group_code':g,'rows':out,'count':len(out),
        'source':'Kiwoom ka01301 · HTS 저장 관심종목 그룹 상세'
    }

def us_watchlist_snapshot(symbols,force=False):
    syms=[];seen=set()
    for x in symbols:
        v=str(x or '').strip().upper()
        if v and v not in seen:
            seen.add(v);syms.append(v)
    key=','.join(syms)
    now=time.time()
    if not force and US_WATCHLIST_CACHE.get('data') and US_WATCHLIST_CACHE.get('key')==key and now-US_WATCHLIST_CACHE.get('ts',0)<60:
        return US_WATCHLIST_CACHE['data']
    client=STATE.get('client')
    if not client:
        return {'updated_at':None,'source':'키움 미국주식 REST usa20100','quotes':[],'errors':{'all':'키움 API 연결이 필요합니다.'}}
    try:
        data=client.us_watchlist_quotes(syms)
        US_WATCHLIST_CACHE.update(ts=now,key=key,data=data)
        return data
    except Exception as e:
        old=US_WATCHLIST_CACHE.get('data') if US_WATCHLIST_CACHE.get('key')==key else None
        if old:return {**old,'errors':{**(old.get('errors') or {}),'all':str(e)}}
        return {'updated_at':None,'source':'키움 미국주식 REST usa20100','quotes':[],'errors':{'all':str(e)}}


# Independent account page -----------------------------------------------------
ACCOUNT_STATUS_CACHE={'ts':0.0,'data':None}
ACCOUNT_REALIZED_CACHE={'ts':0.0,'value':None,'rows':[],'summary':{},'error':None}
ACCOUNT_DAILY_PNL_CACHE={}
ACCOUNT_DAILY_PNL_LOCK=threading.RLock()
ACCOUNT_AUTO_CONNECT_GUARD={'ts':0.0}
ACCOUNT_SOR_QUOTE_CACHE={}
ACCOUNT_SOR_QUOTE_TTL=4.0

def _account_client():
    """Reuse the same Kiwoom session as the rest of LITTO, and restore saved login if needed."""
    with LOCK:
        client=STATE.get('client')
    if client:
        return client

    now=time.time()
    if now-float(ACCOUNT_AUTO_CONNECT_GUARD.get('ts') or 0)>=5.0:
        ACCOUNT_AUTO_CONNECT_GUARD['ts']=now
        try:_startup_auto_connect()
        except Exception:pass

    with LOCK:
        return STATE.get('client')


def _overlay_account_sor_quotes(client,data,now=None):
    """Replace KRX-stale kt00018 prices with Kiwoom integrated SOR quotes.

    kt00018 can report a KRX valuation even when a position was filled on NXT.
    For live accounts, quote() with the _AL/SOR symbol is the same integrated
    current-price source used by LITTO's SOR screens.
    """
    if not isinstance(data,dict) or bool(getattr(client,'mock',False)):
        return data
    now=float(now or time.time())
    rows=data.get('holdings') or []
    if not isinstance(rows,list) or not rows:
        return data

    raw_summary=dict(data.get('summary') or {})
    old_total_eval=raw_summary.get('total_evaluation')
    try: old_total_eval=float(old_total_eval) if old_total_eval not in (None,'') else None
    except (TypeError,ValueError): old_total_eval=None

    # Reuse the shared 0B SOR stream before issuing per-holding REST quotes.
    # This keeps the account screen responsive after the first subscription and
    # removes repeated ka10001 calls when fresh integrated ticks already exist.
    holding_codes=[]
    for src in rows:
        if isinstance(src,dict):
            c=code(src.get('code') or '')
            try: qty=float(src.get('quantity') or 0)
            except (TypeError,ValueError): qty=0
            if c and qty>0 and c not in holding_codes: holding_codes.append(c)
    live_quotes={}
    try:
        feed=getattr(client,'_domestic_realtime_feed',None)
        if feed is None:
            feed=DomesticRealtimeFeed(client); client._domestic_realtime_feed=feed
        feed.ensure(holding_codes,owner='account')
        live_quotes,_rt=feed.snapshot()
    except Exception:
        live_quotes={}

    changed=False
    new_rows=[]
    for src in rows:
        if not isinstance(src,dict):
            continue
        r=dict(src)
        c=code(r.get('code') or '')
        qty=float(r.get('quantity') or 0)
        if not c or qty<=0:
            new_rows.append(r); continue

        q=None
        rtq=live_quotes.get(c) if isinstance(live_quotes,dict) else None
        try: rt_fresh=isinstance(rtq,dict) and now-float(rtq.get('received_at') or 0)<=15.0 and float(rtq.get('price') or 0)>0
        except (TypeError,ValueError): rt_fresh=False
        cached=ACCOUNT_SOR_QUOTE_CACHE.get(c)
        if rt_fresh:
            q={'price':rtq.get('price'),'change':rtq.get('change_rate'),'market_code':rtq.get('venue') or 'SOR','source':'websocket_0B'}
            ACCOUNT_SOR_QUOTE_CACHE[c]={'ts':now,'quote':dict(q)}
        elif isinstance(cached,dict) and now-float(cached.get('ts') or 0)<ACCOUNT_SOR_QUOTE_TTL:
            q=cached.get('quote')
        else:
            try:
                q=_kiwoom_call(lambda:client.quote(c,'SOR'),kind='quote')
                if isinstance(q,dict) and float(q.get('price') or 0)>0:
                    ACCOUNT_SOR_QUOTE_CACHE[c]={'ts':now,'quote':dict(q)}
            except Exception:
                q=(cached or {}).get('quote') if isinstance(cached,dict) else None

        px=float((q or {}).get('price') or 0) if isinstance(q,dict) else 0.0
        if px<=0:
            new_rows.append(r); continue

        # A-mode: keep Kiwoom kt00018 valuation fields exactly as returned.
        # Only overlay the displayed current price with the integrated SOR/NXT quote.
        # Do NOT recalculate evaluation_amount / evaluation_pnl / profit_rate here,
        # because Kiwoom's MTS valuation includes its own fee/tax/accounting basis.
        if abs(float(r.get('current_price') or 0)-px) >= 0.5:
            changed=True
        r.update({
            'current_price':px,
            'price_source':'SOR',
            'market_code':(q or {}).get('market_code'),
        })
        new_rows.append(r)

    if not new_rows:
        return data

    # Preserve the complete kt00018 account summary without recomputation.
    summary=dict(raw_summary)

    out=dict(data)
    out['holdings']=new_rows
    out['summary']=summary
    out['price_basis']='SOR display + Kiwoom kt00018 valuation'
    if changed:
        out['source']=str(out.get('source') or '키움 공식 REST')+' + ka10001 통합(SOR) 현재가(표시용)'
    return out

ACCOUNT_FLIGHT=SingleFlight()

def account_status_snapshot(force=False):
    return ACCOUNT_FLIGHT.run('account',lambda:_account_status_snapshot(force))

def _account_status_snapshot(force=False):
    now=time.time()
    client=_account_client()
    if not client:
        return {
            'connected':False,'account_no':'','mock':False,'updated_at':None,
            'summary':{},'holdings':[],'realized_pnl':None,
            'source':'키움 공식 REST','error':'키움 로그인 연결이 필요합니다.'
        }

    if ACCOUNT_STATUS_CACHE.get('client') is not client:
        ACCOUNT_STATUS_CACHE.clear()
        ACCOUNT_STATUS_CACHE.update(ts=0.0,data=None,client=client)
        ACCOUNT_REALIZED_CACHE.update(ts=0.0,value=None,rows=[],summary={},error=None)
        ACCOUNT_SOR_QUOTE_CACHE.clear()

    cached=ACCOUNT_STATUS_CACHE.get('data')
    if cached and not force and now-float(ACCOUNT_STATUS_CACHE.get('ts') or 0)<1.8:
        return cached

    try:
        data=_kiwoom_call(client.account_snapshot,kind='account')
        # kt00018 can remain KRX-valued during NXT/SOR trading. Overlay each
        # holding with the integrated _AL/SOR quote before serving the account UI.
        data=_overlay_account_sor_quotes(client,data,now)

        # Realized P/L is lighter at 10-second cadence; evaluation/holdings refresh every second.
        # IMPORTANT: prefer Kiwoom ka10073 realized-P/L rows.  ka10170 can expose
        # today's trading journal values whose buy average may differ from the
        # exact cost basis used by Kiwoom's MTS "종목실현손익", especially after
        # partial exits / KRX+NXT(SOR) executions.
        if force or now-float(ACCOUNT_REALIZED_CACHE.get('ts') or 0)>=10.0:
            try:
                def _rn(v):
                    if v in (None,''): return None
                    try:return float(str(v).replace(',','').strip())
                    except (TypeError,ValueError):return None

                today_ymd=datetime.now(KST).strftime('%Y%m%d')
                realized_rows=[]
                summary={}
                source='ka10073'

                # 1) Exact realized P/L source used for the account screen.
                rp=_kiwoom_call(client.realized_pnl,today_ymd,today_ymd,kind='account')
                for r in (rp.get('rows') or []):
                    if not isinstance(r,dict): continue
                    name=str(r.get('stk_nm') or '').strip()
                    code=str(r.get('stk_cd') or '').strip()
                    if code and len(code)>6 and code[0] in 'AJQ': code=code[1:]
                    sell_qty=_rn(r.get('cntr_qty'))
                    if not name and not code: continue
                    if sell_qty is not None and sell_qty<=0: continue

                    buy_avg=_rn(r.get('buy_uv'))
                    sell_avg=_rn(r.get('cntr_pric'))
                    pnl=_rn(r.get('tdy_sel_pl'))
                    profit_rate=_rn(r.get('pl_rt'))
                    fee=_rn(r.get('tdy_trde_cmsn')) or 0.0
                    tax=_rn(r.get('tdy_trde_tax')) or 0.0
                    fees_tax=fee+tax

                    # ka10073 does not always provide amount fields; derive display
                    # amounts only from Kiwoom's own avg-price / filled-qty fields.
                    buy_amount=_rn(r.get('buy_amt'))
                    sell_amount=_rn(r.get('sell_amt'))
                    if buy_amount is None and buy_avg is not None and sell_qty is not None:
                        buy_amount=buy_avg*sell_qty
                    if sell_amount is None and sell_avg is not None and sell_qty is not None:
                        sell_amount=sell_avg*sell_qty

                    realized_rows.append({
                        'name':name,
                        'code':code,
                        'buy_avg_price':buy_avg,
                        'buy_qty':sell_qty,
                        'sell_avg_price':sell_avg,
                        'sell_qty':sell_qty,
                        'fees_tax':fees_tax,
                        'pnl':pnl,
                        'sell_amount':sell_amount,
                        'buy_amount':buy_amount,
                        'profit_rate':profit_rate,
                        'source':'ka10073',
                    })

                # 2) Fallback only when ka10073 has no usable rows.
                if not realized_rows:
                    source='ka10170'
                    j=_kiwoom_call(client.daily_trading_journal,kind='account')
                    summary=j.get('summary') or {}
                    for r in (j.get('rows') or []):
                        if not isinstance(r,dict): continue
                        name=str(r.get('stk_nm') or '').strip()
                        code=str(r.get('stk_cd') or '').strip()
                        if code and len(code)>6 and code[0] in 'AJQ': code=code[1:]
                        sell_qty=_rn(r.get('sell_qty'))
                        if not name and not code: continue
                        if sell_qty is not None and sell_qty<=0: continue
                        realized_rows.append({
                            'name':name,
                            'code':code,
                            'buy_avg_price':_rn(r.get('buy_avg_pric')),
                            'buy_qty':_rn(r.get('buy_qty')),
                            'sell_avg_price':_rn(r.get('sel_avg_pric')),
                            'sell_qty':sell_qty,
                            'fees_tax':_rn(r.get('cmsn_alm_tax')),
                            'pnl':_rn(r.get('pl_amt')),
                            'sell_amount':_rn(r.get('sell_amt')),
                            'buy_amount':_rn(r.get('buy_amt')),
                            'profit_rate':_rn(r.get('prft_rt')),
                            'source':'ka10170',
                        })

                realized_rows.sort(key=lambda x:abs(float(x.get('pnl') or 0)),reverse=True)

                # For ka10073, the account total is the sum of Kiwoom's realized
                # P/L fields, not a LITTO recomputation from the current holding AVG.
                if source=='ka10073':
                    pnl_values=[x.get('pnl') for x in realized_rows if x.get('pnl') is not None]
                    value=sum(float(v) for v in pnl_values) if pnl_values else None
                    summary={'tot_pl_amt':value,'source':'ka10073'}
                else:
                    raw=summary.get('tot_pl_amt')
                    try:value=float(str(raw).replace(',','')) if raw not in (None,'') else None
                    except (TypeError,ValueError):value=None

                ACCOUNT_REALIZED_CACHE.update(
                    ts=now,value=value,rows=realized_rows,summary=summary,error=None
                )
            except Exception as e:
                ACCOUNT_REALIZED_CACHE.update(ts=now,error=str(e)[:180])

        payload={
            **data,'connected':True,
            'realized_pnl':ACCOUNT_REALIZED_CACHE.get('value'),
            'realized_rows':ACCOUNT_REALIZED_CACHE.get('rows') or [],
            'realized_summary':ACCOUNT_REALIZED_CACHE.get('summary') or {},
            'realized_error':ACCOUNT_REALIZED_CACHE.get('error'),
            'poll_seconds':2,'error':None
        }
        ACCOUNT_STATUS_CACHE.update(ts=time.time(),data=payload)
        return payload
    except Exception as e:
        if cached:
            return {**cached,'stale':True,'error':str(e)[:220]}
        return {
            'connected':True,'account_no':'','mock':bool(getattr(client,'mock',False)),
            'updated_at':None,'summary':{},'holdings':[],
            'realized_pnl':ACCOUNT_REALIZED_CACHE.get('value'),
            'realized_rows':ACCOUNT_REALIZED_CACHE.get('rows') or [],
            'realized_summary':ACCOUNT_REALIZED_CACHE.get('summary') or {},
            'source':'키움 공식 REST','error':str(e)[:220]
        }



# Manual order bridge ----------------------------------------------------------
# Orders are never generated automatically.  Every placement/cancel request must
# come from the explicit orderbook UI and carry confirm=True.
MANUAL_ORDER_LOCK=threading.RLock()
MANUAL_ORDER_RECENT={}
# Live-order arming is enforced on the server as well as in the browser.
# It expires automatically so a stale browser checkbox cannot leave live trading armed.
MANUAL_ORDER_ARM={'armed':False,'ts':0.0}
MANUAL_ORDER_ARM_TTL=600.0

def manual_order_arm(payload):
    client=_manual_order_client()
    armed=bool(payload.get('armed'))
    now=time.time()
    with MANUAL_ORDER_LOCK:
        if getattr(client,'mock',False):
            MANUAL_ORDER_ARM.update(armed=False,ts=0.0)
            return {'ok':True,'armed':True,'mock':True,'expires_in':0}
        MANUAL_ORDER_ARM.update(armed=armed,ts=now if armed else 0.0)
    return {'ok':True,'armed':armed,'mock':False,'expires_in':int(MANUAL_ORDER_ARM_TTL if armed else 0)}

def _manual_require_live_arm(client):
    if getattr(client,'mock',False):
        return
    now=time.time()
    with MANUAL_ORDER_LOCK:
        armed=bool(MANUAL_ORDER_ARM.get('armed'))
        ts=float(MANUAL_ORDER_ARM.get('ts') or 0.0)
        if armed and now-ts<=MANUAL_ORDER_ARM_TTL:
            return
        MANUAL_ORDER_ARM.update(armed=False,ts=0.0)
    raise ValueError('실전 주문 잠금 상태입니다. 실전계좌 주문 활성화를 다시 체크하세요.')

def _manual_order_client():
    with LOCK:
        client=STATE.get('client')
    if not client:
        try:_startup_auto_connect()
        except Exception:pass
        with LOCK:
            client=STATE.get('client')
    if not client:
        raise ValueError('키움 API 연결이 필요합니다.')
    return client

def _manual_order_once(request_id):
    rid=str(request_id or '').strip()
    if not rid:
        raise ValueError('주문 요청 식별자가 없습니다.')
    now=time.time()
    with MANUAL_ORDER_LOCK:
        for k,t in list(MANUAL_ORDER_RECENT.items()):
            if now-float(t)>45: MANUAL_ORDER_RECENT.pop(k,None)
        if rid in MANUAL_ORDER_RECENT:
            raise ValueError('같은 주문 요청이 이미 처리되었습니다. 중복 주문을 차단했습니다.')
        MANUAL_ORDER_RECENT[rid]=now
    return rid

def manual_place_order(payload):
    if payload.get('confirm') is not True:
        raise ValueError('주문 확인 절차가 필요합니다.')
    rid=_manual_order_once(payload.get('request_id'))
    client=_manual_order_client()
    _manual_require_live_arm(client)
    try:
        result=_kiwoom_call(
            client.manual_cash_order,
            payload.get('side'),
            payload.get('code'),
            payload.get('qty'),
            payload.get('price'),
            payload.get('order_type') or 'limit',
            payload.get('venue') or 'SOR',
            kind='order'
        )
        # Make the account panel pick up fills/changes immediately on its next refresh.
        try:
            ACCOUNT_STATUS_CACHE['ts']=0.0
            ACCOUNT_REALIZED_CACHE['ts']=0.0
        except Exception:pass
        return {**result,'request_id':rid,'submitted_at':datetime.now(KST).isoformat()}
    except Exception:
        # A provider error means no accepted order number was returned.  Allow user retry.
        with MANUAL_ORDER_LOCK:MANUAL_ORDER_RECENT.pop(rid,None)
        raise

def manual_unfilled_orders(stock_code=''):
    client=_manual_order_client()
    rows=_kiwoom_call(client.unfilled_orders,stock_code or '',kind='order')
    return {
        'rows':rows,
        'count':len(rows),
        'updated_at':datetime.now(KST).isoformat(),
        'mock':bool(getattr(client,'mock',False))
    }

def manual_cancel_order(payload):
    if payload.get('confirm') is not True:
        raise ValueError('취소 확인 절차가 필요합니다.')
    rid=_manual_order_once(payload.get('request_id'))
    client=_manual_order_client()
    try:
        result=_kiwoom_call(
            client.cancel_cash_order,
            payload.get('order_no'),
            payload.get('code'),
            payload.get('qty') or 0,
            payload.get('venue') or 'SOR',
            kind='order'
        )
        return {**result,'request_id':rid,'submitted_at':datetime.now(KST).isoformat()}
    except Exception:
        with MANUAL_ORDER_LOCK:MANUAL_ORDER_RECENT.pop(rid,None)
        raise

def manual_cancel_all(payload):
    if payload.get('confirm') is not True:
        raise ValueError('전체 취소 확인 절차가 필요합니다.')
    rid=_manual_order_once(payload.get('request_id'))
    client=_manual_order_client()
    stock_code=str(payload.get('code') or '').strip()
    rows=_kiwoom_call(client.unfilled_orders,stock_code,kind='order')
    results=[];errors=[]
    for row in rows:
        try:
            r=_kiwoom_call(
                client.cancel_cash_order,
                row.get('order_no'),
                row.get('code'),
                0,
                row.get('venue') or 'SOR',
                kind='order'
            )
            results.append(r)
            time.sleep(0.08)
        except Exception as e:
            errors.append({
                'order_no':row.get('order_no'),
                'code':row.get('code'),
                'error':str(e)[:180]
            })
    return {
        'ok':not errors,
        'request_id':rid,
        'canceled':len(results),
        'errors':errors,
        'submitted_at':datetime.now(KST).isoformat()
    }


# Server-backed auto-buy scheduler ------------------------------------------------
# The browser only arms/cancels the schedule. Trigger timing and order submission
# run in the LITTO backend so minimized/background UI timers cannot miss a slot.
AUTO_BUY_LOCK=threading.RLock()
AUTO_BUY_DEFAULT_STATE={
    'active':False,'code':'','name':'','amount':0,'mode':'','venue_mode':'KRX','started_at':None,
    'jobs':[],'baseline_cost':0,'max_added_cost':0,'target_budget':0,'manual_adjustment_mode':'position_cost',
    'last_message':'자동매매 대기','updated_at':None
}
AUTO_BUY_STRATEGIES={}
AUTO_BUY_CONTEXT=threading.local()
AUTO_BUY_THREAD=None
# Multiple symbols can become due at the exact same second. Kiwoom order/account
# endpoints are serialized, but back-to-back strategy execution could still make
# the second symbol fail on a transient provider/rate-limit error. Keep a small
# gap between symbols and safely retry PRE-ORDER lookups only.
AUTO_BUY_MULTI_ORDER_GAP=1.5
AUTO_BUY_PREFLIGHT_MAX_RETRIES=2

class _AutoBuyPreflightRetry(Exception):
    pass

def _auto_buy_retryable_preflight_error(exc):
    t=str(exc or '').lower()
    keys=('429','rate','too many','초과','제한','timeout','timed out','시간 초과',
          'connection reset','connection aborted','10053','10054','temporar','busy',
          'gateway','연결','조회 실패','응답 실패')
    return any(k in t for k in keys)

class _StrategyStateProxy:
    def __init__(self, registry, default_state, context):
        self.registry=registry; self.default_state=default_state; self.context=context
    def _dict(self, create=True):
        key=getattr(self.context,'key',None)
        if key:
            if create and key not in self.registry:
                self.registry[key]=copy.deepcopy(self.default_state)
            return self.registry.get(key,self.default_state)
        return self.default_state
    def get(self,k,d=None): return self._dict(False).get(k,d)
    def __getitem__(self,k): return self._dict(True)[k]
    def __setitem__(self,k,v): self._dict(True)[k]=v
    def clear(self): self._dict(True).clear()
    def update(self,*a,**kw): self._dict(True).update(*a,**kw)
    def setdefault(self,k,d=None): return self._dict(True).setdefault(k,d)

AUTO_BUY_STATE=_StrategyStateProxy(AUTO_BUY_STRATEGIES,AUTO_BUY_DEFAULT_STATE,AUTO_BUY_CONTEXT)

def _auto_buy_strategy_summaries():
    rows=[]
    for c,st in AUTO_BUY_STRATEGIES.items():
        x=copy.deepcopy(st)
        x['code']=c
        rows.append(x)
    rows.sort(key=lambda x:(not bool(x.get('active')),str(x.get('name') or x.get('code') or '')))
    return rows

def _auto_buy_public_state(code_=None):
    c=base_code(code_ or '')
    with AUTO_BUY_LOCK:
        if c and c in AUTO_BUY_STRATEGIES:
            out=copy.deepcopy(AUTO_BUY_STRATEGIES[c])
        else:
            out=copy.deepcopy(AUTO_BUY_DEFAULT_STATE)
            if c: out['code']=c
        out['strategies']=_auto_buy_strategy_summaries()
        out['active_count']=sum(1 for x in AUTO_BUY_STRATEGIES.values() if x.get('active'))
    out['server_time']=datetime.now(KST).isoformat()
    return out

def _auto_buy_tick_size(price):
    """Korean equity tick-size fallback used only when no executable ask exists."""
    p=max(0,int(float(price or 0)))
    if p<2000:return 1
    if p<5000:return 5
    if p<20000:return 10
    if p<50000:return 50
    if p<200000:return 100
    if p<500000:return 500
    return 1000

def _auto_buy_book(client, stock_code, venue_mode='KRX'):
    c=base_code(stock_code)
    if not c:
        raise ValueError('종목코드가 필요합니다.')
    mode=str(venue_mode or 'KRX').upper()
    # Mock accounts do not expose a separate NXT venue. Use KRX only for dry testing.
    venue='KRX' if bool(getattr(client,'mock',False)) else ('NXT' if mode=='NXT' else 'SOR')
    data=_kiwoom_call(client.domestic_orderbook,c,venue,kind='order')
    actual=str((data or {}).get('venue') or venue).upper()
    return data,actual

def _auto_buy_reference_price(client, stock_code, venue_mode='KRX'):
    data,_venue=_auto_buy_book(client,stock_code,venue_mode)
    p=float(data.get('current_price') or 0)
    if not p:
        asks=data.get('asks') or []
        bids=data.get('bids') or []
        for row in list(asks)+list(bids):
            try:rp=float((row or {}).get('price') or 0)
            except Exception:rp=0
            if rp>0:
                p=rp;break
    if not p or p<=0:
        raise ValueError('실시간 현재가를 확인할 수 없습니다.')
    return int(round(p))

def _auto_buy_nxt_limit_price(client, stock_code):
    """NXT auto-buy: executable best ask LIMIT first; current+1 tick fallback."""
    data,venue=_auto_buy_book(client,stock_code,'NXT')
    if not bool(getattr(client,'mock',False)) and str(venue).upper()!='NXT':
        raise ValueError('NXT 전용 호가를 확인하지 못해 주문을 중단했습니다.')
    asks=data.get('asks') or []
    ask_prices=[]
    for row in asks:
        try:p=int(round(float((row or {}).get('price') or 0)))
        except Exception:p=0
        if p>0:ask_prices.append(p)
    if ask_prices:
        # Orderbook adapters can return either display order. Lowest ask is executable ask1.
        return min(ask_prices),venue,'매도1호가'
    current=int(round(float(data.get('current_price') or 0)))
    if current<=0:
        raise ValueError('NXT 현재가/매도호가를 확인할 수 없습니다.')
    return current+_auto_buy_tick_size(current),venue,'현재가+1틱'

def _auto_buy_holding_cost(stock_code, force=True):
    """Fresh broker-side position cost used to absorb HTS/MTS manual buys.

    purchase_amount/avg_price are broker account values, so the delta from the
    value captured when auto-buy starts reflects additional same-symbol buying
    regardless of whether it came from LITTO, HTS, or MTS.  We retain the
    maximum observed delta so later manual sells cannot reopen auto-buy budget.
    """
    c=base_code(stock_code)
    snap=_account_status_snapshot(force=force)
    for h in (snap.get('holdings') or []):
        if base_code((h or {}).get('code'))!=c:
            continue
        try: qty=max(0,int(float((h or {}).get('quantity') or 0)))
        except Exception: qty=0
        try: avg=max(0.0,float((h or {}).get('avg_price') or 0))
        except Exception: avg=0.0
        try: pur=max(0.0,float((h or {}).get('purchase_amount') or 0))
        except Exception: pur=0.0
        if pur<=0 and qty>0 and avg>0:
            pur=qty*avg
        return int(round(pur)),qty,avg,snap
    return 0,0,0.0,snap


def _auto_buy_open_buy_value(stock_code, fallback_price=0):
    """Conservative value of same-symbol unfilled BUY orders from any UI.

    This prevents a scheduled buy from stacking on top of an HTS/MTS/LITTO buy
    that is accepted by the broker but has not filled yet.
    """
    c=base_code(stock_code)
    total=0
    rows=[]
    try: rows=manual_unfilled_orders(c).get('rows') or []
    except Exception: rows=[]
    for r in rows:
        if base_code((r or {}).get('code')) not in ('',c):
            continue
        side=str((r or {}).get('side') or '').strip().lower()
        raw=' '.join(str((r or {}).get(k) or '') for k in ('side','side_name','order_side','trade_type','bs_type','ord_type')).lower()
        is_buy=(side=='buy') or ('매수' in raw) or raw in ('1','01')
        if not is_buy:
            continue
        try: rem=max(0,int(float((r or {}).get('remain_qty') or (r or {}).get('unfilled_qty') or 0)))
        except Exception: rem=0
        try: px=max(0,int(float((r or {}).get('order_price') or 0)))
        except Exception: px=0
        if px<=0: px=max(0,int(fallback_price or 0))
        total+=rem*px
    return int(total),rows


def _auto_buy_execute(job):
    with AUTO_BUY_LOCK:
        if not AUTO_BUY_STATE.get('active'):
            return
        code_=str(AUTO_BUY_STATE.get('code') or '')
        name_=str(AUTO_BUY_STATE.get('name') or code_)
        amount=int(AUTO_BUY_STATE.get('amount') or 0)
        venue_mode=str(AUTO_BUY_STATE.get('venue_mode') or 'KRX').upper()
    # Everything above the actual order transmit is safe to retry. This is the
    # important distinction for multi-symbol schedules: we NEVER blindly retry
    # after an order transmission may have reached the broker.
    try:
        client=_manual_order_client()
        order_price=None;order_type='market';price_source='시장가 기준';order_venue='KRX' if bool(getattr(client,'mock',False)) else 'SOR'
        if venue_mode=='NXT':
            order_price,order_venue,price_source=_auto_buy_nxt_limit_price(client,code_)
            ref_price=order_price
            order_type='limit'
        else:
            ref_price=_auto_buy_reference_price(client,code_,'KRX')

        # DEV12 A-mode: manual HTS/MTS buys consume the same remaining auto-buy
        # budget. Use fresh broker purchase-cost delta plus same-symbol open buys.
        current_cost,_cur_qty,_cur_avg,_snap=_auto_buy_holding_cost(code_,force=True)
        pending_buy_value,_pending_rows=_auto_buy_open_buy_value(code_,fallback_price=ref_price)
    except Exception as e:
        if _auto_buy_retryable_preflight_error(e):
            raise _AutoBuyPreflightRetry(str(e)) from e
        raise
    with AUTO_BUY_LOCK:
        baseline=max(0,int(AUTO_BUY_STATE.get('baseline_cost') or 0))
        observed=max(0,current_cost-baseline)
        prev=max(0,int(AUTO_BUY_STATE.get('max_added_cost') or 0))
        max_added=max(prev,observed)
        AUTO_BUY_STATE['max_added_cost']=max_added
        target=max(0,int(AUTO_BUY_STATE.get('target_budget') or 0))
        remaining=max(0,target-max_added-pending_buy_value)
        AUTO_BUY_STATE['observed_added_cost']=max_added
        AUTO_BUY_STATE['pending_buy_value']=pending_buy_value
        AUTO_BUY_STATE['remaining_budget']=remaining
        AUTO_BUY_STATE['updated_at']=datetime.now(KST).isoformat()
    if remaining<=0:
        with AUTO_BUY_LOCK:
            job['done']=True;job['ok']=True;job['running']=False;job['skipped']=True
            job['qty']=0;job['finished_at']=datetime.now(KST).isoformat()
            AUTO_BUY_STATE['last_message']=f'{job["idx"]}차 건너뜀 · 수동/기존 매수 반영 후 남은 자동매수 예산이 없습니다.'
            AUTO_BUY_STATE['updated_at']=datetime.now(KST).isoformat()
        return
    effective_amount=min(amount,remaining)
    qty=int(effective_amount//ref_price)
    if qty<1:
        with AUTO_BUY_LOCK:
            job['done']=True;job['ok']=True;job['running']=False;job['skipped']=True
            job['qty']=0;job['finished_at']=datetime.now(KST).isoformat()
            AUTO_BUY_STATE['last_message']=f'{job["idx"]}차 건너뜀 · 남은 예산 {remaining:,}원으로 1주를 살 수 없습니다.'
            AUTO_BUY_STATE['updated_at']=datetime.now(KST).isoformat()
        return

    # Reuse the exact same order bridge as manual trading. Open the server live
    # latch only around this single request, then lock it immediately afterwards.
    req_id=f'autobuy-server-{datetime.now(KST).strftime("%Y%m%d%H%M%S%f")}-{job["idx"]}'
    server_armed=False
    try:
        arm=manual_order_arm({'armed':True})
        server_armed=bool(arm.get('armed'))
        if not server_armed:
            raise ValueError('주문 잠금을 해제하지 못했습니다.')
        res=manual_place_order({
            'confirm':True,'request_id':req_id,'side':'buy','code':code_,
            'qty':qty,'price':order_price,'order_type':order_type,
            'venue':order_venue
        })
        order_no=str(res.get('order_no') or '')
        with AUTO_BUY_LOCK:
            job['done']=True;job['ok']=True;job['running']=False
            job['qty']=qty;job['planned_amount']=amount;job['effective_amount']=effective_amount;job['ref_price']=ref_price;job['order_price']=order_price;job['order_type']=order_type;job['venue']=order_venue;job['price_source']=price_source;job['order_no']=order_no
            job['finished_at']=datetime.now(KST).isoformat()
            mode_txt='NXT 지정가' if venue_mode=='NXT' else '시장가'
            px_txt=f' · {order_price:,}원' if order_price else ''
            AUTO_BUY_STATE['last_message']=f'{job["idx"]}차 접수 완료 · {name_} {qty:,}주 · 예산 {effective_amount:,}원 · {mode_txt}{px_txt} · 주문번호 {order_no or "-"}'
            AUTO_BUY_STATE['updated_at']=datetime.now(KST).isoformat()
    finally:
        if server_armed:
            try:manual_order_arm({'armed':False})
            except Exception:pass

def _auto_buy_worker():
    while True:
        due=None; due_code=None
        with AUTO_BUY_LOCK:
            now=datetime.now(KST)
            for c,st in list(AUTO_BUY_STRATEGIES.items()):
                if not st.get('active'): continue
                AUTO_BUY_CONTEXT.key=c
                for j in st.get('jobs') or []:
                    if j.get('done') or j.get('running'): continue
                    try: when=datetime.fromisoformat(str(j.get('when')))
                    except Exception: continue
                    if when.tzinfo is None: when=when.replace(tzinfo=KST)
                    retry_after=0.0
                    try: retry_after=float(j.get('retry_after') or 0.0)
                    except Exception: retry_after=0.0
                    if when<=now and time.time()>=retry_after:
                        j['running']=True
                        retry_no=int(j.get('retry_count') or 0)
                        retry_txt=f' · 재시도 {retry_no}/{AUTO_BUY_PREFLIGHT_MAX_RETRIES}' if retry_no else ''
                        st['last_message']=f'{j.get("idx")}차 · 주문 준비 중…{retry_txt}'
                        st['updated_at']=now.isoformat()
                        due=j; due_code=c
                        break
                pending=[j for j in (st.get('jobs') or []) if not j.get('done')]
                if not pending and due_code!=c:
                    st['active']=False
                    st['last_message']='오늘 자동매매 처리 완료'
                    st['updated_at']=now.isoformat()
                if due is not None: break
            AUTO_BUY_CONTEXT.key=None
        if due is not None and due_code:
            try:
                AUTO_BUY_CONTEXT.key=due_code
                _auto_buy_execute(due)
            except _AutoBuyPreflightRetry as e:
                with AUTO_BUY_LOCK:
                    st=AUTO_BUY_STRATEGIES.get(due_code)
                    if st is not None:
                        tries=int(due.get('retry_count') or 0)+1
                        due['retry_count']=tries;due['running']=False
                        due['error']=str(e)[:220]
                        if tries<=AUTO_BUY_PREFLIGHT_MAX_RETRIES:
                            delay=2.0 if tries==1 else 5.0
                            due['retry_after']=time.time()+delay
                            st['last_message']=f'{due.get("idx")}차 사전조회 지연 · {delay:.0f}초 뒤 재시도 ({tries}/{AUTO_BUY_PREFLIGHT_MAX_RETRIES})'
                        else:
                            due['done']=True;due['ok']=False;due['finished_at']=datetime.now(KST).isoformat()
                            st['last_message']=f'{due.get("idx")}차 실패 · 사전조회 재시도 초과 · {str(e)[:140]}'
                        st['updated_at']=datetime.now(KST).isoformat()
            except Exception as e:
                with AUTO_BUY_LOCK:
                    st=AUTO_BUY_STRATEGIES.get(due_code)
                    if st is not None:
                        due['done']=True;due['ok']=False;due['running']=False
                        due['error']=str(e)[:220];due['finished_at']=datetime.now(KST).isoformat()
                        st['last_message']=f'{due.get("idx")}차 실패 · {str(e)[:180]}'
                        st['updated_at']=datetime.now(KST).isoformat()
            finally:
                AUTO_BUY_CONTEXT.key=None
            # Same-time multi-stock reservations are deliberately serialized with
            # a small gap so the second symbol does not hit broker REST bursts.
            time.sleep(AUTO_BUY_MULTI_ORDER_GAP)
        time.sleep(0.20)

def _ensure_auto_buy_thread():
    global AUTO_BUY_THREAD
    with AUTO_BUY_LOCK:
        if AUTO_BUY_THREAD is None or not AUTO_BUY_THREAD.is_alive():
            AUTO_BUY_THREAD=threading.Thread(target=_auto_buy_worker,name='litto-auto-buy',daemon=True)
            AUTO_BUY_THREAD.start()

def auto_buy_start(payload):
    client=_manual_order_client()
    c=base_code(payload.get('code'))
    name_=str(payload.get('name') or c or '').strip()
    try: amount=int(float(payload.get('amount') or 0))
    except Exception: amount=0
    if not c: raise ValueError('종목코드가 필요합니다.')
    if amount<=0: raise ValueError('1회 주문금액을 입력해 주세요.')
    now=datetime.now(KST)
    venue_mode=str(payload.get('venue_mode') or 'KRX').upper()
    if venue_mode not in ('KRX','NXT'): raise ValueError('자동매수 시장 설정이 올바르지 않습니다.')
    default_times=['19:40:00','19:50:00','19:59:00'] if venue_mode=='NXT' else ['15:00:00','15:10:00','15:19:00']
    raw_times=payload.get('times')
    if raw_times is None:
        raw_times=default_times
    if not isinstance(raw_times,list) or len(raw_times)!=3:
        raise ValueError('자동매수 예약시간 3개가 필요합니다.')
    clean_times=[]
    time_minutes=[]
    for raw in raw_times:
        text=str(raw or '').strip()
        parts=text.split(':')
        if len(parts) not in (2,3):
            raise ValueError('자동매수 예약시간 형식이 올바르지 않습니다.')
        try:
            h=int(parts[0]);m=int(parts[1]);sec=int(parts[2]) if len(parts)==3 else 0
        except Exception:
            raise ValueError('자동매수 예약시간 형식이 올바르지 않습니다.')
        if not (0<=h<=23 and 0<=m<=59 and 0<=sec<=59):
            raise ValueError('자동매수 예약시간 범위가 올바르지 않습니다.')
        clean_times.append(f'{h:02d}:{m:02d}:{sec:02d}')
        time_minutes.append(h*3600+m*60+sec)
    if not (time_minutes[0]<time_minutes[1]<time_minutes[2]):
        raise ValueError('자동매수 예약시간은 1차 < 2차 < 3차 순서여야 합니다.')
    slots=list(enumerate(clean_times,start=1))
    jobs=[]
    for idx,hm in slots:
        h,m,sec=map(int,hm.split(':'))
        when=now.replace(hour=h,minute=m,second=sec,microsecond=0)
        if when>now:
            jobs.append({'idx':idx,'time':hm,'when':when.isoformat(),'done':False,'ok':False,'running':False})
    if not jobs:
        raise ValueError(f'오늘 설정한 마지막 예약시간 {clean_times[-1][:5]}이 지나 자동매매를 시작할 수 없습니다.')
    # Only future slots count toward today's automatic-buy budget.  Example:
    # starting at 15:08 ignores 15:00 and budgets only the 15:10/15:19 slots.
    baseline_cost,_baseline_qty,_baseline_avg,_baseline_snap=_auto_buy_holding_cost(c,force=True)
    target_budget=amount*len(jobs)
    with AUTO_BUY_LOCK:
        AUTO_BUY_CONTEXT.key=c
        if AUTO_BUY_STATE.get('active'):
            AUTO_BUY_CONTEXT.key=None
            raise ValueError('이 종목은 이미 자동매수가 실행 중입니다. 먼저 취소해 주세요.')
        AUTO_BUY_STATE.clear()
        AUTO_BUY_STATE.update({
            'active':True,'code':c,'name':name_,'amount':amount,'venue_mode':venue_mode,
            'mode':'모의계좌' if bool(getattr(client,'mock',False)) else '실전계좌',
            'started_at':now.isoformat(),'jobs':jobs,
            'baseline_cost':baseline_cost,'baseline_qty':_baseline_qty,'baseline_avg_price':_baseline_avg,
            'target_budget':target_budget,'max_added_cost':0,'observed_added_cost':0,'pending_buy_value':0,'remaining_budget':target_budget,
            'manual_adjustment_mode':'position_cost',
            'last_message':f'{venue_mode} 자동매매 대기 · 다음 {jobs[0]["idx"]}차 {jobs[0]["time"]} · 오늘 예산 {target_budget:,}원',
            'updated_at':now.isoformat()
        })
    AUTO_BUY_CONTEXT.key=None
    _ensure_auto_buy_thread()
    return _auto_buy_public_state(c)

def auto_buy_cancel(payload=None):
    c=base_code((payload or {}).get('code') or '')
    with AUTO_BUY_LOCK:
        if not c:
            active=[k for k,v in AUTO_BUY_STRATEGIES.items() if v.get('active')]
            c=active[0] if len(active)==1 else ''
        if not c or c not in AUTO_BUY_STRATEGIES:
            raise ValueError('취소할 자동매수 종목을 선택해 주세요.')
        AUTO_BUY_CONTEXT.key=c
        st=AUTO_BUY_STRATEGIES[c]
        if any(j.get('running') for j in (st.get('jobs') or [])):
            AUTO_BUY_CONTEXT.key=None
            raise ValueError('주문 전송 중에는 취소할 수 없습니다. 주문 결과 확인 후 다시 시도하세요.')
        st['active']=False
        st['last_message']='자동매매 예약이 취소되었습니다.'
        st['updated_at']=datetime.now(KST).isoformat()
        AUTO_BUY_CONTEXT.key=None
    try:manual_order_arm({'armed':False})
    except Exception:pass
    return _auto_buy_public_state(c)

def auto_buy_cancel_all(payload=None):
    """Stop every pending auto-buy strategy without touching broker orders.

    A strategy currently transmitting an order is deliberately left active so a
    batch-stop can never interrupt an in-flight order/confirmation sequence.
    """
    canceled=[]; blocked=[]
    now=datetime.now(KST).isoformat()
    with AUTO_BUY_LOCK:
        for c,st in AUTO_BUY_STRATEGIES.items():
            if not st.get('active'):
                continue
            if any(j.get('running') for j in (st.get('jobs') or [])):
                blocked.append({'code':c,'name':st.get('name') or c,'reason':'주문 전송 중'})
                continue
            st['active']=False
            st['last_message']='일괄취소 · 남은 자동매수 예약을 중지했습니다.'
            st['updated_at']=now
            canceled.append({'code':c,'name':st.get('name') or c})
    # The live-order latch is only closed after strategy state is settled.  This
    # does not cancel or alter an order that was already accepted by Kiwoom.
    try:manual_order_arm({'armed':False})
    except Exception:pass
    out=_auto_buy_public_state('')
    out['batch_cancel']={'canceled':canceled,'blocked':blocked,'canceled_count':len(canceled),'blocked_count':len(blocked)}
    out['last_message']=(f'자동매수 일괄취소 {len(canceled)}종목 완료'+(f' · 주문 처리 중 {len(blocked)}종목 제외' if blocked else ''))
    return out


# Server-backed auto-sell strategy ------------------------------------------------
# DEV 1.24.5 DEV6: checked profit stages are monitored in the backend.  Orders use
# executable best-bid LIMIT prices (never market) and re-check unfilled quantity.
AUTO_SELL_LOCK=threading.RLock()
AUTO_SELL_DEFAULT_STATE={
    'active':False,'code':'','name':'','mode':'','initial_qty':0,'avg_price':0.0,
    'stages':[],'loss_stop_enabled':False,'loss_stop_pct':-4.0,'loss_stop_ratio':50.0,'loss_stop_done':False,
    'time_stop_enabled':False,'time_stop':'10:00','time_stop_ratio':50.0,'time_stop_done':False,'stop_triggered':False,'stop_running':False,
    'last_message':'자동매도 대기','updated_at':None,'started_at':None,'event_log':[]
}
AUTO_SELL_STRATEGIES={}
AUTO_SELL_CONTEXT=threading.local()
AUTO_SELL_STATE=_StrategyStateProxy(AUTO_SELL_STRATEGIES,AUTO_SELL_DEFAULT_STATE,AUTO_SELL_CONTEXT)

def _auto_sell_event(kind, message, qty=None):
    """Append a compact user-visible auto-sell event. Caller should hold AUTO_SELL_LOCK."""
    ev={'time':datetime.now(KST).isoformat(),'kind':str(kind or 'info'),'message':str(message or '')}
    if qty is not None:
        try: ev['qty']=int(qty)
        except Exception: pass
    log=AUTO_SELL_STATE.setdefault('event_log',[])
    log.append(ev)
    if len(log)>30:
        del log[:-30]

AUTO_SELL_THREAD=None

def _auto_sell_strategy_summaries():
    rows=[]
    for c,st in AUTO_SELL_STRATEGIES.items():
        x=copy.deepcopy(st);x['code']=c;rows.append(x)
    rows.sort(key=lambda x:(not bool(x.get('active')),str(x.get('name') or x.get('code') or '')))
    return rows

def _auto_sell_public_state(code_=None):
    c=base_code(code_ or '')
    with AUTO_SELL_LOCK:
        if c and c in AUTO_SELL_STRATEGIES:
            out=copy.deepcopy(AUTO_SELL_STRATEGIES[c])
        else:
            out=copy.deepcopy(AUTO_SELL_DEFAULT_STATE)
            if c: out['code']=c
        out['strategies']=_auto_sell_strategy_summaries()
        out['active_count']=sum(1 for x in AUTO_SELL_STRATEGIES.values() if x.get('active'))
    out['server_time']=datetime.now(KST).isoformat()
    return out

def _auto_sell_holding(code_, force=True):
    snap=_account_status_snapshot(force=force)
    c=base_code(code_)
    for h in (snap.get('holdings') or []):
        if base_code(h.get('code'))==c:
            return h, snap
    return None, snap

def _auto_sell_open_sell_qty(code_):
    """Return current unfilled SELL quantity for this symbol.

    This is deliberately re-read from the broker before every automatic sell.
    It covers orders entered from LITTO as well as HTS/MTS when the provider
    exposes them through the same unfilled-order feed.
    """
    c=base_code(code_)
    total=0
    rows=[]
    try:
        rows=manual_unfilled_orders(c).get('rows') or []
    except Exception:
        rows=[]
    for r in rows:
        if base_code((r or {}).get('code')) not in ('',c):
            continue
        side=str((r or {}).get('side') or '').strip().lower()
        # Normalized Kiwoom bridge uses buy/sell.  Be tolerant of Korean/raw values.
        raw=' '.join(str((r or {}).get(k) or '') for k in ('side','order_side','trade_type','bs_type','ord_type')).lower()
        is_sell=(side=='sell') or ('매도' in raw) or raw in ('2','02')
        if not is_sell:
            continue
        try:
            rem=max(0,int(float((r or {}).get('remain_qty') or (r or {}).get('unfilled_qty') or 0)))
        except Exception:
            rem=0
        total+=rem
    return total, rows

def _auto_sell_account_guard(code_, force=True):
    """Fresh broker-side quantity guard used immediately before any sell.

    safe_available is capped by both the broker's saleable quantity and current
    holding minus open sell orders, so it remains conservative whether the broker
    already deducts unfilled sells from available_quantity or not.
    """
    holding,snap=_auto_sell_holding(code_,force=force)
    if not holding:
        return {'holding':None,'snapshot':snap,'qty':0,'available':0,'open_sell_qty':0,'safe_available':0}
    try: qty=max(0,int(float(holding.get('quantity') or 0)))
    except Exception: qty=0
    try: avail=max(0,int(float(holding.get('available_quantity') if holding.get('available_quantity') is not None else qty)))
    except Exception: avail=qty
    open_sell,_rows=_auto_sell_open_sell_qty(code_)
    safe=max(0,min(qty,avail,max(0,qty-open_sell)))
    return {'holding':holding,'snapshot':snap,'qty':qty,'available':avail,'open_sell_qty':open_sell,'safe_available':safe}

def _auto_sell_book(client, code_):
    venue='KRX' if bool(getattr(client,'mock',False)) else 'SOR'
    book=_kiwoom_call(client.domestic_orderbook,base_code(code_),venue,kind='order')
    cur=float(book.get('current_price') or 0)
    bids=[x for x in (book.get('bids') or []) if isinstance(x,dict) and float(x.get('price') or 0)>0]
    bids.sort(key=lambda x:float(x.get('price') or 0),reverse=True)
    bid=int(round(float(bids[0].get('price') or 0))) if bids else 0
    return book, int(round(cur)) if cur>0 else 0, bid

def _auto_sell_submit_limit(code_, qty, price, tag):
    client=_manual_order_client()
    req_id=f'autosell-{datetime.now(KST).strftime("%Y%m%d%H%M%S%f")}-{tag}'
    server_armed=False
    try:
        arm=manual_order_arm({'armed':True})
        server_armed=bool(arm.get('armed'))
        if not server_armed:
            raise ValueError('주문 잠금을 해제하지 못했습니다.')
        return manual_place_order({
            'confirm':True,'request_id':req_id,'side':'sell','code':code_,
            'qty':int(qty),'price':int(price),'order_type':'limit',
            'venue':'KRX' if bool(getattr(client,'mock',False)) else 'SOR'
        })
    finally:
        if server_armed:
            try:manual_order_arm({'armed':False})
            except Exception:pass

def _auto_sell_remaining_for_order(order_no, code_):
    """Return (found, remaining). Missing status is NOT treated as a fill."""
    rows=manual_unfilled_orders(code_).get('rows') or []
    ono=str(order_no or '')
    for r in rows:
        if str(r.get('order_no') or '')==ono:
            try:return True,max(0,int(float(r.get('remain_qty') or r.get('unfilled_qty') or 0)))
            except Exception:return True,0
    return False,None

def _auto_sell_cancel_order(order_no, code_, qty):
    try:
        return manual_cancel_order({
            'confirm':True,
            'request_id':f'autosell-cancel-{datetime.now(KST).strftime("%Y%m%d%H%M%S%f")}',
            'order_no':order_no,'code':code_,'qty':int(qty or 0),
            'venue':'KRX' if bool(getattr(_manual_order_client(),'mock',False)) else 'SOR'
        })
    except Exception:
        return None

def _auto_sell_execute_stage(stage):
    with AUTO_SELL_LOCK:
        if not AUTO_SELL_STATE.get('active') or stage.get('done') or stage.get('running') is False:
            return
        code_=str(AUTO_SELL_STATE.get('code') or '')
        name_=str(AUTO_SELL_STATE.get('name') or code_)
        initial_qty=int(AUTO_SELL_STATE.get('initial_qty') or 0)
        avg_price=float(AUTO_SELL_STATE.get('avg_price') or 0)
    guard=_auto_sell_account_guard(code_,force=True)
    holding=guard.get('holding')
    if not holding:
        with AUTO_SELL_LOCK:
            stage.update(done=True,ok=True,running=False,sold_qty=0,error='')
            AUTO_SELL_STATE['active']=False
            AUTO_SELL_STATE['last_message']='보유수량이 없어 자동매도를 종료했습니다.'
            _auto_sell_event('end','보유수량 0주 · 자동매도 종료')
            AUTO_SELL_STATE['updated_at']=datetime.now(KST).isoformat()
        return
    avail=int(guard.get('safe_available') or 0)
    open_sell=int(guard.get('open_sell_qty') or 0)
    with AUTO_SELL_LOCK:
        AUTO_SELL_STATE['account_qty']=int(guard.get('qty') or 0)
        AUTO_SELL_STATE['available_quantity']=avail
        AUTO_SELL_STATE['open_sell_qty']=open_sell
    # Never stack an automatic sell on top of an existing unfilled sell.
    # This includes orders entered from HTS/MTS and previous LITTO orders.
    if open_sell>0:
        raise ValueError(f'기존 미체결 매도 {open_sell:,}주가 있어 자동매도를 대기합니다.')
    if avail<=0:
        if int(guard.get('qty') or 0)<=0:
            with AUTO_SELL_LOCK:
                AUTO_SELL_STATE['active']=False
                AUTO_SELL_STATE['last_message']='실제 보유수량이 0주라 자동매도를 종료했습니다.'
                AUTO_SELL_STATE['updated_at']=datetime.now(KST).isoformat()
            return
        raise ValueError(f'현재 매도가능 수량이 없습니다. 미체결 매도 {int(guard.get("open_sell_qty") or 0):,}주를 확인해 주세요.')
    if stage.get('final'):
        target_qty=avail
    else:
        ratio=max(0.0,min(100.0,float(stage.get('ratio') or 0)))
        target_qty=int(initial_qty*ratio/100.0) if ratio>0 else 0
        target_qty=min(avail,target_qty)
    if target_qty<=0:
        # Small holdings can legitimately round an intermediate allocation below 1 share.
        # Skip that stage once and leave the shares for the final 'sell remainder' stage.
        with AUTO_SELL_LOCK:
            stage.update(done=True,ok=True,running=False,sold_qty=0,skipped=True,error='')
            AUTO_SELL_STATE['last_message']=f'{stage.get("label")} 배분은 1주 미만이라 건너뜁니다' + (' · 잔량은 최종 단계에서 처리' if AUTO_SELL_STATE.get('liquidate_remainder') else ' · 해당 수량은 보유 유지')
            _auto_sell_event('profit',f'{stage.get("label")} 익절 · 1주 미만이라 건너뜀',0)
            AUTO_SELL_STATE['updated_at']=datetime.now(KST).isoformat()
        return

    target_pct=float(stage.get('pct') or 0)
    min_price=avg_price*(1.0+target_pct/100.0)
    remaining=target_qty
    total_submitted=0
    order_nos=[]
    # Up to 6 best-bid revisions. Never chase below the configured profit threshold.
    for attempt in range(1,7):
        if remaining<=0: break
        client=_manual_order_client()
        _book,_cur,bid=_auto_sell_book(client,code_)
        if bid<=0:
            raise ValueError('최우선 매수호가를 확인할 수 없습니다.')
        if float(bid)+1e-9 < min_price:
            if attempt==1:
                raise ValueError(f'최우선 매수호가 {bid:,}원이 목표가격보다 낮아 주문을 보류합니다.')
            break
        # Final broker-side guard immediately before transmission.  This catches
        # HTS/MTS manual sells and any other open sell orders that appeared since
        # the strategy condition was triggered.
        pre=_auto_sell_account_guard(code_,force=True)
        safe_pre=int(pre.get('safe_available') or 0)
        if safe_pre<=0:
            if int(pre.get('qty') or 0)<=0:
                remaining=0
            break
        remaining=min(remaining,safe_pre)
        if remaining<=0: break
        before_qty=int(pre.get('qty') or 0)
        res=_auto_sell_submit_limit(code_,remaining,bid,f'{stage.get("key")}-{attempt}')
        order_no=str(res.get('order_no') or '')
        order_nos.append(order_no)
        total_submitted+=remaining
        # Wait briefly for the broker's unfilled-order feed.  A missing order is
        # never interpreted as fully filled because doing so could duplicate-sell.
        found=False;rem=None
        for _ in range(3):
            time.sleep(0.45)
            if order_no:
                found,rem=_auto_sell_remaining_for_order(order_no,code_)
                if found: break
        post=_auto_sell_account_guard(code_,force=True)
        after_qty=int(post.get('qty') or 0)
        if found:
            if int(rem or 0)<=0:
                remaining=0
                break
            _auto_sell_cancel_order(order_no,code_,int(rem or 0))
            time.sleep(0.35)
            post=_auto_sell_account_guard(code_,force=True)
            remaining=min(int(rem or 0),max(0,int(post.get('safe_available') or 0)))
        else:
            # If holdings clearly fell, count only that observed reduction as fill.
            observed_fill=max(0,min(remaining,before_qty-after_qty))
            if observed_fill>0:
                remaining=max(0,remaining-observed_fill)
            # Status still missing: stop here.  Do not issue another order until the
            # next strategy retry, preventing duplicate orders while broker status lags.
            if remaining>0:
                with AUTO_SELL_LOCK:
                    stage['status_uncertain']=True
                    stage['last_remaining']=remaining
                    stage['running']=False
                    AUTO_SELL_STATE['active']=False
                    AUTO_SELL_STATE['last_message']='주문 상태 확인이 지연되어 중복매도 방지를 위해 자동매도를 안전 중지했습니다. 미체결을 확인 후 다시 시작해 주세요.'
                    AUTO_SELL_STATE['updated_at']=datetime.now(KST).isoformat()
                return

    sold_est=max(0,target_qty-remaining)
    with AUTO_SELL_LOCK:
        # A stage is considered complete after its submitted target is no longer unfilled.
        # If a remainder persists because bid fell below threshold, leave it pending for retry.
        if remaining<=0:
            stage.update(done=True,ok=True,running=False,sold_qty=target_qty,order_nos=order_nos,error='')
            AUTO_SELL_STATE['last_message']=f'{stage.get("label")} 매도 처리 · {name_} {target_qty:,}주'
            _auto_sell_event('profit',f'{stage.get("label")} 익절 완료 · {target_qty:,}주',target_qty)
        else:
            stage.update(done=False,ok=False,running=False,last_remaining=remaining,order_nos=order_nos)
            AUTO_SELL_STATE['last_message']=f'{stage.get("label")} 미체결 {remaining:,}주 · 목표가 아래에서는 추적 대기'
        AUTO_SELL_STATE['updated_at']=datetime.now(KST).isoformat()

def _auto_sell_execute_stop(reason, ratio=100.0, trigger_keys=None):
    """Execute one stop action against the fresh broker-side sellable remainder.

    The first of the two stop conditions sells its allocated percentage of the actual
    remainder. When the other stop condition later fires, the worker passes 100% so the
    then-current remainder is liquidated. Fresh broker quantities automatically reflect
    intervening HTS/MTS manual sells. Market orders are never used.
    """
    trigger_keys=list(trigger_keys or [])
    try:
        ratio=max(1.0,min(100.0,float(ratio)))
    except Exception:
        ratio=100.0
    with AUTO_SELL_LOCK:
        if not AUTO_SELL_STATE.get('active'):
            return
        code_=str(AUTO_SELL_STATE.get('code') or '')
        name_=str(AUTO_SELL_STATE.get('name') or code_)
        AUTO_SELL_STATE['stop_triggered']=True
        AUTO_SELL_STATE['stop_running']=True
        AUTO_SELL_STATE['stop_reason']=str(reason or '손절')
        AUTO_SELL_STATE['last_message']=f'{reason} 발동 · 잔량의 {ratio:g}% 손절 준비 중…'
        AUTO_SELL_STATE['updated_at']=datetime.now(KST).isoformat()
    try:
        guard=_auto_sell_account_guard(code_,force=True)
        qty=int(guard.get('qty') or 0)
        avail=int(guard.get('safe_available') or 0)
        open_sell=int(guard.get('open_sell_qty') or 0)
        with AUTO_SELL_LOCK:
            AUTO_SELL_STATE['account_qty']=qty
            AUTO_SELL_STATE['available_quantity']=avail
            AUTO_SELL_STATE['open_sell_qty']=open_sell
        if qty<=0:
            with AUTO_SELL_LOCK:
                AUTO_SELL_STATE['active']=False
                AUTO_SELL_STATE['stop_running']=False
                AUTO_SELL_STATE['last_message']=f'{reason} 완료 · 보유수량 0주'
                _auto_sell_event('stop',f'{reason} 완료 · 보유수량 0주',0)
                for k in trigger_keys:
                    AUTO_SELL_STATE[f'{k}_stop_done']=True
                AUTO_SELL_STATE['updated_at']=datetime.now(KST).isoformat()
            return
        if open_sell>0:
            raise ValueError(f'기존 미체결 매도 {open_sell:,}주가 있어 손절 주문을 대기합니다.')
        if avail<=0:
            raise ValueError('현재 매도가능 수량이 없어 손절 주문을 대기합니다.')

        target_qty=avail if ratio>=99.999 else max(1,int(avail*ratio/100.0))
        target_qty=min(avail,target_qty)
        remaining=target_qty
        for attempt in range(1,7):
            if remaining<=0:
                break
            pre=_auto_sell_account_guard(code_,force=True)
            safe_pre=int(pre.get('safe_available') or 0)
            if int(pre.get('open_sell_qty') or 0)>0:
                raise ValueError(f'기존 미체결 매도 {int(pre.get("open_sell_qty") or 0):,}주가 있어 손절 주문을 대기합니다.')
            if int(pre.get('qty') or 0)<=0:
                remaining=0
                break
            remaining=min(remaining,safe_pre)
            if remaining<=0:
                break
            _book,_cur,bid=_auto_sell_book(_manual_order_client(),code_)
            if bid<=0:
                raise ValueError('최우선 매수호가를 확인할 수 없습니다.')
            before_qty=int(pre.get('qty') or 0)
            res=_auto_sell_submit_limit(code_,remaining,bid,f'stop-{attempt}')
            order_no=str(res.get('order_no') or '')
            found=False;rem=None
            for _ in range(3):
                time.sleep(0.45)
                if order_no:
                    found,rem=_auto_sell_remaining_for_order(order_no,code_)
                    if found:
                        break
            post=_auto_sell_account_guard(code_,force=True)
            after_qty=int(post.get('qty') or 0)
            if found:
                if int(rem or 0)<=0:
                    remaining=0
                    break
                _auto_sell_cancel_order(order_no,code_,int(rem or 0))
                time.sleep(0.35)
                post=_auto_sell_account_guard(code_,force=True)
                remaining=min(int(rem or 0),max(0,int(post.get('safe_available') or 0)))
            else:
                sold=max(0,before_qty-after_qty)
                if sold>0:
                    remaining=max(0,remaining-sold)
                else:
                    with AUTO_SELL_LOCK:
                        AUTO_SELL_STATE['active']=False
                        AUTO_SELL_STATE['stop_running']=False
                        AUTO_SELL_STATE['last_message']='손절 주문 상태 확인이 지연되어 중복매도 방지를 위해 자동매도를 안전 중지했습니다. 미체결을 확인 후 다시 시작해 주세요.'
                        AUTO_SELL_STATE['updated_at']=datetime.now(KST).isoformat()
                    return

        final_guard=_auto_sell_account_guard(code_,force=True)
        final_qty=int(final_guard.get('qty') or 0)
        completed=remaining<=0
        with AUTO_SELL_LOCK:
            AUTO_SELL_STATE['account_qty']=final_qty
            AUTO_SELL_STATE['available_quantity']=int(final_guard.get('safe_available') or 0)
            AUTO_SELL_STATE['open_sell_qty']=int(final_guard.get('open_sell_qty') or 0)
            AUTO_SELL_STATE['stop_running']=False
            if completed:
                for k in trigger_keys:
                    AUTO_SELL_STATE[f'{k}_stop_done']=True
            if final_qty<=0:
                AUTO_SELL_STATE['active']=False
                AUTO_SELL_STATE['last_message']=f'{reason} 완료 · {name_} 전량 정리'
                _auto_sell_event('stop',f'{reason} 완료 · 전량 정리',target_qty)
            elif completed:
                AUTO_SELL_STATE['stop_triggered']=False
                AUTO_SELL_STATE['last_message']=f'{reason} 완료 · 잔량의 {ratio:g}% 손절 · 남은 보유 {final_qty:,}주 계속 감시'
                _auto_sell_event('stop',f'{reason} 완료 · {target_qty:,}주 손절 · 잔량 {final_qty:,}주',target_qty)
            else:
                AUTO_SELL_STATE['stop_triggered']=False
                AUTO_SELL_STATE['last_message']=f'{reason} 진행 · 목표 {target_qty:,}주 중 미처리 {remaining:,}주 재감시'
            AUTO_SELL_STATE['updated_at']=datetime.now(KST).isoformat()
    except Exception:
        with AUTO_SELL_LOCK:
            AUTO_SELL_STATE['stop_running']=False
            AUTO_SELL_STATE['stop_triggered']=False
        raise

def _auto_sell_worker_one():
    due=None
    stop_reason=None
    try:
        with AUTO_SELL_LOCK:
            active=bool(AUTO_SELL_STATE.get('active'))
            code_=str(AUTO_SELL_STATE.get('code') or '')
            avg=float(AUTO_SELL_STATE.get('avg_price') or 0)
        if active and code_ and avg>0:
            guard=_auto_sell_account_guard(code_,force=True)
            holding=guard.get('holding')
            if not holding or int(guard.get('qty') or 0)<=0:
                with AUTO_SELL_LOCK:
                    AUTO_SELL_STATE['active']=False
                    AUTO_SELL_STATE['available_quantity']=0
                    AUTO_SELL_STATE['account_qty']=0
                    AUTO_SELL_STATE['last_message']='실제 보유수량이 0주라 자동매도를 종료했습니다.'
                    AUTO_SELL_STATE['updated_at']=datetime.now(KST).isoformat()
            else:
                current=float(holding.get('current_price') or 0)
                if current<=0:
                    try:
                        _b,current,_bid=_auto_sell_book(_manual_order_client(),code_)
                    except Exception:current=0
                pct=((current/avg)-1.0)*100.0 if current>0 else -999.0
                now=datetime.now(KST)
                with AUTO_SELL_LOCK:
                    AUTO_SELL_STATE['current_price']=current
                    AUTO_SELL_STATE['profit_pct']=round(pct,4) if current>0 else None
                    AUTO_SELL_STATE['account_qty']=int(guard.get('qty') or 0)
                    AUTO_SELL_STATE['available_quantity']=int(guard.get('safe_available') or 0)
                    AUTO_SELL_STATE['open_sell_qty']=int(guard.get('open_sell_qty') or 0)
                    last_qty=AUTO_SELL_STATE.get('last_seen_qty')
                    if last_qty is not None and int(guard.get('qty') or 0)<int(last_qty):
                        AUTO_SELL_STATE['last_external_change']=f'계좌 보유수량 변경 감지 · {int(last_qty):,}주 → {int(guard.get("qty") or 0):,}주'
                    AUTO_SELL_STATE['last_seen_qty']=int(guard.get('qty') or 0)

                    # Two-step stop plan. The first stop condition to arrive sells its
                    # allocated share of the fresh broker-side remainder. The other stop,
                    # when it later arrives, liquidates the then-current remainder. If both
                    # conditions arrive on the same tick, both are satisfied and the current
                    # remainder is liquidated once. Fresh quantity already reflects manual sells.
                    stop_ratio=None
                    stop_keys=[]
                    reasons=[]
                    loss_enabled=bool(AUTO_SELL_STATE.get('loss_stop_enabled'))
                    time_enabled=bool(AUTO_SELL_STATE.get('time_stop_enabled'))
                    loss_done=bool(AUTO_SELL_STATE.get('loss_stop_done'))
                    time_done=bool(AUTO_SELL_STATE.get('time_stop_done'))
                    if loss_enabled and not loss_done and current>0:
                        limit=float(AUTO_SELL_STATE.get('loss_stop_pct') or -4.0)
                        if pct<=limit+1e-9:
                            reasons.append(f'등락률 손절 {limit:g}%')
                            stop_keys.append('loss')
                    if time_enabled and not time_done:
                        t=str(AUTO_SELL_STATE.get('time_stop') or '10:00')
                        if now.strftime('%H:%M')>=t:
                            reasons.append(f'시간손절 {t}')
                            stop_keys.append('time')
                    if reasons:
                        prior_done=loss_done or time_done
                        if len(stop_keys)>=2 or prior_done:
                            stop_ratio=100.0
                        elif stop_keys[0]=='loss':
                            stop_ratio=float(AUTO_SELL_STATE.get('loss_stop_ratio') if AUTO_SELL_STATE.get('loss_stop_ratio') is not None else 50.0)
                            if not time_enabled:
                                stop_ratio=100.0
                        else:
                            stop_ratio=float(AUTO_SELL_STATE.get('time_stop_ratio') if AUTO_SELL_STATE.get('time_stop_ratio') is not None else 50.0)
                            if not loss_enabled:
                                stop_ratio=100.0
                        stop_reason=' + '.join(reasons)
                        AUTO_SELL_STATE['stop_reason']=stop_reason

                    if not stop_reason:
                        for st in AUTO_SELL_STATE.get('stages') or []:
                            if st.get('done') or st.get('running'): continue
                            if pct+1e-9>=float(st.get('pct') or 0):
                                st['running']=True
                                AUTO_SELL_STATE['last_message']=f'{st.get("label")} 도달 · 지정가 매도 준비 중…'
                                AUTO_SELL_STATE['updated_at']=datetime.now(KST).isoformat()
                                due=st;break
        if stop_reason is not None:
            try:
                _auto_sell_execute_stop(stop_reason,stop_ratio or 100.0,stop_keys)
                with AUTO_SELL_LOCK:
                    if AUTO_SELL_STATE.get('active'):
                        pending_stop=bool((AUTO_SELL_STATE.get('loss_stop_enabled') and not AUTO_SELL_STATE.get('loss_stop_done')) or (AUTO_SELL_STATE.get('time_stop_enabled') and not AUTO_SELL_STATE.get('time_stop_done')))
                        unfinished_profit=any(not bool(st.get('done')) for st in (AUTO_SELL_STATE.get('stages') or []))
                        if not pending_stop and not unfinished_profit:
                            AUTO_SELL_STATE['active']=False
                            AUTO_SELL_STATE['last_message']=(AUTO_SELL_STATE.get('last_message') or '손절 처리 완료')+' · 설정 전략 종료'
                            AUTO_SELL_STATE['updated_at']=datetime.now(KST).isoformat()
            except Exception as e:
                with AUTO_SELL_LOCK:
                    AUTO_SELL_STATE['stop_running']=False
                    AUTO_SELL_STATE['last_message']=f'{stop_reason} 대기 · {str(e)[:170]}'
                    AUTO_SELL_STATE['updated_at']=datetime.now(KST).isoformat()
        elif due is not None:
            try:
                _auto_sell_execute_stage(due)
                with AUTO_SELL_LOCK:
                    stages_now=AUTO_SELL_STATE.get('stages') or []
                    stop_watch=bool((AUTO_SELL_STATE.get('loss_stop_enabled') and not AUTO_SELL_STATE.get('loss_stop_done')) or (AUTO_SELL_STATE.get('time_stop_enabled') and not AUTO_SELL_STATE.get('time_stop_done')))
                    if AUTO_SELL_STATE.get('active') and not AUTO_SELL_STATE.get('liquidate_remainder') and stages_now and all(bool(st.get('done')) for st in stages_now):
                        if stop_watch:
                            AUTO_SELL_STATE['last_message']='설정한 익절 단계 완료 · 남은 수량은 손절 조건 계속 감시'
                        else:
                            AUTO_SELL_STATE['active']=False
                            AUTO_SELL_STATE['last_message']='설정한 자동매도 단계가 모두 완료되었습니다 · 남은 수량은 보유 유지합니다.'
                        AUTO_SELL_STATE['updated_at']=datetime.now(KST).isoformat()
            except Exception as e:
                with AUTO_SELL_LOCK:
                    due['running']=False
                    due['error']=str(e)[:220]
                    AUTO_SELL_STATE['last_message']=f'{due.get("label")} 대기 · {str(e)[:170]}'
                    AUTO_SELL_STATE['updated_at']=datetime.now(KST).isoformat()
    except Exception as e:
        with AUTO_SELL_LOCK:
            if AUTO_SELL_STATE.get('active'):
                AUTO_SELL_STATE['last_message']=f'자동매도 감시 오류 · {str(e)[:170]}'
                AUTO_SELL_STATE['updated_at']=datetime.now(KST).isoformat()


def _auto_sell_worker():
    while True:
        with AUTO_SELL_LOCK:
            codes=list(AUTO_SELL_STRATEGIES.keys())
        for c in codes:
            try:
                AUTO_SELL_CONTEXT.key=c
                _auto_sell_worker_one()
            finally:
                AUTO_SELL_CONTEXT.key=None
        time.sleep(0.35)

def _ensure_auto_sell_thread():
    global AUTO_SELL_THREAD
    with AUTO_SELL_LOCK:
        if AUTO_SELL_THREAD is None or not AUTO_SELL_THREAD.is_alive():
            AUTO_SELL_THREAD=threading.Thread(target=_auto_sell_worker,name='litto-auto-sell',daemon=True)
            AUTO_SELL_THREAD.start()

def auto_sell_start(payload):
    client=_manual_order_client()
    c=base_code(payload.get('code'))
    if not c: raise ValueError('종목코드가 필요합니다.')
    AUTO_SELL_CONTEXT.key=c
    guard=_auto_sell_account_guard(c,force=True)
    holding=guard.get('holding')
    if not holding: raise ValueError('계좌에 보유 중인 종목만 자동매도를 시작할 수 있습니다.')
    qty=int(guard.get('qty') or 0)
    avail=int(guard.get('safe_available') or 0)
    avg=float(holding.get('avg_price') or 0)
    if qty<=0 or avail<=0: raise ValueError('매도가능 보유수량이 없습니다.')
    if avg<=0: raise ValueError('평균매입가를 확인할 수 없습니다.')
    raw=payload.get('stages') or []
    stages=[]
    allowed={0.0:'본절',1.0:'+1%',2.0:'+2%',3.0:'+3%',4.0:'+4%'}
    for x in raw:
        if not isinstance(x,dict) or not bool(x.get('enabled')): continue
        pct=float(x.get('pct') or 0)
        if pct not in allowed: continue
        ratio=max(0.0,min(100.0,float(x.get('ratio') or 0)))
        stages.append({'key':str(x.get('key') or pct),'pct':pct,'label':allowed[pct],'ratio':ratio,'done':False,'ok':False,'running':False})
    stages.sort(key=lambda x:x['pct'])

    stop_master=bool(payload.get('stop_master'))
    loss_stop_enabled=stop_master and bool(payload.get('loss_stop_enabled'))
    time_stop_enabled=stop_master and bool(payload.get('time_stop_enabled'))
    try: loss_stop_pct=float(payload.get('loss_stop_pct') if payload.get('loss_stop_pct') is not None else -4.0)
    except Exception: raise ValueError('등락률 손절값을 확인해 주세요.')
    if loss_stop_enabled and not (-30.0<=loss_stop_pct<=-0.1):
        raise ValueError('등락률 손절은 -30.0% ~ -0.1% 사이로 설정해 주세요.')
    try: loss_stop_ratio=float(payload.get('loss_stop_ratio') if payload.get('loss_stop_ratio') is not None else 50.0)
    except Exception: raise ValueError('등락률 손절 비중을 확인해 주세요.')
    if loss_stop_enabled and not (0.0<=loss_stop_ratio<=100.0):
        raise ValueError('등락률 손절 비중은 0% ~ 100%로 설정해 주세요.')
    time_stop=str(payload.get('time_stop') or '10:00').strip()
    if time_stop_enabled:
        try:
            hh,mm=map(int,time_stop.split(':'))
            if not (0<=hh<=23 and 0<=mm<=59): raise ValueError
            time_stop=f'{hh:02d}:{mm:02d}'
        except Exception:
            raise ValueError('시간손절 시간을 HH:MM 형식으로 설정해 주세요.')
    try: time_stop_ratio=float(payload.get('time_stop_ratio') if payload.get('time_stop_ratio') is not None else 50.0)
    except Exception: raise ValueError('시간손절 비중을 확인해 주세요.')
    if time_stop_enabled and not (0.0<=time_stop_ratio<=100.0):
        raise ValueError('시간손절 비중은 0% ~ 100%로 설정해 주세요.')
    if loss_stop_enabled and time_stop_enabled:
        if not (1.0<=loss_stop_ratio<=99.0 and 1.0<=time_stop_ratio<=99.0):
            raise ValueError('두 손절을 함께 사용할 때 각 비중은 1% ~ 99%로 설정해 주세요.')
        if abs((loss_stop_ratio+time_stop_ratio)-100.0)>1e-6:
            raise ValueError('등락률 손절과 시간손절 비중의 합계는 100%여야 합니다.')
    if stop_master and not (loss_stop_enabled or time_stop_enabled):
        raise ValueError('손절 ON 상태에서는 등락률 손절 또는 시간손절을 하나 이상 켜 주세요.')
    if not stages and not (loss_stop_enabled or time_stop_enabled):
        raise ValueError('익절 단계 또는 손절 조건을 하나 이상 설정해 주세요.')

    liquidate_remainder=bool(payload.get('liquidate_remainder',True))
    if stages:
        # If liquidate_remainder is ON, the highest enabled stage liquidates the
        # actual broker-side remainder. Earlier stages are percentages of the
        # initial holding and must total below 100%.
        if liquidate_remainder:
            alloc_stages=stages[:-1]
            prior_sum=sum(float(st.get('ratio') or 0) for st in alloc_stages)
            if any(float(st.get('ratio') or 0)<=0 for st in alloc_stages):
                raise ValueError('최종 단계 이전의 매도비율은 1% 이상이어야 합니다.')
            if prior_sum>=100.0:
                raise ValueError(f'최종 단계 전 배분 합계가 {prior_sum:g}%입니다. 100% 미만으로 조정해 주세요.')
            stages[-1]['final']=True
            for st in stages[:-1]: st['final']=False
        else:
            total_sum=sum(float(st.get('ratio') or 0) for st in stages)
            if any(float(st.get('ratio') or 0)<=0 for st in stages):
                raise ValueError('체크한 단계의 매도비율은 1% 이상이어야 합니다.')
            if total_sum>100.0:
                raise ValueError(f'선택 단계 배분 합계가 {total_sum:g}%입니다. 100% 이하로 조정해 주세요.')
            for st in stages: st['final']=False

    with AUTO_SELL_LOCK:
        if AUTO_SELL_STATE.get('active'):
            AUTO_SELL_CONTEXT.key=None
            raise ValueError('이 종목은 이미 자동매도 전략이 실행 중입니다. 먼저 중지해 주세요.')
        AUTO_SELL_STATE.clear()
        AUTO_SELL_STATE.update({
            'active':True,'code':c,'name':str(payload.get('name') or holding.get('name') or c),
            'mode':'모의계좌' if bool(getattr(client,'mock',False)) else '실전계좌',
            'initial_qty':qty,'account_qty':qty,'last_seen_qty':qty,'available_quantity':avail,
            'open_sell_qty':int(guard.get('open_sell_qty') or 0),'avg_price':avg,'stages':stages,'liquidate_remainder':liquidate_remainder,
            'loss_stop_enabled':loss_stop_enabled,'loss_stop_pct':loss_stop_pct,'loss_stop_ratio':loss_stop_ratio,'loss_stop_done':False,
            'time_stop_enabled':time_stop_enabled,'time_stop':time_stop,'time_stop_ratio':time_stop_ratio,'time_stop_done':False,
            'stop_triggered':False,'stop_running':False,'stop_reason':'',
            'started_at':datetime.now(KST).isoformat(),'updated_at':datetime.now(KST).isoformat(),
            'last_message':'자동매도 감시 시작 · 익절/손절 조건 동시 감시','event_log':[]
        })
        _auto_sell_event('start',f'자동매도 감시 시작 · {AUTO_SELL_STATE.get("name")} {qty:,}주')
    AUTO_SELL_CONTEXT.key=None
    _ensure_auto_sell_thread()
    return _auto_sell_public_state(c)

def auto_sell_cancel(payload=None):
    c=base_code((payload or {}).get('code') or '')
    with AUTO_SELL_LOCK:
        if not c:
            active=[k for k,v in AUTO_SELL_STRATEGIES.items() if v.get('active')]
            c=active[0] if len(active)==1 else ''
        if not c or c not in AUTO_SELL_STRATEGIES:
            raise ValueError('중지할 자동매도 종목을 선택해 주세요.')
        AUTO_SELL_CONTEXT.key=c
        st=AUTO_SELL_STRATEGIES[c]
        if st.get('stop_running') or any(x.get('running') for x in (st.get('stages') or [])):
            AUTO_SELL_CONTEXT.key=None
            raise ValueError('매도 주문 처리 중에는 중지할 수 없습니다. 잠시 후 다시 시도하세요.')
        st['active']=False
        st['last_message']='자동매도 전략을 중지했습니다.'
        _auto_sell_event('end','사용자 중지 · 자동매도 전략 종료')
        st['updated_at']=datetime.now(KST).isoformat()
        AUTO_SELL_CONTEXT.key=None
    try:manual_order_arm({'armed':False})
    except Exception:pass
    return _auto_sell_public_state(c)

def auto_sell_cancel_all(payload=None):
    """Stop all idle auto-sell monitors; never cancel accepted sell orders."""
    canceled=[]; blocked=[]
    now=datetime.now(KST).isoformat()
    with AUTO_SELL_LOCK:
        for c,st in AUTO_SELL_STRATEGIES.items():
            if not st.get('active'):
                continue
            if st.get('stop_running') or any(x.get('running') for x in (st.get('stages') or [])):
                blocked.append({'code':c,'name':st.get('name') or c,'reason':'매도 주문 처리 중'})
                continue
            AUTO_SELL_CONTEXT.key=c
            st['active']=False
            st['last_message']='일괄취소 · 자동매도 감시를 중지했습니다.'
            _auto_sell_event('end','사용자 일괄취소 · 자동매도 전략 종료')
            st['updated_at']=now
            canceled.append({'code':c,'name':st.get('name') or c})
        AUTO_SELL_CONTEXT.key=None
    try:manual_order_arm({'armed':False})
    except Exception:pass
    out=_auto_sell_public_state('')
    out['batch_cancel']={'canceled':canceled,'blocked':blocked,'canceled_count':len(canceled),'blocked_count':len(blocked)}
    out['last_message']=(f'자동매도 일괄취소 {len(canceled)}종목 완료'+(f' · 주문 처리 중 {len(blocked)}종목 제외' if blocked else ''))
    return out


# R17 orderbook delivery outliers: local UI telemetry only, no provider calls.
OB_DELIVERY_LOCK=threading.Lock()
OB_DELIVERY_EVENTS=[]

def _ob_delivery_snapshot():
    with OB_DELIVERY_LOCK:
        return {'events':list(OB_DELIVERY_EVENTS[-30:]),'count':len(OB_DELIVERY_EVENTS),
                'note':'Browser-side outliers only. This does not imply missing provider executions.'}

class Handler(BaseHTTPRequestHandler):
    def log_message(self,*args):pass
    def respond(self,status,data,ctype='application/json; charset=utf-8',attachment=None):
        if isinstance(data,(dict,list)):data=json.dumps(data,ensure_ascii=False,allow_nan=False)
        if isinstance(data,str):data=data.encode('utf-8')
        self.send_response(status);self.send_header('Content-Type',ctype)
        self.send_header('Content-Length',str(len(data)))
        self.send_header('Cache-Control','no-store');self.send_header('X-Content-Type-Options','nosniff')
        self.send_header('X-Frame-Options','DENY');self.send_header('Referrer-Policy','no-referrer')
        self.send_header('Content-Security-Policy',"default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline'; img-src 'self' data:; connect-src 'self'; frame-ancestors 'none'; base-uri 'none'")
        if attachment:self.send_header('Content-Disposition','attachment; filename="'+attachment+'"')
        try:
            self.end_headers();self.wfile.write(data)
        except (BrokenPipeError,ConnectionAbortedError,ConnectionResetError):
            # The desktop/webview may close or navigate while a response is being
            # written.  This is a normal client-side disconnect, not a backend
            # failure; suppress the noisy traceback and release the worker thread.
            return

    def trusted(self):
        expected=f'127.0.0.1:{self.server.server_port}'
        return self.headers.get('Host')==expected and self.headers.get('Origin') in (None,'http://'+expected)

    def do_GET(self):
        if not self.trusted():return self.respond(403,{'error':'로컬 주소로 접속하세요.'})
        path=urlparse(self.path).path
        if path=='/api/ai-pdf-list':return self.respond(200,litto_pdf_knowledge.listing())
        if path=='/api/ai-pdf-audit':return self.respond(200,litto_pdf_knowledge.audit())
        if path=='/api/ai-learning-status':return self.respond(200,litto_ai_growth.status())
        if path=='/api/ai-reflection-list':return self.respond(200,{'ok':True,'items':litto_ai_growth.recent('',12)})
        if path=='/api/ai-auto-journal-status':return self.respond(200,litto_ai_growth.auto_status(12))
        if path=='/api/state':return self.respond(200,snapshot())
        if path=='/api/api-gate-diagnostics':return self.respond(200,{'api_gate':_api_gate_status(),'note':'Read-only counters; a blocked provider call is not forcibly cancelled.'})
        if path=='/api/scan-diagnostics':return self.respond(200,{'scan':_scan_trace_snapshot(),'note':'Read-only scan milestones. Phase age alone is not a proof of deadlock.'})
        if path=='/api/orderbook-delivery-diagnostics':return self.respond(200,_ob_delivery_snapshot())
        if path=='/api/orderbook-diagnostics':
            with LOCK: client=STATE.get('client')
            feed=getattr(client,'_domestic_orderbook_feed',None) if client else None
            return self.respond(200,{'orderbook':feed.diagnostics() if feed else None,
                                    'note':'Read-only in-memory receive intervals. No extra provider calls.'})
        if path=='/auth/callback':
            try:
                q=parse_qs(urlparse(self.path).query); p=siwc_callback(q)
                html='''<!doctype html><meta charset="utf-8"><title>LITTO ChatGPT 연결</title><style>body{font-family:system-ui;background:#0b1020;color:#eef2ff;display:grid;place-items:center;height:100vh;margin:0}.c{max-width:560px;padding:32px;border:1px solid #334155;border-radius:18px;background:#111827}b{font-size:24px}p{line-height:1.6;color:#cbd5e1}</style><div class="c"><b>✓ ChatGPT 연결 완료</b><p>LITTO에서 ChatGPT 플랜 사용 권한이 연결됐어.<br>이 창은 닫고 라이또로 돌아가면 돼.</p></div>'''
                return self.respond(200,html,'text/html; charset=utf-8')
            except Exception as e:
                html='''<!doctype html><meta charset="utf-8"><title>LITTO ChatGPT 연결 실패</title><body style="font-family:system-ui;background:#111827;color:white;padding:40px"><h2>연결 실패</h2><p>'''+str(e).replace('&','&amp;').replace('<','&lt;')+'''</p><p>라이또로 돌아가 다시 시도해줘.</p></body>'''
                return self.respond(400,html,'text/html; charset=utf-8')
        if path=='/api/newheart-jongba/v4/history':
            return self.respond(200,litto_newheart_jongba_v4.history())
        if path=='/api/newheart-jongba/history':
            return self.respond(200,litto_newheart_jongba_v3.history())
        if path=='/api/ai-generated-image':
            name=(parse_qs(urlparse(self.path).query).get('name') or [''])[0]
            if not re.fullmatch(r'LITTO_AI_[0-9]{8}_[0-9]{6}_[0-9a-f]{8}\.png',name):
                return self.respond(400,{'error':'이미지 이름이 올바르지 않습니다.'})
            f=ROOT/'data'/'ai_generated_images'/name
            if not f.is_file():return self.respond(404,{'error':'이미지가 없습니다.'})
            return self.respond(200,f.read_bytes(),'image/png')
        if path=='/api/litto-diagnostics':
            qs=parse_qs(urlparse(self.path).query)
            kind=(qs.get('kind') or ['prior'])[0]
            stock=(qs.get('code') or [''])[0]
            try:return self.respond(200,_litto_three_diagnostics(kind,stock))
            except Exception as e:return self.respond(400,{'error':str(e)})
        if path=='/api/litto-image-status':return self.respond(200,_litto_image_status())
        if path=='/api/ai-siwc-status':return self.respond(200,siwc_status(load_models=parse_qs(urlparse(self.path).query).get('models',['0'])[0]=='1'))
        if path=='/api/ai-brain-status':return self.respond(200,ai_brain.status())
        if path=='/api/ai-progress':return self.respond(200,_ai_progress_get(parse_qs(urlparse(self.path).query).get('id',[''])[0]))
        if path=='/api/ai-dev/proposals':return self.respond(200,litto_ai_developer.recent(ROOT))
        if path=='/api/gemini-status':return self.respond(200,litto_gemini.key_status())
        if path=='/api/ai-config':return self.respond(200,siwc_status())
        if path=='/api/top5-performance':
            return self.respond(200,top5_performance_snapshot())
        if path=='/api/littobot-performance':
            return self.respond(200,littobot_performance_snapshot())
        if path=='/api/littobot-evolve/status':
            perf=littobot_performance_snapshot()
            return self.respond(200,ai_evolve.status(perf,auto_propose=True))
        if path=='/api/intraday-market-flow-history':
            return self.respond(200,intraday_market_flow_history_snapshot())
        if path=='/api/littobot-performance-refresh':
            try:
                qs=parse_qs(urlparse(self.path).query); max_days=int((qs.get('max_days') or ['5'])[0] or 5)
                return self.respond(200,littobot_performance_refresh(max_days=max_days))
            except Exception as e:return self.respond(400,{'error':str(e)})
        if path=='/api/top5-performance-refresh':
            qs=parse_qs(urlparse(self.path).query)
            try:max_days=int((qs.get('max_days') or ['5'])[0] or 5)
            except Exception:max_days=5
            try:return self.respond(200,top5_performance_refresh_results(max_days=max_days))
            except (ValueError,ApiError) as e:return self.respond(400,{'error':str(e)})
        if path=='/api/account-status':
            force=parse_qs(urlparse(self.path).query).get('force',['0'])[0]=='1'
            return self.respond(200,account_status_snapshot(force=force))
        if path=='/api/account-daily-pnl':
            qs=parse_qs(urlparse(self.path).query)
            y=(qs.get('year') or [''])[0];m=(qs.get('month') or [''])[0]
            force=(qs.get('force') or ['0'])[0]=='1'
            try:return self.respond(200,account_daily_pnl_snapshot(y,m,force=force))
            except (ValueError,ApiError) as e:return self.respond(400,{'error':str(e)})
        if path=='/api/robot-reservations':
            return self.respond(200,robot_reservations.list_orders())
        if path=='/api/auto-buy/status':
            qs=parse_qs(urlparse(self.path).query);c=(qs.get('code') or [''])[0]
            return self.respond(200,_auto_buy_public_state(c))
        if path=='/api/auto-sell/status':
            qs=parse_qs(urlparse(self.path).query);c=(qs.get('code') or [''])[0]
            return self.respond(200,_auto_sell_public_state(c))
        if path=='/api/night-futures':
            return self.respond(200,night_futures.snapshot())
        if path=='/api/page1-diagnostic':
            with LOCK:
                ranks=copy.deepcopy(STATE.get('ranks') or {})
                report=copy.deepcopy(STATE.get('report') or {})
            diag_rows=(((report.get('search_panels') or {}).get('panels') or {}).get('검색 진단') or {}).get('rows',[])
            return self.respond(200,{'at':datetime.now(KST).isoformat(),'live':page1_live_status(),
                                     'rank_source':ranks.get('source'),'value_top':(ranks.get('value_top') or [])[:50],
                                     'change_top':(ranks.get('change_top') or [])[:100],
                                     'search_diagnostic':diag_rows[:80]})
        if path=='/api/orderbook-mini-chart':
            qs=parse_qs(urlparse(self.path).query)
            c=base_code((qs.get('code') or [''])[0])
            tf=str((qs.get('tf') or ['3'])[0]).strip().lower()
            if not c:
                return self.respond(400,{'error':'종목코드가 필요합니다.'})
            if tf not in ('1','3','15','daily'):
                return self.respond(400,{'error':'지원 봉은 1분·3분·15분·일봉입니다.'})
            with LOCK:
                client=STATE.get('client')
            if not client:
                return self.respond(409,{'error':'키움 API 연결이 필요합니다.'})

            now=time.time()
            cache_key=(c,tf)
            ttl=120.0 if tf=='daily' else 25.0
            with ORDERBOOK_CHART_CACHE_LOCK:
                cached=ORDERBOOK_CHART_CACHE.get(cache_key)
                if cached and now-float(cached.get('ts') or 0)<ttl:
                    payload=copy.deepcopy(cached.get('data') or {})
                    payload['cached']=True
                    return self.respond(200,payload)

            try:
                if tf=='daily':
                    raw=_kiwoom_call(client.daily_history_rows,c,150,kind='chart')
                    bars=[daily_bar(r) for r in raw]
                    bars.sort(key=lambda x:x.get('date',''))
                    bars=bars[-120:]
                else:
                    minutes=int(tf)
                    # Performance-first: one SOR(_AL) history request only.
                    # F-zone levels themselves come from the already-computed scanner state;
                    # do not run the heavy F-zone engine or a second NXT history request here.
                    provider=c if bool(getattr(client,'mock',False)) else c+'_AL'
                    raw=_kiwoom_call(
                        client.rows,'ka10080',
                        {'stk_cd':provider,'tic_scope':str(minutes),'upd_stkpc_tp':'1'},
                        'stk_min_pole_chart_qry',360,4,kind='chart'
                    )
                    stamp=datetime.now(KST)
                    merged={}
                    for r in raw:
                        key=str(r.get('cntr_tm') or '')
                        if key:
                            parsed=minute_bar(r,stamp,minutes)
                            if isinstance(parsed,dict):
                                merged[key]=parsed
                    bars=sorted(merged.values(),key=lambda x:x.get('time',''))[-300:]

                payload={
                    'code':c,'tf':tf,'bars':bars,'count':len(bars),
                    'updated_at':datetime.now(KST).isoformat(),
                    'source':'키움 ka10081 SOR' if tf=='daily' else '키움 ka10080 SOR(_AL)',
                    'cached':False,
                }
                with ORDERBOOK_CHART_CACHE_LOCK:
                    ORDERBOOK_CHART_CACHE[cache_key]={'ts':now,'data':copy.deepcopy(payload)}
                return self.respond(200,payload)
            except Exception as e:
                with ORDERBOOK_CHART_CACHE_LOCK:
                    stale=ORDERBOOK_CHART_CACHE.get(cache_key)
                if stale and stale.get('data'):
                    payload=copy.deepcopy(stale['data'])
                    payload['cached']=True
                    payload['stale']=True
                    payload['warning']='최신 차트 조회 실패 · 캐시 표시'
                    return self.respond(200,payload)
                return self.respond(500,{'error':'호가창 차트 조회 실패: '+str(e)})
        if path=='/api/chart-minute-history':
            qs=parse_qs(urlparse(self.path).query)
            c=base_code((qs.get('code') or [''])[0]);tf=str((qs.get('tf') or [''])[0]).strip();mode=str((qs.get('mode') or ['cache'])[0]).strip().lower()
            if not c:return self.respond(400,{'error':'종목코드가 필요합니다.'})
            if tf not in CHART_HISTORY_TARGET_BARS:return self.respond(400,{'error':'지원 봉은 1분·3분·15분입니다.'})
            cached=_chart_history_load(c,tf)
            if mode!='deep':
                return self.respond(200,{'code':c,'tf':tf,'bars':cached,'count':len(cached),'cached':True,'target':CHART_HISTORY_TARGET_BARS[tf],'source':'LITTO 로컬 분봉 캐시'})
            with LOCK: client=STATE.get('client')
            if not client:
                if cached:return self.respond(200,{'code':c,'tf':tf,'bars':cached,'count':len(cached),'cached':True,'stale':True,'warning':'키움 미연결 · 로컬 캐시 표시'})
                return self.respond(409,{'error':'키움 API 연결이 필요합니다.'})
            try:
                with CHART_HISTORY_DEEP_LOCK:
                    bars,pages=_chart_history_fetch_low_priority(client,c,tf)
                return self.respond(200,{'code':c,'tf':tf,'bars':bars,'count':len(bars),'cached':False,'pages':pages,'target':CHART_HISTORY_TARGET_BARS[tf],'source':'키움 ka10080 SOR(_AL) · 요청형 로컬 캐시'})
            except Exception as e:
                cached=_chart_history_load(c,tf)
                if cached:return self.respond(200,{'code':c,'tf':tf,'bars':cached,'count':len(cached),'cached':True,'stale':True,'warning':'과거 분봉 조회 실패 · 로컬 캐시 표시'})
                return self.respond(500,{'error':'과거 분봉 조회 실패: '+str(e)})
        if path=='/api/pattern-similarity':
            qs=parse_qs(urlparse(self.path).query)
            c=base_code((qs.get('code') or [''])[0])
            force=(qs.get('force') or ['0'])[0]=='1'
            if not c:
                return self.respond(400,{'error':'종목코드가 필요합니다.'})
            now=time.time()
            if not force:
                with PATTERN_RESULT_CACHE_LOCK:
                    hit=PATTERN_RESULT_CACHE.get(c)
                    if hit and now-float(hit.get('ts') or 0)<180.0:
                        payload=copy.deepcopy(hit.get('data') or {})
                        payload['cached']=True
                        payload.update(_pattern_basis(payload.get('asof')))
                        return self.respond(200,payload)
            with LOCK:
                client=STATE.get('client')
                loaded=copy.deepcopy((STATE.get('data') or {}).get('stocks') or [])
            target=next((x for x in loaded if base_code(x.get('code',''))==c),None) or {}
            meta=LOOKUP.get(c) or {}
            name=str(target.get('name') or meta.get('name') or c)
            sector=str(target.get('sector') or meta.get('sector') or '')
            bars=list(target.get('daily') or [])
            # One explicit target-history request only. R6 compares this stock only with
            # its own past; no other stock history calls are made.
            if client:
                try:
                    rows=_kiwoom_call(client.daily_history_rows,c,1200,kind='chart')
                    fresh=[daily_bar(r) for r in rows]
                    fresh.sort(key=lambda x:x.get('date',''))
                    if len(fresh)>len(bars):
                        bars=fresh
                except Exception:
                    pass
            try:
                result=pattern_engine.analyze(c,name,sector,bars,loaded,PATTERN_CACHE_FILE,max_matches=60)
                result['cached']=False
                result['updated_at']=datetime.now(KST).isoformat()
                result.update(_pattern_basis(result.get('asof')))
                with PATTERN_RESULT_CACHE_LOCK:
                    PATTERN_RESULT_CACHE[c]={'ts':now,'data':copy.deepcopy(result)}
                return self.respond(200,result)
            except Exception as e:
                return self.respond(500,{'error':'유사패턴 분석 실패: '+str(e)})
        if path=='/api/stock-kki':
            qs=parse_qs(urlparse(self.path).query)
            c=base_code((qs.get('code') or [''])[0])
            if not c:return self.respond(400,{'error':'종목코드가 필요합니다.'})
            with LOCK:
                client=STATE.get('client')
                loaded=copy.deepcopy((STATE.get('data') or {}).get('stocks') or [])
            stock=next((x for x in loaded if base_code(x.get('code',''))==c),None) or {}
            recent=list(stock.get('daily') or [])
            # Never block this HTTP request on Kiwoom.  It only reads local cache,
            # seeds any already-resident daily bars, and starts a daemon if needed.
            return self.respond(200,_kki_payload(c,client=client,recent_bars=recent))
        if path=='/api/chart-daily-history':
            qs=parse_qs(urlparse(self.path).query)
            raw=(qs.get('code') or [''])[0]
            c=base_code(raw)
            if not c:
                return self.respond(400,{'error':'종목코드가 필요합니다.'})
            with LOCK:
                client=STATE.get('client')
            if not client:
                return self.respond(409,{'error':'키움 API 연결이 필요합니다.'})
            try:
                rows=_kiwoom_call(client.daily_history_rows,c,180,kind='chart')
                bars=[daily_bar(r) for r in rows]
                bars.sort(key=lambda x:x.get('date',''))
                return self.respond(200,{'code':c,'daily':bars,'count':len(bars)})
            except Exception as e:
                return self.respond(500,{'error':'일봉 과거데이터 조회 실패: '+str(e)})
        if path=='/api/realtime-rank':
            force=parse_qs(urlparse(self.path).query).get('force',['0'])[0]=='1'
            return self.respond(200,realtime_rank_snapshot(force=force))
        if path=='/api/market-movers':
            force=parse_qs(urlparse(self.path).query).get('force',['0'])[0]=='1'
            return self.respond(200,market_movers_snapshot(force=force))
        if path=='/api/live-leader':
            force=parse_qs(urlparse(self.path).query).get('force',['0'])[0]=='1'
            start_live_leader_engine()
            if not force:
                with LIVE_LEADER_LOCK:
                    cached=LIVE_LEADER_CACHE.get('payload')
                if cached:
                    return self.respond(200,cached)
            return self.respond(200,live_leader_snapshot(force_rank=force))
        if path=='/api/sector-popularity':
            qs=parse_qs(urlparse(self.path).query)
            target=str((qs.get('sector') or [''])[0]).strip()
            if not target:
                return self.respond(400,{'error':'섹터명이 필요합니다.'})
            mapping=sectors.load()
            def _sector_tags(v):
                import re
                return [x.strip() for x in re.split(r'[,;/|]+',str(v or '')) if x.strip()]
            def _norm_sector(v):
                import re
                return re.sub(r'[^0-9A-Za-z가-힣]+','',str(v or '')).lower()
            def _sector_match(target_name, sector_value):
                nt=_norm_sector(target_name)
                if not nt:return False
                for tag in _sector_tags(sector_value):
                    ns=_norm_sector(tag)
                    if not ns:continue
                    if nt==ns or nt in ns or ns in nt:
                        return True
                return False
            # Prefer the full listed universe. If it has not been loaded yet, fall back
            # to codes already known by the scanner / sector database.
            universe=list(UNIVERSE or [])
            by_code={code(x.get('code')):x for x in universe if x.get('code')}
            with LOCK:
                report=(STATE.get('report') or {})
                data=(STATE.get('data') or {})
            for st in data.get('stocks',[]) or []:
                c=code(st.get('code')) if st.get('code') else ''
                if c and c not in by_code: by_code[c]=st
            for c in mapping:
                cc=code(c)
                if cc and cc not in by_code: by_code[cc]={'code':cc,'name':LOOKUP.get(cc,{}).get('name') or cc}
            members=[]
            for c,base in by_code.items():
                info=mapping.get(c) or mapping.get(str(c)) or {}
                sec=info.get('sector') or base.get('sector') or ''
                if not _sector_match(target,sec):
                    continue
                members.append({'code':c,'name':_best_known_stock_name(c,base),'sector':sec})
            if not members:
                panels=((report.get('search_panels') or {}).get('panels') or {})
                seen=set()
                for pname in ('주도주 종배','주도주 상따','끼도주 종배'):
                    for row in ((panels.get(pname) or {}).get('rows') or []):
                        c=code(row.get('code')) if row.get('code') else ''
                        sec=row.get('sector') or ''
                        if c and c not in seen and _sector_match(target,sec):
                            seen.add(c)
                            members.append({'code':c,'name':_best_known_stock_name(c,row),'sector':sec})
            ranks=realtime_rank_snapshot(force=False)
            live_rows=ranks.get('rows') or []
            daily_rows=ranks.get('daily_rows') or []
            live={code(x.get('code')):x for x in live_rows if x.get('code')}
            daily={code(x.get('code')):x for x in daily_rows if x.get('code')}
            result_map={code(x.get('code')):x for x in (report.get('results') or []) if x.get('code')}
            out=[]
            for m in members:
                c=m['code']; lr=live.get(c); dr=daily.get(c); rr=result_map.get(c) or {}
                # popularity order is provider ranking only: current lookup first,
                # then Kiwoom's own daily cumulative lookup rank. Unranked members follow.
                live_rank=int(lr.get('rank')) if lr and str(lr.get('rank','')).isdigit() else None
                daily_rank=int(dr.get('rank')) if dr and str(dr.get('rank','')).isdigit() else None
                src=lr or dr or rr
                resolved_name=_best_known_stock_name(c,lr,dr,rr,m)
                out.append({
                    **m,
                    'name':resolved_name,
                    'live_rank':live_rank,
                    'daily_rank':daily_rank,
                    'price':src.get('price') if isinstance(src,dict) else None,
                    'change':src.get('change') if isinstance(src,dict) else None,
                    'move':lr.get('move') if lr else None,
                    'new':bool(lr.get('new')) if lr else False,
                    'value_eok':rr.get('value_eok') if isinstance(rr,dict) else None,
                })
            out.sort(key=lambda x:(0 if x['live_rank'] is not None else 1,
                                   x['live_rank'] if x['live_rank'] is not None else 999999,
                                   0 if x['daily_rank'] is not None else 1,
                                   x['daily_rank'] if x['daily_rank'] is not None else 999999,
                                   x['name']))
            return self.respond(200,{'sector':target,'rows':out,'count':len(out),'ranked_count':sum(1 for x in out if x['live_rank'] is not None or x['daily_rank'] is not None),'updated_at':ranks.get('updated_at'),'source':'키움 ka00198 실시간 조회순위 → 당일 누적 조회순위','error':ranks.get('error')})
        if path=='/api/stock-search':
            qs=parse_qs(urlparse(self.path).query)
            q=(qs.get('q') or [''])[0]
            try:return self.respond(200,stock_search_snapshot(q,20))
            except ValueError as e:return self.respond(400,{'error':str(e)})
        if path=='/api/watch-realtime':
            qs=parse_qs(urlparse(self.path).query)
            raw=(qs.get('codes') or [''])[0]
            codes=[x.strip() for x in raw.split(',') if x.strip()]
            try:return self.respond(200,watch_realtime_snapshot(codes))
            except (ValueError,ApiError) as e:return self.respond(400,{'error':str(e)})
        if path=='/api/watch-manual-live':
            qs=parse_qs(urlparse(self.path).query)
            raw=(qs.get('codes') or [''])[0]
            codes=[x.strip() for x in raw.split(',') if x.strip()]
            force=(qs.get('force',['0'])[0]=='1')
            try:return self.respond(200,manual_watch_live_snapshot(codes,force=force))
            except (ValueError,ApiError) as e:return self.respond(400,{'error':str(e)})
        if path=='/api/chart-bs':
            qs=parse_qs(urlparse(self.path).query)
            c=(qs.get('code') or [''])[0]
            start=(qs.get('start') or [''])[0]
            mode=(qs.get('mode') or ['full'])[0]
            try:return self.respond(200,chart_bs_snapshot(c,start,mode))
            except (ValueError,ApiError) as e:return self.respond(400,{'error':str(e)})
        if path=='/api/stock-market-cap':
            # Bounded, on-demand, nonblocking popup metadata; no scanner/order changes.
            qs=parse_qs(urlparse(self.path).query)
            c=base_code((qs.get('code') or [''])[0])
            if not re.fullmatch(r'\d{6}', c or ''):
                return self.respond(400, {'error':'종목코드 오류'})
            with LOCK: client=STATE.get('client')
            if not client:return self.respond(409, {'error':'키움 미연결'})
            meta=LOOKUP.get(c) or {}
            mc=str(meta.get('marketCode') or '')
            mn=str(meta.get('marketName') or '').upper()
            market=('코스닥' if mc=='10' or 'KOSDAQ' in mn else
                    '코스피' if mc=='0' or 'KOSPI' in mn else '')
            now=time.monotonic()
            with LITTO_MARKET_CAP_LOCK:
                cached=LITTO_MARKET_CAP_CACHE.get(c)
                if cached and now-cached[0]<1800:
                    v=cached[1]
                    return self.respond(200, {'code':c,'market':market,'status':'ready',
                        'market_cap_eok':v,'rank':None,'cached':True})
                task=LITTO_MARKET_CAP_TASKS.get(c)
                if task and now-task['created']>45 and task['status']=='pending':
                    # A timed-out worker remains alive; do not launch duplicates.
                    task['status']='timeout'
                    task['message']='시가총액 조회 지연: 다른 기능은 계속 사용 가능'
                if task and now-task['created']<60:
                    return self.respond(200,{'code':c,'market':market,'status':task['status'],
                        'message':task.get('message',''),'rank':None,
                        'market_cap_eok':task.get('market_cap_eok')})
                running=sum(t['status']=='pending' for t in LITTO_MARKET_CAP_TASKS.values())
                if running>=1:
                    return self.respond(200,{'code':c,'market':market,'status':'busy',
                        'message':'다른 시가총액 조회 처리 중','rank':None})
                LITTO_MARKET_CAP_TASKS[c]={'status':'pending','created':now,'message':''}
            def _fetch_cap():
                try:
                    # Search API gate is bounded to 3 sec; never block order handlers.
                    v=_kiwoom_call(client.stock_market_cap_eok,c,kind='heavy')
                    v=float(v) if v else None
                    if v is not None and (v!=v or abs(v)>1e16 or v<=0):v=None
                    with LITTO_MARKET_CAP_LOCK:
                        if v:
                            if len(LITTO_MARKET_CAP_CACHE)>512:LITTO_MARKET_CAP_CACHE.clear()
                            LITTO_MARKET_CAP_CACHE[c]=(time.monotonic(),v)
                        LITTO_MARKET_CAP_TASKS[c]={'status':'ready' if v else 'missing',
                            'created':time.monotonic(),'market_cap_eok':v,
                            'message':'' if v else '키움 응답에 시가총액(mac) 값 없음'}
                except Exception as e:
                    detail=str(e or '')
                    if '게이트 대기 초과' in detail:detail='키움 조회가 바빠 이번 요청을 건너뜀'
                    elif '키움 HTTP' in detail or '키움 연결 실패' in detail:detail=detail[:160]
                    else:detail='키움 조회 실패 ('+type(e).__name__+')'
                    with LITTO_MARKET_CAP_LOCK:
                        LITTO_MARKET_CAP_TASKS[c]={'status':'error','created':time.monotonic(),
                            'message':detail}
            threading.Thread(target=_fetch_cap,name='litto-market-cap-'+c,daemon=True).start()
            return self.respond(200,{'code':c,'market':market,'status':'pending',
                'message':'키움 시가총액 조회 중','rank':None})
        if path=='/api/stock-market-cap-rank':
            # Rank only appears when complete per-market source coverage is verified.
            qs=parse_qs(urlparse(self.path).query)
            c=base_code((qs.get('code') or [''])[0])
            if not re.fullmatch(r'\d{6}',c or ''):return self.respond(400,{'error':'종목코드 오류'})
            meta=LOOKUP.get(c) or {}
            mc=str(meta.get('marketCode') or '')
            market=('코스피' if mc=='0' else '코스닥' if mc=='10' else '')
            return self.respond(200,{'code':c,'market':market,
              'rank':LITTO_CAP_RANK_CACHE.get(c),'rank_status':'unavailable',
              'reason':'시가총액 전체 종목 검증 데이터가 없어 정확한 순위를 표시할 수 없습니다.'})
        if path=='/api/stock-venues':
            qs=parse_qs(urlparse(self.path).query)
            raw=(qs.get('codes') or [''])[0]
            codes=[x.strip() for x in raw.split(',') if x.strip()]
            force=(qs.get('force',['0'])[0]=='1')
            try:return self.respond(200,stock_venue_snapshot(codes,force=force))
            except (ValueError,ApiError) as e:return self.respond(400,{'error':str(e)})
        if path=='/api/orderbook-live':
            qs=parse_qs(urlparse(self.path).query)
            c=code((qs.get('code') or [''])[0])
            if not c:return self.respond(400,{'error':'종목코드가 필요합니다.'})
            try:last_seq=int((qs.get('seq') or ['0'])[0] or 0)
            except Exception:last_seq=0
            _ob_t0=time.perf_counter()
            with LOCK: client=STATE.get('client')
            _ob_t_lock=time.perf_counter()
            if not client:return self.respond(400,{'error':'키움 API 연결이 필요합니다.'})
            feed=getattr(client,'_domestic_orderbook_feed',None)
            if feed is None:
                feed=DomesticOrderbookFeed(client);client._domestic_orderbook_feed=feed
            feed.ensure(c)
            _ob_t_ensure=time.perf_counter()
            # Event-waiting endpoint: the request returns as soon as Kiwoom 0D/0B
            # changes instead of polling the REST snapshot every second.
            data=feed.wait_snapshot(c,last_seq,0.75)
            _ob_t_snapshot=time.perf_counter()
            cache=getattr(client,'_orderbook_rest_cache',{})
            static=cache.get(c) if isinstance(cache,dict) else None
            if isinstance(static,dict):
                # Keep slow-changing reference fields warm, but NEVER overwrite a
                # live 0D ladder/current price. This preserves HTS-like latency.
                for k in ('base_price','open','high','low','market_code'):
                    if data.get(k) in (None,'') and static.get(k) not in (None,''):
                        data[k]=static.get(k)
                live_book=any(float(x.get('price') or 0)>0 for x in (data.get('asks') or []) if isinstance(x,dict)) or any(float(x.get('price') or 0)>0 for x in (data.get('bids') or []) if isinstance(x,dict))
                if not live_book:
                    if any(float(x.get('price') or 0)>0 for x in (static.get('asks') or []) if isinstance(x,dict)):
                        data['asks']=static.get('asks',[])
                    if any(float(x.get('price') or 0)>0 for x in (static.get('bids') or []) if isinstance(x,dict)):
                        data['bids']=static.get('bids',[])
                    for k in ('ask_total','bid_total','orderbook_time'):
                        if static.get(k) not in (None,''):data[k]=static.get(k)
                    data['fallback_snapshot']=True
            has_book=any(float(x.get('price') or 0)>0 for x in (data.get('asks') or []) if isinstance(x,dict)) or any(float(x.get('price') or 0)>0 for x in (data.get('bids') or []) if isinstance(x,dict))
            if not has_book:
                last_book=_get_last_orderbook(c,7)
                if isinstance(last_book,dict):
                    for k in ('asks','bids','ask_total','bid_total','orderbook_time','market_code'):
                        if last_book.get(k) not in (None,''):data[k]=last_book.get(k)
                    data['cached_orderbook']=True; data['cached_at']=last_book.get('saved_at')
            now_kst=datetime.now(KST)
            data['market_closed']=(now_kst.weekday()>=5 or not (8 <= now_kst.hour < 20))
            data['name']=_best_known_stock_name(c,LOOKUP.get(c,{}))
            data['server_ts']=time.time()
            # Server timings isolate backend stalls from browser/network scheduling.
            _ob_t_finish=time.perf_counter()
            data['delivery_server_ms']=round((_ob_t_finish-_ob_t0)*1000,1)
            data['delivery_lock_ms']=round((_ob_t_lock-_ob_t0)*1000,1)
            data['delivery_ensure_ms']=round((_ob_t_ensure-_ob_t_lock)*1000,1)
            data['delivery_wait_ms']=round((_ob_t_snapshot-_ob_t_ensure)*1000,1)
            data['delivery_build_ms']=round((_ob_t_finish-_ob_t_snapshot)*1000,1)
            return self.respond(200,data)
        if path=='/api/orderbook':
            qs=parse_qs(urlparse(self.path).query)
            c=code((qs.get('code') or [''])[0])
            if not c:return self.respond(400,{'error':'종목코드가 필요합니다.'})
            with LOCK: client=STATE.get('client')
            if not client:return self.respond(400,{'error':'키움 API 연결이 필요합니다.'})
            feed=getattr(client,'_domestic_orderbook_feed',None)
            if feed is None:
                feed=DomesticOrderbookFeed(client);client._domestic_orderbook_feed=feed
            feed.ensure(c)
            live=feed.snapshot(c)
            # ka10004 is a REST snapshot and remains useful after the realtime
            # websocket stops sending at/after market close.  Cache briefly so
            # the 1-second UI refresh does not spam the REST endpoint.
            cache=getattr(client,'_orderbook_rest_cache',{})
            now=time.time(); cached=cache.get(c) if isinstance(cache,dict) else None
            live_has_book=any(float(x.get('price') or 0)>0 for x in (live.get('asks') or []) if isinstance(x,dict)) or any(float(x.get('price') or 0)>0 for x in (live.get('bids') or []) if isinstance(x,dict))
            # HTS-like first paint: when realtime 0D is already alive, do not block
            # the popup on ka10004/ka10001 REST. Use even a slightly stale static
            # reference snapshot immediately and refresh it in the background.
            static=dict(cached) if isinstance(cached,dict) else None
            fresh=isinstance(cached,dict) and now-float(cached.get('_ts') or 0)<1.2
            if not fresh:
                if live_has_book:
                    _warm_orderbook_static(client,c)
                    if static is None: static={}
                else:
                    try:
                        static=client.domestic_orderbook(c,'SOR')
                        static['_ts']=now
                        if not isinstance(cache,dict): cache={}
                        cache[c]=dict(static); client._orderbook_rest_cache=cache
                    except Exception as e:
                        static={'static_error':str(e)}
            # The bootstrap REST response must not replace an already received
            # real-time 0D ladder with an earlier SOR REST snapshot.
            # Apply either complete ladder as a unit: never mix its bid/ask levels.
            data=_merge_orderbook_initial_snapshot(live,static)
            # Persist the last real 10-level snapshot. Kiwoom REST/realtime can
            # legitimately return an empty ladder after close/weekends; MTS can
            # still display its locally retained close snapshot, so LITTO keeps
            # its own last non-empty snapshot for the same purpose.
            has_book=any(float(x.get('price') or 0)>0 for x in (data.get('asks') or []) if isinstance(x,dict)) or any(float(x.get('price') or 0)>0 for x in (data.get('bids') or []) if isinstance(x,dict))
            if has_book:
                _save_last_orderbook(c,data)
            else:
                last_book=_get_last_orderbook(c,7)
                if isinstance(last_book,dict):
                    for k in ('asks','bids','ask_total','bid_total','orderbook_time','venue','market_code','source'):
                        if last_book.get(k) not in (None,''): data[k]=last_book.get(k)
                    data['cached_orderbook']=True
                    data['cached_at']=last_book.get('saved_at')
            now_kst=datetime.now(KST)
            data['market_closed']=(now_kst.weekday()>=5 or not (8 <= now_kst.hour < 20))
            data['name']=_best_known_stock_name(c,LOOKUP.get(c,{}))
            return self.respond(200,data)
        if path=='/api/investor-flow':
            qs=parse_qs(urlparse(self.path).query)
            c=(qs.get('code') or [''])[0]
            force=(qs.get('force',['0'])[0]=='1')
            try:return self.respond(200,investor_flow_snapshot(c,force=force))
            except (ValueError,ApiError) as e:return self.respond(400,{'error':str(e)})
        if path=='/api/program-flow-watch':
            qs=parse_qs(urlparse(self.path).query)
            raw=(qs.get('codes') or [''])[0]
            codes=[x.strip() for x in raw.split(',') if x.strip()][:80]
            force=(qs.get('force',['0'])[0]=='1')
            try:return self.respond(200,program_flow_watch_snapshot(codes,force=force))
            except (ValueError,ApiError) as e:return self.respond(400,{'error':str(e)})
        if path=='/api/news':
            qs=parse_qs(urlparse(self.path).query)
            c=(qs.get('code') or [''])[0]; name=(qs.get('name') or [''])[0]
            return self.respond(200,fetch_stock_news(c,name,10))
        if path=='/api/sector-strength-calendar':
            qs=parse_qs(urlparse(self.path).query)
            month=(qs.get('month') or [None])[0]
            try:return self.respond(200,sector_strength_calendar_snapshot(month))
            except ValueError as e:return self.respond(400,{'error':str(e)})
        if path=='/api/market-core':
            qs=parse_qs(urlparse(self.path).query)
            force=(qs.get('force',['0'])[0]=='1')
            return self.respond(200,market_core_snapshot(force=force))
        if path=='/api/market-overview':
            qs=parse_qs(urlparse(self.path).query)
            force=(qs.get('force',['0'])[0]=='1')
            return self.respond(200,market_overview_snapshot(force=force))
        if path=='/api/market-index-chart':
            q=parse_qs(urlparse(self.path).query)
            market=(q.get('market') or ['kospi'])[0]
            mode=(q.get('mode') or ['minute'])[0]
            # Do not call market_overview_snapshot here: it performs expensive unrelated queries.
            cached=MARKET_OVERVIEW_CACHE.get('data') or {}
            return self.respond(200,litto_market_extras.index_snapshot(STATE.get('client'),market,mode,cached))
        if path=='/api/market-funds-history':
            # Fast cached response; external official read occurs in its own daemon thread.
            return self.respond(200,litto_market_extras.funds_snapshot())
        if path=='/api/market-investor-history':
            qs=parse_qs(urlparse(self.path).query)
            market=(qs.get('market') or ['kospi'])[0]
            try: days=int((qs.get('days') or ['10'])[0])
            except: days=10
            force=(qs.get('force',['0'])[0]=='1')
            try:return self.respond(200,market_investor_history_snapshot(market,days,force=force))
            except ValueError as e:return self.respond(400,{'error':str(e)})
        if path=='/api/header-indices':
            force=parse_qs(urlparse(self.path).query).get('force',['0'])[0]=='1'
            return self.respond(200,header_indices_snapshot(force=force))
        if path=='/api/nasdaq-futures-chart':
            force=parse_qs(urlparse(self.path).query).get('force',['0'])[0]=='1'
            return self.respond(200,nasdaq_futures_chart_snapshot(force=force))
        if path=='/api/us-market':
            force=parse_qs(urlparse(self.path).query).get('force',['0'])[0]=='1'
            return self.respond(200,us_market_snapshot(force=force))
        if path=='/api/account-watchlist-groups':
            return self.respond(200,account_watchlist_groups_snapshot())
        if path=='/api/account-watchlist':
            qs=parse_qs(urlparse(self.path).query)
            group=(qs.get('group') or [''])[0]
            try:return self.respond(200,account_watchlist_group_snapshot(group))
            except ValueError as e:return self.respond(400,{'error':str(e)})
        if path=='/api/us-watchlist':
            qs=parse_qs(urlparse(self.path).query)
            force=qs.get('force',['0'])[0]=='1'
            raw=(qs.get('symbols') or [''])[0]
            symbols=[x for x in raw.split(',') if x.strip()]
            if len(symbols)>80:return self.respond(400,{'error':'미국 관심종목은 한 번에 80개 이하만 조회합니다.'})
            return self.respond(200,us_watchlist_snapshot(symbols,force=force))
        if path=='/api/market-calendar':
            force=parse_qs(urlparse(self.path).query).get('force',['0'])[0]=='1'
            return self.respond(200,market_calendar.snapshot(force=force))
        if path=='/api/market-actions':
            force=parse_qs(urlparse(self.path).query).get('force',['0'])[0]=='1'
            return self.respond(200,market_actions_snapshot(force=force))
        if path=='/api/screener-history':
            qs=parse_qs(urlparse(self.path).query)
            day=(qs.get('date') or [None])[0]
            panel=(qs.get('panel') or [None])[0]
            try:limit=int((qs.get('limit') or ['1000'])[0])
            except Exception:limit=1000
            try:return self.respond(200,screener_history.snapshot(day,panel,limit))
            except Exception as e:return self.respond(500,{'error':'검색 이력 조회 실패: '+str(e)})
        if path=='/api/journal':
            qs=parse_qs(urlparse(self.path).query)
            start=(qs.get('start') or [None])[0];end=(qs.get('end') or [None])[0]
            try:limit=int((qs.get('limit') or ['500'])[0])
            except Exception:limit=500
            snap=journal.snapshot(ROOT,start=start,end=end,limit=limit)
            # 매매일지의 종목에도 LITTO에 저장된 사용자 섹터 DB를 그대로 표시한다.
            sector_map=sectors.load()
            for row in snap.get('rows',[]):
                c=code(row.get('stock_code'))
                info=sector_map.get(c,{})
                row['saved_sector']=info.get('sector') or ''
                row['saved_sector_source']=info.get('source') or ''
            return self.respond(200,snap)
        if path=='/api/journal/export':
            qs=parse_qs(urlparse(self.path).query);start=(qs.get('start') or [None])[0];end=(qs.get('end') or [None])[0]
            rows=journal.list_trades(ROOT,start,end,2000);buf=io.StringIO();w=csv.writer(buf)
            w.writerow(['날짜','종목코드','종목명','매수수량','평균매수가','매도수량','평균매도가','손익','수익률','수수료','세금','전략','원칙준수','추격','물타기','진입이유','매도이유','잘한점','잘못한점','다음행동','출처'])
            for r in rows:
                w.writerow([safe_cell(x) for x in [r.get('trade_date'),r.get('stock_code'),r.get('stock_name'),r.get('buy_qty'),r.get('buy_avg'),r.get('sell_qty'),r.get('sell_avg'),r.get('pnl'),r.get('return_rate'),r.get('fees'),r.get('tax'),r.get('strategy'),r.get('rule_followed'),r.get('chasing'),r.get('averaging_down'),r.get('entry_reason'),r.get('exit_reason'),r.get('good'),r.get('bad'),r.get('next_action'),r.get('source')]])
            return self.respond(200,'\ufeff'+buf.getvalue(),'text/csv; charset=utf-8','trading_journal.csv')
        if path=='/api/theme-sync/diagnose':
            qs=parse_qs(urlparse(self.path).query)
            raw=(qs.get('code') or [''])[0].strip().upper().removeprefix('A')
            if not re.fullmatch(r'\d{6}',raw):
                return self.respond(400,{'error':'6자리 종목코드가 필요합니다.'})
            item=sectors.load().get(raw) or {}
            provider=None; snapshot_asof=None
            try:
                snap=json.loads((sectors.DATA_DIR/'kiwoom_market_theme_snapshot.json').read_text(encoding='utf-8'))
                provider=(snap.get('themes_by_code') or {}).get(raw)
                snapshot_asof=snap.get('asof')
            except (FileNotFoundError,ValueError,TypeError):pass
            live=next((x for x in STATE.get('data',{}).get('stocks',[]) if base_code(x.get('code',''))==raw),None)
            source=str(item.get('source') or '')
            protected=source.startswith('사용자 직접 지정')
            return self.respond(200,{'code':raw,'saved_sector':item.get('sector') or '',
                'saved_source':source,'manual_protected':protected,
                'kiwoom_theme':provider,'theme_snapshot_asof':snapshot_asof,
                'screen_sector':(live or {}).get('sector'),
                'explanation':('직접 지정으로 보호됨' if protected else
                    '키움 테마 미수록 또는 분류 미수신' if not provider else
                    '화면 재계산 또는 캐시 갱신 확인 필요' if live and live.get('sector')!=item.get('sector') else '저장된 분류와 화면 표시 일치')})
        if path=='/api/theme-sync/status':
            with THEME_REFRESH_LOCK:return self.respond(200,dict(THEME_REFRESH_STATE))
        if path=='/api/sectors':
            buf=io.StringIO();w=csv.writer(buf);w.writerow(['code','name','sector','source','asof']);mapping=sectors.load()
            for item in UNIVERSE:
                v=mapping.get(item['code'],{});w.writerow([safe_cell(x) for x in [item['code'],item['name'],v.get('sector','미분류'),v.get('source',''),v.get('asof','')]])
            return self.respond(200,'\ufeff'+buf.getvalue(),'text/csv; charset=utf-8','sectors.csv')
        if path=='/api/template':return self.respond(200,dataset(),attachment='example_prices.json')
        if path=='/api/export':
            with LOCK:report=STATE['report']
            buf=io.StringIO();writer=csv.writer(buf)
            writer.writerow(['종목코드','종목명','섹터','분류출처','기법','기술조건','상태','현재가','등락률(%)','거래대금(억원)','기준봉','조회시각','자료모드','미충족·확인사항'])
            for r in report['results']:
                for p in r['patterns']:
                    missing=' / '.join(c['label']+': '+c['detail'] for c in p['checks']+p['quality'] if c['state']!='pass')
                    writer.writerow([safe_cell(x) for x in [r['code'],r['name'],r['sector'],r.get('sector_source',''),p['name'],p['technical'],p['status'],r['price'],round(r['change'],2),r['value_eok'],(r['base'] or {}).get('date'),r['asof'],report['mode'],missing]])
            return self.respond(200,'\ufeff'+buf.getvalue(),'text/csv; charset=utf-8','scan_results.csv')
        if path=='/mts':
            html=(ROOT/'web/mts.html').read_text(encoding='utf-8').replace('__CSRF__',CSRF)
            return self.respond(200,html,'text/html; charset=utf-8')
        if path in ('/mts.js','/mts.css'):
            ctype='application/javascript' if path.endswith('.js') else 'text/css'
            return self.respond(200,(ROOT/'web'/path[1:]).read_bytes(),ctype+'; charset=utf-8')
        if path=='/':
            html=(ROOT/'web/index.html').read_text(encoding='utf-8').replace('__CSRF__',CSRF)
            # Dev build self-heal: always expose page 4 even if an older index.html
            # was accidentally left in the working folder.
            if 'data-page="us"' not in html:
                anchor='<button class="litto-pagebtn" data-page="market">3. 시장종합</button>'
                usbtn=anchor+'\n      <button class="litto-pagebtn" data-page="us">4. 미국시장</button>'
                html=html.replace(anchor,usbtn,1)
            if 'data-page="journal"' not in html:
                anchor='<button class="litto-pagebtn" data-page="us">4. 미국시장</button>'
                html=html.replace(anchor,anchor+'\n      <button class="litto-pagebtn" data-page="journal">5. 매매일지</button>',1)
            # Force a fresh frontend on every dev patch revision.
            html=html.replace('href="/style.css"','href="/style.css?v=litto-ai-restore-r8-20261013"')
            html=html.replace('src="/app.js"','src="/app.js?v=litto-ai-restore-r8-20261013"')
            return self.respond(200,html,'text/html; charset=utf-8')
        if path in ('/app.js','/style.css'):
            ctype='application/javascript' if path.endswith('.js') else 'text/css'
            return self.respond(200,(ROOT/'web'/path[1:]).read_bytes(),ctype+'; charset=utf-8')
        return self.respond(404,{'error':'찾을 수 없습니다.'})

    def do_POST(self):
        if not self.trusted() or self.headers.get('X-Session-Token')!=CSRF:
            return self.respond(403,{'error':'세션 확인 실패. 페이지를 새로고침하세요.'})
        try:
            size=int(self.headers.get('Content-Length',0))
            if not 0<size<=30_000_000:raise ValueError('요청 파일은 30MB 이하입니다.')
            body=json.loads(self.rfile.read(size))
            path=urlparse(self.path).path
            if path=='/api/orderbook-delivery-report':
                if not isinstance(body,dict):raise ValueError('invalid report')
                event={
                    'at':time.time(),
                    'symbol':str(body.get('symbol',''))[:16],
                    'reason':str(body.get('reason',''))[:32],
                    'gap_ms':round(float(body.get('gap_ms') or 0),1),
                    'request_ms':round(float(body.get('request_ms') or 0),1),
                    'paint_ms':round(float(body.get('paint_ms') or 0),1),
                    'server_book_age_s':body.get('book_age_s'),
                    'server_trade_age_s':body.get('trade_age_s'),
                    'seq_delta':int(body.get('seq_delta') or 0),
                }
                with OB_DELIVERY_LOCK:
                    OB_DELIVERY_EVENTS.append(event)
                    if len(OB_DELIVERY_EVENTS)>30:del OB_DELIVERY_EVENTS[:-30]
                return self.respond(200,{'ok':True})
            # User-triggered full backup save. Keep this completely outside the
            # scanner/realtime lock so backup I/O can never stall live market paths.
            if path=='/api/full-backup/save':
                raw_name=str(body.get('name') or 'LITTO_FULL_BACKUP.json')
                safe_name=re.sub(r'[^0-9A-Za-z가-힣._-]+','_',raw_name).strip('._') or 'LITTO_FULL_BACKUP.json'
                if not safe_name.lower().endswith('.json'):
                    safe_name += '.json'
                content=body.get('content')
                if not isinstance(content,str) or not content:
                    raise ValueError('저장할 백업 데이터가 없습니다.')
                # SAVE ONLY: embed user's sector mapping in the existing backup JSON.
                # The restore path is intentionally unchanged and ignores this extra field.
                try:
                    backup_payload=json.loads(content)
                    if not isinstance(backup_payload,dict) or backup_payload.get('format')!='LITTO_FULL_BACKUP_V1':
                        raise ValueError('라이또 전체 백업 형식이 아닙니다.')
                    sector_mapping=sectors.load()
                    backup_payload['sector_backup']={
                        'format':'LITTO_SECTORS_V1',
                        'source':'user_local_sector_mapping',
                        'mapping':sector_mapping,
                    }
                    content=json.dumps(backup_payload,ensure_ascii=False,indent=2)
                except ValueError:
                    raise
                except Exception as e:
                    raise ValueError('섹터 포함 백업 생성 실패: '+str(e))
                # R14: open the native Windows Save As dialog only when the user
                # presses 전체 저장.  This runs in a short-lived PowerShell process,
                # so it does not touch pywebview startup or the realtime/scanner loops.
                if os.name=='nt':
                    ps_script=r'''
Add-Type -AssemblyName System.Windows.Forms
Add-Type -AssemblyName System.Drawing
$dlg = New-Object System.Windows.Forms.SaveFileDialog
$dlg.Title = '라이또 전체 백업 저장'
$dlg.Filter = 'LITTO 백업 파일 (*.json)|*.json|모든 파일 (*.*)|*.*'
$dlg.DefaultExt = 'json'
$dlg.AddExtension = $true
$dlg.OverwritePrompt = $true
$dlg.RestoreDirectory = $true
$dlg.FileName = $env:LITTO_BACKUP_NAME
$downloads = Join-Path $HOME 'Downloads'
if (Test-Path $downloads) { $dlg.InitialDirectory = $downloads }
$owner = New-Object System.Windows.Forms.Form
$owner.ShowInTaskbar = $false
$owner.TopMost = $true
$owner.StartPosition = 'CenterScreen'
$owner.Size = New-Object System.Drawing.Size(1,1)
$owner.Opacity = 0
$owner.Show()
$owner.Activate()
try {
  $result = $dlg.ShowDialog($owner)
  if ($result -eq [System.Windows.Forms.DialogResult]::OK) {
    [Convert]::ToBase64String([Text.Encoding]::UTF8.GetBytes($dlg.FileName))
  } else {
    '__CANCELLED__'
  }
} finally {
  $owner.Close()
  $owner.Dispose()
  $dlg.Dispose()
}
'''
                    env=os.environ.copy(); env['LITTO_BACKUP_NAME']=safe_name
                    try:
                        cp=subprocess.run(
                            ['powershell.exe','-STA','-NoProfile','-ExecutionPolicy','Bypass','-Command',ps_script],
                            capture_output=True,text=True,encoding='utf-8',errors='replace',env=env,timeout=120,
                            creationflags=(getattr(subprocess,'CREATE_NO_WINDOW',0) if hasattr(subprocess,'CREATE_NO_WINDOW') else 0)
                        )
                        out=(cp.stdout or '').strip().splitlines()
                        token=out[-1].strip() if out else ''
                        if token=='__CANCELLED__':
                            return self.respond(200,{'ok':False,'cancelled':True})
                        if cp.returncode!=0 or not token:
                            raise RuntimeError((cp.stderr or cp.stdout or 'Windows 저장 위치 선택창 오류').strip())
                        try:
                            selected=base64.b64decode(token).decode('utf-8')
                        except Exception as e:
                            raise RuntimeError('저장 위치를 읽지 못했습니다: '+str(e))
                        target=Path(selected)
                        target.parent.mkdir(parents=True,exist_ok=True)
                        target.write_text(content,encoding='utf-8')
                        return self.respond(200,{'ok':True,'path':str(target),'name':target.name,'dialog':True})
                    except subprocess.TimeoutExpired:
                        raise ValueError('저장 위치 선택 시간이 초과되었습니다.')
                    except Exception as e:
                        raise ValueError('Windows 저장 위치 선택창을 열지 못했습니다: '+str(e))
                # Non-Windows/browser fallback: keep the safe automatic location.
                candidates=[Path.home()/'Downloads', ROOT/'backups']
                last_error=None
                for folder in candidates:
                    try:
                        folder.mkdir(parents=True,exist_ok=True)
                        target=folder/safe_name
                        if target.exists():
                            stem=target.stem; suffix=target.suffix; i=1
                            while target.exists():
                                target=folder/f'{stem}_{i}{suffix}'; i+=1
                        target.write_text(content,encoding='utf-8')
                        return self.respond(200,{'ok':True,'path':str(target),'name':target.name,'dialog':False})
                    except Exception as e:
                        last_error=e
                raise ValueError('백업 파일 저장 실패: '+str(last_error or '알 수 없는 오류'))
            # Discard is allowed for pending proposals only, with explicit UI confirmation.
            if path == '/api/ai-dev/discard':
                pid = str(body.get('id') or '')
                if body.get('confirmation') != 'discard ' + pid:
                    return self.respond(400, {'error':'삭제 확인 문구가 일치하지 않아.'})
                try:
                    return self.respond(200, litto_ai_developer.discard(ROOT, pid))
                except ValueError as e:
                    return self.respond(409, {'error': str(e)})
            # Explicit local UI click only: NEVER expose apply/rollback as AI tools.
            # Reject mutation during any active Kiwoom connection or scanner.
            if path in ('/api/ai-dev/apply','/api/ai-dev/rollback'):
                pid=str(body.get('id') or '')
                operation='apply' if path.endswith('/apply') else 'rollback'
                if body.get('confirmation') != operation+' '+pid:
                    return self.respond(400,{'error':'확인 문구가 일치하지 않아. 수정하지 않았어.'})
                info=litto_ai_developer.pending(ROOT,pid)
                if operation=='apply' and not info.get('checks') or (operation=='apply' and not all(c.get('ok') is True for c in info.get('checks',[]))):
                    return self.respond(409,{'error':'자동 검증이 통과하지 않았어.'})
                # Non-hot updates: approve now, apply at next LITTO startup.
                # Never ask the user to close the very UI required for approval.
                can_live=litto_ai_developer.is_hot_safe(ROOT,pid,operation)
                if operation=='apply' and not can_live:
                    try:
                        return self.respond(200,litto_ai_developer.schedule_apply(ROOT,pid))
                    except ValueError as e:
                        return self.respond(409,{'error':str(e)})
                # Safe hot-swappable classifier is permitted while connected.
                # Every other code change still requires disconnect and idle state.
                can_live=litto_ai_developer.is_hot_safe(ROOT,pid,operation)
                if (STATE.get('connected') or STATE.get('busy')) and not can_live:
                    return self.respond(409,{'error':'키움 연결 또는 검색이 진행 중이야. 이 수정은 종료 후 적용해줘.'})
                result=litto_ai_developer.apply(ROOT,pid) if operation=='apply' else litto_ai_developer.rollback(ROOT,pid)
                if can_live:
                    try:
                        target=litto_ai_developer.current_hot_source(ROOT, pid, operation)
                        result.update(litto_ai_live_patch.install(globals(),target,validation='forward' if operation=='apply' else 'rollback'))
                        result['restart_required']=False
                        result['note']='AI 명령 인식 코드가 재시작 없이 즉시 반영됐어.'
                    except Exception as exc:
                        # Fail closed: restore original source; do not alter in-memory handler.
                        try:
                            litto_ai_developer.rollback(ROOT,pid) if operation=='apply' else litto_ai_developer.reapply_after_failed_rollback(ROOT,pid)
                        except Exception as rollback_exc:
                            return self.respond(500,{'error':'실시간 반영 실패 및 파일 복원 실패. 재시작 전 점검이 필요해.', 'detail':str(rollback_exc)[:300]})
                        return self.respond(409,{'error':'실시간 반영 검증 실패. 변경 파일을 복원했어.', 'detail':str(exc)[:300]})
                return self.respond(200,result)
            if path=='/api/ai-pdf-add':
                return self.respond(200,litto_pdf_knowledge.add(body.get('name'),body.get('content_b64')))
            if path=='/api/ai-pdf-drive-connect':
                return self.respond(200,litto_pdf_knowledge.connect_drive(body.get('folder','')))
            if path=='/api/ai-pdf-drive-sync':
                return self.respond(200,litto_pdf_knowledge.start_drive_sync())
            if path=='/api/ai-pdf-delete':
                return self.respond(200,litto_pdf_knowledge.remove(body.get('id')))
            # AI reasoning can legitimately take several minutes in max mode.
            # Never hold the global market/UI lock while waiting for the model.
            if path=='/api/gemini-mode':
                return self.respond(200,litto_gemini.set_mode(body.get('mode')))
            if path=='/api/gemini-key':
                return self.respond(200,litto_gemini.save_key(body.get('api_key',''),body.get('mode','free')))
            if path=='/api/newheart-jongba/v4/capture':
                return self.respond(200,litto_newheart_jongba_v4.capture(body))
            if path=='/api/newheart-jongba/evaluate':
                return self.respond(200,litto_newheart_jongba_v42.evaluate(body))
            if path=='/api/newheart-jongba/save':
                return self.respond(200,litto_newheart_jongba_v3.save(body))
            if path=='/api/ai-debate':
                return self.respond(200,litto_debate.run(body,openai_litto_chat,litto_gemini.chat,_ai_tool_definitions(),_ai_tool_dispatch))
            if path=='/api/gemini-chat':
                # Preserve GPT's existing deterministic robot reservation intake.
                # Explicit trading commands use the SAME parser, account guards,
                # idempotency and reservation store as /api/ai-chat. This path
                # returns before any ChatGPT-model call, so Gemini API users do
                # not require a ChatGPT connection for robot reservations.
                gem_msg=str((body or {}).get('message') or '').strip()
                if re.search(r'(매수|매도|사줘|팔아줘|추매|익절)', gem_msg):
                    return self.respond(200,openai_litto_chat(body))
                # Gemini personality/memory is isolated from GPT's ai_brain.
                # Keep robot reservation intercept above unchanged.
                import litto_gemini_brain
                def _gemini_dispatch(name,args,ctx,actions):
                    if name=='litto_memory':
                        action=str(args.get('action') or 'search')
                        if action=='status':return litto_gemini_brain.status()
                        if action=='list':return {'memories':litto_gemini_brain.memories(max(1,min(30,int(args.get('limit') or 10))))}
                        if action=='search':return {'memories':litto_gemini_brain.recall(str(args.get('query') or ''),max(1,min(30,int(args.get('limit') or 8))))}
                        if action=='save':return litto_gemini_brain.remember(str(args.get('key') or ''),str(args.get('value') or ''),str(args.get('kind') or 'preference'))
                        if action=='delete':return litto_gemini_brain.forget(str(args.get('key') or ''),str(args.get('kind') or ''))
                    if name=='litto_get_ai_experience':return {'episodes':litto_gemini_brain.search_episodes(str(args.get('query') or ''),max(1,min(20,int(args.get('limit') or 6))))}
                    return _ai_tool_dispatch(name,args,ctx,actions)
                query=str(body.get('message') or '')
                memories=litto_gemini_brain.recall(query,6)
                gemini_body=dict(body)
                gemini_body['_persona_memory']=[{'key':m.get('mkey'),'value':m.get('value')} for m in memories]
                result=litto_gemini.chat(gemini_body, tool_definitions=_ai_tool_definitions(), tool_dispatch=_gemini_dispatch)
                try:litto_gemini_brain.log_episode(query,str(result.get('text') or ''),str(result.get('model') or ''),result.get('tools_used') or [],result.get('actions') or [],{})
                except Exception:pass
                return self.respond(200,result)
            if path=='/api/ai-chat':
                try:
                    return self.respond(200,openai_litto_chat(body))
                except Exception as e:
                    _ai_progress_set(str((body or {}).get('request_id') or ''),'오류','AI 처리 중 오류가 발생했어.',done=True,error=str(e))
                    raise
            with LOCK:
                # The heavy scanner runs in a background thread.  Keep local/UI
                # operations responsive while it is running.  Only operations
                # that would start another heavy scan or replace/disconnect the
                # Kiwoom client are blocked.
                scan_conflicts={'/api/scan','/api/connect','/api/disconnect','/api/demo','/api/import'}
                if STATE['busy'] and path in scan_conflicts and path!='/api/cancel':
                    return self.respond(409,{'error':'백그라운드 검색 중입니다. 이 작업은 검색 완료 후 다시 시도하세요.'})
                if path=='/api/ai-siwc-start':
                    return self.respond(200,siwc_start(self.server.server_port))
                if path=='/api/ai-siwc-signout':
                    return self.respond(200,siwc_signout())
                if path=='/api/ai-config':
                    return self.respond(200,siwc_status())
                if path=='/api/top5-performance/save':
                    return self.respond(200,top5_performance_save_snapshot(body))
                if path=='/api/littobot-performance/save':
                    return self.respond(200,littobot_performance_save(body))
                if path=='/api/littobot-evolve/approve':
                    return self.respond(200,ai_evolve.approve(littobot_performance_snapshot()))
                if path=='/api/littobot-evolve/reject':
                    return self.respond(200,ai_evolve.reject())
                if path=='/api/littobot-evolve/rollback':
                    return self.respond(200,ai_evolve.rollback())
                if path=='/api/intraday-market-flow/import':
                    return self.respond(200,intraday_market_flow_import_snapshot(body))
                if path=='/api/robot-reservations/create':
                    return self.respond(200,robot_reservations.create_order(body))
                if path=='/api/robot-reservations/cancel':
                    return self.respond(200,robot_reservations.cancel_order(body))
                if path=='/api/robot-reservations/hide-selected':
                    return self.respond(200,robot_reservations.hide_selected(body))
                if path=='/api/robot-reservations/cancel-all':
                    return self.respond(200,robot_reservations.cancel_all(body))
                if path=='/api/robot-reservations/split/create':
                    return self.respond(200,robot_reservations.create_split(body))
                if path=='/api/robot-reservations/split/preview':
                    return self.respond(200,robot_reservations.preview_split(body))
                if path=='/api/robot-reservations/preview':
                    return self.respond(200,robot_reservations.preview_quantity(body))
                if path=='/api/auto-buy/start':
                    return self.respond(200,auto_buy_start(body))
                elif path=='/api/auto-buy/cancel':
                    return self.respond(200,auto_buy_cancel(body))
                elif path=='/api/auto-buy/cancel-all':
                    return self.respond(200,auto_buy_cancel_all(body))
                elif path=='/api/auto-sell/start':
                    return self.respond(200,auto_sell_start(body))
                elif path=='/api/auto-sell/cancel':
                    return self.respond(200,auto_sell_cancel(body))
                elif path=='/api/auto-sell/cancel-all':
                    return self.respond(200,auto_sell_cancel_all(body))
                elif path=='/api/order/arm':
                    return self.respond(200,manual_order_arm(body))
                elif path=='/api/order/place':
                    return self.respond(200,manual_place_order(body))
                elif path=='/api/order/unfilled':
                    return self.respond(200,manual_unfilled_orders(body.get('code') or ''))
                elif path=='/api/order/cancel':
                    return self.respond(200,manual_cancel_order(body))
                elif path=='/api/order/cancel-all':
                    return self.respond(200,manual_cancel_all(body))
                elif path=='/api/journal/import':
                    result=journal_import_from_kiwoom(body.get('date'))
                    STATE['progress']=f"매매일지 자동수집 완료 · {result['date']} · {result['rows']}건"
                    return self.respond(200,{**result,'journal':journal.snapshot(ROOT,start=result['date'],end=result['date'],limit=500)})
                elif path=='/api/journal/review':
                    row=journal.update_review(ROOT,int(body.get('id')),body.get('review') or {})
                    return self.respond(200,{'row':row,'journal':journal.snapshot(ROOT,limit=500)})
                elif path=='/api/journal/manual':
                    row=journal.add_manual(ROOT,body.get('trade') or {})
                    return self.respond(200,{'row':row,'journal':journal.snapshot(ROOT,limit=500)})
                elif path=='/api/journal/delete':
                    journal.delete_trade(ROOT,int(body.get('id')))
                    return self.respond(200,{'ok':True,'journal':journal.snapshot(ROOT,limit=500)})
                elif path=='/api/journal/storage':
                    info=journal.set_storage_dir(ROOT,body.get('directory') or '',migrate=bool(body.get('migrate',True)))
                    return self.respond(200,{'ok':True,'storage':info,'journal':journal.snapshot(ROOT,limit=500)})
                elif path=='/api/journal/storage-reset':
                    info=journal.reset_storage_dir(ROOT,migrate=bool(body.get('migrate',True)))
                    return self.respond(200,{'ok':True,'storage':info,'journal':journal.snapshot(ROOT,limit=500)})
                elif path=='/api/journal/storage-confirm-default':
                    info=journal.confirm_default_storage(ROOT)
                    return self.respond(200,{'ok':True,'storage':info,'journal':journal.snapshot(ROOT,limit=500)})
                elif path=='/api/sectors':
                    incoming=sectors.parse(body['text']);mapping=sectors.load();mapping.update(incoming);sectors.save(mapping);sectors.apply(STATE['data'],mapping);_request_page1_recalc();STATE['progress']=f'섹터 {len(incoming)}개 적용 및 저장'
                elif path=='/api/theme-sync':
                    if not STATE.get('client'):raise ValueError('키움 API 연결 후 갱신하세요.')
                    with THEME_REFRESH_LOCK:
                        if THEME_REFRESH_STATE['busy']:raise ValueError('시장테마 갱신 진행 중입니다.')
                        THEME_REFRESH_STATE.update(busy=True,progress='시장테마 목록 조회 시작',done=0,total=0)
                    threading.Thread(target=market_theme_refresh_worker,daemon=True).start()
                    return self.respond(200,{'ok':True,'message':'시장테마 갱신을 별도 작업으로 시작했습니다.'})
                elif path=='/api/sector-sync':
                    if not STATE['client']:raise ValueError('키움 API 연결이 필요합니다.')
                    if STATE.get('sector_busy'):raise ValueError('이미 섹터 동기화 중입니다.')
                    threading.Thread(target=sector_sync_worker,daemon=True).start()
                    STATE['sector_progress']='전 종목 섹터 동기화 시작'
                elif path=='/api/sector':
                    c=code(body['code']); sector='/'.join(dict.fromkeys(p.strip() for p in str(body.get('sector','')).split('/') if p.strip()))[:100]
                    if not sector: raise ValueError('섹터명을 입력하세요.')
                    mapping=sectors.load()
                    mapping[c]={'sector':sector,'source':'사용자 직접 지정','asof':datetime.now(KST).date().isoformat()}
                    sectors.save(mapping)
                    # Apply immediately to all current stock rows and recompute panels.
                    for st in STATE['data'].get('stocks',[]):
                        if code(st.get('code'))==c:
                            st['sector']=sector;st['sector_source']='사용자 직접 지정 '+datetime.now(KST).date().isoformat()
                    _request_page1_recalc();STATE['progress']=f'{c} 사용자 섹터 저장: {sector}'
                elif path=='/api/demo':
                    STATE['data']=dataset();STATE['fetch_errors']=[];STATE['ranks']={'value_top':[],'change_top':[],'today_limit':[],'prev_limit':[],'source':'가상 예시'};recompute();STATE['progress']='가상 예시 불러옴'
                elif path=='/api/import':
                    data=parse_file(body['text'],body.get('kind','json'),body.get('asof') or None)
                    sectors.apply(data,sectors.load())
                    report=scan_dataset(data,STATE['settings'],STATE['market'])
                    if not report['results'] and not report['excluded_products']:raise ValueError('유효한 종목 없음: '+str(report['errors'][:3]))
                    STATE.update(data=data,report=report,fetch_errors=[],progress='시세 파일 분석 완료')
                elif path=='/api/settings':
                    new=config(body.get('settings'))
                    market=body.get('market','unknown')
                    if market not in ('unknown','weak','strong','mixed'):raise ValueError('장세 설정값 오류')
                    STATE['settings']=new;STATE['market']=market;recompute()
                elif path=='/api/review':
                    c=code(body['code']);found=False
                    for s in STATE['data']['stocks']:
                        if code(s['code'])==c:
                            rev=body.get('review',{})
                            if any(rev.get(k) is not None and type(rev.get(k)) is not bool for k in REVIEW_FIELDS):raise ValueError('확인값 오류')
                            rev={k:rev.get(k) for k in REVIEW_FIELDS}
                            rev['date']=max(b['date'] for b in s['daily'])
                            s['review']=rev
                            sector=str(body.get('sector','미분류'))[:80]
                            if sector and sector!='미분류' and sector!=s.get('sector'):
                                mapping=sectors.load();mapping[c]={'sector':sector,'source':'사용자 직접 지정','asof':rev['date']};sectors.save(mapping)
                            s['sector']=sector;found=True;break
                    if not found:raise ValueError('종목을 찾을 수 없습니다.')
                    recompute()
                elif path=='/api/connect':
                    appkey=body.get('appkey') or ''
                    secretkey=body.get('secretkey') or ''
                    if not appkey or not secretkey:
                        saved_app,saved_secret=_load_credentials()
                        appkey=appkey or saved_app or os.getenv('KIWOOM_APPKEY','')
                        secretkey=secretkey or saved_secret or os.getenv('KIWOOM_SECRETKEY','')
                    if not appkey or not secretkey:raise ValueError('App Key와 Secret Key를 입력하세요.')
                    client=Kiwoom(appkey,secretkey,body.get('mock',False))
                    client.auth()
                    if not client.mock:
                        try:_save_credentials(appkey,secretkey)
                        except Exception as e:raise ValueError('인증은 성공했지만 자동 로그인 저장에 실패했습니다: '+str(e))
                    STATE.update(client=client,connected=True,mock=client.mock,progress='키움 인증 성공 · 로그인 유지 설정 완료 · 아직 시세 검색 전',realtime_rank={'rows':[],'daily_rows':[],'updated_at':None,'source':'키움 ka00198 · 2초 확인','daily_source':'키움 ka00198 · 당일 누적','error':None},realtime_rank_prev={})
                    # Same daily guard as auto-login: first successful login only.
                    _start_daily_stock_master_refresh(client)
                    # First-use convenience: populate basic sectors automatically.
                    # Existing manual sectors remain authoritative.
                    try:
                        mapping=sectors.load()
                        mapped=sum(1 for v in mapping.values() if v.get('sector') and v.get('sector')!='미분류')
                        if mapped < 100 and not STATE.get('sector_busy'):
                            threading.Thread(target=sector_sync_worker,daemon=True).start()
                    except Exception:
                        pass
                    start_page1_live_engine()
                elif path=='/api/forget-credentials':
                    _delete_credentials();STATE['progress']='저장된 키움 인증정보 삭제 완료'
                elif path=='/api/disconnect':
                    old_client=STATE.get('client')
                    if old_client:
                        try:
                            f=getattr(old_client,'_domestic_realtime_feed',None)
                            if f:f.stop()
                        except Exception:
                            pass
                    stop_live_leader_engine()
                    stop_page1_live_engine()
                    STATE.update(client=None,connected=False,progress='키움 연결 해제 · 저장된 인증정보는 유지됨',realtime_rank={'rows':[],'daily_rows':[],'updated_at':None,'source':'키움 ka00198 · 2초 확인','daily_source':'키움 ka00198 · 당일 누적','error':'키움 미연결'},realtime_rank_prev={})
                elif path=='/api/formula-rank-limits':
                    raw=body.get('limits') or {}
                    cur=_formula_rank_limits()
                    for k in cur:
                        if k in raw:
                            try:v=int(raw[k])
                            except (TypeError,ValueError):raise ValueError(f'{k} 거래대금 순위는 숫자로 입력하세요.')
                            if not 1<=v<=50:raise ValueError(f'{k} 거래대금 순위는 1~50위까지 설정할 수 있습니다.')
                            cur[k]=v
                    with LOCK:
                        opts=copy.deepcopy(STATE.get('scan_options') or {'scope':'all','limit':100,'watchlist':''})
                        opts['formula_rank_limits']=cur
                        STATE['scan_options']=opts
                        ranks=STATE.get('ranks') or {}
                        ranks['formula_rank_limits']=cur
                        STATE['ranks']=ranks
                        if STATE.get('report'):
                            STATE['report']['search_panels']=search_panels.build(STATE['report'],ranks)
                    _save_page1_runtime_cache()
                    # Increasing a ceiling can require daily bars for newly admitted ranks.
                    # Start one normal background scan so the change becomes complete without altering formulas.
                    if STATE.get('client') and not STATE.get('busy'):
                        with LOCK:
                            STATE.update(busy=True,done=0,total=0,progress='거래대금 순위 변경 반영 중');STATE['cancel'].clear()
                            scan_opts=copy.deepcopy(STATE.get('scan_options') or {})
                        threading.Thread(target=live_worker,args=(scan_opts,),daemon=True).start()
                elif path=='/api/today-limit-value-min':
                    raw=body.get('value_eok')
                    try:v=int(raw)
                    except (TypeError,ValueError):raise ValueError('오늘의 상한가 거래대금 기준은 숫자로 입력하세요.')
                    if not 100<=v<=10000 or v%100!=0:
                        raise ValueError('오늘의 상한가 거래대금 기준은 100~10,000억원 범위에서 100억원 단위로 설정하세요.')
                    with LOCK:
                        opts=copy.deepcopy(STATE.get('scan_options') or {'scope':'all','limit':100,'watchlist':''})
                        opts['today_limit_min_eok']=v
                        STATE['scan_options']=opts
                        ranks=STATE.get('ranks') or {}
                        ranks['today_limit_min_eok']=v
                        STATE['ranks']=ranks
                        if STATE.get('report'):
                            STATE['report']['search_panels']=search_panels.build(STATE['report'],ranks)
                    _save_page1_runtime_cache()
                elif path=='/api/fzone-watchlist-sync':
                    # Watchlist is stored in the browser; explicitly sync its
                    # stock codes to the backend for F-zone eligibility only.
                    incoming=body.get('codes') or []
                    if not isinstance(incoming,list) or len(incoming)>500:
                        raise ValueError('관심종목 코드 형식 오류')
                    watched=[]
                    for item in incoming:
                        v=str(item or '').strip().upper()
                        if v.startswith('A'):v=v[1:]
                        if not (len(v)==6 and v.isdigit()):continue
                        if v not in watched:watched.append(v)
                    with LOCK:
                        changed=watched!=(STATE.get('fzone_watchlist') or [])
                        STATE['fzone_watchlist']=watched
                        (STATE.get('ranks') or {}).update({'fzone_watchlist_codes':list(watched)})
                    if changed:_request_page1_recalc()
                    return self.respond(200,{'ok':True,'count':len(watched),'changed':changed})
                elif path=='/api/scan':
                    if not STATE['client']:raise ValueError('키움 API 연결이 필요합니다.')
                    STATE['scan_options']={'scope':body.get('scope','all'),'limit':body.get('limit',100),'watchlist':body.get('watchlist',''),'formula_rank_limits':_formula_rank_limits(),'today_limit_min_eok':_today_limit_min_eok()}
                    STATE.update(busy=True,done=0,total=0,progress='검색 대상 조회 중');STATE['cancel'].clear()
                    threading.Thread(target=live_worker,args=(body,),daemon=True).start()
                elif path=='/api/cancel':STATE['cancel'].set();STATE['progress']='현재 종목 조회 후 중지합니다.'
                else:return self.respond(404,{'error':'없는 요청입니다.'})
            return self.respond(200,snapshot())
        except (ValueError,KeyError,TypeError,ApiError) as e:
            return self.respond(400,{'error':str(e)})

# Robot live worker: independent low-rate scheduling; no changes to manual or
# existing strategy workers. Execution requires previously approved reservations.
_ROBOT_RUN_LOCK=threading.RLock()
_ROBOT_LAST_QUOTES={}
_ROBOT_ACTIVATED_AT=None

def _robot_activate_new_orders_only():
    """Durable activation fence: never execute pre-upgrade pending reservations."""
    from pathlib import Path
    root=Path(os.environ.get('LOCALAPPDATA') or (Path.home() / 'AppData' / 'Local')) / 'LITTO' / 'robot'
    root.mkdir(parents=True,exist_ok=True)
    marker=root / 'live_orders_activation_R5.txt'
    if not marker.exists():
        # Exclusive creation prevents overwriting the original activation time.
        try:
            with marker.open('x',encoding='utf-8') as f:
                f.write(datetime.now(KST).isoformat(timespec='microseconds'))
                f.flush();os.fsync(f.fileno())
        except FileExistsError:pass
    stamp=datetime.fromisoformat(marker.read_text(encoding='utf-8').strip())
    if stamp.tzinfo is None:raise ValueError('로봇 활성화 시각의 시간대가 없습니다.')
    return stamp.astimezone(KST)


def _robot_broker_quote(code):
    client=_manual_order_client()
    # A fresh broker request, not the browser's last displayed/cached quote.
    venue='KRX' if bool(getattr(client,'mock',False)) else 'SOR'
    book=_kiwoom_call(client.domestic_orderbook,code,venue,kind='order')
    if not isinstance(book,dict):raise ValueError('실시간 호가 요청 실패')
    def prices(key):
        out=[]
        for v in book.get(key) or []:
            try:p=int(abs(float((v or {}).get('price') or 0)))
            except (ValueError,TypeError):continue
            if p>0:out.append(p)
        return out
    asks=prices('asks');bids=prices('bids')
    if not asks or not bids:raise ValueError('매수/매도 1호가 수신 실패')
    return {'ask':min(asks),'bid':max(bids),'current':int(abs(float(book.get('current_price') or 0))),
            'venue':venue,'sample_time':time.time()}

def _robot_cash_available(client):
    """Broker cash inquiry, fail closed if official orderable amount is absent."""
    client.auth()
    data,_=_kiwoom_call(client._post,'/api/dostk/acnt',{'qry_tp':'2'},
        {'authorization':'Bearer '+client.token,'api-id':'kt00001'},kind='account')
    # Different Kiwoom account types can expose different fields. Only the
    # explicit orderable-cash value is acceptable; never use total assets.
    for key in ('ord_psbl_amt','ord_alow_amt'):
        raw=data.get(key)
        if raw is None or str(raw).strip()=='':continue
        try:
            value=int(str(raw).strip().replace(',',''))
            if value>=0:return value
        except (ValueError,TypeError):pass
    raise ValueError('키움 주문가능금액을 확인할 수 없어 매수를 차단했습니다.')


def _robot_preflight(row, shares, price):
    client=_manual_order_client()
    if getattr(client,'mock',False):
        raise ValueError('모의계좌는 실전 로봇매매 대상이 아닙니다.')
    code=base_code(row['code'])
    shares=int(shares);price=int(price)
    if shares<=0 or price<=0 or shares>1000000:
        raise ValueError('잘못된 주문 수량 또는 가격')
    snap=_account_status_snapshot(force=True)
    if not snap.get('connected') or snap.get('mock') or not snap.get('account_no'):
        raise ValueError('실계좌 상태를 확인할 수 없습니다.')
    # Refuse all trades if broker open-order feed is unavailable. Prevent
    # silent overspending/overselling via stale local snapshots.
    pending=manual_unfilled_orders(code)
    if not isinstance(pending.get('rows'),list):raise ValueError('미체결 조회 실패')
    if row['side']=='buy':
        avail=_robot_cash_available(client)
        if shares*price>avail:
            raise ValueError('주문금액이 키움 주문가능금액을 초과합니다.')
    else:
        guard=_auto_sell_account_guard(code,force=True)
        if shares>guard['safe_available']:
            raise ValueError('보유·미체결 반영 매도가능수량 초과')
    return client


def _robot_submit(row, quote, shares, price, tag):
    # Do not arm/disarm the MANUAL trading panel from a background worker.
    # The reservation claim is durably saved before this function is called.
    req='robot-'+row['id']+'-'+str(tag)
    with _ROBOT_RUN_LOCK:
        client=_robot_preflight(row,shares,price)
        _manual_order_once(req)
        result=_kiwoom_call(client.manual_cash_order,row['side'],row['code'],
            int(shares),int(price),'limit','SOR',kind='order')
        try:
            ACCOUNT_STATUS_CACHE['ts']=0.0
            ACCOUNT_REALIZED_CACHE['ts']=0.0
        except Exception:pass
        return {**result,'request_id':req,'submitted_at':datetime.now(KST).isoformat()}

def _robot_live_worker():
    while True:
        try:
            now=datetime.now(KST)
            active=robot_reservations.eligible(now)
            # Avoid any polling or API load with no live reservations.
            for row in active:
                # Ignore all reservations created before this installation's
                # activation fence. Keep records intact for user review.
                if _ROBOT_ACTIVATED_AT is None:continue
                try:
                    created=datetime.fromisoformat(row.get('created_at') or '')
                    if created.tzinfo is None or created.astimezone(KST)<=_ROBOT_ACTIVATED_AT:continue
                except (ValueError,TypeError):continue
                is_cost=row.get('kind')=='cost_trigger'
                is_price=row.get('kind')=='price_trigger'
                is_split=row.get('kind')=='split'
                if is_split:
                    steps=[(idx,x) for idx,x in enumerate(row['steps']) if x.get('status')=='waiting' and int(x.get('shares') or 0)>0]
                    if not steps:continue
                elif not (is_cost or is_price):
                    try:when=datetime.fromisoformat(row['when']).astimezone(KST)
                    except Exception:robot_reservations.expire(row['id'],'예약 시각 오류');continue
                    if now<when:continue
                    if (now-when).total_seconds()>20:
                        robot_reservations.expire(row['id'],'실행 시각 20초 경과: 추격 주문 금지');continue
                # Don't send orders outside scheduled market hours, even if the clock is due.
                if not (8<=now.hour<20):
                    if not is_split and not is_cost and not is_price:robot_reservations.expire(row['id'],'매매 가능 시간(08~20시) 외 주문 보류')
                    continue
                # Keep one quote request per candidate only when relevant.
                try:quote=_robot_broker_quote(row['code'])
                except Exception:
                    # No quote -> no order. Only short time-based jobs expire at T+20s.
                    continue
                px=quote['ask'] if row['side']=='buy' else quote['bid']
                if px<=0:continue
                if is_price:
                    target=int(row.get('target_price') or 0)
                    if target<=0:continue
                    # Use executable book-side price, never last traded / stale display price.
                    if (row['side']=='buy' and px>target) or (row['side']=='sell' and px<target):continue
                    qty=int(row.get('value') or 0)
                    if qty<1:continue
                    claimed=robot_reservations.claim(row['id'])
                    if not claimed:continue
                    try:
                        # Limit submitted at executable best quote, capped by user's target.
                        result=_robot_submit(row,quote,qty,px,'target')
                        robot_reservations.settle(row['id'],result,None,True)
                    except Exception as e:
                        robot_reservations.settle(row['id'],{'error':str(e)[:400]},None,False)
                    continue
                if is_cost:
                    target=float(row.get('target_price') or 0)
                    if target<=0:continue
                    if not ((row['side']=='buy' and px<=target) or (row['side']=='sell' and px>=target)):
                        # Never treat last traded price as an executable quote.
                        # Keep pending to avoid buying above the user's target
                        # or selling below it. Log this at most once a minute.
                        diag=_ROBOT_LAST_QUOTES.get(row['id']) or 0.0
                        if time.monotonic()-diag>=60.0:
                            _ROBOT_LAST_QUOTES[row['id']]=time.monotonic()
                            print('[robot] 조건 대기',row.get('code'),row.get('id'),
                                  '매도1호가' if row['side']=='buy' else '매수1호가',
                                  px,'목표',round(target,2),flush=True)
                        continue
                    unit=row.get('unit');val=int(row.get('value') or 0)
                    if unit=='shares':qty=val
                    elif unit=='amount':qty=val//px
                    elif unit=='holding_percent' and row['side']=='sell':
                        guard=_auto_sell_account_guard(row['code'],force=True)
                        qty=int(guard.get('safe_available') or 0)*val//100
                    else:continue
                    if qty<1:continue
                    claimed=robot_reservations.claim(row['id'])
                    if not claimed:continue
                    try:
                        result=_robot_submit(row,quote,qty,px,'cost')
                        robot_reservations.settle(row['id'],result,None,True)
                    except Exception as e:
                        robot_reservations.settle(row['id'],{'error':str(e)[:400]},None,False)
                    continue
                if is_split:
                    for idx,step in steps:
                        target=int(step['price'])
                        if not ((row['side']=='buy' and px<=target) or (row['side']=='sell' and px>=target)):continue
                        count=int(step.get('shares') or 0)
                        if count<=0:continue
                        claimed=robot_reservations.claim(row['id'],idx)
                        if not claimed:continue
                        try:
                            result=_robot_submit(row,quote,count,px,idx)
                            robot_reservations.settle(row['id'],result,idx,True)
                        except Exception as e:
                            robot_reservations.settle(row['id'],{'error':str(e)[:400]},idx,False)
                        # One stage per tick to avoid bursts and permit account updates.
                        break
                else:
                    limit=int(row['price_limit'])
                    if (row['side']=='buy' and px>limit) or (row['side']=='sell' and px<limit):continue
                    qty=(int(row['value'])//px if row['unit']=='amount' else int(row['value']))
                    if qty<1:robot_reservations.expire(row['id'],'예약 금액으로 1주도 주문할 수 없음');continue
                    claimed=robot_reservations.claim(row['id'])
                    if not claimed:continue
                    try:
                        result=_robot_submit(row,quote,qty,px,'once')
                        robot_reservations.settle(row['id'],result,None,True)
                    except Exception as e:
                        robot_reservations.settle(row['id'],{'error':str(e)[:400]},None,False)
        except Exception as e:
            try:print('[robot]',str(e)[:240],flush=True)
            except Exception:pass
        time.sleep(3)


def main():
    parser=argparse.ArgumentParser();parser.add_argument('--port',type=int,default=8765);parser.add_argument('--no-browser',action='store_true');a=parser.parse_args()
    try:server=LittoBoundedHTTPServer(('127.0.0.1',a.port),Handler)
    except OSError:
        print('포트 사용 중입니다. 기존 실행 창을 닫거나 python app.py --port 8766 으로 실행하세요.');return
    url=f'http://127.0.0.1:{server.server_port}'
    print(f'LITTO Trading System v{LITTO_VERSION} | '+url+' | 종료: Ctrl+C')
    # Restore the saved Kiwoom session BEFORE opening the browser.
    # This makes restart/login behavior deterministic instead of racing the UI.
    _startup_auto_connect()
    # Explicit AI-approved NEW reservations only; preserve older reservations
    # without automatically submitting them after an upgrade.
    global _ROBOT_ACTIVATED_AT
    try:
        _ROBOT_ACTIVATED_AT=_robot_activate_new_orders_only()
        os.environ['LITTO_ROBOT_LIVE_ENABLED']='1'
        threading.Thread(target=_robot_live_worker,daemon=True,name='LITTO-ROBOT-LIVE').start()
        print('[robot] LIVE enabled for reservations created AFTER',_ROBOT_ACTIVATED_AT.isoformat(),flush=True)
    except Exception as exc:
        os.environ['LITTO_ROBOT_LIVE_ENABLED']='0'
        print('[robot] LIVE unavailable:',str(exc)[:300],flush=True)
    if not a.no_browser:threading.Timer(.35,lambda:webbrowser.open(url)).start()
    _ensure_intraday_market_flow_collector()
    _start_market_theme_refresh_if_stale()
    try:server.serve_forever()
    except KeyboardInterrupt:STATE['cancel'].set();server.server_close()

# Market cap metadata is loaded only by on-demand stock-action popup requests.
LITTO_MARKET_CAP_LOCK=threading.Lock()
LITTO_MARKET_CAP_CACHE={}
LITTO_MARKET_CAP_TASKS={}
LITTO_CAP_RANK_CACHE={}  # Only fill from a complete, verified market-wide ranking.

if __name__=='__main__':main()

