"""Newheart v4: KST timed read-only TOP5 evidence, no orders/provider calls."""
import json, os, tempfile, threading, re
from pathlib import Path
from datetime import datetime
from zoneinfo import ZoneInfo
import litto_newheart_jongba_v3 as v3

KST=ZoneInfo('Asia/Seoul')
FILE=Path(__file__).resolve().parent/'data'/'newheart_jongba_evidence_v4.json'
LOCK=threading.RLock()
SLOTS=('15:20','15:29')

def classify_market(clock, venue=None):
    """Time alone cannot identify venue during overlapping KRX/NXT main hours."""
    venue=str(venue or '').upper().strip()
    if venue not in ('KRX','NXT'):return '거래소 미확인'
    if venue=='KRX':
        if '09:00'<=clock<'15:30':return 'KRX 정규장'
        if '15:40'<=clock<'16:00':return 'KRX 시간외종가'
        if '16:00'<=clock<'20:00':return 'KRX 애프터마켓'
        return 'KRX 비거래시간'
    if '08:00'<=clock<'08:50':return 'NXT 프리마켓'
    if '09:00'<=clock<'15:20':return 'NXT 메인마켓 (시작 09:00:30)'
    if '15:40'<=clock<'20:00':return 'NXT 애프터마켓'
    return 'NXT 비거래시간'

def _load():
    try:
        with FILE.open(encoding='utf-8') as stream: data=json.load(stream)
        return data if isinstance(data,list) else []
    except (OSError,ValueError):return []

def _atomic(rows):
    FILE.parent.mkdir(parents=True,exist_ok=True)
    fd,tmp=tempfile.mkstemp(prefix='.newheart_v4_',suffix='.tmp',dir=str(FILE.parent))
    try:
        with os.fdopen(fd,'w',encoding='utf-8') as stream:
            json.dump(rows,stream,ensure_ascii=False,separators=(',',':'))
            stream.flush();os.fsync(stream.fileno())
        os.replace(tmp,FILE)
    finally:
        if os.path.exists(tmp):os.unlink(tmp)

def capture(payload, now=None):
    now=(now or datetime.now(KST)).astimezone(KST)
    if now.weekday()>=5 or now.strftime('%H:%M') not in SLOTS:
        return {'ok':False,'saved':False,'reason':'예약된 한국시간(15:20/15:29) 정규 요일에만 수집'}
    if not isinstance(payload,dict):raise ValueError('payload는 객체여야 합니다')
    top5=payload.get('top5')
    if not isinstance(top5,list) or not top5:
        return {'ok':False,'saved':False,'reason':'TOP5 캐시 없음: 증거 생성 불가'}
    normalized=[];seen=set()
    for i,row in enumerate(top5[:5],1):
        if not isinstance(row,dict):continue
        code=str(row.get('code') or '').strip().removeprefix('A')
        if not re.fullmatch(r'\d{6}',code) or code in seen:continue
        seen.add(code)
        normalized.append({'rank':i,'code':code,'name':str(row.get('name') or code)[:80],
            'sector':str(row.get('sector') or '')[:80], 'score':row.get('score'),
            'price':row.get('price'), 'change':row.get('change'),
            'venue':str(row.get('venue') or '').upper() if row.get('venue') in ('KRX','NXT') else '미확인',
            'market_session':classify_market(now.strftime('%H:%M'),row.get('venue')),
            'orderbook':'미확인 (호가 스냅샷 제공되지 않음)',
            'chart':'미확인 (해당 시점 분봉 미전달)'})
    if not normalized:return {'ok':False,'saved':False,'reason':'유효한 종목코드 없음'}
    day=now.date().isoformat();slot=now.strftime('%H:%M')
    # server clock is authoritative; never trust client claimed capture time
    record={'id':day+'_'+slot.replace(':',''),'trade_date':day,'slot':slot,
        'captured_at':now.isoformat(),'source':'브라우저 기존 TOP5 메모리 캐시 (키움 추가조회 없음)',
        'source_asof':str(payload.get('source_asof') or '')[:40],
        'market_venue_policy':'KRX/NXT 거래소 식별자가 없으면 분리 확정하지 않음',
        'read_only':True,'stock_count':len(normalized),'top5':normalized,
        'decision':'증거 저장만 완료 · 매수 판정 아님'}
    with LOCK:
        rows=_load()
        if any(x.get('id')==record['id'] for x in rows):
            return {'ok':True,'saved':False,'duplicate':True,'id':record['id']}
        rows.append(record);_atomic(rows[-1000:])
    return {'ok':True,'saved':True,'id':record['id'],'count':len(normalized)}

def history():
    with LOCK:rows=_load()
    return {'ok':True,'count':len(rows),'rows':rows[-100:][::-1],
      'note':'실제 수집된 시각의 기존 캐시만 기록. 미실행 시각을 소급 생성하지 않음.'}


def evidence_for(code, trade_date):
    """Read-only lookup: only actual captured TOP5; never reconstruct historic rank."""
    code=str(code or '').removeprefix('A').split('_')[0]
    with LOCK: rows=_load()
    found=[]
    for rec in rows:
        if rec.get('trade_date')!=trade_date:continue
        for item in rec.get('top5',[]):
            if str(item.get('code'))==code:
                found.append({'slot':rec.get('slot'),'captured_at':rec.get('captured_at'),
                    'rank':item.get('rank'),'score':item.get('score'),
                    'source_asof':rec.get('source_asof'),'venue':item.get('venue')})
    return sorted(found,key=lambda x:x.get('slot') or '')
