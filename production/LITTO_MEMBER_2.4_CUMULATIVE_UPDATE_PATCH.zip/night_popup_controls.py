"""Native controls for the LITTO night chart WebView window.

A local WinForms button, never a script injected into the third-party page.
"""
from __future__ import annotations
import os
import threading

_button = None
_handlers = []


def _on_ui(control, cb):
    import System
    if control.InvokeRequired:
        control.BeginInvoke(System.Action(cb))
    else:
        cb()


def update_label(popup, embedded):
    if os.name != 'nt':
        return
    global _button
    btn = _button
    if btn is None:
        return
    try:
        def update():
            if not btn.IsDisposed:
                btn.Text = '↗ 라이또 밖으로' if embedded else '↙ 라이또 안으로'
                btn.Enabled = True
                btn.BringToFront()
        _on_ui(btn, update)
    except Exception:
        return


def install(popup, on_toggle, logger):
    if os.name != 'nt':
        return
    try:
        form = popup.native
        if form is None or form.IsDisposed:
            return
        def add():
            global _button
            try:
                import System.Windows.Forms as Forms
                import System.Drawing as Drawing
                from night_embedded import is_embedded
                if form.IsDisposed:
                    return
                if _button is not None and not _button.IsDisposed and _button.Parent == form:
                    return
                btn = Forms.Button()
                btn.Text = '↗ 라이또 밖으로' if is_embedded() else '↙ 라이또 안으로'
                btn.Width, btn.Height = 146, 30
                btn.Left = max(4, int(form.ClientSize.Width) - 158)
                btn.Top = 5
                btn.Anchor = Forms.AnchorStyles.Top | Forms.AnchorStyles.Right
                btn.BackColor = Drawing.Color.FromArgb(19, 49, 74)
                btn.ForeColor = Drawing.Color.White
                btn.FlatStyle = Forms.FlatStyle.Flat
                btn.FlatAppearance.BorderColor = Drawing.Color.FromArgb(80, 128, 170)
                btn.TabStop = False
                btn.Cursor = Forms.Cursors.Hand
                def clicked(sender, args):
                    btn.Enabled = False
                    def run():
                        try:
                            status = on_toggle()
                            if status == 'external': update_label(popup, False)
                            elif status == 'internal': update_label(popup, True)
                            else: update_label(popup, is_embedded())
                        except Exception as exc:
                            logger('Night mode button failed: ' + str(exc))
                            update_label(popup, is_embedded())
                    threading.Thread(target=run, daemon=True, name='NightWindowToggle').start()
                btn.Click += clicked
                _handlers.append(clicked)
                form.Controls.Add(btn)
                btn.BringToFront()
                _button = btn
            except Exception as exc:
                logger('Night controls unavailable: ' + str(exc))
        _on_ui(form, add)
    except Exception as exc:
        logger('Night control setup skipped: ' + str(exc))
