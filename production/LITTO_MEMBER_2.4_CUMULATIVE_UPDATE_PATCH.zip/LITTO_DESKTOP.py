from __future__ import annotations

import os
import sys
import time
import socket
import subprocess
import urllib.request
import traceback
import json
import threading
from pathlib import Path

PORT = 8874
HOST = '127.0.0.1'
URL = f'http://{HOST}:{PORT}/'
BASE = Path(__file__).resolve().parent
DESKTOP_LOG = BASE / 'LITTO_DESKTOP.log'
STARTUP_LOG = BASE / 'LITTO_STARTUP.log'
LAUNCHED_BY_EXE = os.environ.get('LITTO_LAUNCHED_BY_EXE') == '1'


def append_startup_log(text: str) -> None:
    try:
        with STARTUP_LOG.open('a', encoding='utf-8') as f:
            f.write(f'[{time.strftime("%Y-%m-%d %H:%M:%S")}] {text}\n')
    except Exception:
        pass


def port_open(host: str, port: int) -> bool:
    try:
        with socket.create_connection((host, port), timeout=0.35):
            return True
    except OSError:
        return False


def http_ready(url: str) -> bool:
    try:
        with urllib.request.urlopen(url, timeout=0.7) as r:
            return 200 <= getattr(r, 'status', 200) < 500
    except Exception:
        return False


def show_error(message: str) -> None:
    # When launched by LITTO.exe, the EXE presents one consolidated popup
    # after collecting the traceback. Direct script execution still gets a popup.
    if LAUNCHED_BY_EXE:
        return
    try:
        import tkinter as tk
        from tkinter import messagebox
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror('LITTO Trading System v2.4 MEMBER', message)
        root.destroy()
    except Exception:
        print(message)


def desktop_log_tail(lines: int = 12) -> str:
    try:
        raw = DESKTOP_LOG.read_text(encoding='utf-8', errors='replace').splitlines()
        return '\n'.join(raw[-lines:])
    except Exception:
        return ''


def start_backend():
    app_py = BASE / 'app.py'
    if not app_py.exists():
        raise FileNotFoundError('app.py 파일을 찾을 수 없습니다.')

    if http_ready(URL):
        append_startup_log('Existing LITTO backend detected; reusing it.')
        return None, False

    if port_open(HOST, PORT):
        raise RuntimeError(f'포트 {PORT}이 사용 중이지만 LITTO 서버 응답이 없습니다. 이미 실행 중인 프로세스를 확인해 주세요.')

    flags = getattr(subprocess, 'CREATE_NO_WINDOW', 0) if os.name == 'nt' else 0
    log_fp = open(DESKTOP_LOG, 'a', encoding='utf-8', buffering=1)
    log_fp.write(f'\n[{time.strftime("%Y-%m-%d %H:%M:%S")}] desktop backend start\n')
    proc = subprocess.Popen(
        [sys.executable, str(app_py), '--port', str(PORT), '--no-browser'],
        cwd=str(BASE),
        stdout=log_fp,
        stderr=subprocess.STDOUT,
        creationflags=flags,
    )

    deadline = time.time() + 30
    while time.time() < deadline:
        if proc.poll() is not None:
            log_fp.flush()
            tail = desktop_log_tail()
            extra = f'\n\n서버 로그:\n{tail}' if tail else ''
            raise RuntimeError('LITTO 서버가 시작 중 종료되었습니다.' + extra)
        if http_ready(URL):
            append_startup_log('LITTO backend ready.')
            return (proc, log_fp), True
        time.sleep(0.25)

    try:
        proc.terminate()
    except Exception:
        pass
    tail = desktop_log_tail()
    extra = f'\n\n서버 로그:\n{tail}' if tail else ''
    raise TimeoutError('LITTO 서버 시작 시간이 30초를 초과했습니다.' + extra)


def stop_backend(handle):
    if not handle:
        return
    proc, log_fp = handle
    try:
        proc.terminate()
        proc.wait(timeout=4)
    except Exception:
        try:
            proc.kill()
        except Exception:
            pass
    try:
        log_fp.close()
    except Exception:
        pass



class NightFuturesWindowAPI:
    """Windowed site view (not iframe): persist size/position, bound to LITTO lifetime.

    Never inject scripts into or scrape the third-party site.
    """

    CONFIG = BASE / 'LITTO_NIGHT_WINDOW.json'
    DEFAULT = {'x': 120, 'y': 100, 'width': 960, 'height': 700}

    def __init__(self):
        self._night_window = None
        self._lock = threading.RLock()
        self._geometry = self._read_geometry()
        self._last_write = 0.0
        self._closing = False
        self._popup_embedded = False

    @classmethod
    def _read_geometry(cls):
        try:
            data = json.loads(cls.CONFIG.read_text(encoding='utf-8'))
            if not isinstance(data, dict):
                raise ValueError('Invalid geometry')
            values = dict(cls.DEFAULT)
            for field in values:
                if isinstance(data.get(field), (int, float)) and not isinstance(data[field], bool):
                    values[field] = int(data[field])
            values['width'] = max(500, min(3000, values['width']))
            values['height'] = max(370, min(2200, values['height']))
            values['x'] = max(-3000, min(12000, values['x']))
            values['y'] = max(-3000, min(12000, values['y']))
            return values
        except (OSError, ValueError, TypeError):
            return dict(cls.DEFAULT)

    def _save_geometry(self, force=False):
        now = time.monotonic()
        with self._lock:
            if not force and now - self._last_write < 0.8:
                return
            self._last_write = now
            state = dict(self._geometry)
        try:
            tmp = self.CONFIG.with_suffix('.json.tmp')
            tmp.write_text(json.dumps(state, ensure_ascii=False, indent=2), encoding='utf-8')
            os.replace(tmp, self.CONFIG)
        except OSError as exc:
            append_startup_log(f'Night window geometry save error: {exc}')

    def _on_moved(self, x, y):
        if self._popup_embedded:
            return
        with self._lock:
            self._geometry['x'] = int(x)
            self._geometry['y'] = int(y)
        self._save_geometry()

    def _on_resized(self, width, height):
        with self._lock:
            if not self._popup_embedded:
                self._geometry['width'] = max(500, int(width))
            if not self._popup_embedded:
                self._geometry['height'] = max(370, int(height))
            popup = self._night_window
        self._save_geometry()
        # Only the night-site WebView changes zoom and focus viewport; LITTO main UI is untouched.
        if popup is not None:
            from night_autoscale import apply_zoom
            apply_zoom(popup, width, height, append_startup_log)

    def _on_night_shown(self):
        with self._lock:
            popup = self._night_window
            geometry = dict(self._geometry)
        if popup is not None:
            from night_autoscale import apply_zoom
            apply_zoom(popup, geometry['width'], geometry['height'], append_startup_log)
            try:
                from night_popup_controls import install
                install(popup, self.toggle_night_futures_mode, append_startup_log)
            except Exception as exc:
                append_startup_log(f'Night popup toolbar warning: {exc}')

    def _on_closed(self):
        self._save_geometry(force=True)
        with self._lock:
            self._night_window = None
            self._popup_embedded = False

    def open_night_futures_window(self):
        import webview
        with self._lock:
            if self._closing:
                return 'app-closing'
            existing = self._night_window
            if existing is not None and existing in webview.windows:
                try:
                    existing.show()
                    existing.restore()
                except Exception as exc:
                    append_startup_log(f'Night window focus warning: {exc}')
                return 'already-open'
            geometry = dict(self._geometry)
            self._night_window = webview.create_window(
                'LITTO | 코스피200 야간선물',
                'https://sonmul.co.kr/futures/KOSPI200_NIGHT',
                x=geometry['x'], y=geometry['y'],
                width=geometry['width'], height=geometry['height'],
                min_size=(500, 370), resizable=True,
                text_select=True,
            )
            popup = self._night_window
            popup.events.moved += self._on_moved
            popup.events.resized += self._on_resized
            popup.events.shown += self._on_night_shown
            popup.events.closed += self._on_closed
            # Experimental internal WebView2: no main window object in js_api.
            # If Win32 embedding fails, the fully working standalone window remains.
            if os.name == 'nt':
                def try_embed():
                    try:
                        from night_embedded import embed_when_ready
                        result = embed_when_ready(append_startup_log)
                        with self._lock:
                            self._popup_embedded = bool(result)
                        try:
                            from night_popup_controls import update_label
                            update_label(popup, bool(result))
                        except Exception:
                            pass
                    except Exception as exc:
                        append_startup_log(f'Night embed fallback: {exc}')
                threading.Thread(target=try_embed, daemon=True, name='LittoNightEmbed').start()
        return 'opened'

    def toggle_night_futures_mode(self):
        """Native Win32 internal/external toggle; no reload or duplicate page."""
        import webview
        if os.name != 'nt':
            return 'unsupported'
        with self._lock:
            popup = self._night_window
            if popup is None or popup not in webview.windows:
                return 'not-open'
            geometry = dict(self._geometry)
            from night_embedded import is_embedded, embed_when_ready, detach_to_desktop
            try:
                if is_embedded():
                    success = detach_to_desktop(append_startup_log, geometry)
                    if success:
                        self._popup_embedded = False
                    return 'external' if success else 'failed'
                success = embed_when_ready(append_startup_log, timeout=2.0)
                if success:
                    self._popup_embedded = True
                return 'internal' if success else 'failed'
            except Exception as exc:
                append_startup_log(f'Night window toggle error: {exc}')
                return 'failed'

    def close_night_window(self, *args, **kwargs):
        with self._lock:
            self._closing = True
            popup = self._night_window
        self._save_geometry(force=True)
        if popup is not None:
            try:
                popup.destroy()
            except Exception as exc:
                append_startup_log(f'Night window close warning: {exc}')


def main() -> int:
    try:
        import webview
    except Exception as e:
        msg = f'pywebview를 불러오지 못했습니다: {e}'
        append_startup_log(msg)
        show_error(msg)
        return 2

    backend = None
    started_by_us = False
    try:
        backend, started_by_us = start_backend()
        append_startup_log('Opening LITTO desktop window.')
        night_api = NightFuturesWindowAPI()
        window = webview.create_window(
            'LITTO Trading System v2.4 MEMBER',
            URL,
            js_api=night_api,
            width=1600,
            height=960,
            min_size=(1100, 700),
            resizable=True,
            fullscreen=False,
            text_select=True,
            confirm_close=False,
        )
        window.events.closing += night_api.close_night_window

        def start_maximized():
            try:
                window.maximize()
            except Exception:
                pass

        webview.start(start_maximized, gui='edgechromium', debug=False, private_mode=False)
        append_startup_log('Desktop window closed normally.')
        return 0
    except Exception as e:
        tb = traceback.format_exc()
        append_startup_log('DESKTOP ERROR:\n' + tb)
        show_error(str(e))
        return 1
    finally:
        if started_by_us:
            stop_backend(backend)


if __name__ == '__main__':
    raise SystemExit(main())
