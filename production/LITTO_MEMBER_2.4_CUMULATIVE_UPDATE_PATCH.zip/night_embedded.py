"""Experimental Win32 child WebView host for LITTO desktop (Windows only).

The third-party page is a normal top-level WebView navigation, not an iframe.
No network interception, script injection, or change to security headers.
On any native window error, leave the original independent window intact.
"""
from __future__ import annotations

import ctypes
import os
import threading
import time
from ctypes import wintypes

MAIN_TITLE = 'LITTO Trading System v2.4 MEMBER'
NIGHT_TITLE = 'LITTO | 코스피200 야간선물'

# Window styles from WinUser.h
GWL_STYLE = -16
WS_CHILD = 0x40000000
WS_POPUP = 0x80000000
WS_CAPTION = 0x00C00000
WS_THICKFRAME = 0x00040000
WS_SYSMENU = 0x00080000
SWP_NOZORDER = 0x0004
SWP_FRAMECHANGED = 0x0020


def embed_when_ready(logger, timeout=12.0):
    """Best-effort attach to LITTO main HWND. Never raises to the app."""
    if os.name != 'nt':
        logger('Embedded WebView2 only supported on Windows; using normal window')
        return False
    try:
        user32 = ctypes.WinDLL('user32', use_last_error=True)
        user32.FindWindowW.argtypes = [wintypes.LPCWSTR, wintypes.LPCWSTR]
        user32.FindWindowW.restype = wintypes.HWND
        user32.SetParent.argtypes = [wintypes.HWND, wintypes.HWND]
        user32.SetParent.restype = wintypes.HWND
        user32.GetWindowLongW.argtypes = [wintypes.HWND, ctypes.c_int]
        user32.GetWindowLongW.restype = ctypes.c_long
        user32.SetWindowLongW.argtypes = [wintypes.HWND, ctypes.c_int, ctypes.c_long]
        user32.SetWindowLongW.restype = ctypes.c_long
        user32.GetClientRect.argtypes = [wintypes.HWND, ctypes.POINTER(wintypes.RECT)]
        user32.GetClientRect.restype = wintypes.BOOL
        user32.SetWindowPos.argtypes = [wintypes.HWND, wintypes.HWND, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, wintypes.UINT]
        user32.SetWindowPos.restype = wintypes.BOOL
        deadline = time.monotonic() + timeout
        main = popup = None
        while time.monotonic() < deadline:
            main = user32.FindWindowW(None, MAIN_TITLE)
            popup = user32.FindWindowW(None, NIGHT_TITLE)
            if main and popup and main != popup:
                break
            time.sleep(0.15)
        else:
            logger('Embedded WebView2 window handles not found; original window retained')
            return False
        rc = wintypes.RECT()
        if not user32.GetClientRect(main, ctypes.byref(rc)):
            logger('GetClientRect failed; original window retained')
            return False
        cw, ch = rc.right-rc.left, rc.bottom-rc.top
        if cw < 740 or ch < 560:
            logger('Main LITTO window is too small; original window retained')
            return False
        # Keep original geometry/style for rollback on any failure.
        original_style = user32.GetWindowLongW(popup, GWL_STYLE)
        new_style = (original_style | WS_CHILD | WS_CAPTION | WS_THICKFRAME | WS_SYSMENU) & ~WS_POPUP
        ctypes.set_last_error(0)
        user32.SetWindowLongW(popup, GWL_STYLE, new_style)
        if ctypes.get_last_error() != 0:
            logger('SetWindowLong failed; original window retained')
            user32.SetWindowLongW(popup, GWL_STYLE, original_style)
            return False
        ctypes.set_last_error(0)
        old_parent = user32.SetParent(popup, main)
        error = ctypes.get_last_error()
        if not old_parent and error:
            user32.SetWindowLongW(popup, GWL_STYLE, original_style)
            logger(f'SetParent failed ({error}); original window retained')
            return False
        width = min(950, cw-50)
        height = min(700, ch-85)
        x = max(12, (cw-width)//2)
        y = max(12, (ch-height)//2)
        if not user32.SetWindowPos(popup, None, x, y, width, height, SWP_NOZORDER|SWP_FRAMECHANGED):
            user32.SetParent(popup, old_parent)
            user32.SetWindowLongW(popup, GWL_STYLE, original_style)
            logger('SetWindowPos failed; original window retained')
            return False
        logger('Night futures WebView embedded as native LITTO child window')
        return True
    except Exception as exc:
        logger(f'Night embed unavailable ({type(exc).__name__}: {exc}); original window retained')
        return False


def detach_to_desktop(logger, geometry=None):
    """Convert the existing native child back to a normal movable desktop popup.

    No page navigation or new window, so the current chart session is retained.
    """
    if os.name != 'nt':
        return False
    try:
        user32 = ctypes.WinDLL('user32', use_last_error=True)
        user32.FindWindowW.argtypes = [wintypes.LPCWSTR, wintypes.LPCWSTR]
        user32.FindWindowW.restype = wintypes.HWND
        user32.FindWindowExW.argtypes = [wintypes.HWND, wintypes.HWND, wintypes.LPCWSTR, wintypes.LPCWSTR]
        user32.FindWindowExW.restype = wintypes.HWND
        user32.GetParent.argtypes = [wintypes.HWND]
        user32.GetParent.restype = wintypes.HWND
        user32.SetParent.argtypes = [wintypes.HWND, wintypes.HWND]
        user32.SetParent.restype = wintypes.HWND
        user32.GetWindowLongW.argtypes = [wintypes.HWND, ctypes.c_int]
        user32.GetWindowLongW.restype = ctypes.c_long
        user32.SetWindowLongW.argtypes = [wintypes.HWND, ctypes.c_int, ctypes.c_long]
        user32.SetWindowLongW.restype = ctypes.c_long
        user32.SetWindowPos.argtypes = [wintypes.HWND, wintypes.HWND, ctypes.c_int, ctypes.c_int, ctypes.c_int, ctypes.c_int, wintypes.UINT]
        user32.SetWindowPos.restype = wintypes.BOOL
        main = user32.FindWindowW(None, MAIN_TITLE)
        popup = user32.FindWindowW(None, NIGHT_TITLE)
        if main and not popup:
            popup = user32.FindWindowExW(main, None, None, NIGHT_TITLE)
        if not main or not popup:
            logger('Night detach failed: missing window handle')
            return False
        if user32.GetParent(popup) != main:
            logger('Night popup is already a desktop window')
            return True
        g = geometry or {}
        x = max(-3000, min(12000, int(g.get('x', 120))))
        y = max(-3000, min(12000, int(g.get('y', 100))))
        w = max(500, min(3000, int(g.get('width', 960))))
        h = max(370, min(2200, int(g.get('height', 700))))
        old_style = user32.GetWindowLongW(popup, GWL_STYLE)
        desktop_style = (old_style | WS_POPUP | WS_CAPTION | WS_THICKFRAME | WS_SYSMENU) & ~WS_CHILD
        user32.SetWindowLongW(popup, GWL_STYLE, desktop_style)
        ctypes.set_last_error(0)
        user32.SetParent(popup, None)
        err = ctypes.get_last_error()
        if user32.GetParent(popup) == main or err:
            user32.SetWindowLongW(popup, GWL_STYLE, old_style)
            logger(f'Night detach SetParent failed: {err}')
            return False
        if not user32.SetWindowPos(popup, None, x, y, w, h, SWP_NOZORDER | SWP_FRAMECHANGED | 0x0040):
            logger('Night popup detached; could not restore saved rectangle')
        else:
            logger('Night popup detached to a movable desktop window')
        return True
    except Exception as exc:
        logger(f'Night detach failed: {type(exc).__name__}: {exc}')
        return False


def is_embedded():
    if os.name != 'nt':
        return False
    user32 = ctypes.WinDLL('user32', use_last_error=True)
    user32.FindWindowW.argtypes = [wintypes.LPCWSTR, wintypes.LPCWSTR]
    user32.FindWindowW.restype = wintypes.HWND
    user32.GetParent.argtypes = [wintypes.HWND]
    user32.GetParent.restype = wintypes.HWND
    user32.FindWindowExW.argtypes = [wintypes.HWND, wintypes.HWND, wintypes.LPCWSTR, wintypes.LPCWSTR]
    user32.FindWindowExW.restype = wintypes.HWND
    main = user32.FindWindowW(None, MAIN_TITLE)
    popup = user32.FindWindowExW(main, None, None, NIGHT_TITLE) if main else None
    return bool(main and popup and user32.GetParent(popup) == main)
