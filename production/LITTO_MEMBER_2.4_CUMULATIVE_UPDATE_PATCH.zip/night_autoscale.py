"""Native display adjustments for the *night-futures popup only*.

The external page is loaded unmodified in its own top-level WebView2.
This does not intercept requests, remove page elements, or alter third-party scripts.
"""
from __future__ import annotations

import os

BASE_WIDTH = 960
BASE_HEIGHT = 700
MIN_ZOOM = 0.48
MAX_ZOOM = 1.0
# A clipped viewport means a bottom-fixed website banner is outside the window.
# This is a visual focus mode, not content removal or an API workaround.
FOCUS_CROP_PX = 170
# Hide the website's introductory title and trading-hours header in the
# compact pop-up view; its original web page is left unchanged.
TOP_FOCUS_CROP_PX = 315


def zoom_for_size(width, height):
    try:
        w, h = int(width), int(height)
        return round(max(MIN_ZOOM, min(MAX_ZOOM, w / BASE_WIDTH, h / BASE_HEIGHT)), 3)
    except (ValueError, TypeError, OverflowError):
        return 1.0


def _set_viewport_focus(form, control, crop_px=FOCUS_CROP_PX, zoom=1.0):
    """Oversize the WebView behind its parent Form's normal clipping area.

    The WebView's bottom-fixed page content becomes outside the visible Form.
    Restore a sensible scrollable page viewport and leave external HTML alone.
    Called on the WinForms UI thread only.
    """
    import System.Windows.Forms as Forms

    crop = max(0, min(250, int(crop_px)))
    top_crop = max(0, min(250, round(TOP_FOCUS_CROP_PX * float(zoom))))
    width = max(1, int(form.ClientSize.Width))
    height = max(1, int(form.ClientSize.Height))
    # If pywebview uses DockStyle.Fill by default, explicitly opt out or the
    # WinForms layout engine will immediately undo this size adjustment.
    if control.Dock != getattr(Forms.DockStyle, 'None'):
        control.Dock = getattr(Forms.DockStyle, 'None')
    anchor = Forms.AnchorStyles.Top | Forms.AnchorStyles.Left | Forms.AnchorStyles.Right
    if control.Anchor != anchor:
        control.Anchor = anchor
    if control.Left != 0 or control.Top != -top_crop or control.Width != width or control.Height != height + crop + top_crop:
        control.SetBounds(0, -top_crop, width, height + crop + top_crop)


def apply_zoom(window, width, height, log=None):
    """Apply site zoom and chart-focused viewport on native WebView2 UI thread."""
    if os.name != 'nt':
        return False
    factor = zoom_for_size(width, height)
    try:
        form = window.native
        if form is None or form.IsDisposed:
            return False
        control = form.webview
        if control is None or control.IsDisposed:
            return False
        import System

        def update_view():
            try:
                if control.IsDisposed or form.IsDisposed:
                    return
                if abs(float(control.ZoomFactor) - factor) > 0.015:
                    control.ZoomFactor = factor
                _set_viewport_focus(form, control, zoom=factor)
            except Exception as exc:
                if log:
                    log(f'Night popup focus skipped: {type(exc).__name__}: {exc}')

        if control.InvokeRequired:
            control.BeginInvoke(System.Action(update_view))
        else:
            update_view()
        return True
    except Exception as exc:
        if log:
            log(f'Night popup view adjustment skipped: {type(exc).__name__}: {exc}')
        return False
