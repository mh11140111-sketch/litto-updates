from __future__ import annotations

import os
import sys
import time
import socket
import subprocess
import urllib.request
import traceback
from pathlib import Path

PORT = 8874
HOST = '127.0.0.1'
URL = f'http://{HOST}:{PORT}/'
BASE = Path(__file__).resolve().parent
DESKTOP_LOG = BASE / 'LITTO_DESKTOP.log'
STARTUP_LOG = BASE / 'LITTO_STARTUP.log'
LAUNCHED_BY_EXE = os.environ.get('LITTO_LAUNCHED_BY_EXE') == '1'


def append_startup_log(text: str) -> None:
    try:
        with STARTUP_LOG.open('a', encoding='utf-8') as f:
            f.write(f'[{time.strftime("%Y-%m-%d %H:%M:%S")}] {text}\n')
    except Exception:
        pass


def port_open(host: str, port: int) -> bool:
    try:
        with socket.create_connection((host, port), timeout=0.35):
            return True
    except OSError:
        return False


def http_ready(url: str) -> bool:
    try:
        with urllib.request.urlopen(url, timeout=0.7) as r:
            return 200 <= getattr(r, 'status', 200) < 500
    except Exception:
        return False


def show_error(message: str) -> None:
    # When launched by LITTO.exe, the EXE presents one consolidated popup
    # after collecting the traceback. Direct script execution still gets a popup.
    if LAUNCHED_BY_EXE:
        return
    try:
        import tkinter as tk
        from tkinter import messagebox
        root = tk.Tk()
        root.withdraw()
        messagebox.showerror('LITTO Trading System v1.24.4', message)
        root.destroy()
    except Exception:
        print(message)


def desktop_log_tail(lines: int = 12) -> str:
    try:
        raw = DESKTOP_LOG.read_text(encoding='utf-8', errors='replace').splitlines()
        return '\n'.join(raw[-lines:])
    except Exception:
        return ''


def start_backend():
    app_py = BASE / 'app.py'
    if not app_py.exists():
        raise FileNotFoundError('app.py 파일을 찾을 수 없습니다.')

    if http_ready(URL):
        append_startup_log('Existing LITTO backend detected; reusing it.')
        return None, False

    if port_open(HOST, PORT):
        raise RuntimeError(f'포트 {PORT}이 사용 중이지만 LITTO 서버 응답이 없습니다. 이미 실행 중인 프로세스를 확인해 주세요.')

    flags = getattr(subprocess, 'CREATE_NO_WINDOW', 0) if os.name == 'nt' else 0
    log_fp = open(DESKTOP_LOG, 'a', encoding='utf-8', buffering=1)
    log_fp.write(f'\n[{time.strftime("%Y-%m-%d %H:%M:%S")}] desktop backend start\n')
    proc = subprocess.Popen(
        [sys.executable, str(app_py), '--port', str(PORT), '--no-browser'],
        cwd=str(BASE),
        stdout=log_fp,
        stderr=subprocess.STDOUT,
        creationflags=flags,
    )

    deadline = time.time() + 30
    while time.time() < deadline:
        if proc.poll() is not None:
            log_fp.flush()
            tail = desktop_log_tail()
            extra = f'\n\n서버 로그:\n{tail}' if tail else ''
            raise RuntimeError('LITTO 서버가 시작 중 종료되었습니다.' + extra)
        if http_ready(URL):
            append_startup_log('LITTO backend ready.')
            return (proc, log_fp), True
        time.sleep(0.25)

    try:
        proc.terminate()
    except Exception:
        pass
    tail = desktop_log_tail()
    extra = f'\n\n서버 로그:\n{tail}' if tail else ''
    raise TimeoutError('LITTO 서버 시작 시간이 30초를 초과했습니다.' + extra)


def stop_backend(handle):
    if not handle:
        return
    proc, log_fp = handle
    try:
        proc.terminate()
        proc.wait(timeout=4)
    except Exception:
        try:
            proc.kill()
        except Exception:
            pass
    try:
        log_fp.close()
    except Exception:
        pass


def main() -> int:
    try:
        import webview
    except Exception as e:
        msg = f'pywebview를 불러오지 못했습니다: {e}'
        append_startup_log(msg)
        show_error(msg)
        return 2

    backend = None
    started_by_us = False
    try:
        backend, started_by_us = start_backend()
        append_startup_log('Opening LITTO desktop window.')
        window = webview.create_window(
            'LITTO Trading System v1.24.4',
            URL,
            width=1600,
            height=960,
            min_size=(1100, 700),
            resizable=True,
            fullscreen=False,
            text_select=True,
            confirm_close=False,
        )
        def start_maximized():
            try:
                window.maximize()
            except Exception:
                pass

        webview.start(start_maximized, gui='edgechromium', debug=False, private_mode=False)
        append_startup_log('Desktop window closed normally.')
        return 0
    except Exception as e:
        tb = traceback.format_exc()
        append_startup_log('DESKTOP ERROR:\n' + tb)
        show_error(str(e))
        return 1
    finally:
        if started_by_us:
            stop_backend(backend)


if __name__ == '__main__':
    raise SystemExit(main())
