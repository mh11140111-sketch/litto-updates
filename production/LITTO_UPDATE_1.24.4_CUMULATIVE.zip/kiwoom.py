"""Read-only Kiwoom REST adapter, based on the official API examples.
Credentials stay in process memory. Read-only account journal endpoints are supported; order placement is not implemented.
Live end-to-end verification requires the user's registered API key and IP.
"""
import json
import time
import threading
import urllib.request
import urllib.error
import urllib.parse
import re
from datetime import datetime,timedelta,timezone
from zoneinfo import ZoneInfo
from engine import KST, code, number
from yaksang import excluded_product
from us_realtime import UsRealtimeFeed

def base_code(v):
    s=str(v).strip()
    if s.endswith('_NX') or s.endswith('_AL'):
        s=s[:-3]
    return code(s)

def sor_code(v):
    return base_code(v)+'_AL'

def nxt_code(v):
    return base_code(v)+'_NX'

class ApiError(Exception): pass

def unsigned(v):
    n=number(v)
    return abs(n) if n is not None else None

def daily_bar(row):
    prices={k:unsigned(row.get(src)) for k,src in [('open','open_pric'),('high','high_pric'),('low','low_pric'),('close','cur_prc')]}
    volume=unsigned(row.get('trde_qty')); value=unsigned(row.get('trde_prica'))
    # ka10081 does NOT provide pred_pre/flu_rt. Its official previous-close field is
    # pred_close_pric. Use that when present; otherwise leave change_rate empty and
    # let the UI fall back to the adjacent daily close.
    pred_close=unsigned(row.get('pred_close_pric'))
    change_rate=None
    close=prices.get('close')
    if close is not None and pred_close not in (None,0):
        change_rate=(close/pred_close-1.0)*100.0
    # Official example: 53 shares at 133,600 -> trde_prica=7 (million KRW).
    # Validate against the day's price/volume range; never estimate missing money.
    value=value*1_000_000 if value is not None else None
    if value is not None and volume and prices['low'] and prices['high']:
        if not (prices['low']*volume*.98-1_000_000<=value<=prices['high']*volume*1.02+1_000_000):
            value=None
    dt=datetime.strptime(str(row['dt']),'%Y%m%d').date().isoformat()
    return dict(prices,date=dt,volume=volume,value=value,pred_close=pred_close,change_rate=change_rate)

def minute_bar(row, now, minutes=15):
    stamp=datetime.strptime(str(row['cntr_tm']),'%Y%m%d%H%M%S').replace(tzinfo=KST)
    return {'time':stamp.isoformat(),
            **{k:unsigned(row.get(src)) for k,src in [('open','open_pric'),('high','high_pric'),('low','low_pric'),('close','cur_prc')]},
            'volume':unsigned(row.get('trde_qty')),'value':None,
            # Exclude the newest incomplete minute period according to its timeframe.
            'complete': stamp+timedelta(minutes=minutes)<=now}

class Kiwoom:
    ALLOWED={'ka10032':'/api/dostk/rkinfo','ka10027':'/api/dostk/rkinfo','ka10017':'/api/dostk/stkinfo','ka10001':'/api/dostk/stkinfo','ka10099':'/api/dostk/stkinfo','ka00198':'/api/dostk/stkinfo','ka10004':'/api/dostk/mrkcond','ka10081':'/api/dostk/chart','ka10080':'/api/dostk/chart','ka10060':'/api/dostk/chart','ka90004':'/api/dostk/stkinfo','ka90013':'/api/dostk/mrkcond','ka20003':'/api/dostk/sect','ka20002':'/api/dostk/sect','ka20001':'/api/dostk/sect','ka20005':'/api/dostk/chart','ka10051':'/api/dostk/sect','ka10170':'/api/dostk/acnt','ka10073':'/api/dostk/acnt','ka10076':'/api/dostk/acnt','ka00001':'/api/dostk/acnt','kt00018':'/api/dostk/acnt','ka10075':'/api/dostk/acnt','ka01300':'/api/dostk/watchlist','ka01301':'/api/dostk/watchlist'}
    def __init__(self,appkey,secretkey,mock=False):
        if not appkey or not secretkey:raise ApiError('앱키와 시크릿키가 필요합니다.')
        self.key=appkey.strip();self.secret=secretkey.strip();self.mock=bool(mock)
        self.host='https://mockapi.kiwoom.com' if mock else 'https://api.kiwoom.com'
        self.token=None;self.expires=None;self.last=0
        self._pace_lock=threading.Lock()
        self._auth_lock=threading.RLock()

    def _wait_request_slot(self):
        # Shared by read and order calls, including paths outside app.API_GATE.
        with self._pace_lock:
            wait=.3-(time.monotonic()-self.last)
            if wait>0:time.sleep(wait)
            self.last=time.monotonic()

    def _post(self,path,body,headers=None):
        self._wait_request_slot()
        h={'Content-Type':'application/json;charset=UTF-8',**(headers or {})}
        req=urllib.request.Request(self.host+path,json.dumps(body).encode(),h,method='POST')
        try:
            with urllib.request.urlopen(req,timeout=20) as r:
                data=json.loads(r.read(8_000_000));rh=dict((k.lower(),v) for k,v in r.headers.items())
        except urllib.error.HTTPError as e:
            raise ApiError(f'키움 HTTP {e.code}: 키 권한·등록 IP·호출 제한을 확인하세요.') from None
        except (urllib.error.URLError,TimeoutError,OSError,json.JSONDecodeError):
            raise ApiError('키움 연결 실패: 네트워크·서비스 상태를 확인하세요.') from None
        if str(data.get('return_code','0'))!='0':
            # Do not return a raw provider message that could contain credentials.
            raise ApiError('키움 응답 오류 '+str(data.get('return_code'))+' · API 설정/권한 확인')
        return data,rh

    def auth(self):
        with self._auth_lock:
            return self._auth_locked()

    def _auth_locked(self):
        if self.token and self.expires and datetime.now(KST)<self.expires-timedelta(seconds=60):return
        data,_=self._post('/oauth2/token',{'grant_type':'client_credentials','appkey':self.key,'secretkey':self.secret})
        if not data.get('token'):raise ApiError('토큰이 반환되지 않았습니다.')
        self.token=data['token']
        try:self.expires=datetime.strptime(data['expires_dt'],'%Y%m%d%H%M%S').replace(tzinfo=KST)
        except (KeyError,ValueError):self.expires=datetime.now(KST)+timedelta(minutes=5)

    def rows(self,api,body,key,limit=100,max_pages=5):
        if api not in self.ALLOWED:raise ApiError('허용되지 않은 API입니다.')
        self.auth();output=[];continuation='N';nextkey='';seen=set()
        for _ in range(max_pages):
            data,h=self._post(self.ALLOWED[api],body,{'authorization':'Bearer '+self.token,'api-id':api,'cont-yn':continuation,'next-key':nextkey})
            rows=data.get(key)
            if not isinstance(rows,list):raise ApiError('API 응답 필드가 다릅니다: '+key)
            output.extend(rows)
            if len(output)>=limit or h.get('cont-yn')!='Y':break
            continuation='Y';nextkey=h.get('next-key','')
            if not nextkey or nextkey in seen:raise ApiError('연속조회 키가 누락되었거나 반복됩니다.')
            seen.add(nextkey)
        return output[:limit]


    @staticmethod
    def _watch_code(raw):
        """Normalize ka01301 cod2 to the 6-digit domestic stock code when possible."""
        s=str(raw or '').strip().upper()
        # ka01301 documents cod2 as an 18-character provider field.  In practice
        # the domestic 6-digit code is embedded in that value.  Prefer a numeric
        # 6-digit token; fall back to a directly supplied 6-char code.
        hits=re.findall(r'(?<!\d)(\d{6})(?!\d)',s)
        if hits:
            return hits[-1]
        if re.fullmatch(r'[0-9A-Z]{6}',s):
            return s
        m=re.search(r'([0-9A-Z]{6})$',s)
        return m.group(1) if m else ''

    def watchlist_groups(self):
        """Read saved Kiwoom/HTS domestic watchlist groups (ka01300)."""
        self.auth()
        data,_=self._post(
            self.ALLOWED['ka01300'],{},
            {'authorization':'Bearer '+self.token,'api-id':'ka01300'}
        )
        rows=data.get('nofi')
        if not isinstance(rows,list):
            raise ApiError('관심종목 그룹 응답 형식이 다릅니다.')
        out=[]
        for r in rows:
            if not isinstance(r,dict): continue
            gcod=str(r.get('gcod') or '').strip()
            name=str(r.get('name') or '').strip()
            if gcod:
                out.append({'group_code':gcod,'group_name':name or gcod})
        return out

    def watchlist_group(self,group_code):
        """Read one saved Kiwoom/HTS watchlist group (ka01301)."""
        g=str(group_code or '').strip()
        if not g:
            raise ApiError('관심종목 그룹코드가 필요합니다.')
        self.auth()
        data,_=self._post(
            self.ALLOWED['ka01301'],{'arn_grp_id':g},
            {'authorization':'Bearer '+self.token,'api-id':'ka01301'}
        )
        rows=data.get('nofj')
        if not isinstance(rows,list):
            raise ApiError('관심종목 상세 응답 형식이 다릅니다.')
        out=[]
        seen=set()
        for r in rows:
            if not isinstance(r,dict): continue
            c=self._watch_code(r.get('cod2'))
            if not c or c in seen: continue
            seen.add(c)
            out.append({
                'code':c,
                'bookmark':str(r.get('bgb') or '').strip(),
                'bookmark_color':str(r.get('bgb_clr') or '').strip()
            })
        return out

    def industry_map(self):
        """Return a basic KRX industry mapping from Kiwoom's official sector APIs.

        This is classification metadata only. It never changes the three locked
        search formulas or their ranking. Broad market/size indexes are skipped.
        """
        # ka20003 returns the sector/index catalogue for KOSPI or KOSDAQ.
        # ka20002 returns the constituent stocks for one sector.
        generic_names={
            '종합(KOSPI)','종합(KOSDAQ)','종합','대형주','중형주','소형주',
            'KOSPI200','코스피200','KOSTAR','KRX100','코스닥150','KOSDAQ150'
        }
        out={}
        sectors_seen=[]
        for market,root in (('0','001'),('1','101')):
            rows=self.rows('ka20003',{'inds_cd':root},'all_inds_idex',500,max_pages=10)
            for r in rows:
                raw_cd=str(r.get('stk_cd') or '').strip()
                name=str(r.get('stk_nm') or '').strip()
                inds_cd=raw_cd.split('_',1)[0]
                if not inds_cd or not name or name in generic_names:
                    continue
                # Ignore obvious market/size aggregate indexes.  Industry names
                # such as 전기전자/기계/화학/제약 remain eligible.
                compact=name.replace(' ','').upper()
                if compact in {'KOSPI','KOSDAQ','코스피','코스닥'} or '대형주' in name or '중형주' in name or '소형주' in name:
                    continue
                sectors_seen.append((market,inds_cd,name))
        # Deduplicate catalogue entries before constituent queries.
        seen=set()
        for market,inds_cd,name in sectors_seen:
            key=(market,inds_cd)
            if key in seen: continue
            seen.add(key)
            try:
                rows=self.rows('ka20002',{'mrkt_tp':market,'inds_cd':inds_cd,'stex_tp':'3'},'inds_stkpc',5000,max_pages=30)
            except ApiError:
                continue
            for r in rows:
                raw=r.get('stk_cd')
                if not raw: continue
                c=base_code(raw)
                # Keep the first narrow industry classification encountered.
                # Manual sectors are handled at the app layer and always win.
                out.setdefault(c,{'sector':name,'source':'키움 업종 자동분류','asof':datetime.now(KST).date().isoformat()})
        return out

    def market_overview(self):
        """KOSPI/KOSDAQ current index, breadth, investor net flow and intraday charts."""
        self.auth()
        now=datetime.now(KST)
        out={}
        for key,mrkt,inds in [('kospi','0','001'),('kosdaq','1','101')]:
            cur,_=self._post(self.ALLOWED['ka20001'],{'mrkt_tp':mrkt,'inds_cd':inds},{'authorization':'Bearer '+self.token,'api-id':'ka20001'})
            inv=self.rows('ka10051',{'mrkt_tp':mrkt,'amt_qty_tp':'0','base_dt':now.strftime('%Y%m%d'),'stex_tp':'3'},'inds_netprps',300,max_pages=10)
            invrow=next((r for r in inv if str(r.get('inds_cd','')).split('_')[0]==inds), inv[0] if inv else {})
            # Keep both KOSPI and KOSDAQ intraday index charts on the same 1-minute basis.
            # Use enough rows/pages to cover the full regular session without changing
            # any investor-flow or other market-overview logic.
            chart_scope='1'
            chart_limit=430
            chart_pages=10
            chart=self.rows('ka20005',{'inds_cd':inds,'tic_scope':chart_scope,'base_dt':now.strftime('%Y%m%d')},'inds_min_pole_qry',chart_limit,max_pages=chart_pages)
            def n(v,absval=False):
                try:
                    x=float(str(v or '0').replace(',','').replace('+',''))
                    return abs(x) if absval else x
                except: return None
            pts=[]
            for r in reversed(chart):
                ts=str(r.get('cntr_tm') or '')
                pts.append({'time':ts,'close':n(r.get('cur_prc'),True),'open':n(r.get('open_pric'),True),'high':n(r.get('high_pric'),True),'low':n(r.get('low_pric'),True),'volume':n(r.get('trde_qty'),True)})
            out[key]={
                'name':'코스피' if key=='kospi' else '코스닥',
                'price':n(cur.get('cur_prc'),True),'change':n(cur.get('pred_pre')),'change_rate':n(cur.get('flu_rt')),
                # ka20001 거래대금은 키움 응답 단위(백만원)를 원화로 정규화해 전달한다.
                # raw 값도 남겨 기존 호환성을 유지한다.
                'trading_value':n(cur.get('trde_prica'),True),
                'trading_value_krw':(n(cur.get('trde_prica'),True)*1_000_000 if n(cur.get('trde_prica'),True) is not None else None),
                'volume':n(cur.get('trde_qty'),True),
                'breadth':{'up':int(n(cur.get('rising'),True) or 0),'flat':int(n(cur.get('stdns'),True) or 0),'down':int(n(cur.get('fall'),True) or 0),'upper':int(n(cur.get('upl'),True) or 0),'lower':int(n(cur.get('lst'),True) or 0)},
                'investor':{'personal':n(invrow.get('ind_netprps')),'foreign':n(invrow.get('frgnr_netprps')),'institution':n(invrow.get('orgn_netprps'))},
                'chart':pts
            }
        return {'updated_at':now.isoformat(),'source':'키움 공식 REST ka20001·ka10051·ka20005','markets':out}

    def market_investor_history(self, market='kospi', days=10):
        """Recent market investor net-buy amounts for KOSPI/KOSDAQ.

        ka10051 is a base-date snapshot, so request recent weekdays one by one and
        keep the latest successful trading-day rows.  Amount mode (amt_qty_tp=0)
        matches the market-overview investor figures already used by LITTO.
        """
        self.auth()
        key=str(market or '').strip().lower()
        if key not in ('kospi','kosdaq'):
            raise ApiError('market은 kospi 또는 kosdaq 이어야 합니다.')
        days=max(1,min(int(days or 10),20))
        mrkt='0' if key=='kospi' else '1'
        inds='001' if key=='kospi' else '101'
        name='코스피' if key=='kospi' else '코스닥'
        now=datetime.now(KST)
        out=[]
        seen=set()
        cursor=now.date()
        # 10 trading days normally fit in 14 calendar days; leave extra room for holidays.
        for _ in range(35):
            if len(out)>=days: break
            if cursor.weekday()>=5:
                cursor-=timedelta(days=1); continue
            day=cursor.strftime('%Y%m%d')
            try:
                data,_=self._post(self.ALLOWED['ka10051'],{
                    'mrkt_tp':mrkt,'amt_qty_tp':'0','base_dt':day,'stex_tp':'3'
                },{'authorization':'Bearer '+self.token,'api-id':'ka10051'})
                rows=(data or {}).get('inds_netprps') or []
                row=next((r for r in rows if str(r.get('inds_cd','')).split('_')[0]==inds),None)
                if row:
                    def n(v):
                        try:return float(str(v or '0').replace(',','').replace('+',''))
                        except:return None
                    vals=(n(row.get('ind_netprps')),n(row.get('frgnr_netprps')),n(row.get('orgn_netprps')))
                    # Some non-trading dates may repeat the previous snapshot.  Do not let an
                    # identical adjacent snapshot consume another "trading day" slot.
                    sig=(vals,n(row.get('cur_prc')))
                    if sig not in seen:
                        seen.add(sig)
                        out.append({'date':cursor.isoformat(),'personal':vals[0],'foreign':vals[1],
                                    'institution':vals[2],'index_price':n(row.get('cur_prc'))})
            except Exception:
                pass
            cursor-=timedelta(days=1)
        out=sorted(out,key=lambda x:x['date'])[-days:]
        totals={k:sum(float(r.get(k) or 0) for r in out) for k in ('personal','foreign','institution')}
        return {'market':key,'name':name,'days':len(out),'rows':out,'totals':totals,
                'updated_at':now.isoformat(),'source':'키움 공식 REST ka10051 · 금액 기준 · SOR 통합'}

    def us_rows(self,api,body,key='result_list',limit=50,max_pages=3):
        """Read-only U.S. stock helper.  Kiwoom separates U.S. REST paths from KRX paths."""
        paths={
            'usa01980':['/api/us/rkinfo'],
            'usa20530':['/api/us/rkinfo'],
            'usa20540':['/api/us/rkinfo'],
            'usa20880':['/api/us/rkinfo'],
            'usa20910':['/api/us/rkinfo'],
            'usa23100':['/api/us/sect','/api/us/rkinfo'],
        }.get(api)
        if not paths: raise ApiError('허용되지 않은 미국주식 API입니다.')
        self.auth(); last_error=None
        for path in paths:
            output=[]; continuation='N'; nextkey=''; seen=set()
            try:
                for _ in range(max_pages):
                    data,h=self._post(path,body,{'authorization':'Bearer '+self.token,'api-id':api,'cont-yn':continuation,'next-key':nextkey})
                    rows=data.get(key)
                    if not isinstance(rows,list): raise ApiError('미국주식 API 응답 필드가 다릅니다: '+key)
                    output.extend(rows)
                    if len(output)>=limit or h.get('cont-yn')!='Y': break
                    continuation='Y';nextkey=h.get('next-key','')
                    if not nextkey or nextkey in seen: break
                    seen.add(nextkey)
                return output[:limit]
            except ApiError as e:
                last_error=e
        raise last_error or ApiError('미국주식 API 조회 실패')

    @staticmethod
    def _us_num(v):
        try:
            if v is None or v=='': return None
            return float(str(v).replace(',','').replace('+',''))
        except Exception:return None

    @staticmethod
    def _us_price(v):
        """Normalize Kiwoom U.S. price fields.

        Kiwoom can prefix price fields with +/- as a direction marker.  Prices
        themselves must never be negative, so strip the directional sign only
        for price-like fields.  Change/change-rate fields continue to use
        _us_num() so their sign is preserved.
        """
        n=Kiwoom._us_num(v)
        return abs(n) if n is not None else None

    @staticmethod
    def _us_item(r):
        def first(*keys):
            for k in keys:
                if r.get(k) not in (None,''): return r.get(k)
            return None
        n=Kiwoom._us_num
        return {
            'rank': int(n(first('rank','rnk','kw_high_rank')) or 0) or None,
            'exchange': str(first('stex_tp','exch_cd','ovrs_excg_cd') or ''),
            'code': str(first('stk_cd','symb','symbol') or ''),
            'name': str(first('stk_nm','kor_nm','name') or ''),
            'name_en': str(first('stk_enm','eng_nm') or ''),
            'price': Kiwoom._us_price(first('cur_prc','curr_pric','last_pric','now_pric')),
            'change': n(first('pred_pre','chg_val','diff')),
            'change_rate': n(first('flu_rt','diff_rate_for_prev','chg_rt','rate')),
            'volume': n(first('acc_trde_qty','trde_qty','volume')),
            'trading_value': n(first('trde_prica','trde_amt','turnover')),
        }

    def _us_try(self,api,bodies,limit=30):
        """Try request-body variants until one returns actual rows.

        Some U.S. ranking TRs accept a default/empty selector but return an empty
        result_list.  Treating that as success prevents the valid selector from
        ever being tried, so empty responses must fall through to the next body.
        """
        errs=[]
        empty_count=0
        for body in bodies:
            try:
                rows=self.us_rows(api,body,'result_list',limit=limit,max_pages=3)
                items=[self._us_item(r) for r in rows]
                if items:
                    return items,None
                empty_count+=1
            except Exception as e:
                errs.append(str(e))
        if errs:
            return [],errs[-1]
        if empty_count:
            return [],'키움 응답은 정상이나 조회 결과가 비어 있습니다.'
        return [],'조회 실패'

    def us_exchange_map(self, force=False):
        """Return ticker -> exchange map from Kiwoom usa10099.

        usa20100 requires an exact U.S. exchange code (ND/NASDAQ, NY/NYSE,
        NA/AMEX).  Guessing three exchanges for every ticker causes needless
        requests and can trigger rate limits, so resolve the exchange once from
        Kiwoom's stock master and cache it for six hours.
        """
        now=time.time()
        cached=getattr(self,'_us_master_cache',None)
        if cached and not force and now-cached.get('ts',0)<21600:
            return cached.get('map',{})
        self.auth()
        mp={}
        for ex in ('ND','NY','NA'):
            try:
                data,_=self._post('/api/us/stkinfo',{'stex_tp':ex},{'authorization':'Bearer '+self.token,'api-id':'usa10099'})
                rows=data.get('list') or []
                if isinstance(rows,list):
                    for r in rows:
                        if not isinstance(r,dict): continue
                        sym=str(r.get('stk_cd') or '').strip().upper()
                        rex=str(r.get('stex_tp') or ex).strip().upper()
                        if sym: mp[sym]=rex or ex
            except Exception:
                # Keep the other exchanges usable even if one master request fails.
                continue
        self._us_master_cache={'ts':now,'map':mp}
        if not hasattr(self,'_us_exchange_cache'): self._us_exchange_cache={}
        self._us_exchange_cache.update(mp)
        return mp

    def _us_latest_execution(self, sym, ex):
        """Fallback quote from Kiwoom usa20150 detailed executions.

        usa20100 can occasionally stay pinned to the previous close for some
        U.S. ETFs during extended-hours trading.  usa20150 exposes the latest
        execution price/change rate, so use it only when usa20100 looks stale.
        """
        last=None
        for attempt in range(3):
            try:
                data,_=self._post('/api/us/mrkcond',{'stex_tp':ex,'stk_cd':sym},
                                  {'authorization':'Bearer '+self.token,'api-id':'usa20150'})
                rows=data.get('result_list') or []
                if not isinstance(rows,list) or not rows:
                    return None
                # Kiwoom returns the newest executions first. Pick the first row
                # that contains a usable current price.
                for r in rows:
                    if not isinstance(r,dict):
                        continue
                    cur=self._us_price(r.get('cur_prc'))
                    if cur is None:
                        continue
                    return {
                        'price':cur,
                        'change':self._us_num(r.get('pred_pre')),
                        'change_rate':self._us_num(r.get('flu_rt')),
                        'time':str(r.get('cntr_tm') or ''),
                        'raw':r,
                    }
                return None
            except Exception as e:
                last=e
                if 'HTTP 429' in str(e) and attempt<2:
                    time.sleep(1.15*(attempt+1))
                    continue
                return None
        return None

    def _us_orderbook_reference(self, sym, ex, base_close=None):
        """Verified last/current-price fallback from usa20101.

        IMPORTANT: bid/ask prices are quotations, not executions.  They must not
        be promoted to the watchlist's 'current price'.  Only Kiwoom's cur_prc
        is eligible here, and only when it is demonstrably different from the
        previous close or Kiwoom itself reports a non-zero change rate.
        """
        for attempt in range(3):
            try:
                data,_=self._post('/api/us/mrkcond', {'stex_tp':ex,'stk_cd':sym},
                                  {'authorization':'Bearer '+self.token,'api-id':'usa20101'})
                cur=self._us_price(data.get('cur_prc'))
                api_rate=self._us_num(data.get('flu_rt'))
                if cur is None or cur <= 0:
                    return None
                moved=False
                if base_close not in (None,0):
                    moved=abs(cur-float(base_close)) > max(1e-9, abs(float(base_close))*1e-8)
                if not moved and not (api_rate is not None and abs(api_rate)>1e-12):
                    return None
                change=None; rate=api_rate
                if base_close not in (None,0):
                    base=float(base_close)
                    change=cur-base
                    rate=(cur/base-1.0)*100.0
                return {
                    'price':cur,
                    'change':change,
                    'change_rate':rate,
                    'source':'usa20101_cur_prc_verified',
                    'raw_cur_prc':cur,
                    'raw_flu_rt':api_rate,
                    'bid_tm':str(data.get('bid_tm') or ''),
                }
            except Exception as e:
                if 'HTTP 429' in str(e) and attempt<2:
                    time.sleep(1.15*(attempt+1)); continue
                return None
        return None


    def _us_external_extended_quote(self, ticker):
        """Conservative same-U.S.-trading-day fallback for stale 0.00% quotes."""
        sym=str(ticker or '').strip().upper()
        if not sym:
            return None
        now=time.time()
        ny=ZoneInfo('America/New_York')
        us_today=datetime.now(ny).date()
        cache=getattr(self,'_us_external_cache',None)
        if cache is None:
            cache={}; self._us_external_cache=cache
        old=cache.get(sym)
        if old and old.get('quote') and now-old.get('ts',0)<600:
            try:
                q=old['quote']
                qdate=datetime.fromtimestamp(int(q.get('external_time')),tz=timezone.utc).astimezone(ny).date()
                if qdate == us_today:
                    return q
            except Exception:
                pass

        quote=None
        for rng in ('1d','5d'):
            if quote:
                break
            for host in ('query1.finance.yahoo.com','query2.finance.yahoo.com'):
                try:
                    url=(f'https://{host}/v8/finance/chart/{urllib.parse.quote(sym)}'
                         f'?interval=1m&range={rng}&includePrePost=true&events=div%2Csplits')
                    req=urllib.request.Request(url,headers={
                        'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124 Safari/537.36',
                        'Accept':'application/json,text/plain,*/*',
                        'Referer':'https://finance.yahoo.com/'
                    })
                    with urllib.request.urlopen(req,timeout=6) as r:
                        payload=json.loads(r.read(3_000_000))
                    result=((payload.get('chart') or {}).get('result') or [None])[0]
                    if not isinstance(result,dict):
                        continue
                    meta=result.get('meta') or {}
                    ts=result.get('timestamp') or []
                    closes=((((result.get('indicators') or {}).get('quote') or [{}])[0] or {}).get('close') or [])
                    vals=[]
                    for t,c in zip(ts,closes):
                        try:
                            if c is None:
                                continue
                            stamp=int(t); price=abs(float(c))
                            if price<=0:
                                continue
                            d=datetime.fromtimestamp(stamp,tz=timezone.utc).astimezone(ny).date()
                            if d == us_today:
                                vals.append((stamp,price))
                        except Exception:
                            pass
                    if not vals:
                        continue
                    stamp,price=vals[-1]
                    prev=None
                    for k in ('chartPreviousClose','previousClose','regularMarketPreviousClose'):
                        try:
                            v=meta.get(k)
                            if v not in (None,''):
                                prev=abs(float(v)); break
                        except Exception:
                            pass
                    if not prev:
                        continue
                    rate=(price/prev-1.0)*100.0
                    if not (-25.0 <= rate <= 25.0):
                        continue
                    if abs(price-prev) <= max(1e-8,abs(prev)*1e-8):
                        continue
                    quote={
                        'price':price,'base_close':prev,'change':price-prev,
                        'change_rate':rate,'source':f'yahoo_same_day_{rng}',
                        'external_time':stamp
                    }
                    break
                except Exception:
                    continue
        if quote:
            cache[sym]={'ts':now,'quote':quote}
            return quote
        return None

    def us_quote(self, ticker, exchange=None):
        """Return one U.S. stock/ETF quote from Kiwoom usa20100, with usa20150 stale-quote fallback."""
        if self.mock:
            raise ApiError('모의투자에서는 미국주식 현재가 조회가 제한될 수 있습니다.')
        self.auth()
        if not hasattr(self,'_us_exchange_cache'):
            self._us_exchange_cache={}
        sym=str(ticker or '').strip().upper()
        if not sym:
            raise ApiError('미국주식 티커가 비어 있습니다.')
        cached=self._us_exchange_cache.get(sym)
        exchanges=[]
        for ex in (exchange,cached,'ND','NY','NA'):
            if ex and ex not in exchanges: exchanges.append(ex)
        last=None
        for ex in exchanges:
            # Retry the same exchange on HTTP 429 instead of incorrectly moving
            # to another market.  Kiwoom applies TR-specific request limits.
            for attempt in range(3):
                try:
                    data,_=self._post('/api/us/mrkcond',{'stex_tp':ex,'stk_cd':sym},{'authorization':'Bearer '+self.token,'api-id':'usa20100'})
                    cur=self._us_price(data.get('cur_prc'))
                    flu_api=self._us_num(data.get('flu_rt'))
                    base_close=self._us_price(data.get('base_close_pric'))
                    pred_pre=self._us_num(data.get('pred_pre'))

                    # usa20100 occasionally returns flu_rt=0.00 even when the
                    # current price has moved (observed on actively traded names
                    # such as TSLA).  The same response includes base_close_pric,
                    # so calculate the percentage ourselves from the authoritative
                    # price pair whenever both are available.
                    flu_calc=None
                    if cur is not None and base_close not in (None,0):
                        flu_calc=(cur/base_close-1.0)*100.0

                    # Prefer the directly calculated current-vs-previous-close
                    # rate.  However, usa20100 sometimes pins an ETF to the
                    # previous close (cur_prc == base_close_pric, flu_rt == 0)
                    # even while extended-hours trades are occurring.  In that
                    # exact stale pattern, confirm with usa20150 detailed
                    # executions and use its latest trade instead.
                    flu=flu_calc if flu_calc is not None else flu_api
                    change_calc=(cur-base_close) if cur is not None and base_close is not None else None
                    change=change_calc if change_calc is not None else pred_pre
                    rate_source='calc' if flu_calc is not None else 'api'
                    fallback=None
                    stale_zero=(
                        cur is not None and base_close not in (None,0) and
                        abs(cur-base_close) < 1e-12 and
                        (flu_api is None or abs(flu_api) < 1e-12)
                    )
                    if stale_zero:
                        # 1) detailed executions: best source when a fresh trade exists
                        fallback=self._us_latest_execution(sym,ex)
                        promoted=False
                        if fallback and fallback.get('price') is not None:
                            fcur=fallback['price']
                            frate=fallback.get('change_rate')
                            if base_close not in (None,0):
                                frate=(fcur/base_close-1.0)*100.0
                            if frate is not None and abs(frate)>1e-12:
                                cur=fcur
                                flu=frate
                                change=(cur-base_close) if base_close is not None else fallback.get('change')
                                rate_source='usa20150'
                                promoted=True

                        # 2) usa20101 verified cur_prc: use only an actual Kiwoom current-price field.
                        # Never synthesize current price from bid/ask.
                        if not promoted:
                            book=self._us_orderbook_reference(sym,ex,base_close)
                            if book and book.get('price') is not None:
                                bcur=book['price']
                                brate=book.get('change_rate')
                                # usa20101 can itself be pinned to the previous close.
                                # A flat 0.00% orderbook snapshot must NOT block the
                                # external extended-hours confirmation (XLRE case).
                                book_is_fresh = (
                                    base_close in (None,0) or
                                    abs(bcur-base_close) > 1e-8 or
                                    (brate is not None and abs(brate) > 1e-8)
                                )
                                if book_is_fresh:
                                    cur=bcur
                                    flu=brate
                                    change=book.get('change')
                                    rate_source=book.get('source') or 'usa20101_cur_prc_verified'
                                    promoted=(flu is not None)
                                if fallback is None: fallback={}
                                fallback={'usa20150':fallback,'usa20101':book}

                        if not promoted:
                            # 3) Same U.S. trading-day external confirmation.
                            # This runs only for Kiwoom stale-zero snapshots.
                            ext=self._us_external_extended_quote(sym)
                            if ext and ext.get('price') is not None:
                                ecur=ext['price']
                                erate=(ecur/base_close-1.0)*100.0 if base_close not in (None,0) else ext.get('change_rate')
                                if erate is not None and abs(erate)>1e-12:
                                    cur=ecur
                                    flu=erate
                                    change=(cur-base_close) if base_close is not None else ext.get('change')
                                    rate_source=ext.get('source') or 'external_same_day'
                                    promoted=True
                                    if isinstance(fallback,dict):
                                        fallback['external']=ext
                                    else:
                                        fallback={'kiwoom':fallback,'external':ext}

                        if not promoted:
                            # No confirmed same-day trade anywhere: keep Kiwoom's
                            # flat snapshot. Never synthesize from stale/one-sided quotes.
                            cur=base_close
                            flu=0.0
                            change=0.0
                            rate_source='usa20100_flat_no_same_day_trade'

                    if cur is None and flu is None:
                        break
                    self._us_exchange_cache[sym]=ex
                    # Temporary diagnostics for the U.S. watchlist.  Keep both
                    # the parsed values and the exact Kiwoom response fields so a
                    # genuine 0.00% can be distinguished from a stale/misnamed
                    # previous-close field without guessing.
                    diag_keys=('cur_prc','base_close_pric','base_pric','flu_rt','pred_pre',
                               'pred_pre_sig','open_pric','high_pric','low_pric',
                               'acc_trde_qty','trde_qty','stex_tp','stk_cd','stk_nm')
                    diag_raw={k:data.get(k) for k in diag_keys if k in data}
                    return {
                        'code':sym,
                        'exchange':ex,
                        'name':str(data.get('stk_nm') or ''),
                        'name_en':str(data.get('stk_enm') or ''),
                        'price':cur,
                        'base_close':base_close,
                        'change':change,
                        'change_rate':flu,
                        'change_rate_api':flu_api,
                        'change_rate_calc':flu_calc,
                        'change_rate_source':rate_source,
                        'fallback_usa20150':fallback,
                        'volume':self._us_num(data.get('acc_trde_qty') or data.get('trde_qty')),
                        'diag_raw':diag_raw,
                        'diag_keys':sorted(str(k) for k in data.keys()),
                    }
                except Exception as e:
                    last=e
                    if 'HTTP 429' in str(e) and attempt<2:
                        time.sleep(1.15*(attempt+1))
                        continue
                    break
        raise last or ApiError('미국주식 현재가 조회 실패: '+sym)

    def _us_index_quote(self, code):
        """Return an actual U.S. cash-index quote for the four dashboard indices.

        Kiwoom usa10102 is an index *master/list* endpoint only (index code/name),
        not a current-price endpoint.  Therefore the dashboard must not fake the
        index with SPY/DIA/QQQ/IWM.  For these four rows only, read the cash-index
        chart metadata/last 1-minute print and calculate change vs the official
        previous close.  Cash indices do not have a stock-style pre/after market;
        outside regular hours the last official cash-index print remains visible.
        """
        req=str(code or '').strip().upper()
        symbols={'SPX':'^GSPC','DJI':'^DJI','IXIC':'^IXIC','RUT':'^RUT'}
        names={
            'SPX':('S&P 500 지수','S&P 500 Index'),
            'DJI':('다우존스 산업평균지수','Dow Jones Industrial Average'),
            'IXIC':('나스닥 종합지수','Nasdaq Composite'),
            'RUT':('러셀 2000','Russell 2000'),
        }
        ysym=symbols.get(req)
        if not ysym:
            return None
        now=time.time()
        cache=getattr(self,'_us_index_quote_cache',None)
        if cache is None:
            cache={}; self._us_index_quote_cache=cache
        old=cache.get(req)
        if old and now-old.get('ts',0)<10 and old.get('quote'):
            return dict(old['quote'])

        last_err=None
        for host in ('query1.finance.yahoo.com','query2.finance.yahoo.com'):
            try:
                url=(f'https://{host}/v8/finance/chart/{urllib.parse.quote(ysym, safe="")}'
                     '?interval=1m&range=1d&includePrePost=false&events=div%2Csplits')
                r=urllib.request.Request(url,headers={
                    'User-Agent':'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124 Safari/537.36',
                    'Accept':'application/json,text/plain,*/*',
                    'Referer':'https://finance.yahoo.com/'
                })
                with urllib.request.urlopen(r,timeout=6) as resp:
                    payload=json.loads(resp.read(2_000_000))
                result=((payload.get('chart') or {}).get('result') or [None])[0]
                if not isinstance(result,dict):
                    continue
                meta=result.get('meta') or {}
                price=None
                for k in ('regularMarketPrice','chartPreviousClose','previousClose'):
                    try:
                        v=meta.get(k)
                        if v not in (None,''):
                            price=abs(float(v)); break
                    except Exception:
                        pass
                # During regular trading, the last 1-minute close is the freshest
                # official cash-index print; outside the session this remains the
                # last official print and must not be replaced by an ETF proxy.
                ts=result.get('timestamp') or []
                closes=((((result.get('indicators') or {}).get('quote') or [{}])[0] or {}).get('close') or [])
                last_stamp=None
                for t,c in zip(ts,closes):
                    try:
                        if c is None: continue
                        cv=abs(float(c))
                        if cv>0:
                            price=cv; last_stamp=int(t)
                    except Exception:
                        pass
                prev=None
                for k in ('chartPreviousClose','previousClose','regularMarketPreviousClose'):
                    try:
                        v=meta.get(k)
                        if v not in (None,''):
                            prev=abs(float(v)); break
                    except Exception:
                        pass
                if not price or not prev:
                    continue
                rate=(price/prev-1.0)*100.0
                ko,en=names[req]
                quote={
                    'code':req,'name':ko,'name_en':en,'price':price,
                    'base_close':prev,'change':price-prev,'change_rate':rate,
                    'change_rate_source':'cash_index','is_index':True,
                    'index_symbol':ysym,'index_time':last_stamp or meta.get('regularMarketTime'),
                    'source':'actual_cash_index'
                }
                cache[req]={'ts':now,'quote':quote}
                return dict(quote)
            except Exception as e:
                last_err=e
                continue
        if old and old.get('quote'):
            return dict(old['quote'])
        if last_err:
            raise ApiError('미국지수 현재값 조회 실패: '+req)
        return None

    def us_watchlist_quotes(self, tickers):
        """U.S. watchlist: actual cash indices + stock/ETF REST/FE quotes."""
        requested=[];seen=set()
        for raw in tickers:
            sym=str(raw or '').strip().upper()
            if sym and sym not in seen:
                seen.add(sym);requested.append(sym)

        index_codes={'SPX','DJI','IXIC','RUT'}
        actual=[sym for sym in requested if sym not in index_codes]

        # Only tradable stocks/ETFs belong in the FE subscription.  Cash indices
        # are intentionally excluded so they can never be confused with ETF proxies.
        feed=getattr(self,'_us_realtime_feed',None)
        if feed is None:
            feed=UsRealtimeFeed(self); self._us_realtime_feed=feed
        feed.ensure(actual)

        now=time.time(); key=','.join(actual)
        cache=getattr(self,'_us_watch_rest_cache',None) or {}
        if cache.get('key')==key and now-cache.get('ts',0)<60 and cache.get('quotes') is not None:
            base_by_actual={k:dict(v) for k,v in cache['quotes'].items()}
            errors=dict(cache.get('errors') or {})
        else:
            base_by_actual={}; errors={}
            master=self.us_exchange_map(False)
            for sym in actual:
                ex=master.get(sym) or getattr(self,'_us_exchange_cache',{}).get(sym)
                try:
                    base_by_actual[sym]=self.us_quote(sym,ex)
                except Exception as e:
                    errors[sym]=str(e)
            self._us_watch_rest_cache={'ts':now,'key':key,'quotes':{k:dict(v) for k,v in base_by_actual.items()},'errors':dict(errors)}

        live,rt_status=feed.snapshot()
        merged={}
        for sym in actual:
            q=dict(base_by_actual.get(sym) or {'code':sym})
            rq=live.get(sym)
            if rq:
                raw_price=rq.get('price')
                try: price=abs(float(raw_price)) if raw_price is not None else None
                except Exception: price=None
                base=q.get('base_close')
                try: base=float(base) if base is not None else None
                except Exception: base=None
                sane=price is not None and price>0
                if sane and base is not None and base>0:
                    sane=(0.25 <= price/base <= 4.0)
                if sane:
                    q['price']=price
                    if base is not None and base>0:
                        q['change']=price-base
                        q['change_rate']=(price/base-1.0)*100.0
                        q['change_rate_source']='websocket_FE_price_calc'
                    q['live']=True;q['live_time']=rq.get('time');q['received_at']=rq.get('received_at')
                else:q['live']=False
            else:q['live']=False
            merged[sym]=q

        out=[];out_errors={}
        for req in requested:
            if req in index_codes:
                try:
                    q=self._us_index_quote(req)
                    if q: out.append(q)
                    else:
                        out.append({'code':req,'is_index':True,'price':None,'change_rate':None})
                        out_errors[req]='미국지수 현재값 없음'
                except Exception as e:
                    out.append({'code':req,'is_index':True,'price':None,'change_rate':None})
                    out_errors[req]=str(e)
                continue
            q=dict(merged.get(req) or {'code':req});q['code']=req;out.append(q)
            if req in errors:out_errors[req]=errors[req]

        return {'updated_at':datetime.now(KST).isoformat(),
                'source':'미국지수 실제 포인트 + 키움 FE/REST 미국주식',
                'quotes':out,'errors':out_errors,'realtime':rt_status}

    def us_market_snapshot(self):
        """U.S. market ranking dashboard using Kiwoom REST only.

        This deliberately keeps each source independent: a rejected/unsupported TR
        does not blank the whole page.  Filters are conservative and use Kiwoom's
        all-market/default values first, with common exchange-code fallbacks.
        """
        if self.mock:
            return {'updated_at':datetime.now(KST).isoformat(),'source':'키움 미국주식 REST','sections':{},'errors':{'all':'모의투자 REST에서는 미국주식 순위 조회가 제한될 수 있습니다.'}}
        sections={}; errors={}
        # Real-time view popularity. svc_type values differ by service revision;
        # try the documented/default empty value first and common service values.
        rows,err=self._us_try('usa01980',[{'svc_type':''},{'svc_type':'1'},{'svc_type':'0'},{'svc_type':'2'}],30)
        popular_source='usa01980'
        # Some live accounts return a successful usa01980 response with an empty
        # result_list.  In that case fall back to Kiwoom's own U.S. top-traded
        # ranking (usa20880) instead of leaving the card blank.  Try conservative
        # selector variants because service revisions differ in accepted values.
        if not rows:
            trade_bodies=[
                {},
                {'qry_tp':'1','dt_unit_tp':'1'},
                {'qry_tp':'0','dt_unit_tp':'1'},
                {'qry_tp':'1','dt_unit_tp':'0'},
                {'qry_tp':'2','dt_unit_tp':'1'},
                {'qry_tp':'1','dt_unit_tp':'2'},
            ]
            fb_rows,fb_err=self._us_try('usa20880',trade_bodies,30)
            if fb_rows:
                rows=fb_rows
                err=None
                popular_source='usa20880'
            elif fb_err:
                err=(err+' / ' if err else '')+'usa20880: '+fb_err
        sections['popular']=rows
        sections['popular_source']=popular_source
        if err:errors['popular']=err

        # Day transaction-value / change ranking. Empty exchange means all where supported;
        # fallbacks query U.S. market codes used by Kiwoom account/stock APIs.
        value_bodies=[]; gain_bodies=[]
        for ex in ('','ND','NY','NA'):
            value_bodies.append({'stex_tp':ex,'inds_cd':'','stk_tp':'1','trde_qty_tp':'0','qry_tp':'1','stk_cnd':'0','pric_cnd':'0','trde_prica_cnd':'0'})
            gain_bodies.append({'stex_tp':ex,'inds_cd':'','inds_cls_tp':'0','sort_tp':'1','stk_tp':'1','stk_cnd':'0','pric_cnd':'0','trde_prica_cnd':'0','trde_qty_tp':'0'})
        rows,err=self._us_try('usa20540',value_bodies,30);sections['value']=rows
        if err:errors['value']=err
        rows,err=self._us_try('usa20910',gain_bodies,30);sections['gainers']=rows
        if err:errors['gainers']=err

        sector_bodies=[]
        for ex in ('','ND','NY','NA'):
            sector_bodies.append({'stex_tp':ex,'sort_tp':'1','inds_cd':''})
        rows,err=self._us_try('usa23100',sector_bodies,30);sections['sectors']=rows
        if err:errors['sectors']=err
        return {'updated_at':datetime.now(KST).isoformat(),'source':'키움 미국주식 REST usa01980·usa20540·usa20910·usa23100','sections':sections,'errors':errors}

    def account_snapshot(self):
        """Read-only domestic account evaluation / holdings using official Kiwoom REST TRs."""
        self.auth()

        def num(v, absolute=False):
            if v in (None,''): return None
            try:
                x=float(str(v).replace(',','').strip())
                return abs(x) if absolute else x
            except (TypeError,ValueError):
                return None

        acct_no=getattr(self,'_litto_account_no',None)
        if acct_no is None:
            data,_=self._post('/api/dostk/acnt',{},{
                'authorization':'Bearer '+self.token,
                'api-id':'ka00001',
                'cont-yn':'N','next-key':''
            })
            acct_no=str(data.get('acctNo') or '').strip()
            self._litto_account_no=acct_no

        # Use the integrated SOR account valuation so holdings bought on NXT are
        # evaluated with the combined KRX+NXT market instead of KRX-only prices.
        # Mock trading supports KRX only.  If SOR account valuation is unavailable
        # in a given environment, fall back to KRX rather than breaking the account page.
        venue='KRX' if self.mock else 'SOR'
        body={'qry_tp':'1','dmst_stex_tp':venue}
        rows=[]; summary={}; cont='N'; next_key=''; seen=set()
        for _ in range(10):
            try:
                data,h=self._post('/api/dostk/acnt',body,{
                    'authorization':'Bearer '+self.token,
                    'api-id':'kt00018',
                    'cont-yn':cont,
                    'next-key':next_key
                })
            except Exception:
                # Some provider revisions may not accept SOR on kt00018.
                # Retry once using KRX so account lookup still works.
                if venue!='SOR' or cont!='N':
                    raise
                venue='KRX'
                body={'qry_tp':'1','dmst_stex_tp':'KRX'}
                data,h=self._post('/api/dostk/acnt',body,{
                    'authorization':'Bearer '+self.token,
                    'api-id':'kt00018',
                    'cont-yn':'N',
                    'next-key':''
                })
            part=data.get('acnt_evlt_remn_indv_tot') or []
            if not isinstance(part,list):
                raise ApiError('kt00018 계좌 잔고 목록 형식이 다릅니다.')
            rows.extend(part)
            for k in ('tot_pur_amt','tot_evlt_amt','tot_evlt_pl','tot_prft_rt',
                      'prsm_dpst_aset_amt','tot_loan_amt'):
                if k in data: summary[k]=data.get(k)
            if h.get('cont-yn')!='Y': break
            cont='Y'; next_key=h.get('next-key','')
            if not next_key or next_key in seen: break
            seen.add(next_key)

        by_code={}
        for r in rows:
            raw=str(r.get('stk_cd') or '').strip()
            c=raw[1:] if len(raw)>=7 and raw[0] in 'AJQ' else base_code(raw)
            if not c: continue
            qty=num(r.get('rmnd_qty'),True) or 0
            if qty<=0: continue
            by_code[c]={
                'code':c,
                'name':str(r.get('stk_nm') or '').strip(),
                'quantity':qty,
                'available_quantity':num(r.get('trde_able_qty'),True),
                'avg_price':num(r.get('pur_pric'),True),
                'current_price':num(r.get('cur_prc'),True),
                'purchase_amount':num(r.get('pur_amt')),
                'evaluation_amount':num(r.get('evlt_amt')),
                'evaluation_pnl':num(r.get('evltv_prft')),
                'profit_rate':num(r.get('prft_rt')),
                'weight':num(r.get('poss_rt')),
            }

        holdings=list(by_code.values())
        holdings.sort(key=lambda x:abs(float(x.get('evaluation_amount') or 0)),reverse=True)
        return {
            'account_no':acct_no,
            'mock':bool(self.mock),
            'summary':{
                'estimated_assets':num(summary.get('prsm_dpst_aset_amt')),
                'total_purchase':num(summary.get('tot_pur_amt')),
                'total_evaluation':num(summary.get('tot_evlt_amt')),
                'total_pnl':num(summary.get('tot_evlt_pl')),
                'total_profit_rate':num(summary.get('tot_prft_rt')),
                'total_loan':num(summary.get('tot_loan_amt')),
            },
            'holdings':holdings,
            'updated_at':datetime.now(KST).isoformat(),
            'source':f'키움 공식 REST kt00018 · {venue}'
        }

    def _order_post(self, api_id, body):
        """Order-only POST.

        Kept separate from generic _post so an order rejection can surface
        Kiwoom's provider message without changing error handling elsewhere.
        """
        self.auth()
        h={
            'Content-Type':'application/json;charset=UTF-8',
            'authorization':'Bearer '+self.token,
            'api-id':str(api_id),
            'cont-yn':'N',
            'next-key':''
        }
        self._wait_request_slot()
        req=urllib.request.Request(
            self.host+'/api/dostk/ordr',
            json.dumps(body).encode(),
            h,
            method='POST'
        )
        try:
            with urllib.request.urlopen(req,timeout=20) as r:
                data=json.loads(r.read(2_000_000))
        except urllib.error.HTTPError as e:
            detail=''
            try:
                raw=e.read(200000)
                if raw:
                    try:
                        err=json.loads(raw.decode('utf-8','replace'))
                        detail=str(err.get('return_msg') or err.get('message') or err.get('error') or '').replace('\n',' ').strip()
                        code=err.get('return_code')
                        if code not in (None,''):
                            detail=f'{code} · {detail}' if detail else str(code)
                    except Exception:
                        detail=raw.decode('utf-8','replace').replace('\n',' ').strip()
            except Exception:
                detail=''
            suffix=f' · {detail[:180]}' if detail else ''
            raise ApiError(f'키움 주문 HTTP {e.code}{suffix}') from None
        except (urllib.error.URLError,TimeoutError,OSError,json.JSONDecodeError):
            raise ApiError('키움 주문 연결 실패: 네트워크·서비스 상태를 확인하세요.') from None

        if str(data.get('return_code','0'))!='0':
            msg=str(data.get('return_msg') or '주문 거부').replace('\n',' ').strip()[:180]
            raise ApiError(f"키움 주문 오류 {data.get('return_code')} · {msg}")
        return data

    def manual_cash_order(self, side, stock_code, qty, price=None, order_type='limit', venue='SOR'):
        """Manual cash buy/sell.  No automatic strategy calls this method."""
        self.auth()
        side=str(side or '').lower().strip()
        if side not in ('buy','sell'):
            raise ApiError('매수/매도 구분 오류')
        c=base_code(stock_code)
        if not c:
            raise ApiError('종목코드가 필요합니다.')
        try:q=int(qty)
        except Exception:q=0
        if q<=0:
            raise ApiError('주문수량은 1주 이상이어야 합니다.')

        typ=str(order_type or 'limit').lower().strip()
        if typ not in ('limit','market'):
            raise ApiError('주문유형 오류')
        try:p=int(float(price or 0))
        except Exception:p=0
        if typ=='limit' and p<=0:
            raise ApiError('지정가 주문가격이 필요합니다.')

        v=str(venue or 'SOR').upper()
        if v not in ('KRX','NXT','SOR'): v='SOR'
        # Kiwoom mock domestic orders support KRX only.
        if self.mock: v='KRX'

        api_id='kt10000' if side=='buy' else 'kt10001'
        body={
            'dmst_stex_tp':v,
            'stk_cd':c,
            'ord_qty':str(q),
            'ord_uv':str(p) if typ=='limit' else '',
            'trde_tp':'0' if typ=='limit' else '3',
            'cond_uv':''
        }
        data=self._order_post(api_id,body)
        order_no=str(data.get('ord_no') or '').strip()
        return {
            'ok':bool(order_no),
            'uncertain':not bool(order_no),
            'side':side,
            'code':c,
            'qty':q,
            'price':p if typ=='limit' else None,
            'order_type':typ,
            'venue':v,
            'order_no':order_no,
            'provider_message':str(data.get('return_msg') or '').strip(),
            'status':'accepted' if order_no else 'acceptance_unknown',
            'mock':bool(self.mock)
        }

    def unfilled_orders(self, stock_code=''):
        """Current unfilled cash orders (ka10075)."""
        self.auth()
        c=base_code(stock_code) if stock_code else ''
        body={
            'all_stk_tp':'1' if c else '0',
            'trde_tp':'0',
            'stk_cd':c,
            'stex_tp':'0'
        }
        rows=self.rows('ka10075',body,'oso',500,max_pages=10)
        out=[]
        def iv(v):
            try:return int(float(str(v or '0').replace(',','')))
            except Exception:return 0
        for r in rows:
            remain=iv(r.get('oso_qty'))
            if remain<=0: continue
            raw=str(r.get('stk_cd') or '').strip()
            rc=raw[1:] if len(raw)>=7 and raw[0] in 'AJQ' else base_code(raw)
            side_name=str(r.get('io_tp_nm') or '').strip()
            side='buy' if '매수' in side_name else ('sell' if '매도' in side_name else '')
            venue=str(r.get('stex_tp_txt') or '').upper().strip()
            if venue not in ('KRX','NXT','SOR'):
                venue='SOR' if str(r.get('sor_yn') or '').upper()=='Y' else 'KRX'
            out.append({
                'order_no':str(r.get('ord_no') or '').strip(),
                'orig_order_no':str(r.get('orig_ord_no') or '').strip(),
                'code':rc,
                'name':str(r.get('stk_nm') or '').strip(),
                'side':side,
                'side_name':side_name,
                'order_qty':iv(r.get('ord_qty')),
                'filled_qty':iv(r.get('cntr_qty')),
                'remain_qty':remain,
                'order_price':iv(r.get('ord_pric')),
                'filled_price':iv(r.get('cntr_pric')),
                'status':str(r.get('ord_stt') or '').strip(),
                'time':str(r.get('tm') or '').strip(),
                'venue':venue,
            })
        return out

    def cancel_cash_order(self, order_no, stock_code, qty=0, venue='SOR'):
        """Cancel one open order. qty=0 means all remaining quantity."""
        self.auth()
        no=str(order_no or '').strip()
        c=base_code(stock_code)
        if not no or not c:
            raise ApiError('취소할 주문번호와 종목코드가 필요합니다.')
        try:q=max(0,int(qty or 0))
        except Exception:q=0
        v=str(venue or 'SOR').upper()
        if v not in ('KRX','NXT','SOR'): v='SOR'
        if self.mock: v='KRX'
        body={
            'dmst_stex_tp':v,
            'orig_ord_no':no,
            'stk_cd':c,
            'cncl_qty':str(q),
        }
        data=self._order_post('kt10003',body)
        return {
            'ok':True,
            'order_no':str(data.get('ord_no') or '').strip(),
            'canceled_order_no':no,
            'code':c,
            'qty':q,
            'venue':v,
            'provider_message':str(data.get('return_msg') or '').strip(),
            'mock':bool(self.mock)
        }

    def daily_trading_journal(self, base_dt=None):
        """Return Kiwoom's account-level daily trading journal (ka10170).

        ka10170 is preferred because it already aggregates same-day buy/sell
        activity per stock and supplies realized P/L.  The exact payload is kept
        read-only; no order endpoint is exposed from this adapter.
        """
        self.auth()
        dt=(base_dt or datetime.now(KST).strftime('%Y%m%d')).replace('-','')
        body={'base_dt':dt,'ottks_tp':'2','ch_crd_tp':'0'}
        output=[];summary={};continuation='N';nextkey='';seen=set()
        for _ in range(10):
            data,h=self._post('/api/dostk/acnt',body,{'authorization':'Bearer '+self.token,'api-id':'ka10170','cont-yn':continuation,'next-key':nextkey})
            rows=data.get('tdy_trde_diary')
            if rows is None:
                # Service revisions occasionally use alternate table keys; keep
                # diagnostics safe while accepting only list-shaped account rows.
                for k,v in data.items():
                    if isinstance(v,list) and k not in {'data'}:
                        rows=v;break
            if rows is not None and not isinstance(rows,list):
                raise ApiError('ka10170 응답의 매매일지 목록 형식이 다릅니다.')
            output.extend(rows or [])
            for k in ('tot_sell_amt','tot_buy_amt','tot_cmsn_tax','tot_exct_amt','tot_pl_amt','tot_prft_rt'):
                if k in data: summary[k]=data.get(k)
            if h.get('cont-yn')!='Y':break
            continuation='Y';nextkey=h.get('next-key','')
            if not nextkey or nextkey in seen:break
            seen.add(nextkey)
        return {'rows':output,'summary':summary,'source':'ka10170','date':dt}

    def realized_pnl(self, start_dt=None, end_dt=None):
        """Fallback realized-P/L source using official ka10073 account API."""
        self.auth()
        start=(start_dt or datetime.now(KST).strftime('%Y%m%d')).replace('-','')
        end=(end_dt or start).replace('-','')
        rows=self.rows('ka10073',{'strt_dt':start,'end_dt':end},'dt_stk_rlzt_pl',2000,max_pages=20)
        return {'rows':rows,'source':'ka10073','start':start,'end':end}

    def filled_orders(self, limit=1000):
        """Raw filled-order query (ka10076), retained for diagnostics."""
        bodies=[
            {'qry_tp':'0','sell_tp':'0','stex_tp':'0'},
            {'qry_tp':'1','sell_tp':'0','stex_tp':'0'},
            {'qry_tp':'0','sell_tp':'0','stex_tp':'3'},
        ]
        last=None
        for body in bodies:
            try:
                rows=self.rows('ka10076',body,'cntr',limit,max_pages=20)
                if rows:return rows
            except ApiError as e:last=e
        if last:raise last
        return []

    def realtime_rank(self,qry_tp='5',limit=30):
        """Kiwoom ka00198 real-time stock lookup ranking.

        qry_tp: 1=1min, 2=10min, 3=1hour, 4=day cumulative, 5=30sec.
        The provider's rank is returned unchanged; LITTO only normalizes numbers.
        """
        qry_tp=str(qry_tp)
        if qry_tp not in {'1','2','3','4','5'}:
            raise ApiError('실시간 조회순위 구분값 오류')
        rows=self.rows('ka00198',{'qry_tp':qry_tp},'item_inq_rank',max(1,int(limit)),max_pages=10)
        out=[]
        for row in rows:
            c=base_code(row.get('stk_cd',''))
            try: rank=int(float(str(row.get('bigd_rank','')).replace(',','')))
            except (ValueError,TypeError): rank=None
            def num(key,absolute=False):
                try:
                    v=float(str(row.get(key,'')).replace(',',''))
                    return abs(v) if absolute else v
                except (ValueError,TypeError): return None
            out.append({
                'code':c,'name':(row.get('stk_nm') or '').strip(),
                'rank':rank,'provider_rank_change':num('rank_chg'),
                'provider_rank_sign':str(row.get('rank_chg_sign') or '').strip(),
                'price':num('past_curr_prc',True),'change':num('base_comp_chgr'),
                'prev_change':num('prev_base_chgr'),
                'date':str(row.get('dt') or '').strip(),'time':str(row.get('tm') or '').strip()
            })
        return [x for x in out if x['rank'] is not None]

    def top(self,n):
        """Return Kiwoom's RAW integrated trading-value ranking.

        Do not remove/re-rank ETF/ETN here. The user's original condition is
        "거래대금 순위 상위 35" and rank positions must stay exactly as Kiwoom
        returned them. Product exclusion, when requested, is applied only after
        the raw top-35 universe is fixed, without filling vacant ranks.
        """
        return self.rows('ka10032',{'mrkt_tp':'000','mang_stk_incls':'1','stex_tp':'3'},
                         'trde_prica_upper',n,max_pages=10)

    def change_top(self,n=100):
        body={'mrkt_tp':'000','sort_tp':'1','trde_qty_cnd':'0000','stk_cnd':'0','crd_cnd':'0',
              'updown_incls':'1','pric_cnd':'0','trde_prica_cnd':'0','stex_tp':'3'}
        return self.rows('ka10027',body,'pred_pre_flu_rt_upper',n,max_pages=10)

    def change_top_side(self, side='up', n=20):
        """HTS 0177-style 상승/하락 + 거래대금순.

        사용자 HTS 설정:
        - [0177] 특정일자 상한가/하한가 (통합)
        - 상승 또는 하락
        - 정렬: 거래대금순

        REST에서는 HTS 화면번호 자체를 호출하지 않으므로,
        통합 거래대금 순위(ka10032, KRX+NXT)를 넓게 받은 뒤
        등락률 부호로 상승/하락을 나눠 원래 거래대금 순서를 유지한다.
        """
        side=str(side or 'up').lower()
        if side not in {'up','down'}:
            raise ApiError('상승/하락 구분값 오류')

        want=max(1,int(n))
        # 하락 종목이 적은 강세장도 고려해 충분한 거래대금 상위 원천을 확보한다.
        raw=self.top(max(300,want*15))

        def num(row,*keys,absolute=False):
            for key in keys:
                if key not in row:
                    continue
                try:
                    v=float(str(row.get(key,'')).replace(',','').replace('+',''))
                    return abs(v) if absolute else v
                except (ValueError,TypeError):
                    pass
            return None

        parsed=[]
        for row in raw:
            c=base_code(row.get('stk_cd',''))
            if not c:
                continue

            name=(row.get('stk_nm') or '').strip()
            upper_name=name.upper()

            # HTS 0177 요청 기준: ETF / ETN / 스팩(SPAC) 제외.
            product_type=str(row.get('product_type') or '').upper()
            etf_flag=str(row.get('etf') or '').upper()
            etn_flag=str(row.get('etn') or '').upper()
            is_etf = ('ETF' in product_type or etf_flag in {'1','Y','TRUE'}
                      or upper_name.startswith(('KODEX ','TIGER ','KBSTAR ','ACE ','ARIRANG ','HANARO ','SOL ','KOSEF ','RISE ')))
            is_etn = ('ETN' in product_type or etn_flag in {'1','Y','TRUE'} or ' ETN' in upper_name or upper_name.endswith('ETN'))
            is_spac = ('스팩' in name or 'SPAC' in upper_name)
            if is_etf or is_etn or is_spac:
                continue

            rate=num(row,'flu_rt','base_comp_chgr','pred_pre_flu_rt')
            if rate is None:
                continue
            if side=='up' and rate <= 0:
                continue
            if side=='down' and rate >= 0:
                continue
            provider_rank=num(row,'now_rank',absolute=True)
            parsed.append({
                'provider_rank':int(provider_rank) if provider_rank is not None else 999999,
                'code':c,
                'name':(row.get('stk_nm') or '').strip(),
                'price':num(row,'cur_prc','past_curr_prc','now_prc',absolute=True),
                'change_rate':rate,
                'change_amount':num(row,'pred_pre','base_comp','diff'),
                'volume':num(row,'now_trde_qty','trde_qty',absolute=True),
                'trading_value':num(row,'trde_prica',absolute=True),
            })

        # ka10032 provider order is 거래대금순. now_rank is retained as a stable key.
        parsed.sort(key=lambda x:(x['provider_rank'],x['code']))
        out=[]
        for i,x in enumerate(parsed[:want],1):
            x=dict(x)
            x['rank']=i
            out.append(x)
        return out
    def limit_codes(self,previous=False):
        body={'mrkt_tp':'000','updown_tp':'6' if previous else '1','sort_tp':'1','stk_cnd':'0',
              'trde_qty_tp':'00000','crd_cnd':'0','trde_gold_tp':'0','stex_tp':'3'}
        rows=self.rows('ka10017',body,'updown_pric',100,max_pages=10)
        return [base_code(r['stk_cd']) for r in rows if r.get('stk_cd')]


    def quote(self,c,venue='SOR'):
        """Provider current quote without local percentage recomputation.

        SOR uses _AL for the integrated KRX+NXT quote used by the three search formulas.
        NXT uses _NX only for the MTS display quote during NXT trading.
        """
        c=base_code(c)
        if self.mock:
            market_code=c; venue_used='KRX(mock)'
        elif str(venue).upper()=='NXT':
            market_code=nxt_code(c); venue_used='NXT'
        else:
            market_code=sor_code(c); venue_used='SOR'
        self.auth()
        data,_=self._post(self.ALLOWED['ka10001'],{'stk_cd':market_code},
                          {'authorization':'Bearer '+self.token,'api-id':'ka10001'})
        def num(k,absolute=False):
            try:
                v=float(str(data.get(k,'')).replace(',',''))
                return abs(v) if absolute else v
            except (ValueError,TypeError):
                return None
        return {'name':(data.get('stk_nm') or data.get('name') or '').strip(),
                'price':num('cur_prc',True),'change':num('flu_rt'),'pred_pre':num('pred_pre'),
                'base_price':num('base_pric',True),'open':num('open_pric',True),
                'high':num('high_pric',True),'low':num('low_pric',True),
                'venue':venue_used,'market_code':market_code}


    def domestic_orderbook(self,c,venue='SOR'):
        """Return a 10-level domestic orderbook snapshot.

        SOR uses the integrated ``_AL`` code so the snapshot matches Kiwoom MTS
        통합 호가 as closely as possible.  Falls back to KRX when SOR is not
        available.  The quote fields come from ka10001 using the same venue so
        기준가/등락률 do not get mixed with KRX-only chart values.
        """
        c=base_code(c)
        self.auth()
        market_code=sor_code(c) if str(venue).upper()=='SOR' else (nxt_code(c) if str(venue).upper()=='NXT' else c)
        try:
            data,_=self._post(self.ALLOWED['ka10004'],{'stk_cd':market_code},
                              {'authorization':'Bearer '+self.token,'api-id':'ka10004'})
            venue_used=str(venue).upper()
        except Exception:
            if market_code==c: raise
            data,_=self._post(self.ALLOWED['ka10004'],{'stk_cd':c},
                              {'authorization':'Bearer '+self.token,'api-id':'ka10004'})
            market_code=c; venue_used='KRX'
        def num(k,absolute=True):
            try:
                v=float(str(data.get(k,'')).replace(',','').replace('+','').strip())
                return abs(v) if absolute else v
            except (ValueError,TypeError):
                return None
        asks=[]; bids=[]
        asks.append({'level':1,'price':num('sel_fpr_bid'),'qty':num('sel_fpr_req')})
        bids.append({'level':1,'price':num('buy_fpr_bid'),'qty':num('buy_fpr_req')})
        for i in range(2,11):
            asks.append({'level':i,'price':num(f'sel_{i}th_pre_bid'),'qty':num(f'sel_{i}th_pre_req')})
            bids.append({'level':i,'price':num(f'buy_{i}th_pre_bid'),'qty':num(f'buy_{i}th_pre_req')})
        # Quote and orderbook use the same venue.  This avoids mixing KRX 기준가
        # with SOR/NXT current prices, which produced the +4.70% / +5.96% mismatch.
        try:
            q=self.quote(c,venue_used)
        except Exception:
            q={}
        return {
            'code':c,'market_code':market_code,'venue':venue_used,
            'asks':asks,'bids':bids,
            'ask_total':num('tot_sel_req') or 0,'bid_total':num('tot_buy_req') or 0,
            'orderbook_time':str(data.get('bid_req_base_tm') or ''),
            'current_price':q.get('price'),'change_rate':q.get('change'),
            'base_price':q.get('base_price'),'open':q.get('open'),'high':q.get('high'),'low':q.get('low'),
            'source':'키움 ka10004 통합(SOR) 호가 + ka10001 통합(SOR) 시세' if venue_used=='SOR' else '키움 ka10004 KRX 호가 + ka10001 KRX 시세'
        }

    def universe(self):
        out=[]
        for market in ('0','10'):
            rows=self.rows('ka10099',{'mrkt_tp':market},'list',4000,max_pages=10)
            for r in rows:
                c=r.get('code') or r.get('stk_cd')
                if c: out.append({'code':code(c),'name':r.get('name') or r.get('stk_nm') or c})
        seen={}
        for x in out: seen[x['code']]=x
        return list(seen.values())

    def minute(self,c,minutes=3,limit=3000):
        """Return an SOR-style minute history for F-zone calculations.

        Kiwoom's _AL current quote is integrated, but historical ka10080 can omit
        NXT-only pre/after-market bars on some responses. To keep the F-zone input
        aligned with the MTS integrated chart, fetch both _AL and _NX histories.

        Merge policy:
        - _AL is authoritative for timestamps it supplies (regular/overlap session).
        - _NX fills timestamps that are absent from _AL (notably NXT-only sessions).
        - This avoids inventing OHLC ordering when both venues traded in the same
          minute bucket while still restoring missing 08:00/after-market NXT bars.
        """
        c=base_code(c);now=datetime.now(KST)
        if self.mock:
            rows=self.rows('ka10080',{'stk_cd':c,'tic_scope':str(minutes),'upd_stkpc_tp':'1'},
                           'stk_min_pole_chart_qry',limit,max_pages=50)
            merged={r['cntr_tm']:minute_bar(r,now,minutes) for r in rows}
            return sorted(merged.values(),key=lambda x:x['time'])

        al_rows=self.rows('ka10080',{'stk_cd':sor_code(c),'tic_scope':str(minutes),'upd_stkpc_tp':'1'},
                          'stk_min_pole_chart_qry',limit,max_pages=50)
        nx_rows=self.rows('ka10080',{'stk_cd':nxt_code(c),'tic_scope':str(minutes),'upd_stkpc_tp':'1'},
                          'stk_min_pole_chart_qry',limit,max_pages=50)

        # Start with NXT, then let _AL overwrite identical timestamps.  This keeps
        # the provider's integrated/regular-session candle whenever it exists while
        # adding NXT-only bars such as 08:00 that _AL history may omit.
        merged={r['cntr_tm']:minute_bar(r,now,minutes) for r in nx_rows}
        for r in al_rows:
            merged[r['cntr_tm']]=minute_bar(r,now,minutes)
        return sorted(merged.values(),key=lambda x:x['time'])

    def daily_history_rows(self,c,limit=180):
        """Fetch a compact daily history for chart MA5/10/20/60.

        Keep SOR recent data authoritative and use one KRX history request as
        a lightweight backfill source. 180 bars is enough for a 90-bar
        viewport to render MA60 from the first visible candle without the
        expensive MA120 multi-page backfill.
        """
        c=base_code(c); now=datetime.now(KST)
        market_code=c if self.mock else sor_code(c)
        merged={}

        def add_rows(rows, overwrite=False):
            for r in rows or []:
                dt=str(r.get('dt') or '')
                if not dt:
                    continue
                if overwrite or dt not in merged:
                    merged[dt]=r

        try:
            al=self.rows('ka10081',{'stk_cd':market_code,'base_dt':now.strftime('%Y%m%d'),'upd_stkpc_tp':'1'},
                         'stk_dt_pole_chart_qry',limit,max_pages=8)
            add_rows(al,True)
        except ApiError:
            if self.mock:
                raise

        if not self.mock and len(merged)<150:
            try:
                krx=self.rows('ka10081',{'stk_cd':c,'base_dt':now.strftime('%Y%m%d'),'upd_stkpc_tp':'1'},
                              'stk_dt_pole_chart_qry',limit,max_pages=8)
                add_rows(krx,False)
            except ApiError:
                pass

        rows=list(merged.values())
        rows.sort(key=lambda r:str(r.get('dt') or ''))
        return rows[-limit:]

    def stock(self,c,name,sector='미분류'):
        c=base_code(c);now=datetime.now(KST)
        # SOR(_AL) = KRX+NXT 통합 시세. 모의투자는 KRX만 지원하므로 원코드 사용.
        market_code=c if self.mock else sor_code(c)
        ds=self.daily_history_rows(c,180)
        ms=self.rows('ka10080',{'stk_cd':market_code,'tic_scope':'15','upd_stkpc_tp':'1'},'stk_min_pole_chart_qry',300)
        # Pagination boundaries may repeat the final record: de-duplicate by date/time.
        daily={r['dt']:daily_bar(r) for r in ds}
        minute={r['cntr_tm']:minute_bar(r,now,15) for r in ms}
        daily_sorted=sorted(daily.values(),key=lambda x:x['date'])
        # The newest candle should use the same provider current-quote percentage
        # used elsewhere in LITTO. This keeps the daily hover rate identical to the
        # watchlist/realtime quote even when adjusted daily closes make an adjacent-
        # close calculation differ from the provider's official change rate.
        try:
            q=self.quote(c,'SOR')
            q_rate=number(q.get('change'))
            q_price=unsigned(q.get('price'))
            if daily_sorted and q_rate is not None:
                last=daily_sorted[-1]
                if q_price is None or last.get('close') is None or abs(float(last['close'])-float(q_price)) < max(1.0,float(q_price)*0.02):
                    last['change_rate']=q_rate
                    last['change_rate_source']='ka10001_flu_rt'
        except ApiError:
            pass
        return {'code':c,'name':name,'sector':sector,'daily':daily_sorted,
                'm15':sorted(minute.values(),key=lambda x:x['time']),'m3':[]}
