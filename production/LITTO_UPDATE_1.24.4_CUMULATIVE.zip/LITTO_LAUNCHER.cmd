@echo off
setlocal
cd /d "%~dp0"
if not exist "LITTO.exe" goto missing
powershell.exe -NoProfile -ExecutionPolicy Bypass -File "%~dp0LITTO_Updater_V2.ps1"
exit /b %errorlevel%
:missing
echo.
echo [LITTO] LITTO.exe not found.
echo Put this launcher in the same folder as LITTO.exe.
echo.
pause
exit /b 1
