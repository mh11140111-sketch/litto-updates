﻿$ErrorActionPreference = "Stop"
$Root = Split-Path -Parent $MyInvocation.MyCommand.Path
$ExePath = Join-Path $Root "LITTO.exe"
$VersionPath = Join-Path $Root "LITTO_PROD_VERSION.txt"
$LogDir = Join-Path $Root "_LITTO_LAUNCHER_LOG"
$ManifestUrl = "https://raw.githubusercontent.com/mh11140111-sketch/litto-updates/main/production/manifest.json"
$BaselineVersion = "1.23.0"

New-Item -ItemType Directory -Force -Path $LogDir | Out-Null
$LogPath = Join-Path $LogDir "launcher_v2.log"
function Log([string]$Message) { Add-Content -LiteralPath $LogPath -Value ((Get-Date -Format "yyyy-MM-dd HH:mm:ss") + " " + $Message) -Encoding UTF8 }
function Launch-Litto { Log "Launching LITTO.exe"; Start-Process -FilePath $ExePath -WorkingDirectory $Root }

if (-not (Test-Path -LiteralPath $ExePath)) { Log "ERROR: LITTO.exe not found"; exit 1 }
if (-not (Test-Path -LiteralPath $VersionPath)) { Set-Content -LiteralPath $VersionPath -Value $BaselineVersion -Encoding ASCII; Log ("Production baseline registered: " + $BaselineVersion) }

$backupDir = $null
try {
    $current = (Get-Content -LiteralPath $VersionPath -Raw).Trim()
    $manifest = Invoke-RestMethod -Uri $ManifestUrl -UseBasicParsing -TimeoutSec 8
    $target = [string]$manifest.version
    if ([string]::IsNullOrWhiteSpace($target)) { throw "Manifest version missing" }
    Log ("Current=" + $current + ", Target=" + $target)
    if ($current -eq $target) { Launch-Litto; exit 0 }

    $stamp = Get-Date -Format "yyyyMMdd_HHmmss"
    $backupDir = Join-Path $Root ("_LITTO_BACKUPS\\" + $stamp)
    New-Item -ItemType Directory -Force -Path $backupDir | Out-Null

    # Mode A: small text replacement operations published in manifest.
    $repls = @($manifest.replacements)
    if ($repls.Count -gt 0) {
        $touched = @{}
        foreach ($op in $repls) {
            $rel = [string]$op.file
            $old = [string]$op.old
            $new = [string]$op.new
            if ([string]::IsNullOrWhiteSpace($rel) -or $rel.Contains("..") -or [IO.Path]::IsPathRooted($rel)) { throw ("Unsafe replacement path: " + $rel) }
            $dest = Join-Path $Root $rel
            if (-not (Test-Path -LiteralPath $dest)) { throw ("Replacement target missing: " + $rel) }
            if (-not $touched.ContainsKey($rel)) {
                $backupFile = Join-Path $backupDir $rel
                New-Item -ItemType Directory -Force -Path (Split-Path -Parent $backupFile) | Out-Null
                Copy-Item -LiteralPath $dest -Destination $backupFile -Force
                $touched[$rel] = $true
            }
            $text = Get-Content -LiteralPath $dest -Raw -Encoding UTF8
            if ($text.Contains($old)) { $text = $text.Replace($old, $new); [IO.File]::WriteAllText($dest, $text, (New-Object Text.UTF8Encoding($false))) }
            elseif (-not $text.Contains($new)) { throw ("Expected text not found in " + $rel) }
        }
        Set-Content -LiteralPath $VersionPath -Value $target -Encoding ASCII
        Log ("Replacement update applied: " + $target)
        Launch-Litto
        exit 0
    }

    # Mode B: ordinary ZIP patch for larger updates.
    $patchUrl = [string]$manifest.patch_url
    $expectedSha = ([string]$manifest.sha256).Trim().ToLowerInvariant()
    if ([string]::IsNullOrWhiteSpace($patchUrl)) { Log "No patch payload published; launching current LITTO"; Launch-Litto; exit 0 }

    $tempDir = Join-Path $Root ("_LITTO_UPDATE_TEMP\\" + $stamp)
    $extractDir = Join-Path $tempDir "extract"
    $zipPath = Join-Path $tempDir "patch.zip"
    New-Item -ItemType Directory -Force -Path $extractDir | Out-Null
    Invoke-WebRequest -Uri $patchUrl -UseBasicParsing -TimeoutSec 20 -OutFile $zipPath
    if ([string]::IsNullOrWhiteSpace($expectedSha)) { throw "Manifest SHA256 missing" }
    $actualSha = (Get-FileHash -LiteralPath $zipPath -Algorithm SHA256).Hash.ToLowerInvariant()
    if ($actualSha -ne $expectedSha) { throw "Patch SHA256 mismatch" }
    Expand-Archive -LiteralPath $zipPath -DestinationPath $extractDir -Force
    $patchFiles = Get-ChildItem -LiteralPath $extractDir -File -Recurse
    if (-not $patchFiles) { throw "Patch ZIP contains no files" }

    $newFiles = New-Object System.Collections.Generic.List[string]
    foreach ($f in $patchFiles) {
        $rel = $f.FullName.Substring($extractDir.Length).TrimStart('\\')
        if ($rel.Contains("..") -or [IO.Path]::IsPathRooted($rel)) { throw ("Unsafe patch path: " + $rel) }
        $dest = Join-Path $Root $rel
        if (Test-Path -LiteralPath $dest) {
            $backupFile = Join-Path $backupDir $rel
            New-Item -ItemType Directory -Force -Path (Split-Path -Parent $backupFile) | Out-Null
            Copy-Item -LiteralPath $dest -Destination $backupFile -Force
        } else { $newFiles.Add($dest) }
    }
    foreach ($f in $patchFiles) {
        $rel = $f.FullName.Substring($extractDir.Length).TrimStart('\\')
        $dest = Join-Path $Root $rel
        New-Item -ItemType Directory -Force -Path (Split-Path -Parent $dest) | Out-Null
        Copy-Item -LiteralPath $f.FullName -Destination $dest -Force
    }
    Set-Content -LiteralPath $VersionPath -Value $target -Encoding ASCII
    Remove-Item -LiteralPath $tempDir -Recurse -Force -ErrorAction SilentlyContinue
    Log ("ZIP update applied: " + $target)
    Launch-Litto
    exit 0
}
catch {
    Log ("UPDATE FAILED: " + $_.Exception.Message)
    if ($backupDir -and (Test-Path -LiteralPath $backupDir)) {
        foreach ($bf in (Get-ChildItem -LiteralPath $backupDir -File -Recurse)) {
            $rel = $bf.FullName.Substring($backupDir.Length).TrimStart('\\')
            $dest = Join-Path $Root $rel
            New-Item -ItemType Directory -Force -Path (Split-Path -Parent $dest) | Out-Null
            Copy-Item -LiteralPath $bf.FullName -Destination $dest -Force
        }
        Log "Rollback completed"
    }
    Log "Launching current LITTO unchanged"
    Launch-Litto
    exit 0
}
