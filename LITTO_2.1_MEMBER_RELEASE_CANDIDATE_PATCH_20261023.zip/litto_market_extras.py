"""Isolated, best-effort market information: never called by scanner/order workers."""
import csv, re, time, threading
from datetime import datetime
from html.parser import HTMLParser
from urllib.request import Request, urlopen
from pathlib import Path

ROOT = Path(__file__).resolve().parent
_INDEX_LOCK = threading.Lock()
_INDEX_STATE = {}
_FUND_LOCK = threading.Lock()
_FUND_STATE = {'last_check':0, 'busy':False, 'rows':[], 'error':None}

class _Plain(HTMLParser):
    def __init__(self):
        super().__init__(); self.parts=[]
    def handle_data(self,s):
        s=s.strip()
        if s:self.parts.append(s)

def parse_freesis_summary(html):
    """Official FreeSIS homepage highlights; not a substitute for full [0201] history."""
    parser=_Plain(); parser.feed(html)
    txt=' '.join(parser.parts)
    result={}
    for key,label in (('deposit','투자자예탁금'),('credit_balance','신용융자')):
        m=re.search(re.escape(label)+r'\s*(?:백만원)?\s*(?:\|)?\s*(\d{1,2}/\d{1,2})\s*(?:\|)?\s*([\d,]+)',txt)
        if m:
            val=float(m.group(2).replace(',',''))/100  # KOFIA highlights: million KRW to 100M KRW
            result[key]=(m.group(1),val)
    return result

def _fund_worker():
    try:
        req=Request('https://freesis.kofia.or.kr/stat/main.do',headers={'User-Agent':'Mozilla/5.0 (compatible; LITTO/1.0)'})
        with urlopen(req,timeout=6) as resp: html=resp.read(750000).decode('utf-8','replace')
        values=parse_freesis_summary(html)
        if not values: raise ValueError('공식 홈페이지 표지 지표 자동 추출 불가')
        # Two summaries can have different reference dates; never manufacture missing columns.
        keyed={}
        now=datetime.now(); year=now.year
        for k,(month_day,val) in values.items():
            mm,dd=map(int,month_day.split('/'))
            y=year-1 if mm>now.month+1 else year
            date=f'{y:04d}-{mm:02d}-{dd:02d}'
            r=keyed.setdefault(date,{'date':date,'deposit':None,'deposit_change':None,'turnover':None,'unsettled':None,'credit_balance':None})
            r[k]=val
        with _FUND_LOCK:
            _FUND_STATE.update(rows=sorted(keyed.values(),key=lambda x:x['date'],reverse=True),error=None,busy=False)
    except Exception as e:
        with _FUND_LOCK:_FUND_STATE.update(error=str(e),busy=False)

def funds_snapshot():
    f=ROOT/'data'/'market_funds_history.csv'
    if f.is_file():
        try:
            with f.open(encoding='utf-8-sig',newline='') as stream:
                rows=[]
                for x in csv.DictReader(stream):
                    date=str(x.get('date','')).strip()
                    if not re.fullmatch(r'\d{4}-\d{2}-\d{2}',date):continue
                    row={'date':date}
                    for field in ('deposit','deposit_change','turnover','unsettled','credit_balance'):
                        raw=str(x.get(field,'')).replace(',','').strip()
                        try: row[field]=float(raw) if raw else None
                        except ValueError: row[field]=None
                    rows.append(row)
            if rows:
                rows.sort(key=lambda x:x['date'],reverse=True)
                return dict(ok=True,rows=rows[:120],source='사용자 제공 통계 CSV',as_of=rows[0]['date'],message=None)
        except (OSError,UnicodeError,csv.Error) as e:
            return dict(ok=False,rows=[],message='CSV 읽기 실패: '+str(e))
    now=time.monotonic()
    with _FUND_LOCK:
        if not _FUND_STATE['busy'] and now-_FUND_STATE['last_check']>21600:
            _FUND_STATE.update(busy=True,last_check=now)
            threading.Thread(target=_fund_worker,name='litto-funds-readonly',daemon=True).start()
        rows=list(_FUND_STATE['rows']);busy=_FUND_STATE['busy'];error=_FUND_STATE['error']
    return dict(ok=True,rows=rows,source='금융투자협회 FreeSIS 공식 홈페이지 공개 요약',as_of=rows[0]['date'] if rows else None,loading=busy,partial=True,
        message=('금융투자협회 공식 요약 조회 중' if busy else '일별 전체 표 자동 연동 전: 예탁금·신용융자 공개 요약만 제공') if not error else '공식 공개 데이터 수신 실패: '+error)

def _index_worker(client,key,mode):
    inds={'kospi':'001','kosdaq':'101'}[key]
    isday=mode=='daily'
    try:
        client.auth()
        now=datetime.now()
        api='ka20006' if isday else 'ka20005'
        body={'inds_cd':inds,'base_dt':now.strftime('%Y%m%d')}
        if not isday:body['tic_scope']='1'
        field='inds_dt_pole_qry' if isday else 'inds_min_pole_qry'
        raw=client.rows(api,body,field,260 if isday else 240,max_pages=6 if isday else 2)
        points=[]
        for x in reversed(raw):
            t=str(x.get('dt' if isday else 'cntr_tm') or '')
            if not re.fullmatch(r'\d{8}' if isday else r'\d{14}',t):continue
            def val(field):
                try:return abs(float(str(x.get(field,'')).replace(',','').replace('+','')))
                except (TypeError,ValueError):return None
            close=val('cur_prc')
            if close is None:continue
            points.append(dict(time=t,close=close/100 if isday else close,open=(val('open_pric')/100 if isday and val('open_pric') is not None else val('open_pric')),high=(val('high_pric')/100 if isday and val('high_pric') is not None else val('high_pric')),low=(val('low_pric')/100 if isday and val('low_pric') is not None else val('low_pric')),volume=val('trde_qty')))
        with _INDEX_LOCK:_INDEX_STATE[(key,mode)]={'points':points,'updated_at':datetime.now().isoformat(),'error':None if len(points)>=2 else '키움 조회 결과에 유효한 지수 봉이 부족합니다.','busy':False,'ts':time.monotonic()}
    except Exception as e:
        with _INDEX_LOCK:
            old=_INDEX_STATE.get((key,mode),{})
            _INDEX_STATE[(key,mode)]={**old,'error':str(e),'busy':False,'ts':time.monotonic()}

def index_snapshot(client,key,mode,overview=None):
    if key not in ('kospi','kosdaq') or mode not in ('minute','daily'):
        return dict(ok=False,error='시장 또는 차트 구분 오류')
    old=((overview or {}).get('markets') or {}).get(key) or {}
    cached=old.get('daily_chart' if mode=='daily' else 'chart') or []
    if len(cached)>=(250 if mode=='daily' else 2) and (mode!='daily' or all(p.get('open') is not None and p.get('high') is not None and p.get('low') is not None for p in cached)):
        return dict(ok=True,points=cached,source='라이또 기존 지수 캐시',updated_at=(overview or {}).get('updated_at'),loading=False)
    if not client:return dict(ok=False,points=[],error='키움 연결 상태를 확인하세요.',loading=False)
    with _INDEX_LOCK:
        state=_INDEX_STATE.get((key,mode),{})
        now=time.monotonic()
        should_retry=not state.get('busy') and (not state.get('ts') or now-state['ts']>90)
        if should_retry:
            _INDEX_STATE[(key,mode)]={**state,'busy':True}
            threading.Thread(target=_index_worker,args=(client,key,mode),name='litto-index-chart-'+key+'-'+mode,daemon=True).start()
            state=_INDEX_STATE[(key,mode)]
        points=state.get('points') or []
        return dict(ok=bool(points),points=points,source='키움 업종봉 전용 조회',updated_at=state.get('updated_at'),loading=bool(state.get('busy')),error=state.get('error'))
